//angular.module( window.AppName ).controller('UsersCtrl', function($scope, $http, ngDialog, $compile, $state, usersServices){
var UsersCtrl = function($scope, $http, ngDialog, $compile, $state, usersServices){

    $scope.colours = [{
        name: "Red",
        hex: "#F21B1B"
    }, {
        name: "Blue",
        hex: "#1B66F2"
    }, {
        name: "Green",
        hex: "#07BA16"
    }];
    $scope.colour = "";

    $scope.toggleTab = function() {
      $scope.tab = !$scope.tab;
    }

    $scope.displayFirstTab = function() {
        if( $scope.tab == true ) {
          return "vz-show";
      } else {
          return "vz-hide";
      }
    }

    $scope.displaySecondTab = function() {
      if( $scope.tab != true ) {
          return "vz-show";
      } else {
          return "vz-hide";
      }
    }

    $scope.activateFirstTab = function( index ) {
      if( $scope.tab == true ) {
          return "selected";
      } else {
          return "";
      }
    }

    $scope.activateSecondTab = function( index ) {
      if( $scope.tab == false ) {
          return "selected";
      } else {
          return "";
      }
    }

    function getUsers() {
        $scope.type = "code";
        $scope.vzGridTpl = "partials/users/vz-grid/vz.grid.users.html";
        getData();
    }

    function getData() {
        usersServices.getData()
            .success(function (result) {
                $scope.collection = result.data.rows;
            })
            .error(function (error) {
                $scope.status = 'Unable to load customer data: ' + error.message;
            });
    }

    function init() {

        //Initialize Variables
        $scope.collection = {};

        //Load the line information
        getUsers();

        $scope.vzGridCodeSearchTpl = "partials/users/vz-grid/vz.grid.users.search.html";

        $scope.lineDeviceFilterOptions = {
            availableOptions : [
                                {"id":"0","name":"All"}
                             ],
                selectedOption: {id:"0", name:"All"}
        };


    }

    init();

};

UsersCtrl.$inject = ["$scope", "$http", "ngDialog", "$compile", "$state", "usersServices"];
angular.module( window.AppName ).controller("UsersCtrl", UsersCtrl);