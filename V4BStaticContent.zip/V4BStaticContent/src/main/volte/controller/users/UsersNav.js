var UsersNav = function($scope, $http, $state, $stateParams, $state) {

	$scope.viewOptions = ["All","Disabled","Request Approval"];

};

UsersNav.$inject = ["$scope", "$http", "$state", "$stateParams", "$state"];
angular.module( window.AppName ).controller("UsersNav", UsersNav);