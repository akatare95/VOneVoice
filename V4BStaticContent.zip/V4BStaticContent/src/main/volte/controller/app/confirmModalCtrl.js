/*
*   confirmCtrl - Confirmation modal
*
*
*/
var confirmModalCtrl = function($scope, $state, $stateParams, $rootScope) {

    $scope.cancel = function() {
      $rootScope.displayNetworkErrorFlag = false;
      $rootScope.confirmModal.close();
      return false;
    }


    $scope.proceed = function() {
      //console.log("rr - ", $rootScope.toState);
      $rootScope.vzSubmitBtnStatus = false;
      $rootScope.confirmModal.close();
      $state.go( $rootScope.toState.name );
    }

};

confirmModalCtrl.$inject = ["$scope", "$state", "$stateParams", "$rootScope"];
angular.module( window.AppName ).controller("confirmModalCtrl", confirmModalCtrl);