/*
*   volteCtrl - This controller takes care of authorization and decides which page needs to be redirected.
*               A strict routing mechanism has been implemented in app.js which enforces the page to be displayed based on authorization
*
*/
var volteCtrl = function($http, ngDialog, $state, $rootScope, $window, Constants, $scope, Idle){

    /*
    *  Initiate the life cycle of the variables.
    *
    */
    function declareVariables() {

        //Statuses
        INITIAL = 'I';
        PENDING = 'P';
        ACTIVE = 'A';
        NO = 'N';
        E = 'E';

        //Roles
        SPOC = 'S';
        ADMIN = 'A';

        //Navigation
        ONBOARD = 'onboard';
        OVERVIEW = 'overview';

    }

    /*
    *  Load the user profiles from ECPD system
    *
    */
    function initiateAuthorization(args) {

        //var userProfile = Constants.API_HOST + Constants.API.ONBOARD_PAGE.PROFILE;
        //console.log(user)
        // $http.post( userProfile, {} ).success(function( result ) {
          console.log("**************args")
          authorize($rootScope, args, $state);

        // });

    }


    /*
    *  Implement authorization
    *
    */
    function authorize($rootScope, result, $state) {

        /*
        * Fetch the contents that can be used across the applications
        */
        $rootScope.userProfileIdList       = result.appResult.serviceRepsonse.service.serviceHeader;
        $rootScope.userProfile      = result.appResult.serviceRepsonse.service.serviceBody.serviceResponse;
        $rootScope.userProfile.role = result.appResult.ur;
        $rootScope.accessibility    = result.appResult.accessibilityMatrix;

        //console.log("User Profile - ", $rootScope.userProfile);
        /*$rootScope.userProfile.role = 'S';
        $rootScope.userProfile.v4BElegibleInd = 'Y';
        $rootScope.userProfile.v4BProvisioningStatus = 'I';*/

        var redirectionLink = '';
        var eligibility = $rootScope.userProfile.v4BElegibleInd;
        var role = $rootScope.userProfile.role;
        var v4BID = $rootScope.userProfile.v4BID;

        if( eligibility )
          eligibility = eligibility.toUpperCase();

        if( role )
          role = role.toUpperCase();


        if( eligibility != NO ) {

          $rootScope.userProfile.showFeatures = true;

          switch( $rootScope.userProfile.v4BProvisioningStatus ) {

            case INITIAL:
            case PENDING:
            case NO:
            case E:

              $rootScope.userProfile.showFeatures = true;
              redirectionLink = ONBOARD;
              break;

            case ACTIVE:

              if( (role != ADMIN && role != SPOC) || (v4BID == null || v4BID.length == 0) ) {

                 redirectionLink = ONBOARD;

              } else {

                if( !window.location.hash.length || window.location.hash.indexOf( 'onboard' ) > -1 ) {

                  redirectionLink = OVERVIEW;

                }

              }
              break;

            default:
              redirectionLink = ONBOARD;
              break;
          }

        }  else {
          redirectionLink = ONBOARD;
        }

        if( redirectionLink ) {
          $state.go( redirectionLink, {}, { reload: true });
        }
    }

    $scope.$on('IdleStart', function() {
      //console.log('Idle Start');
      sessionWarningDialog();
    });

    /*$rootScope.$on('IdleEnd', function() {
       //console.log('Idle End');
       //alert("Idle End");
    });*/

    $scope.$on('IdleTimeout', function() {
      //alert('Redirecting to logout....')
       //console.log('Idle Timeout');
       //alert('Idle Timeout');
       //exit();
       logoutSession();
    });

    var sessionWarningDialog = function() {
      //console.log('dialog opened');
      ngDialog.closeAll();
      var new_dialog = ngDialog.open({ template: 'partials/components/dialog/timeoutWarning.html',
        closeByDocument: false,
        closeByEscape: false,
        showClose: false
      });
    }

    $scope.continueSession = function() {
      ngDialog.closeAll();
      keepAlive();
      Idle.watch();
    }

    var keepAlive = function() {
      $http.get(Constants.API_HOST+Constants.API.SESSION.KEEP_ALIVE);
    }

    var logoutSession = function() {
      //console.log('Session Logout');
      ngDialog.closeAll();
      if(typeof window.volte != "undefined") {
        window.volte.app.exit();
      }
    }

    $scope.Math = window.Math;

    $scope.gotoEPAMLink = function( feature ) {

      //window.location.href = $scope.EPAMLink;

      // Redirect with back URL
      var currentUrlPath = window.location.href;
      var redirectUrlPath = $scope.EPAMLink;
      window.location.href = redirectUrlWithReturnURL(redirectUrlPath, currentUrlPath, Constants.API.REDIRECT_URL_PATHS.split_At);

    }


    /*
    *  Initiate the functionalities
    *
    */
    function init() {

      if (typeof $rootScope.userProfile == 'undefined') {
        declareVariables();
      }

    }
    $scope.$on('userProfileAppResult', function (event, args) {
              init();
              initiateAuthorization(args);
             // $scope.$broadcast('refreshevents');
    });
    //init();

};

volteCtrl.$inject = ["$http", "ngDialog", "$state", "$rootScope", "$window", "Constants","$scope","Idle"];
angular.module( window.AppName ).controller("volteCtrl", volteCtrl);
