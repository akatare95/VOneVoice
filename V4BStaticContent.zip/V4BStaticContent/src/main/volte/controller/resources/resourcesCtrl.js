var ResourcesCtrl = function($scope,$state) {

	$scope.faqLink = function() {
		window.open('http://www.verizonwireless.com/businessportals/support/faqs/FeaturesandOptionalServices/one-talk.html');
	};

	$scope.getStartedLink = function() {
		window.open('http://www.verizonwireless.com/businessportals/support/faqs/FeaturesandOptionalServices/one-talk.html#g1');
	};

	$scope.costAnalysisLink = function() {
		window.open('http://www.verizonwireless.com/');
	};

	$scope.howToVideoLink = function() {
		window.open('http://www.verizonwireless.com/support/one-talk-assembly-video');
	};

	$scope.contactUsLink = function() {
		window.open('http://www.verizonwireless.com/b2c/businessSolutions/contactUs.jsp');
	};

	$scope.termsLink = function() {
		window.open('http://verizonwireless.com/support/one-talk-from-verizon-business-legal');
	};

};

ResourcesCtrl.$inject = ["$scope","$state"];
angular.module( window.AppName ).controller("ResourcesCtrl", ResourcesCtrl);