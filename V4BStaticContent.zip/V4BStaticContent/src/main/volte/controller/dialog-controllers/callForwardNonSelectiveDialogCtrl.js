(function() {
    var callForwardNonSelectiveDialogCtrl = function($scope, volteServices, ngDialog, remoteCallPickupBargeInConst, Constants) {
       $scope.submitSettingsForwarding = function(dialogInfo) {
        var activeFlagVal;
        console.log($scope.row.settingsInfo.active);
        var param = { "updateFeatures": { "updateFeature": [] }};
            if($scope.row!=undefined && $scope.row.settingsInfo!=undefined){
                activeFlagVal = $scope.row.settingsInfo.active;
            }else{
                activeFlagVal = false;
            }
            var voiceMailSettingsVal;
            if($scope.row!=undefined && $scope.row.voiceMailSettings!=undefined){
                voiceMailSettingsVal = $scope.row.voiceMailSettings;
            }else{
                voiceMailSettingsVal = false;
            }

            param.updateFeatures.updateFeature.push({
                "updateType": "STATUS",
                "phoneNo":$scope.row.phoneNo,
                "userName":$scope.row.userName,
                "settingsInfo":{
                    "active":activeFlagVal.toString(),
                    "voiceMailSettings": {
                        "active": voiceMailSettingsVal
                    }
                }
            });

        if ($scope.row.forwardToPhoneNumber != undefined && $scope.row.forwardToPhoneNumber != "") {
                param.updateFeatures.updateFeature[0].settingsInfo.forwardToPhoneNumber = $scope.row.forwardToPhoneNumber;
            }

            // if(dialogInfo != undefined){
            // if (dialogInfo.forwardToPhoneNumber != undefined && dialogInfo.forwardToPhoneNumber != "") {
            //     param.updateFeatures.updateFeature[0].settingsInfo.forwardToPhoneNumber = dialogInfo.forwardToPhoneNumber;
            // }
            // if (dialogInfo.settingsInfo.numberOfRings != undefined && dialogInfo.settingsInfo.numberOfRings != "") {
            //     param.updateFeatures.updateFeature[0].settingsInfo.numberOfRings = dialogInfo.settingsInfo.numberOfRings;
            // }
            // }else{
            //  param.updateFeatures.updateFeature[0].settingsInfo.forwardToPhoneNumber ="";
            //  param.updateFeatures.updateFeature[0].settingsInfo.numberOfRings = "0";
            // }
        console.log(param)
        volteServices.setOption( Constants.API.CALL_FORWARDING[$scope.tabSelected.toUpperCase()].POST );
        volteServices.postData(param).success(function(response) {
            if(response.appHeader.statusCode == "OK") {
                $scope.row.isSubmitClicked=true;
                console.log($scope.row);
                 // for(var i=0;i<arrCollection.length;i++)
                 // {
                 //      arrCollection[i].criteriaName='Option'+i;
                 // }
                console.log($scope.row.settingsInfo.active);
                $scope.row.settingsInfo.forwardToPhoneNumber=$scope.row.forwardToPhoneNumber;
                $scope.row.settingsInfo.voiceMailSettings=param.updateFeatures.updateFeature[0].settingsInfo.voiceMailSettings;
                $scope.$parent.msgType = "success";
                $scope.$parent.msgTxt = 'Successfully Updated';
                $scope.$parent.showMsg = true;
                $scope.closeDialog();
            } else {
                if($scope.gearType===true)
                {

                    $scope.row.settingsInfo.active = false;
                }
                $scope.$parent.msgType = "error";
                if(response.appHeader != undefined)
                $scope.$parent.msgTxt = response.appHeader.statusMessage;
                else
                    $scope.$parent.msgTxt = 'updation failed';
                $scope.$parent.showMsg = true;
                $scope.closeDialog();
            }
        }).error(function() {});
    }
        function initData() {
            $scope.row = $scope.ngDialogData.row;
            $scope.$parent.showMsg=false;
            console.log('callForwardNonSelectiveDialogCtrl');
            $scope.settings = remoteCallPickupBargeInConst.pageTitle;
            $scope.gearType = $scope.ngDialogData.gearType;
            $scope.tabSelected = $scope.ngDialogData.tabSelected;
            $scope.row.forwardToPhoneNumber=$scope.row.settingsInfo.forwardToPhoneNumber;
            if(!!$scope.row.settingsInfo && !!$scope.row.settingsInfo.voiceMailSettings.active){
              console.log($scope.row.settingsInfo.voiceMailSettings.active=='true');
              $scope.row.voiceMailSettings = $scope.row.settingsInfo.voiceMailSettings.active;
            }
            else{
                console.log('inside elese');
                $scope.row.voiceMailSettings='false';
            }
            if ($scope.row.settingsInfo.forwardToPhoneNumber==undefined)
                $scope.row.settingsInfo.forwardToPhoneNumber = '';
        }
        initData();
    };

    callForwardNonSelectiveDialogCtrl.$inject = ['$scope', 'volteServices', 'ngDialog', 'remoteCallPickupBargeInConst', 'Constants'];

    angular.module(window.AppName).controller('callForwardNonSelectiveDialogCtrl', callForwardNonSelectiveDialogCtrl);
})();