(function() {
    var directedCallPickUpDialogCtrl = function($scope, volteServices, ngDialog, remoteCallPickupBargeInConst, Constants) {
        console.log(ngDialog);
        console.log($scope);
        $scope.submitPickupData = function(row) {
            console.log(row);
            params = {
                "updateFeatures": {
                    "updateFeature": [{
                        "phoneNo": row.phoneNo,
                        "updateType": "Status",
                        "settingsInfo": {
                            "active": row.settingsInfo.active.toString(),
                            "enableBargeInWarningTone": (!!$scope.enable.BargeInWarningTone).toString(),
                            "enableAutomaticTargetSelection": (!!$scope.enable.AutomaticTargetSelection).toString()
                        }
                    }]
                }
            };
            volteServices.setOption(API.POST);
            volteServices.postData(params)
                .success(function(result) {
                    if (result.appHeader.statusCode == "OK") {
                        $scope.row.isSubmitClicked = true;
                        updateCollection();
                        $scope.$parent.msgType = "success";
                        $scope.$parent.msgTxt = "Updated Successfully";
                        $scope.$parent.showMsg = true;
                        console.log($scope.row)
                        $scope.closeDialog();
                    } else {
                        // if ($scope.gearType) {
                        //     $scope.collection[$scope.rowIndex].settingsInfo.active = false;
                        // }
                        $scope.$parent.msgType = "error";
                        $scope.$parent.msgTxt = result.appHeader.statusMessage;
                        $scope.$parent.showMsg = true;
                        $scope.closeDialog();
                        // $scope.msgType = "error";
                        // $scope.msgTxt = result.appHeader.statusMessage;
                        // $scope.showMsg = true;
                    }
                })
                .error(function() {
                    //console.log('error');
                    //scope.toggleSbtBtnStatus = false;
                });
        };

        function updateCollection() {
            $scope.row.settingsInfo.enableAutomaticTargetSelection = $scope.enable.AutomaticTargetSelection.toString();
             $scope.row.settingsInfo.enableBargeInWarningTone=$scope.enable.BargeInWarningTone.toString();
        }
        function initData() {
            API = Constants.API.DIRECTED_CALL_PICKUP;
            $scope.row = $scope.ngDialogData.row;
            $scope.settings = remoteCallPickupBargeInConst.pageTitle;
            console.log($scope.row);
            //$scope.checkActive=false;
            $scope.gearType = $scope.ngDialogData.gearType;
            $scope.rowIndex = $scope.ngDialogData.rowIndex;
            console.log($scope.rowIndex);
            $scope.enable = {};
            var settingsInfo = $scope.row.settingsInfo;
            console.log('21323'+settingsInfo.enableBargeInWarningTone === 'true');
            $scope.enable.BargeInWarningTone = settingsInfo.enableBargeInWarningTone === 'true';
            $scope.enable.AutomaticTargetSelection = settingsInfo.enableAutomaticTargetSelection === 'true';
            console.log($scope.enable.BargeInWarningTone, $scope.enable.AutomaticTargetSelection);
        }
        initData();
    };

    directedCallPickUpDialogCtrl.$inject = ['$scope', 'volteServices', 'ngDialog', 'remoteCallPickupBargeInConst', 'Constants'];

    angular.module(window.AppName).controller('directedCallPickUpDialogCtrl', directedCallPickUpDialogCtrl);
})();