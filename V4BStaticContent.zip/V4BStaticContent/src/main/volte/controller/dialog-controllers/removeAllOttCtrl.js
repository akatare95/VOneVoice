var removeAllOttCtrl = function ($scope,dropdownValueConst,linesService) {
   //var 'REMOVEALLOTT'=$scope.ottType.toUpperCase();
   $scope.EPAMLink=window.EPAMLink;
   $scope.remove=function(){
      var submitParams=$scope.removeAllOttList;
      linesService.removeAllOtt(submitParams).
        then(function (result) {
          console.log(result);
          $scope.confirmationNumber=result.transactionId;
          //$scope.confirmationNumber = result.transactionId;
          $scope.thankuTxtDrop=dropdownValueConst['REMOVEALLOTT'][0].thankuTxt;
          $scope.msgTxtDrop=dropdownValueConst['REMOVEALLOTT'][0].pageSuccessTxt;
          $scope.msgTypeDrop='success';
          $scope.$parent.showMsg = false;
          confirmationOtt();
          //$scope.$parent.ottCalling=$scope.$parent.ottCalling == 'Unblocked' ? 'Blocked' : 'Unblocked';
          // $scope.$parent.selectedAction='';
        },
        function(reason){
          console.log(reason);
          //console.log($scope.ottCalling);
          $scope.thankuTxtDrop=reason;
          $scope.msgTxtDrop='';
          $scope.msgTypeDrop='error';
          $scope.$parent.showMsg = false;
          confirmationOtt();
          //console.log(reason);
          // $scope.$parent.selectedAction='';
        });
   };
   function confirmationOtt(){
      $scope.confirmation=true;
      $scope.showWarning=false;
      $scope.showMsgDrop=true;
   }
   function warningOtt(){
      $scope.confirmation=false;
      $scope.showWarning=true;
      $scope.showMsgDrop=true;
   }
   function initOtt(){
      warningOtt();
      $scope.hideLines=true;
      $scope.msgTypeDrop='error';
      console.log($scope.ottType);
      $scope.alertMsg=dropdownValueConst['REMOVEALLOTT'][0].pageAlertTxt;
      $scope.msgTxtDrop=dropdownValueConst['REMOVEALLOTT'][0].pageConfirmationTxt;
   }
   initOtt();
 };
    removeAllOttCtrl.$inject = ['$scope', 'dropdownValueConst', 'linesService'];

    angular.module(window.AppName).controller('removeAllOttCtrl', removeAllOttCtrl);
