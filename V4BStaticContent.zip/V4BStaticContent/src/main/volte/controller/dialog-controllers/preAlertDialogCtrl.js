(function() {
    var preAlertDialogCtrl = function($scope, volteServices, Constants, $rootScope, preAlertingAnnouncementConst) {
        function success(msgTxt){
          $scope.$parent.msgType = "success";
          $scope.$parent.msgTxt = msgTxt || "Sucessfully Updated";
          $scope.$parent.showMsg = true;
        }
        function error(msgTxt){
            console.log($scope.$parent)
          $scope.$parent.msgType = "error";
          $scope.$parent.msgTxt = msgTxt || 'Error performing Operation';
          $scope.$parent.showMsg = true;
        }
        function uploadError(evt) {

            /*$scope.$apply(function(){
                $rootScope.ajaxLoading = false;
                error( "Upload Failed!" );
            });*/
        }
        function uploadCanceled(evt) {

            var result = JSON.parse( evt.target.response );

            $scope.$apply(function(){
                $rootScope.ajaxLoading = false;
                var msg = "Unable to process request";
                error( msg );
            })
        }

        $scope.onUpload = function(event) {
            event.preventDefault();
            //$scope.callingPlanFrm.$pristine=true;
            console.log(document.getElementById('fileToUploadUser'));
            document.getElementById('fileToUploadUser').click();
        }
        $scope.play = function($event) {
            document.getElementById('audio_player').play();
            $scope.isStreaming = true;
        }

        $scope.pause = function() {
            document.getElementById('audio_player').pause();
            $scope.isStreaming = false;
        }
        $scope.setFiles = function(element) {
            var doSetFiles = function () {
                if (element.files[0].size / 1024 <= Constants.MAX_FILE_SIZE.PRE_ALERTING) {
                    // Turn the FileList object into an Array
                    $scope.files = [];
                    for (var i = 0; i < element.files.length; i++) {
                        $scope.files.push(element.files[i]);
                        $scope.theFile.name = element.files[i].name;
                        console.log($scope.theFile);
                        console.log ('name is' , $scope.theFile.name.split('.').pop()) ;
                    }

                    $scope.callingPlanFrm.$pristine = false;
                    $scope.isValid = true;
                    // $scope.musicForm.$pristine = false;
                    $scope.src = URL.createObjectURL(element.files[0]);
                    //console.log($scope.src);
                    $scope.showdialogMsg = false;
                } else {
                    $scope.msgdialogType = "error";
                    $scope.msgdialogTxt = "Please choose a file less than 2 MB.";
                    $scope.showdialogMsg = true;
                }
            };

            //console.log('its wrkingkkdlsdf');
            //This helps in preventing from redirction
            var fileStr = element.files[0].type.split("/");
            if (fileStr[fileStr.length - 1].search("wav") !== -1 || fileStr[fileStr.length - 1].search("wma") !== -1) {
                if ($scope.$$phase) {
                    doSetFiles();
                } else {
                    $scope.$apply(function() {
                        doSetFiles();
                    });
                }
            } else {
                $scope.$apply(function($scope) {

                    $scope.msgdialogType = "error";
                    $scope.msgdialogTxt = "Please choose a file with WAV or WMA extension only";
                    $scope.showdialogMsg = true;
                    $scope.callingPlanFrm.$pristine = true;
                    $scope.theFile.name = null;

                    //console.log($scope.showMsg);

                });
            }
        };

        function uploadProgress(evt) {
            $scope.$apply(function() {

                //Close the dialog loader
                $rootScope.ajaxLoading = false;
                try {
                    var xhrSatus = parseInt(evt.target.status);
                    if (xhrSatus == 200 || xhrSatus == 302) {
                        var result = JSON.parse(evt.target.response);
                        if (result.appHeader.statusCode == "OK" || result.appResult.serviceRepsonse.errorCode == "0" || result.appResult.serviceRepsonse.errorCode == "00") {
                            success();
                            $scope.row.isSubmitClicked=true;
                            //console.log($scope.collection[$scope.selectedIndex],$scope.DialogChangedVal.updateFeatures.updateFeature[0].settingsInfo);
                            var updateFeatures = $scope.DialogChangedVal.updateFeatures.updateFeature[0];
                            $scope.row.settingsInfo = updateFeatures.settingsInfo;
                            $scope.row.settingsInfo.active = updateFeatures.settingsInfo.active === "true";
                            $scope.row.criteriaInfo = updateFeatures.criteriaInfo;
                            console.log(result);
                            $scope.closeThisDialog();
                            //console.log($scope.collection[$scope.selectedIndex]);
                            //Keep the submit button in disabled mode
                            //$scope.autoAttendantForm.$pristine = true;

                        } else {

                            //Incase if service is down then display the error message
                            console.log('inside error');
                            var msg = (typeof(result.appResult.serviceRepsonse.message) != '') ? result.appResult.serviceRepsonse.message : "Upload Failed";
                            // error( msg );
                            console.log($scope.gearType)
                            if ($scope.gearType) {
                                // $scope.$apply(function(){
                                   $scope.row.settingsInfo.active = false;
                                // });
                            }
                            $scope.$parent.msgType = "error";
                            $scope.$parent.msgTxt = result.appHeader.statusMessage || 'Error performing Operation';
                            $scope.$parent.showMsg = true;
                            $scope.closeDialog();

                            //Enable the submit button
                            //$scope.autoAttendantForm.$pristine = false;

                        }

                    } else {

                        //Incase if any error occured like 404 or 500 then display the error message

                        error("Upload Failed!");
                        // error( "Upload Failed!" );

                    }

                } catch (err) {
                    console.log("Error -  ", err);
                }
            });
        }

        function modifyWithFile(param) {
            $scope.DialogChangedVal = param;
            console.log($scope.DialogChangedVal);
            console.log($scope.collection[$scope.selectedIndex]);
            var API = Constants.API.PRE_ALERT_ANNOUNCEMENT;
            var fd = new FormData();
            var restructureJSON = JSON.stringify(param);
            fd.append("modifyPreAlertRequest", encodeURIComponent(restructureJSON));
            fd.append("multiPartPreAlertFile", $scope.files[0]);
            $rootScope.ajaxLoading = true;
            var xhr = new XMLHttpRequest();
            xhr.addEventListener("load", angular.bind(null, uploadProgress), false)
            window.addEventListener('error', angular.bind(null, uploadError), true);
            xhr.addEventListener("abort", angular.bind(null, uploadCanceled), false);
            xhr.open("POST", Constants.API_HOST + Constants.API.PRE_ALERT_ANNOUNCEMENT.POSTFILE);
            $scope.progressVisible = true;
            xhr.setRequestHeader("X-XSRF-TOKEN", _.last(String(document.cookie.match(/XSRF-Token=([^\s;]*);/gi)).split(';')[0].split('=')));
            xhr.send(fd);
        }
        $scope.updateData = function(row, tpl, settings) {
            console.log($scope);
            $scope.checkActive = true;
            var audioSelection = "Default";
            console.log(angular.element(document.getElementsByClassName('red-button')))
            var params = {
                "updateFeatures": {
                    "updateFeature": [{
                        "phoneNo": $scope.row.phoneNo,
                        "updateType": "Both",
                        "settingsInfo": {
                            "active": $scope.row.settingsInfo.active.toString()
                        },
                        "criteriaInfo": [{
                            "criteriaName": 'option1'
                        }]
                    }]
                }
            };
            if (!$scope.tpl.msgSelection) {
                /**
                 * When Always is selcted and criteriaInfo is previously not defined then  dont send timeSchedule and holiday schedule parameters
                 */
                if ($scope.row.criteriaInfo && $scope.row.criteriaInfo[0].timeSchedule && $scope.row.criteriaInfo[0].holidaySchedule) {
                    params.updateFeatures.updateFeature[0].criteriaInfo[0].timeSchedule = '';
                    params.updateFeatures.updateFeature[0].criteriaInfo[0].holidaySchedule = '';
                    params.updateFeatures.updateFeature[0].criteriaInfo[0].criteriaName = !$scope.row.criteriaInfo[0].criteriaName ? 'option1' : $scope.row.criteriaInfo[0].criteriaName;
                    params.updateFeatures.updateFeature[0].criteriaInfo[0].fromDnCriteria = $scope.row.criteriaInfo[0].fromDnCriteria;
                }
            } else {
                if (!!$scope.row.biz_schedule_selected && !!$scope.row.holiday_schedule_selected) {
                    params.updateFeatures.updateFeature[0].criteriaInfo[0].timeSchedule = $scope.row.biz_schedule_selected;
                    params.updateFeatures.updateFeature[0].criteriaInfo[0].holidaySchedule = $scope.row.holiday_schedule_selected;
                }
                if ($scope.row.criteriaInfo) {
                    params.updateFeatures.updateFeature[0].criteriaInfo[0].criteriaName = $scope.row.criteriaInfo[0].criteriaName;
                    params.updateFeatures.updateFeature[0].criteriaInfo[0].fromDnCriteria = $scope.row.criteriaInfo[0].fromDnCriteria;
                }
            };
            var res = !!$scope.theFile.name?$scope.theFile.name.split('.'):[];

        //    var extn = $scope.theFile.name.split('.').pop() ;

          //  console.log (extn) ;



            console.log(res[0],$scope.files ) ;
            console.log(res[1],$scope.files ) ;
           // console.log(res[0] ,res[1],$scope.files ) ;




            if (!$scope.tpl.isSystemDefault && !!res[0] && !!res[1]) {
                if($scope.files.length)
                {
                        params.updateFeatures.updateFeature[0].settingsInfo.audioFileDescription = $scope.theFile.name.substr(0,$scope.theFile.name.lastIndexOf("."));
                        params.updateFeatures.updateFeature[0].settingsInfo.audioMediaType = $scope.theFile.name.split('.').pop().toUpperCase();
                }
                params.updateFeatures.updateFeature[0].settingsInfo.audioSelection = 'File';
                if($scope.files.length>=1)
                {
                   modifyWithFile(params);
                   return;
                }
            }
            else
            {
               params.updateFeatures.updateFeature[0].settingsInfo.audioSelection = "Default";
            }



            console.log(params);
            var option = Constants.API.PRE_ALERT_ANNOUNCEMENT.POST;
            volteServices.setOption(option);
            volteServices.postData(params).success(function(response) {
                if (response.appHeader.statusCode == "OK") {
                    var updateFeatures = params.updateFeatures.updateFeature[0];
                    $scope.row.settingsInfo = updateFeatures.settingsInfo;
                    $scope.row.settingsInfo.active = updateFeatures.settingsInfo.active === "true";
                    $scope.row.criteriaInfo = updateFeatures.criteriaInfo;
                    $scope.row.isSubmitClicked=true;
                    success();
                    $scope.closeThisDialog();
                } else {
                    // $scope.$apply(function() {
                    if ($scope.gearType) {
                        $scope.row.settingsInfo.active = false;
                    }
                    error(response.appHeader.statusMessage);
                    $scope.closeThisDialog();
                }
            }).error(function() {});

        };


        function updatePredefinedSchedule() {
            if (!!$scope.row.scheduleInfo) {
                var scheduleList = $scope.row.scheduleInfo;
                var bzList = [];
                var hoList = [];
                angular.forEach(scheduleList, function(value, key) {
                    if (value.scheduleType == 'HOLIDAY') {
                        hoList.push({
                            'name': value.scheduleName,
                            'value': value.scheduleName
                        });
                    } else {
                        bzList.push({
                            'name': value.scheduleName,
                            'value': value.scheduleName
                        });
                    }
                });
                $scope.biz_schedule = bzList;
                $scope.holiday_schedule = hoList;
            } else {
                $scope.biz_schedule = [];
                $scope.holiday_schedule = [];
            }
        }

        function initData() {
            console.log('its working!!!!!')


            $scope.dialogTitle = preAlertingAnnouncementConst.pageTitle;
            $scope.row = $scope.ngDialogData.row;
            console.log($scope.row);
            //var settingsInfo = row.settingsInfo;
            $scope.tpl = {};
            $scope.isSystemDefault = $scope.row.settingsInfo.audioSelection;

            $scope.checkActive = false;
            $scope.gearType = $scope.ngDialogData.gearType;
            console.log($scope.gearType);
            // $scope.tpl.isSystemDefault=true;
            // $scope.tpl.msgSelection=false;
            $scope.files = [];
            $scope.theFile = {
                'name': null
            };
            $scope.showdialogMsg = false;
            $scope.src = null;
            if(!!$scope.row.settingsInfo.audioSelection && $scope.row.settingsInfo.audioSelection=='File')
            {
                $scope.tpl.isSystemDefault= false;
                $scope.isValid = true;
                // $scope.theFile.name = $scope.row.settingsInfo.audioFileDescription + '.' + $scope.row.settingsInfo.audioMediaType;
            }
            else
            {
                $scope.tpl.isSystemDefault= true;
            }
            if($scope.row.settingsInfo.audioFileDescription && $scope.row.settingsInfo.audioMediaType)
            {
               $scope.theFile.name = $scope.row.settingsInfo.audioFileDescription + '.' + $scope.row.settingsInfo.audioMediaType;
            }
            // if (!!$scope.row.settingsInfo.audioFileDescription) {
            //     $scope.isValid = true;
            //     $scope.theFile.name = $scope.row.settingsInfo.audioFileDescription + '.' + $scope.row.settingsInfo.audioMediaType;
            // }
            // $scope.tpl.isSystemDefault = $scope.row.settingsInfo.audioSelection === 'Default' ? true : false;
            if (!!$scope.row.criteriaInfo && !!$scope.row.criteriaInfo[0] && !!$scope.row.criteriaInfo[0].timeSchedule && !!$scope.row.criteriaInfo[0].holidaySchedule) {
                $scope.tpl.msgSelection = true;
                $scope.row.biz_schedule_selected = $scope.row.criteriaInfo[0].timeSchedule;
                $scope.row.holiday_schedule_selected = $scope.row.criteriaInfo[0].holidaySchedule;
            } else {
                $scope.tpl.msgSelection = false;
                $scope.row.biz_schedule_selected = '';
                $scope.row.holiday_schedule_selected = '';
            }
            $scope.enableSbtnBtnForCustom = function() {

                $scope.isValid = true;
                // this.formScope.callingPlanFrm.$setPristine();
                if ($scope.theFile.name == null) {
                    console.log('set pristine')
                    this.formScope.callingPlanFrm.$setPristine();
                }
            }
            //updatePredefinedSchedule();
        }
        initData();
    };

    preAlertDialogCtrl.$inject = ['$scope', 'volteServices', 'Constants', '$rootScope', 'preAlertingAnnouncementConst'];

    angular.module(window.AppName).controller('preAlertDialogCtrl', preAlertDialogCtrl);
})();