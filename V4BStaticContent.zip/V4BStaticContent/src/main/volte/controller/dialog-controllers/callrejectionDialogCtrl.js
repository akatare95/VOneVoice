(function() {
    var callrejectionDialogCtrl = function($scope, volteServices, ngDialog, remoteCallPickupBargeInConst, Constants) {

$scope.submitSettingsSelective = function(row) {
        //$scope.checkActive=true;
        var option = ($scope.tabSelected=='acceptance')?Constants.API.SELECTIVE_CALL_ACCEPTANCE.POST:Constants.API.SELECTIVE_CALL_REJECTION.POST;
        var param = { "updateFeatures": { "updateFeature": [] }};
        param.updateFeatures.updateFeature.push({
            "updateType": "Criteria",
            "phoneNo":$scope.row.phoneNo,
            "criteriaInfo": []
        });
        var arrCollection=$scope.selData.slice();
        for(var i=0;i<$scope.deleteCriteriaArr.length;i++)
        {
            //fruits.splice(2, 0, "Lemon", "Kiwi");
           $scope.selData.splice($scope.deleteCriteriaArr[i].rowIndex,0,$scope.deleteCriteriaArr[i])
        }
        for(var i=0;i<$scope.selData.length;i++)
        {
            // $scope.selData[i].fromDnCriteria.phoneNumber[0];
            $scope.selData[i].fromDnCriteria.phoneNumber = $scope.selData[i].fromDnCriteria.phoneNumber.filter(function( record ) {
                                            //$scope.existNumber = true;
                                            return !!record;
                                });
            $scope.selData[i].criteriaName = "Option"+i;
            $scope.selData[i].timeSchedule = $scope.selData[i].timeSchedule ? $scope.selData[i].timeSchedule:undefined;
            $scope.selData[i].holidaySchedule = $scope.selData[i].holidaySchedule ? $scope.selData[i].holidaySchedule :undefined;
        }

        param.updateFeatures.updateFeature[0].criteriaInfo = $scope.selData;
        console.log(param);
        $scope.row.criteriaInfo= [];
        volteServices.setOption( option );
        volteServices.postData(param).success(function(response) {
            if(response.appHeader.statusCode == "OK") {
                $scope.row.isSubmitClicked=true;
                 for(var i=0;i<arrCollection.length;i++)
                 {
                      arrCollection[i].criteriaName='Option'+i;
                 }
                //console.log(arrCollection);
                $scope.row.criteriaInfo=arrCollection;
                //console.log($scope.row.criteriaInfo);
                $scope.$parent.msgType = "success";
                $scope.$parent.msgTxt = 'Successfully Updated';
                $scope.$parent.showMsg = true;
                $scope.closeDialog();
            } else {
                if($scope.gearType==true)
                {
                  $scope.collection[$scope.rowIndex].currentStatus = false;
                }
                $scope.$parent.msgType = "error";
                $scope.$parent.msgTxt = response.appHeader.statusMessage;
                $scope.$parent.showMsg = true;
                $scope.closeDialog();
            }
        }).error(function() {});
    }
    $scope.removeForwardFrom = function(index) {
        $scope.selData[$scope.selectedOption].fromDnCriteria.phoneNumber.splice(index, 1);
       /* if ($scope.selData[$scope.selectedOption].fromDnCriteria.phoneNumber.length > 9){
            $scope.enableLinkFlag = false;
        }else
            $scope.enableLinkFlag = true;*/
    }
    $scope.addOption = function(filteredlen) {
        // if ($scope.circleOptions.length < 5) {
            // if($scope.circleOptions.length == 4) $scope.showAddOption = false;
            // $scope.circleOptions.push({'name':'Option',"delBox":false});
            // $scope.selectOption($scope.circleOptions.length-1);
        // } else {
        //     $scope.showAddOption = false;
        // }
        var params = {
                "timeSchedule": "",
                "holidaySchedule": "",
                "criteriaName": "Option"+$scope.selData.length,
                "deleteCriteria": false,
                "fromDnCriteria": {
                    "fromDnCriteriaSelection": "Any",
                    "includeAnonymousCallers": "true",
                    "includeUnavailableCallers": "true",
                    "phoneNumber": ['']
                },
                "rowIndex":$scope.selData.length
        };
        $scope.selData.push(params);
        $scope.selectedOption = $scope.selData.length-1;
    }
    $scope.selectOption = function(index) {
        $scope.selectedOption = index;
    }

    $scope.addBox = function ()
        {
                $scope.selData[$scope.selectedOption].fromDnCriteria.phoneNumber.push('') ;
        }




    $scope.addForwardFrom = function() {
        $scope.showInput = true;
        if ($scope.selData[$scope.selectedOption].fromDnCriteria.phoneNumber.length < 10){
        $scope.selData[$scope.selectedOption].fromDnCriteria.phoneNumber.push('');
        }else{
            $scope.enableLinkFlag = false;
        }
        if ($scope.selData[$scope.selectedOption].fromDnCriteria.phoneNumber.length > 9){
            $scope.enableLinkFlag = false;
        }else
            $scope.enableLinkFlag = true;
    }
    $scope.deleteOption = function(criteriaName,index) {
        //console.log(index)
         $scope.changeDelCriteria = [];
         if($scope.row.criteriaInfo)
         {
             angular.forEach($scope.row.criteriaInfo, function(value) {
               if(value.criteriaName == criteriaName)
               {
                    console.log(index,value.criteriaName,criteriaName);
                    $scope.selData[index].deleteCriteria = true;
                    $scope.deleteCriteriaArr.push($scope.selData[index]);
                    console.log($scope.selData)
                    $scope.selData.splice(index,1);
                    $scope.selectedOption = index-1;
                    console.log($scope.selData)
                    //$scope.selData[index].deleteCriteria = true;
                    $scope.changeDelCriteria.push($scope.selData[index])
                    return;
               }
         });
         }
         if($scope.changeDelCriteria.length == 0)
         {
           $scope.selData.splice(index,1);
           $scope.selectedOption = index>$scope.selData.length-1?$scope.selData.length-1:index;
         }
    }
    $scope.lookup = function() {
        $scope.lookupSearch='';
        $scope.phoneNumberSize=$scope.selData[$scope.selectedOption].fromDnCriteria.phoneNumber.length + 1;
        $scope.row.nglookUpSelected=true;
         //console.log($scope.dialogInfo)
         $scope.phoneNumber = null;

         volteServices.setOption( Constants.API.COMMON.LINE_LOOKUP );
         volteServices.getData()
             .success(function (result) {
                $scope.loadFlag     =  false;
                 console.log(result);
                 $scope.lookupNos = result.appResult.serviceRepsonse.lineInfoList;
                 console.log("Lookup - ", result.appResult.serviceRepsonse );
         });






         $scope.lookupDropdown = [
             {name:"Phone Lines", value: "phoneLines"},
             {name:"User Name", value: "userName"},
         ];

         $scope.lookupSearchResp = function() {
             return lookupSearch;
         }

         $scope.updateFromLookUp = function( record ) {
             $scope.phoneNumber = record.phoneNumber;
             //console.log("$scope.phoneNumber" + $scope.phoneNumber + " &&  record.phoneNumber" + $scope.phoneNumber = record.phoneNumber );

         }
         $scope.updateLookUp=function()
         {
             $scope.row.nglookUpSelected=false;
         }
         $scope.addToTextBox = function() {

             if( $scope.lookupNos.length == 0  ) {
                 alert('There aren\'t any records to be added');
             }

             if( $scope.phoneNumber == null  ) {
                 alert("Please select a record");
             }
            var filteredArray = $scope.selData[$scope.selectedOption].fromDnCriteria.phoneNumber.filter(function( record ) {
                $scope.existNumber = true;
                                 return record== $scope.phoneNumber ;
                             });
            if(filteredArray.length==0 && $scope.selData[$scope.selectedOption].fromDnCriteria.phoneNumber.length < 10)
            {
                 $scope.existNumber = false;
                console.log($scope.dialogrowInfo);
              $scope.selData[$scope.selectedOption].fromDnCriteria.phoneNumber.push( $scope.phoneNumber);
              console.log($scope.dialogrowInfo);
              $scope.row.nglookUpSelected=false;
              }else
              {$scope.existNumber = true;
               $scope.existsMsgType='error';
               $scope.exitsNumberMessage='Phone number already exists!'}
              $scope.selData[$scope.selectedOption].fromDnCriteria.fromDnCriteriaSelection="Specified Only";

             // document.getElementById("lookupNo").value = processLineFormatting( $scope.phoneNumber );

         }
     }
    function initData() {
        $scope.row = $scope.ngDialogData.row;
        $scope.tabSelected=$scope.row.featureId=='1014'?'acceptance':'rejection';
        $scope.settings = remoteCallPickupBargeInConst.pageTitle;
        $scope.gearType = $scope.ngDialogData.gearType;
        $scope.deleteCriteriaArr = [];
        $scope.selectedOption=0;
        $scope.selData=[];
        console.log($scope.row)
        //angular.forEach($scope.collection, function(eachRow) {
            // if (eachRow.phoneNo == lineNumber) {
                $scope.row.nglookUpSelected=false;
                if (!!$scope.row.criteriaInfo && $scope.row.criteriaInfo.length ) {
                    var selectIndex = 0;
                    console.log($scope.row.criteriaInfo)
                    angular.forEach($scope.row.criteriaInfo, function(criteria) {
                          // $scope.selData[selectIndex]
                          $scope.selData[selectIndex] = {
                            "timeSchedule": criteria.timeSchedule,
                            "holidaySchedule": criteria.holidaySchedule,
                            "blacklisted": "false",
                            "criteriaName": criteria.criteriaName,
                            "deleteCriteria":false,
                            "forwardToPhoneNumber" : criteria.forwardToPhoneNumber,
                            "fromDnCriteria": {
                                "fromDnCriteriaSelection": criteria.fromDnCriteria.fromDnCriteriaSelection,
                                "includeAnonymousCallers": "true",
                                "includeUnavailableCallers": "true",
                                "phoneNumber": criteria.fromDnCriteria.phoneNumber.slice()
                            },
                            "rowIndex":selectIndex
                        };
                        $scope.selData[selectIndex].fromDnCriteria.phoneNumber.splice(0, 0, "");
                        console.log($scope.selData)
                       //  $scope.circleOptions[selectIndex] = {'name':'Option '+(selectIndex+1),'delBox':false};
                       //  if($scope.circleOptions.length==5)
                       //  {
                       //      $scope.showAddOption=false;
                       //  }
                       // // $scope.circleOptions[selectIndex] = {name:'Option '+(selectIndex+1)};
                      selectIndex++;
                    });
                    // $scope.updateFeature= $scope.selData.slice();
                }
    // });
    }
    initData();
    };

    callrejectionDialogCtrl.$inject = ['$scope', 'volteServices', 'ngDialog', 'remoteCallPickupBargeInConst', 'Constants'];

    angular.module(window.AppName).controller('callrejectionDialogCtrl', callrejectionDialogCtrl);
})();
