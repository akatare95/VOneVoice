(function() {
    var simultaneousRingDilaogCtrl = function($scope, volteServices, Constants) {
        /**
         * SubmitRingService method is used to updtae the request for dialog with the below params
         *
         * @method     submitDataRingService
         */
        var API = Constants.API.SIMULTANEOUS_RING_SERVICE;
        $scope.submitDataRingService = function() {

           $scope.inputBoxCollection = $scope.inputBoxCollection.filter(function( record ) {
                                            //$scope.existNumber = true;
                                            return !!record.phoneNumber;
                                });
            // $scope.row.isSubmitClicked=true;
            var params = {
                "updateFeatures": {
                    "updateFeature": [{
                        "phoneNo": $scope.row.phoneNo,
                        "updateType": "Both",
                        "settingsInfo": {
                            "active": $scope.row.settingsInfo.active.toString(),
                            "doNotRingIfOnCall": "true",
                            "simultaneousReplacementRingNumberList": {
                                "simultaneousRingNumbers": $scope.inputBoxCollection
                            }
                        },
                        "criteriaInfo": [{
                            "criteriaName": "Testing789",
                            "blacklisted": "false",
                            "fromDnCriteria": {
                                "fromDnCriteriaSelection": "Any",
                                "includeAnonymousCallers": "false",
                                "includeUnavailableCallers": "false",
                                "phoneNumber": [$scope.phoneNo]
                            }
                        }]
                    }]
                }
            };
            if (!$scope.dialogData.messageSourceSelection) {
                /**
                 * When Always is selcted and criteriaInfo is previously not defined then  dont send timeSchedule and holiday schedule parameters
                 */
                if ($scope.row.criteriaInfo && $scope.row.criteriaInfo[0].timeSchedule && $scope.row.criteriaInfo[0].holidaySchedule) {
                    params.updateFeatures.updateFeature[0].criteriaInfo[0].timeSchedule = '';
                    params.updateFeatures.updateFeature[0].criteriaInfo[0].holidaySchedule = '';
                }
            } else {
                if(!!$scope.row.biz_schedule_selected && !!$scope.row.holiday_schedule_selected)
                {
                   params.updateFeatures.updateFeature[0].criteriaInfo[0].timeSchedule = $scope.row.biz_schedule_selected;
                   params.updateFeatures.updateFeature[0].criteriaInfo[0].holidaySchedule = $scope.row.holiday_schedule_selected;
                }

                else if (!!$scope.row.biz_schedule_selected && !$scope.row.holiday_schedule_selected )
                {
                    params.updateFeatures.updateFeature[0].criteriaInfo[0].timeSchedule = $scope.row.biz_schedule_selected;
                }

                else if (!!$scope.row.holiday_schedule_selected && !$scope.row.biz_schedule_selected)
                {
                    params.updateFeatures.updateFeature[0].criteriaInfo[0].holidaySchedule = $scope.row.holiday_schedule_selected;
                }

            }



            console.log(params);
            volteServices.setOption(API.POST);
            volteServices.postData(params)
                .success(function(result) {
                    if (result.appHeader.statusCode == "OK") {
                        updateCollection(params);
                        $scope.row.isSubmitClicked=true;
                        $scope.transactionId = result.appResult.serviceRepsonse.updateFeaturesResponse.transactionId;
                        $scope.$parent.msgType = "success";
                        $scope.$parent.msgTxt = result.appHeader.statusMessage;
                        $scope.$parent.showMsg = true;
                        $scope.$parent.closeDialog();
                    } else {
                        $scope.$parent.msgType = "error";
                        $scope.$parent.msgTxt = result.appHeader.statusMessage;
                        $scope.$parent.showMsg = true;
                        $scope.$parent.closeDialog();
                        //$scope.closeThisDialog();
                    }
                })
                .error(function() {
                   // $scope.closeThisDialog();
                    $scope.$parent.msgType = "error";
                    $scope.$parent.msgTxt = "Error performing operation";
                    $scope.$parent.showMsg = true;
                });

        };
        /**
         * Update the UserFeature Collection
         *
         * @method     setUserFeaturePageParams
         * @param      {<type>}  params  { description }
         */
        function updateCollection(params)
        {
            $scope.row.settingsInfo.simultaneousReplacementRingNumberList=params.updateFeatures.updateFeature[0].settingsInfo.simultaneousReplacementRingNumberList;
            $scope.row.criteriaInfo=params.updateFeatures.updateFeature[0].criteriaInfo;
        };
        /**
         *  Search LookUp function used to select phonenumber from the list and update AddPhoneNumberList
         *
         * @method     lookup
         */
        $scope.lookup = function() {
            $scope.lookupSearch = '';
            $scope.nglookUpSelected = true;
            $scope.exitsNumber = false;
            $scope.phoneNumber = null;
            console.log(Constants);
            volteServices.setOption(Constants.API.COMMON.LINE_LOOKUP);
            volteServices.getData()
                .success(function(result) {
                    $scope.loadFlag = false;
                    console.log(result);
                    $scope.lookupNos = result.appResult.serviceRepsonse.lineInfoList;
                    console.log("Lookup - ", result.appResult.serviceRepsonse);
                });
            $scope.lookupDropdown = [{
                name: "Phone Lines",
                value: "phoneLines"
            }, {
                name: "User Name",
                value: "userName"
            }, ];

            $scope.lookupSearchResp = function() {
                return lookupSearch;
            };
            $scope.updateFromLookUp = function(record) {
                $scope.phoneNumber = record.phoneNumber;
            };
            $scope.updateLookUp = function() {
                $scope.nglookUpSelected = false;
            };
            $scope.addToTextBox = function() {
                if ($scope.lookupNos.length === 0) {
                    console.log($scope.lookupNos);
                    alert('There aren\'t any records to be added');
                }
                if (!$scope.phoneNumber) {
                    console.log($scope.phoneNumber);
                    alert("Please select a record");
                }
                if ($scope.phoneNo == $scope.phoneNumber) {
                    console.log($scope.phoneNo, $scope.phoneNumber);
                    $scope.existsMsgType = 'error';
                    $scope.exitsNumberMessage = "This is a duplicate phone number. Please enter a unique phone number";
                    $scope.exitsNumber = true;
                    // $scope.existsMsgType = 'error';
                    return;
                }
                var filteredArray = $scope.inputBoxCollection.filter(function(record) {
                    $scope.exitsNumberMessage = "Phone number already exists!";
                    $scope.exitsNumber = true;
                    $scope.existsMsgType = 'error';
                    return record.phoneNumber == $scope.phoneNumber;
                });
                $scope.forms.simultaneousForm.$pristine = false;
                if (filteredArray.length === 0 && $scope.inputBoxCollection.length < 10) {
                    $scope.exitsNumber = false;
                    $scope.inputBoxCollection.push({
                        'phoneNumber': $scope.phoneNumber,
                        'answerConfirmationRequired': 'false'
                    });
                    $scope.nglookUpSelected = false;
                } else {
                    $scope.exitsNumber = true;
                }
            };
        };


        $scope.addBox = function ()
        {
                 $scope.inputBoxCollection.push({
                'phoneNumber': '',
                'answerConfirmationRequired': 'false'
            });
        }



        $scope.addForwardFrom = function() {
            $scope.inputBoxCollection.push({
                'phoneNumber': '',
                'answerConfirmationRequired': 'false'
            });
            $scope.arrayStatus = false;
        };
        $scope.removeForwardFrom = function(index) {
            $scope.inputBoxCollection.splice(index, 1);
            $scope.forms.simultaneousForm.$pristine = false;
            $scope.arrayStatus = false;
        };
        /**
         *  Initialize dialog data
         *
         * @method     initData
         */
        function initData() {
            console.log($scope.ngDialogData);
            $scope.row = $scope.ngDialogData.row;
            console.log($scope.row);
            $scope.phoneNo = $scope.row.phoneNo;
            $scope.inputBoxCollection = [];
            $scope.dialogData = {};
            $scope.typeGear = $scope.ngDialogData.typeGear;
            /**
             *@messageSourceSelection :Always--flase/Schedule--true
             *@HolidaySchedule & BusinessSchedule
             */
            if (!!$scope.row.criteriaInfo && !!$scope.row.criteriaInfo[0] && (!!$scope.row.criteriaInfo[0].timeSchedule || !!$scope.row.criteriaInfo[0].holidaySchedule)) {
                $scope.row.biz_schedule_selected = $scope.row.criteriaInfo[0].timeSchedule;
                $scope.row.holiday_schedule_selected = $scope.row.criteriaInfo[0].holidaySchedule;
                $scope.dialogData.messageSourceSelection = true;
            } else {
                $scope.dialogData.messageSourceSelection = false;
                $scope.row.biz_schedule_selected = '';
                $scope.row.holiday_schedule_selected = '';
            }
            //@AddphoneNumberlist
            if (!!$scope.row && !!$scope.row.settingsInfo && !!$scope.row.settingsInfo.simultaneousReplacementRingNumberList && !!$scope.row.settingsInfo.simultaneousReplacementRingNumberList.simultaneousRingNumbers) {
                var emptyBox={
                    'phoneNumber': '',
                    'answerConfirmationRequired': 'false'
                 };
                $scope.inputBoxCollection = $scope.row.settingsInfo.simultaneousReplacementRingNumberList.simultaneousRingNumbers.slice();
                $scope.inputBoxCollection.splice(0,0,emptyBox)
            }
            $scope.arrayStatus = true;
            // if (!!$scope.row.scheduleInfo) {
            //     var scheduleList = $scope.row.scheduleInfo;
            //     var bzList = [];
            //     var hoList = [];
            //     angular.forEach(scheduleList, function(value, key) {
            //         if (value.scheduleType == 'HOLIDAY') {
            //             hoList.push({
            //                 'name': value.scheduleName,
            //                 'value': value.scheduleName
            //             });
            //         } else {
            //             bzList.push({
            //                 'name': value.scheduleName,
            //                 'value': value.scheduleName
            //             });
            //         }
            //     });
            //     $scope.biz_schedule = bzList;
            //     $scope.holiday_schedule = hoList;
            // } else {
            //     $scope.biz_schedule = [];
            //     $scope.holiday_schedule = [];
            // }
        }
        initData();
    };

    simultaneousRingDilaogCtrl.$inject = ['$scope', 'volteServices', 'Constants'];

    angular.module(window.AppName).controller('simultaneousRingDilaogCtrl', simultaneousRingDilaogCtrl);
})();