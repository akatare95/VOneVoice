(function() {
    var callingPlanDialogCtrl = function($scope, volteServices, ngDialog, remoteCallPickupBargeInConst, Constants, $filter) {
        var addText = '';
    $scope.getLabel = function(label){
        if (label=="Authorization Code Required")
            {addText = "Use Authorization Code" } else { addText = label; }
      return addText;//.replace("test", "Use Authorization Code");
    };

    var postText = '';
    $scope.postLabel = function(label){
        if (label=="Use Authorization Code")
            {postText = "Authorization Code Required" } else { postText = label; }
      return postText;//.replace("test", "Use Authorization Code");
    };

    function getCodeDetails(row) {

        var id = 0;
        console.log(row.length);
        for (id;  id < row.length ; id++) {
             $scope.authorizCollection.push({"id":id,"record":"O","code":row[id].code,"description":row[id].description ,"delete":"false"});
        }
        //console.log(" Update " +  JSON.stringify($scope.authorizCollection));
    }

//add to the real data holder
    $scope.addAuthorizedcode = function addAuthorizedcode() {
        $scope.validationstatus = false;

        if($scope.authorizCollection.code.length <= 1) {

            $scope.msgTypepop = "error";
            $scope.msgTxtpop  = "Please enter Authorized Code";
            $scope.showMsgpop = true;
            return false;
            }
       var itemscounts = ($filter('filter')($scope.authorizCollection, {delete: false}));
       if(itemscounts.length >= 5) {
            $scope.msgTypepop = "error";
            $scope.msgTxtpop  = "More than 5 authorized codes are not allowed";
            $scope.showMsgpop = true;
            return false;
        }

         var items = ($filter('filter')($scope.authorizCollection, {code: $scope.authorizCollection.code }));
            //alert(items.length);
            if(items.length  >= 1) {
                $scope.showMsgpop = true;
                $scope.msgTypepop = "error";
                $scope.msgTxtpop  = "Authorized code already exits";

              return false;
            }
            var id;
           id = $scope.authorizCollection.length + 10
         $scope.authorizCollection.push({"id":id,"record":"N","code":$scope.authorizCollection.code,"description":$scope.authorizCollection.description ,"delete":"false"});
         $scope.authorizCollection.code =""
         $scope.authorizCollection.description ="";
        $scope.showMsgpop = false;

    };

    $scope.deleteItem = function ( index) {
        $scope.delBox[ index ] = true;
     }

     $scope.deleteNo = function(index) {

        //$scope.delindex = index;
          $scope.delBox[ index ] = false;
         // console.log($scope.delBox[ index ]);
        };

     $scope.deleteYes = function (row,index) {
              $scope.showMsgpop = false;
              console.log(row);
              row.delete = true;
            $scope.forms.callingPlanDialogForm.$pristine = false;
            $scope.delBox[index] = false;
        };

     $scope.submitDataCallingPlan = function(row)
     {

         var param = { "updateFeatures": { "updateFeature": [] }};
         $scope.codeEntries =[];

         angular.forEach($scope.authorizCollection, function(u, i) {

              if ((u.record === "N")  && (u.delete === "true")) {
                    console.log(u);
              } else
              {
                  if ((u.record === "O")  && (u.delete === "false"))
                    {
                         console.log("condition " +  u );
                    }else
                    {
                        $scope.codeEntries.push({"code":u.code,"description":u.description ,"delete":u.delete});
                    }

              }
            });


      if ($scope.row.internationalvalue == true)
        {$scope.international ="Use Authorization Code"; }
      else if ($scope.row.internationalvalue == false) { $scope.international ="Allow"; }
      else{$scope.international = $scope.row.international};

      console.log($scope.international);
          if ($scope.international =="Use Authorization Code")
          {
           if ($scope.authorizCollection.length == 0 )
               {
                  $scope.showMsgpop = true;
                  $scope.msgTypepop = "error";
                  $scope.msgTxtpop  = "Please add Authorization code";
                    return false;
               }
          }

         // console.log( " test12 "+ $scope.row.internationalvalue);
         // //console.log( " test "+ $scope.postLabel($scope.row.international));
         // console.log( " test "+ $scope.postLabel($scope.international));

          param.updateFeatures.updateFeature.push({
            "phoneNo": row.phoneNo,
            "updateType": "Status",
            "settingsInfo": {
                "useCustomSettings": row.settingsInfo.useCustomSettings,
                "userPermissions": {
                    "national": "Allow",
                    "international": $scope.postLabel($scope.international)
                },
                "codeEntries": $scope.codeEntries,
                }});
         console.log($scope.filteredAuthorizCollection);
       // var option = Constants.API.CALLING_PLAN.POST;
        // callingPlanService.setOption(API.UPDATE);
        // callingPlanService.postData(param).success(function(response) {
          //console.log("API -1-"+JSON.stringify(API));
          // if(Constants.API.CALLING_PLAN!= undefined){
          //   if(Constants.API.CALLING_PLAN.UPDATE == undefined){
          //     Constants.API.CALLING_PLAN = Constants.API.CALLING_PLAN;
          //     Constants.API.CALLING_PLAN.UPDATE = Constants.API.CALLING_PLAN.UPDATE;
          //   console.log("API Update -"+API.UPDATE);
          //   }
          // }else{
          //   API = Constants.API.CALLING_PLAN;
          // }
          //console.log("API -value-"+JSON.stringify(API));
        volteServices.setOption(Constants.API.CALLING_PLAN.UPDATE);
        volteServices.postData(param).success(function(response) {
            if(response.appHeader.statusCode == "OK") {
                $scope.closeThisDialog();
                $scope.msgType = "success";
                $scope.msgTxt = 'Successfully Updated';
                $scope.showMsg = true;
                $scope.forms.callingPlanDialogForm.$pristine = true;
                $scope.row.settingsInfo.userPermissions.international=$scope.international;
                var itemscounts = ($filter('filter')($scope.authorizCollection, {delete: false}));
                console.log(itemscounts);
                console.log($scope.row.settingsInfo.codeEntries);
                console.log($scope.filteredAuthorizCollection);
                // if($scope.codeEntries.length)
                // {
                  $scope.row.settingsInfo.codeEntries=itemscounts;
                // }
                // calling api method for grid update
                //getCallPlanDetails();

            } else {
                $scope.closeThisDialog();
                $scope.msgType = "error";
                $scope.msgTxt = 'Record Updation Failed';
                $scope.showMsg = true;
            }
        }).error(function() {
                $scope.closeThisDialog();
                $scope.msgType = "error";
                $scope.msgTxt = 'Record Updation Failed';
                $scope.showMsg = true;});
                $scope.forms.callingPlanDialogForm.$pristine = true;
     }
        function initData() {
            //API = Constants.API.DIRECTED_CALL_PICKUP;
        //$scope.row = $scope.ngDialogData.row;
        $scope.msgTypepop = "";
        $scope.msgTxtpop  = "";
        $scope.showMsgpop = false;
        $scope.row=$scope.ngDialogData.row;
        //$scope.filteredAuthorizCollection = [];
        console.log("row : "+JSON.stringify($scope.row));

     // $scope.authorizAccess=row.settingsInfo.userPermissions;
       //$scope.authorizCollection= row.settingsInfo.codeEntries;
        $scope.authorizCollection = [];
        getCodeDetails($scope.row.settingsInfo.codeEntries);

        //$scope.national = row.settingsInfo.userPermissions.national;
       // $scope.international = row.settingsInfo.userPermissions.international;

        //$scope.row.national = $scope.getLabel(row.settingsInfo.userPermissions.national);

        $scope.row.international = $scope.getLabel($scope.row.settingsInfo.userPermissions.international);
        $scope.row.internationalvalue = $scope.row.settingsInfo.userPermissions.international;
        if ($scope.row.international =="Use Authorization Code")
        { $scope.row.internationalvalue = true; }
      else if ($scope.row.international =="Allow") { $scope.row.internationalvalue = false;} else{$scope.row.internationalvalue = '';};

      console.log("Ineternal"+$scope.row.international)

        if (($scope.row.international =="Use Authorization Code") || ($scope.row.international =="Allow"))
        {
           //console.log("T"+$scope.row.international)
          $scope.disable = false;
        } else {
           //console.log("F"+$scope.row.international)
          $scope.disable = true;
          $scope.msgTypeDrop = "confirm";
          $scope.thankuTxtDrop = " If you want to add international calling to a line, please add the appropriate feature by";
          $scope.msgTxtDrop = "clicking here.";

          // $scope.msgTypepop = "error";
          // $scope.msgTxtpop  = "If you want to add international calling to a line,please add the approprite feature by clicking here";
        }
        }
        initData();
    };

    callingPlanDialogCtrl.$inject = ['$scope', 'volteServices', 'ngDialog', 'remoteCallPickupBargeInConst', 'Constants', '$filter'];

    angular.module(window.AppName).controller('callingPlanDialogCtrl', callingPlanDialogCtrl);
})();