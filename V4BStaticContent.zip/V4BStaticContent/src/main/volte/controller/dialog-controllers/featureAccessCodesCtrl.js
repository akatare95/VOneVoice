(function() {
    var featureAccessCodesCtrl = function($scope, volteServices, Constants) {
     $scope.setSelectedOption=function(row)
     {
        $scope.code=row.code;
     }
     function getData(){
      console.log('response vAL')
      $scope.faccList = [];
       volteServices.setOption( Constants.API.FACC.GET );
        volteServices.getData().success(function( response ){
          $scope.loadFlag     =  true;
          console.log(response)
           $scope.loadFlag     =  false;
            if( response.appHeader.statusCode == "OK")  {
              //console.log(response)
                var resp = response.appResult.serviceRepsonse;
                $scope.faccList = resp.faccList;
            } else {
              $scope.closeThisDialog();
              $scope.showMsg = true;
              $scope.msgType="error";
              $scope.msgTxt = response.appHeader.statusMessage;
              $scope.serverError = true;
            }
        }).error(function() {
            $scope.serverError = true;
        });
     }
    //  function initData(){
    //   $scope.faccList = [];
    //   getData();
    // };
    getData();
  }
    featureAccessCodesCtrl.$inject = ['$scope', 'volteServices', 'Constants'];

    angular.module(window.AppName).controller('featureAccessCodesCtrl', featureAccessCodesCtrl);
})();