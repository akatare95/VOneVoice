(function() {
    var AddNewDeviceCtrl = function($scope, $http, Constants) {
        var associatedDevices,deskPhoneAllowedCount = 0,smartPhoneAllowedCount=0;
        function getDeskNSmartAllowedCount(){
            $scope.lineData = $scope.ngDialogData.associatedDeviceInfo.lineNumber;
            $scope.associatedDeviceInfo = $scope.ngDialogData.associatedDeviceInfo;
            associatedDevices = $scope.associatedDeviceInfo.associatedDevices;
            console.log(associatedDevices)
            for(var i=0 ; i< associatedDevices.length;i++)
            {
                if(associatedDevices[i].deviceType.toUpperCase() =="DESKPHONE")
                {
                   deskPhoneAllowedCount++;
                }
                else if (associatedDevices[i].deviceType.toUpperCase() == "SMARTPHONE")
                {
                    smartPhoneAllowedCount++;
                }
            }
            console.log('smartPhoneCount'+smartPhoneAllowedCount+'deskPhoneCount'+deskPhoneAllowedCount);
        }
        function init () {
            var hideMobileClient = $scope.hideMobileClient = !!$scope.ngDialogData,
                defaultItem = 'device';
            $scope.activeItem = hideMobileClient ? 'device' : defaultItem;
            $scope.pageTitle = hideMobileClient ? 'Add a device' : 'Add One Talk line';
            if($scope.ngDialogData)
            {
                getDeskNSmartAllowedCount();
             }
            // $scope.lineData = $scope.ngDialogData.associatedDeviceInfo.lineNumber;
           // $scope.associatedDeviceInfo = $scope.ngDialogData.associatedDeviceInfo;
            $scope.getHostURL();
            updateDesc();
        }
        $scope.getHostURL = function() {

                    var getHostDetailsArr = [];
                    var subdomain = null;
                    var protocol = "https://";
                    var domain = "b2b";

                    getHostDetailsArr = getHostDetails();

                    $scope.hostURL = protocol + domain + '.' + getHostDetailsArr[1] + '.' + getHostDetailsArr[2];

                    if (getHostDetailsArr.length > 3) {
                        subdomain = getHostDetailsArr[0].slice(3);
                        $scope.hostURL = protocol + domain + subdomain + '.' + getHostDetailsArr[1] + '.' + getHostDetailsArr[2] + '.' + getHostDetailsArr[3];
                    }
        }
        function activateExistingDevice () {
            console.log('activate existing device');
            if(!$scope.ngDialogData)
            {
               console.log($scope.hostURL + '/b2b/commerce/amsecure/index.go?ssPath=NSO')
               //window.location = $scope.hostURL + '/b2b/commerce/amsecure/index.go?ssPath=NSO';

                // Redirect with back URL
                var currentUrlPath = window.location.href;
                var redirectUrlPath = $scope.hostURL + '/b2b/commerce/amsecure/index.go?ssPath=NSO';
                window.location = redirectUrlWithReturnURL(redirectUrlPath, currentUrlPath, Constants.API.REDIRECT_URL_PATHS.split_At);

            }
            else
            {
                $scope.lineData = $scope.ngDialogData.associatedDeviceInfo.lineNumber;
                var params = {};
                params.actionSelected = "AddEndPoint";
                params.line = $scope.lineData;
                params.line = params.line.split("-").join("").match(
                        new RegExp('.{1,4}$|.{1,3}', 'g'))
                    .join("-");
                console.log("input data params : " + JSON.stringify(params));
                var serviceURL = $scope.hostURL + '/epam/app/secure/processActions.go';
                console.log('smartPhoneCount'+smartPhoneAllowedCount+'deskPhoneCount'+deskPhoneAllowedCount);
                console.log("serviceURL : " + serviceURL);
                $http({
                        url: serviceURL,
                        method: "POST",
                        data: params,
                        crossDomain: true,
                        // xhrFields: { withCredentials: true },
                        withCredentials: true,
                        headers: {
                            'Content-type': 'application/json'
                        },
                    })
                    .success(
                        function(data, status,
                            headers, config) {
                            console
                                .log("success in processAction  ");
                            $scope
                                .startTransaction();
                        })
                    .error(
                        function(data, status,
                            headers, config) {
                            console
                                .log("dsdfujsnjsfhusfhxk ");
                        });
                }
        }

        $scope.startTransaction = function() {
            console
                .log("making startTransaction call to EPAM");
            var params = {},smartPhoneCount, deskPhoneCount;;
            params.actionSelected = "AddEndPoint";
            params.line = $scope.lineData;
            params.line = params.line.split("-").join("").match(
                    new RegExp('.{1,4}$|.{1,3}', 'g'))
                .join("-");
            params.source = "VOLTE";
            console.log("input data params : " + JSON.stringify(params));
            console.log('smartPhoneCount'+smartPhoneAllowedCount+'deskPhoneCount'+deskPhoneAllowedCount);
            var serviceURL = $scope.hostURL + '/epam/app/secure/servicelines/selectstring';
            console.log("serviceURL : " + serviceURL);

            $http({
                    url: serviceURL,
                    method: "POST",
                    data: params,
                    crossDomain: true,
                    /* xhrFields: { withCredentials: true }, */
                    withCredentials: true,
                    headers: {
                        'Content-type': 'application/json'
                    },
                })
                .success(
                    function(data, status, headers,
                        config) {
                        console
                            .log("success in startTransaction  ");
                        console.log("respUrl : " + data.redirectUrl);
                        console.log('smartPhoneCount'+smartPhoneAllowedCount+'deskPhoneCount'+deskPhoneAllowedCount);
                        var transcURL = data.redirectUrl+'&smartPhoneCount='+smartPhoneAllowedCount+'&deskPhoneCount='+deskPhoneAllowedCount;

                        // Redirect with back URL
                        var currentUrlPath = window.location.href;
                        var redirectUrlPath = transcURL;
                        transcURL = redirectUrlWithReturnURL(redirectUrlPath, currentUrlPath, Constants.API.REDIRECT_URL_PATHS.split_At);

                        $scope
                            .navigateToUrl(transcURL);
                    })
                .error(
                    function(data, status, headers,
                        config) {
                        console
                            .log("error in startTransaction  ");
                    });
        };
        $scope.navigateToUrl = function(url) {
                    console.log("addNewDeviceCtrl - navigateToUrl input url : " + url);
                    var f = document.createElement("FORM");
                    f.action = url;

                    var indexQM = url.indexOf("?");
                    if (indexQM >= 0) {
                        // the URL has parameters => convert them to
                        // hidden form inputs
                        var params = url.substring(indexQM + 1)
                            .split("&");
                        for (var i = 0; i < params.length; i++) {
                            var keyValuePair = params[i].split("=");
                            var input = document
                                .createElement("INPUT");
                            input.type = "hidden";
                            input.name = keyValuePair[0];
                            input.value = keyValuePair[1];
                            f.appendChild(input);
                        }
                    }

                    document.body.appendChild(f);
                    f.submit();
                };
        function purchaseNewDevice () {
            if(!$scope.ngDialogData)
            {
                console.log($scope.hostURL + '/b2b/commerce/amsecure/index.go?ssPath=NSE');
               //window.location = $scope.hostURL + '/b2b/commerce/amsecure/index.go?ssPath=NSE';

                // Redirect with back URL
                var currentUrlPath = window.location.href;
                var redirectUrlPath = $scope.hostURL + '/b2b/commerce/amsecure/index.go?ssPath=NSE';
                window.location = redirectUrlWithReturnURL(redirectUrlPath, currentUrlPath, Constants.API.REDIRECT_URL_PATHS.split_At);

            }
            else
            {
                //$scope.lineData = $scope.ngDialogData.associatedDeviceInfo.lineNumber;
                var mtn = $scope.lineData;
                //$scope.associatedDeviceInfo = $scope.ngDialogData.associatedDeviceInfo;
                //var associatedDevices = $scope.associatedDeviceInfo.associatedDevices;


                var maxdeskPhoneAllowedCount= 2;
                var maxsmartPhoneAllowedCount =1;
                mtn = mtn.split("-").join("").match(
                        new RegExp('.{1,4}$|.{1,3}', 'g'))
                    .join("-");
                // for(var i=0 ; i< associatedDevices.length;i++)
                // {
                //     if(associatedDevices[i].deviceType.toUpperCase() =="DESKPHONE")
                //     {
                //        deskPhoneAllowedCount++;
                //     }
                //     else if (associatedDevices[i].deviceType.toUpperCase() == "SMARTPHONE")
                //     {
                //         smartPhoneAllowedCount++;
                //     }
                // }
                smartPhoneAllowedCount = maxsmartPhoneAllowedCount - smartPhoneAllowedCount;
                deskPhoneAllowedCount = maxdeskPhoneAllowedCount - deskPhoneAllowedCount;
                console.log($scope.hostURL + '/b2b/commerce/amsecure/index.go?ssPath=addEndPoint&mtn='+mtn+'&smartPhoneAllowedCount='+smartPhoneAllowedCount+'&deskPhoneAllowedCount='+deskPhoneAllowedCount);
                //window.location = $scope.hostURL + '/b2b/commerce/amsecure/index.go?ssPath=addEndPoint&mtn='+mtn+'&smartPhoneAllowedCount='+smartPhoneAllowedCount+'&deskPhoneAllowedCount='+deskPhoneAllowedCount;

                // Redirect with back URL
                var currentUrlPath = window.location.href;
                var redirectUrlPath = $scope.hostURL + '/b2b/commerce/amsecure/index.go?ssPath=addEndPoint&mtn='+mtn+'&smartPhoneAllowedCount='+smartPhoneAllowedCount+'&deskPhoneAllowedCount='+deskPhoneAllowedCount;
                window.location = redirectUrlWithReturnURL(redirectUrlPath, currentUrlPath, Constants.API.REDIRECT_URL_PATHS.split_At);

            }
        }

        function purchaseNewMobileClient () {
            if(!$scope.ngDialogData)
            {
               //window.location = $scope.hostURL + '/b2b/commerce/amsecure/index.go?ssPath=OTT';

                // Redirect with back URL
                var currentUrlPath = window.location.href;
                var redirectUrlPath = $scope.hostURL + '/b2b/commerce/amsecure/index.go?ssPath=OTT';
                window.location = redirectUrlWithReturnURL(redirectUrlPath, currentUrlPath, Constants.API.REDIRECT_URL_PATHS.split_At);

            }
            else
            {
            console.log('purchase new mobile client');
            }
        }

        $scope.$watch('activeItem', updateDesc);

        function updateDesc () {
            var hideMobileClient = $scope.hideMobileClient,
                activeItem = $scope.activeItem;

            $scope.pageDesc = hideMobileClient ?
                'Purchase a new One Talk  capable smartphone or desk phone.' :
                activeItem === 'device' ?
                    'Get a new One Talk number for a smartphone or desk phone or activate One Talk service on an existing number.' :
                    'Get a new One Talk Mobile Client number.';
        }

        $scope.onBtnClick = function (action) {
            switch (action) {
                case 'activateExisting':
                    activateExistingDevice();
                    break;
                case 'purchaseNew':
                    if ($scope.activeItem === 'device') {
                        purchaseNewDevice();
                    } else {
                        purchaseNewMobileClient();
                    }
                    break;
            }
        };

        init();

        // $scope.startTransaction = function() {
        //     console
        //         .log("making startTransaction call to EPAM");
        //     var params = {};
        //     params.actionSelected = "AddEndPoint";
        //     params.line = $scope.lineData;
        //     params.line = params.line.split("-").join("").match(
        //             new RegExp('.{1,4}$|.{1,3}', 'g'))
        //         .join("-");
        //     params.source = "VOLTE";
        //     console.log("input data params : " + JSON.stringify(params));
        //     var serviceURL = $scope.hostURL + '/epam/app/secure/servicelines/selectstring';
        //     console.log("serviceURL : " + serviceURL);

        //     $http({
        //             url: serviceURL,
        //             method: "POST",
        //             data: params,
        //             crossDomain: true,
        //             /* xhrFields: { withCredentials: true }, */
        //             withCredentials: true,
        //             headers: {
        //                 'Content-type': 'application/json'
        //             },
        //         })
        //         .success(
        //             function(data, status, headers,
        //                 config) {
        //                 console
        //                     .log("success in startTransaction  ");
        //                 console.log("respUrl : " + data.redirectUrl);
        //                 $scope
        //                     .navigateToUrl(data.redirectUrl);
        //             })
        //         .error(
        //             function(data, status, headers,
        //                 config) {
        //                 console
        //                     .log("error in startTransaction  ");
        //             });

        // }
        // $scope.process = function() {
        //     console
        //         .log("making processActions call to server");

        //     console.log("Value for EPAMlink is..." + $scope.EPAMLink);
        //     console.log($scope.action);

        //     if ($scope.action=='existingDevice') {
        //         var params = {};
        //         params.actionSelected = "AddEndPoint";
        //         params.line = $scope.lineData;
        //         params.line = params.line.split("-").join("").match(
        //                 new RegExp('.{1,4}$|.{1,3}', 'g'))
        //             .join("-");
        //         console.log("input data params : " + JSON.stringify(params));
        //         var serviceURL = $scope.hostURL + '/epam/app/secure/processActions.go';
        //         console.log("serviceURL : " + serviceURL);
        //         $http({
        //                 url: serviceURL,
        //                 method: "POST",
        //                 data: params,
        //                 crossDomain: true,
        //                 // xhrFields: { withCredentials: true },
        //                 withCredentials: true,
        //                 headers: {
        //                     'Content-type': 'application/json'
        //                 },
        //             })
        //             .success(
        //                 function(data, status,
        //                     headers, config) {
        //                     console
        //                         .log("success in processAction  ");
        //                     $scope
        //                         .startTransaction();
        //                 })
        //             .error(
        //                 function(data, status,
        //                     headers, config) {
        //                     console
        //                         .log("dsdfujsnjsfhusfhxk ");
        //                 });
        //     } else {
        //         var mtn = $scope.lineData;
        //         var associatedDevices = $scope.associatedDeviceInfo.associatedDevices;
        //         var smartPhoneAllowedCount=0;
        //         var deskPhoneAllowedCount = 0;
        //         var maxdeskPhoneAllowedCount= 2;
        //         var maxsmartPhoneAllowedCount =1;
        //         mtn = mtn.split("-").join("").match(
        //                 new RegExp('.{1,4}$|.{1,3}', 'g'))
        //             .join("-");
        //         for(var i=0 ; i< associatedDevices.length;i++)
        //         {
        //             if(associatedDevices[i].deviceType.toUpperCase() =="DESKPHONE")
        //             {
        //                deskPhoneAllowedCount++;
        //             }
        //             else if (associatedDevices[i].deviceType.toUpperCase() == "SMARTPHONE")
        //             {
        //                 smartPhoneAllowedCount++;
        //             }
        //         }
        //         smartPhoneAllowedCount = maxsmartPhoneAllowedCount - smartPhoneAllowedCount;
        //         deskPhoneAllowedCount = maxdeskPhoneAllowedCount - deskPhoneAllowedCount;
        //         console.log($scope.hostURL + '/b2b/commerce/amsecure/index.go?ssPath=addEndPoint&mtn='+mtn+'&smartPhoneAllowedCount='+smartPhoneAllowedCount+'&deskPhoneAllowedCount='+deskPhoneAllowedCount);
        //         window.location = $scope.hostURL + '/b2b/commerce/amsecure/index.go?ssPath=addEndPoint&mtn='+mtn+'&smartPhoneAllowedCount='+smartPhoneAllowedCount+'&deskPhoneAllowedCount='+deskPhoneAllowedCount;
        //     }

        // }
        // $scope.getHostURL = function() {

        //             var getHostDetailsArr = [];
        //             var subdomain = null;
        //             var protocol = "https://";
        //             var domain = "b2b";

        //             getHostDetailsArr = getHostDetails();

        //             $scope.hostURL = protocol + domain + '.' + getHostDetailsArr[1] + '.' + getHostDetailsArr[2];

        //             if (getHostDetailsArr.length > 3) {
        //                 subdomain = getHostDetailsArr[0].slice(3);
        //                 $scope.hostURL = protocol + domain + subdomain + '.' + getHostDetailsArr[1] + '.' + getHostDetailsArr[2] + '.' + getHostDetailsArr[3];
        //             }
        //         }
        // function initData() {
        //     $scope.action = 'purchaseDevice';
        //     console.log($scope.ngDialogData)
        //     $scope.lineData = $scope.ngDialogData.associatedDeviceInfo.lineNumber;
        //     $scope.associatedDeviceInfo = $scope.ngDialogData.associatedDeviceInfo;
        //     console.log($scope.lineData,$scope.associatedDeviceInfo)
        //     $scope.getHostURL();
        // }
        // initData();
    };

    AddNewDeviceCtrl.$inject = ['$scope', '$http', 'Constants'];

    angular.module(window.AppName).controller('addNewDeviceCtrl', AddNewDeviceCtrl);
})();