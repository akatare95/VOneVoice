(function() {
    var callForwardSelectiveDialogCtrl = function($scope, volteServices, ngDialog, remoteCallPickupBargeInConst, Constants) {
       $scope.submitSettingsForwarding = function(dialogInfo) {
        $scope.checkActive =true;
        console.log('dialogInfo', JSON.stringify($scope.dialogInfo));
        // console.log($scope.activeAlways[0]);
        var param = { "updateFeatures": { "updateFeature": [] }};
        var number = 1000;

        // if ($scope.tabSelected == 'selective') {
            param.updateFeatures.updateFeature.push({
                "updateType": "Both",
                "phoneNo":$scope.row.phoneNo,
                "settingsInfo":{
                    "active":"true",
                    "defaultForwardToPhoneNumber":$scope.row.settingsInfo.defaultForwardToPhoneNumber,
                    "playRingReminder":"true"
                },
                "criteriaInfo": []
            });
            var arrCollection=$scope.selData.slice();
            for(var i=0;i<$scope.deleteCriteriaArr.length;i++)
            {
               $scope.selData.splice($scope.deleteCriteriaArr[i].rowIndex,0,$scope.deleteCriteriaArr[i])
            }
            angular.forEach($scope.selData, function(eachData, key) {

                 $scope.selData[i].fromDnCriteria.phoneNumber = $scope.selData[i].fromDnCriteria.phoneNumber.filter(function( record ) {
                                            //$scope.existNumber = true;
                                            return !!record;
                                });
                console.log(!!eachData.forwardToPhoneNumber)
                eachData.criteriaName = "Option"+key;
                //eachData.forwardToNumberSelection=!!eachData.forwardToPhoneNumber?'Forward To Specified Number':delete $scope.selData[key].forwardToNumberSelection && delete $scope.selData[key].forwardToPhoneNumber;

                if(!!eachData.forwardToPhoneNumber)
                {
                  eachData.forwardToNumberSelection = 'Forward To Specified Number' ;
                }
                else{
                    console.log("entered"+key)
                  delete eachData.forwardToNumberSelection;
                  delete $scope.selData[key].forwardToPhoneNumber;
                  console.log(eachData.forwardToPhoneNumber)
                }
                if(eachData.schedule == 'always')
                  {
                    if(!!$scope.row.criteriaInfo)
                    {
                        eachData.timeSchedule=!!$scope.row.criteriaInfo[key]?(!!$scope.row.criteriaInfo[key].timeSchedule?'':undefined):undefined;
                        eachData.holidaySchedule=!!$scope.row.criteriaInfo[key]?(!!$scope.row.criteriaInfo[key].holidaySchedule?'':undefined):undefined;
                    }
                    else
                    {
                        eachData.timeSchedule = undefined;
                        eachData.holidaySchedule = undefined;
                    }
                  }else{
                      if(!eachData.timeSchedule && !eachData.holidaySchedule)
                      {
                        if(!!$scope.row.criteriaInfo)
                        {
                            eachData.timeSchedule=!!$scope.row.criteriaInfo[key]?(!!$scope.row.criteriaInfo[key].timeSchedule?'':undefined):undefined;
                            eachData.holidaySchedule=!!$scope.row.criteriaInfo[key]?(!!$scope.row.criteriaInfo[key].holidaySchedule?'':undefined):undefined;
                        }
                        else
                        {
                            eachData.timeSchedule = undefined;
                            eachData.holidaySchedule = undefined;
                        }
                      }
                  }

            });
        param.updateFeatures.updateFeature[0].criteriaInfo = $scope.selData;
        console.log(Constants.API.CALL_FORWARDING[$scope.tabSelected.toUpperCase()])
        volteServices.setOption( Constants.API.CALL_FORWARDING[$scope.tabSelected.toUpperCase()].POST);
        volteServices.postData(param).success(function(response) {
            if(response.appHeader.statusCode == "OK") {
                $scope.row.isSubmitClicked=true;
                 for(var i=0;i<arrCollection.length;i++)
                 {
                      arrCollection[i].criteriaName='Option'+i;
                 }
                $scope.row.criteriaInfo=arrCollection;
                $scope.$parent.msgType = "success";
                $scope.$parent.msgTxt = response.appHeader ? response.appHeader.statusMessage : 'updation failed';
                $scope.$parent.showMsg = true;
                $scope.closeDialog();
                // $scope.successHandler(response.appHeader.statusMessage);
                console.log($scope.msgTxt)
            } else {
                console.log(Constants.API.CALL_FORWARDING[$scope.tabSelected.toUpperCase()])
                var msgTxt = response.appHeader ? response.appHeader.statusMessage : 'updation failed';
                // if($scope.gearType===true)
                // {

                //     $scope.row.settingsInfo.active = false;
                // }
                $scope.$parent.msgType = "error";
                $scope.$parent.msgTxt = response.appHeader ? response.appHeader.statusMessage : 'updation failed';
                $scope.$parent.showMsg = true;
                $scope.closeDialog();
                //$scope.errorHandler(msgTxt);
                //console.log(Constants.API.CALL_FORWARDING[$scope.tabSelected.toUpperCase()])
            }
        }).error(function() {});
    }

        $scope.addOption = function() {
            var params = {
                //dont need a blank parameter in the service HD
                //"timeSchedule": "",
                //"holidaySchedule": "",
                "criteriaName": "Option" + $scope.selData.length,
                "schedule": "always",
                "deleteCriteria": false,
                // "forwardToNumberSelection": "Forward To Default Number",
                // "forwardToPhoneNumber": "",
                "fromDnCriteria": {
                    "fromDnCriteriaSelection": "Any",
                    "includeAnonymousCallers": "true",
                    "includeUnavailableCallers": "true",
                    "phoneNumber": ['']
                },
                "rowIndex":$scope.selData.length
            };
            console.log(params);
            $scope.selData.push(params);
            $scope.selectedOption = $scope.selData.length - 1;
        };



         $scope.addBox = function ()
        {
                $scope.selData[$scope.selectedOption].fromDnCriteria.phoneNumber.push('') ;
        }





        $scope.setDeleteIndex = function(indexVal){
          $scope.selData[$scope.selectedOption].deleteCriteria = true;
        }
        $scope.deleteOption = function() {
            $scope.changeDelCriteria = [];
            //console.log($scope.selData[$scope.selectedOption]);
            angular.forEach($scope.row.criteriaInfo, function(value) {
                if (value.criteriaName == $scope.selData[$scope.selectedOption].criteriaName) {
                    //console.log(index, value.criteriaName, criteriaName);
                    $scope.selData[$scope.selectedOption].deleteCriteria = true;
                    $scope.deleteCriteriaArr.push($scope.selData[$scope.selectedOption]);
                    console.log($scope.selData)
                    $scope.selData.splice($scope.selectedOption, 1);
                    $scope.selectedOption = $scope.selectedOption - 1;
                    console.log($scope.selData)
                        //$scope.selData[index].deleteCriteria = true;
                    $scope.changeDelCriteria.push($scope.selData[$scope.selectedOption])
                    return;
                }
            });
            if ($scope.changeDelCriteria.length == 0) {
                $scope.selData.splice($scope.selectedOption, 1);
                $scope.selectedOption = $scope.selectedOption > $scope.selData.length - 1 ? $scope.selData.length - 1 : $scope.selectedOption;
            }
        }

         $scope.selectOption = function(index) {
            //console.log(typeof $scope.selData[index]);
            $scope.selectedOption = index;
        };
        $scope.lookup = function() {
            $scope.lookupSearch = '';
            $scope.phoneNumberSize = $scope.selData[$scope.selectedOption].fromDnCriteria.phoneNumber.length + 1;
            $scope.row.nglookUpSelected = true;
            //console.log($scope.dialogInfo)
            $scope.phoneNumber = null;

            volteServices.setOption(Constants.API.COMMON.LINE_LOOKUP);
            volteServices.getData()
                .success(function(response) {
                    // $scope.loadFlag     =  false;
                    console.log(response);
                    $scope.lookupNos = response.appResult.serviceRepsonse.lineInfoList;
                    console.log("Lookup - ", response.appResult.serviceRepsonse);
                });


            $scope.lookupDropdown = [{
                name: "Phone Lines",
                value: "phoneLines"
            }, {
                name: "User Name",
                value: "userName"
            }, ];

            $scope.lookupSearchResp = function() {
                return lookupSearch;
            }

            $scope.updateFromLookUp = function(record) {
                $scope.phoneNumber = record.phoneNumber;
                //console.log("$scope.phoneNumber" + $scope.phoneNumber + " &&  record.phoneNumber" + $scope.phoneNumber = record.phoneNumber );

            }
            $scope.updateLookUp = function() {
                $scope.row.nglookUpSelected = false;
            }
            $scope.addToTextBox = function() {

                if ($scope.lookupNos.length == 0) {
                    alert('There aren\'t any records to be added');
                }

                if ($scope.phoneNumber == null) {
                    alert("Please select a record");
                }
                var filteredArray = $scope.selData[$scope.selectedOption].fromDnCriteria.phoneNumber.filter(function(record) {
                    $scope.existNumber = true;
                    return record == $scope.phoneNumber;
                });
                if (filteredArray.length == 0 && $scope.selData[$scope.selectedOption].fromDnCriteria.phoneNumber.length < 10) {
                    $scope.existNumber = false;
                    $scope.selData[$scope.selectedOption].fromDnCriteria.phoneNumber.push($scope.phoneNumber);
                    $scope.row.nglookUpSelected = false;
                } else {
                    $scope.existNumber = true;
                }
                $scope.selData[$scope.selectedOption].fromDnCriteria.fromDnCriteriaSelection = "Specified Only";


                // document.getElementById("lookupNo").value = processLineFormatting( $scope.phoneNumber );

            }
        }

        $scope.removeForwardFrom = function(index)
            {
                $scope.selData[$scope.selectedOption].fromDnCriteria.phoneNumber.splice(index, 1);
                $scope.arrayStatus=false;
            }



        function initData() {
            $scope.row = $scope.ngDialogData.row;
            console.log($scope.row);
            $scope.$parent.showMsg=false;
            $scope.settings = remoteCallPickupBargeInConst.pageTitle;
            $scope.gearType = $scope.ngDialogData.gearType;
            $scope.selectedOption = 0;
            $scope.row.nglookUpSelected = false;
            $scope.deleteCriteriaArr=[];
            $scope.selData=[];
            console.log($scope.row);
            if (!!$scope.row.criteriaInfo && $scope.row.criteriaInfo.length) {
                angular.forEach($scope.row.criteriaInfo, function(criteria, index) {
                    $scope.selData.push({
                        "timeSchedule": criteria.timeSchedule,
                        "holidaySchedule": criteria.holidaySchedule,
                        "criteriaName": criteria.criteriaName,
                        "schedule": (!!criteria.timeSchedule || !!criteria.holidaySchedule) ? "defined" : "always",
                        "deleteCriteria": false,
                        "forwardToNumberSelection": "Forward To Default Number",
                        "forwardToPhoneNumber": criteria.forwardToPhoneNumber,
                        "fromDnCriteria": {
                            "fromDnCriteriaSelection": criteria.fromDnCriteria.fromDnCriteriaSelection,
                            "includeAnonymousCallers": "true",
                            "includeUnavailableCallers": "true",
                            "phoneNumber": criteria.fromDnCriteria.phoneNumber.slice()

                        },
                        "rowIndex":index
                    });
                });
            }
        }
        initData();
    };

    callForwardSelectiveDialogCtrl.$inject = ['$scope', 'volteServices', 'ngDialog', 'remoteCallPickupBargeInConst', 'Constants'];

    angular.module(window.AppName).controller('callForwardSelectiveDialogCtrl', callForwardSelectiveDialogCtrl);
})();