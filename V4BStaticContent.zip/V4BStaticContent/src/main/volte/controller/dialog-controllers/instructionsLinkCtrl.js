(function() {
    var instructionsLinkCtrl = function($scope, volteServices, Constants, linkInstructions) {
     $scope.setSelectedOption=function(row)
     {
        $scope.code=row.code;
     }
     function getData(){
      console.log('response vAL');
      $scope.recordInstructions = linkInstructions.recordInstructions;
     }
    getData();
  }
    instructionsLinkCtrl.$inject = ['$scope', 'volteServices', 'Constants', 'linkInstructions'];

    angular.module(window.AppName).controller('instructionsLinkCtrl', instructionsLinkCtrl);
})();