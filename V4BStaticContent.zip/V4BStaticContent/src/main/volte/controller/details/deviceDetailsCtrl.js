var deviceDetailsCtrl =  function($scope, $http, ngDialog, $timeout, $state, $compile, $templateCache, asyncLoadData, lineServices,volteServices,Constants,AuthorizeConst,$rootScope){

    // deviceIndex = $state.params.deviceID;
    // deviceContainer = document.getElementById('associated-device-details');
    // device      =  document.getElementById("associated-device-" + deviceIndex);
    // deviceClass = angular.element( device ).attr("class");

    // function devicePath() {

    //     $scope.imageHost = window.ENV;

    // }

    // function loadDeviceInfo() {
    //     console.log('in deviceDetailsCtrl loadDeviceInfo');
    //     $timeout(function() {

    //         var device      =  document.getElementById('associated-device-' + deviceIndex);
    //         var deviceType  =  angular.element( device ).attr('device-type');
    //         var URL = 'partials/details/devices/' + deviceType.toUpperCase() + '.html';
    //         $scope.deviceType=deviceType;
    //         fetchTemplate( URL );

    //     }, 1000);

    // }
    // $scope.checkValue=function()
    // {
    //     alert('123');
    // }
    // function fetchTemplate( URL ) {

    //     $http.get(URL, {cache: $templateCache}).success(function( result ){

    //         //angular.element( deviceContainer ).children().remove();
    //         var el = angular.element( result );
    //           // iElement.append( $compile(el)(scope) );
    //           // prevEl = el;
    //         console.log('in deviceDetailsCtrl fetchTemplate before appending');
    //         angular.element( deviceContainer ).append( $compile(el)($scope)  );
    //         console.log('in deviceDetailsCtrl fetchTemplate after appending');
    //         getData911UpdateData();
    //         //Deselect all the tabs
    //         for(deviceList = 0; deviceList<8; deviceList++) {
    //             var deviceItem      =  document.getElementById("associated-device-" + deviceList);
    //             console.log(deviceItem);
    //             angular.element( deviceItem ).attr("class",  "device-item-sans-grid ng-scope")
    //         }

    //         //Highlight the selected tab
    //         device      =  document.getElementById("associated-device-" + deviceIndex);
    //         console.log(deviceIndex);
    //         deviceClass = angular.element( device ).attr("class");
    //         angular.element( device ).attr("class",  deviceClass + " item-selected");
    //     });

    // }
    // function getData911UpdateData()
    // {
    //     // console.log($state.params.lineNumber,);
    //     var params={
    //        'lineNumber':$state.params.lineNumber,
    //        'deviceId':$scope.deviceType
    //     }
    //     volteServices.setOption( Constants.API.UPDATE911ADDRESS.GET );
    //     volteServices.postData(params).success(function( response ){

    //         if(response.appHeader.statusCode == "OK") {
    //             var serviceRepsonse=response.appResult.serviceRepsonse;
    //             $scope.address911=serviceRepsonse._911Address;
    //             $scope.bridgedLines=serviceRepsonse.bridgedLines;
    //             $scope.deviceId911=serviceRepsonse.deviceId;
    //             $scope.status=serviceRepsonse.status;
    //             // var windowIDs = ngDialog.getOpenDialogs();
    //             // //console.log(windowIDs);
    //             // ngDialog.close(windowIDs[1]);
    //             // console.log('submitted Successfully'+JSON.stringify(params));
    //             // $scope.updateUserInfoFrm.$pristine = true;

    //         } else {

    //             $scope.msgType  = "error";
    //             $scope.msgTxt   = result.appHeader.statusMessage;
    //             $scope.showMsg  = true;
    //             // var windowIDs = ngDialog.getOpenDialogs();
    //             // //console.log(windowIDs);
    //             // ngDialog.close(windowIDs[1]);
    //         }

    //     });
    // }
    // $scope.update911Address=function(){
    //     $scope.addressone=$scope.address911.address_Line_1;
    //     $scope.addresstwo=$scope.address911.address_Line_2;
    //     $scope.city=$scope.address911.city;
    //     $scope.state=$scope.address911.state;
    //     filteredArray = $scope.state_values.filter(function( record ) {
    //                                     return record.value==$scope.address911.state;
    //                                 });
    //     $scope.state=filteredArray[0].name;
    //         //console.log(filteredArray[0].);
    //     $scope.zipcode=$scope.address911.zipCode;
    //     var new_dialog = ngDialog.open({ template: 'partials/components/dialog/update911Address.html',
    //        closeByDocument: false,
    //        closeByEscape: false,
    //        scope: $scope,
    //        controller:'deviceDetailsCtrl'
    //         });
    // }
    // $scope.submit911AddressInfo=function(){
    //         //console.log($scope.deviceMDNList);
    //         $scope.deviceMDNList=[{
    //                               "lineNumber": $state.params.lineNumber,
    //                               "deviceId":  $scope.deviceType
    //                             }];
    //         var arrayVal=[$scope.addressone,$scope.addresstwo,$scope.city,$scope.state,$scope.zipcode]
    //         console.log(arrayVal);
    //         for(var i=0;i<arrayVal.length;i++)
    //         {
    //           if(arrayVal[i]==''||arrayVal[i]==undefined)
    //           {
    //             if(i!=1)
    //             {
    //                $scope.showMsgdial=true;
    //                     $scope.msgTypedial='error';
    //                     $scope.msgTxtdial='Please fill required fields';
    //                     $scope.update911Form.$setPristine();
    //                     console.log('Please Select Deskphones');
    //                     return;
    //             }
    //           }
    //         }
    //         var params={
    //                           "deviceMDNList":$scope.deviceMDNList,
    //                           "911Address": {
    //                             "addressLine1": $scope.addressone,
    //                             "addressLine2": $scope.addresstwo,
    //                             "city": $scope.city,
    //                             "state":$scope.state,
    //                             "zipCode": $scope.zipcode
    //                           }
    //                         };
    //             volteServices.setOption( Constants.API.UPDATE911ADDRESS.POST );
    //             volteServices.postData( params ).success(function( response ){

    //                 if(response.appHeader.statusCode == "OK") {

    //                     $scope.$parent.msgType  = "success";
    //                     $scope.$parent.msgTxt   = "Successfully Updated!";
    //                     $scope.$parent.showMsg  = true;
    //                     $scope.$parent.address911.address_Line_1=$scope.addressone;
    //                     $scope.$parent.address911.address_Line_2=$scope.addresstwo;
    //                     $scope.$parent.address911.city=$scope.city;
    //                     filteredArray = $scope.state_values.filter(function( record ) {
    //                         console.log(record);
    //                                     return record.name==$scope.state||record.value==$scope.state;
    //                                 });
    //                     console.log(filteredArray,$scope.state);
    //                     $scope.$parent.address911.state=filteredArray[0].value;
    //                     $scope.$parent.address911.zipCode=$scope.zipcode;
    //                     //var loop=0;
    //                     // console.log($scope.$parent.collection,$scope.lines_actions_selected );
    //                     // angular.forEach($scope.$parent.collection, function(value, key) {
    //                     //   $scope.$parent.collection[loop].Selected = false;
    //                     //   loop++;
    //                     // });
    //                     //$scope.$parent.lines_actions_selected = undefined;
    //                     var windowIDs = ngDialog.getOpenDialogs();
    //                     //console.log(windowIDs);
    //                     ngDialog.close(windowIDs[1]);
    //                     console.log('submitted Successfully with unchecked'+JSON.stringify(params));
    //                     // $scope.updateUserInfoFrm.$pristine = true;

    //                 } else {

    //                     $scope.$parent.msgType  = "error";
    //                     $scope.$parent.msgTxt   = result.appHeader.statusMessage;
    //                     $scope.$parent.showMsg  = true;
    //                     // var loop=0;
    //                     // console.log($scope.$parent.collection,$scope.$parent.lines_actions_selected );
    //                     // angular.forEach($scope.$parent.collection, function(value, key) {
    //                     //   $scope.$parent.collection[loop].Selected = false;
    //                     //   loop++;
    //                     // });
    //                     // $scope.$parent.lines_actions_selected = undefined;
    //                     var windowIDs = ngDialog.getOpenDialogs();
    //                     //console.log(windowIDs);
    //                     ngDialog.close(windowIDs[1]);
    //                 }
    //             })

    //     }
    // $scope.enableForLines = function() {

    //     if($state.params.deviceType == 'lines')
    //         return true;
    //     else
    //         return false;
    // }
    // $scope.enableForDevices = function() {

    //     //console.log("Type = " + $scope.type);

    //     if($state.params.deviceType == 'devices')
    //         return true;
    //     else
    //         return false;
    // }
    // function init() {
    //     console.log('in deviceDetailsCtrl init');
    //     // $scope.associatedDevices=lineServices.getAssociatedDetails();
    //     // console.log($scope.associatedDevices);
    //     loadDeviceInfo();
    //     //  $scope.addressone='';
    //     // $scope.addresstwo='';
    //     // $scope.city='';
    //     // $scope.state='';
    //     // $scope.zipcode='';
    //     $scope.state_values=AuthorizeConst.STATE_LIST;
    //    // $scope.state='';
    // }

    // init();

};

deviceDetailsCtrl.$inject = ["$scope", "$http", "ngDialog", "$timeout", "$state", "$compile", "$templateCache", "asyncLoadData", "lineServices.deprecated","volteServices","Constants","AuthorizeConst",
"$rootScope"];
angular.module( window.AppName ).controller("deviceDetailsCtrl", deviceDetailsCtrl);