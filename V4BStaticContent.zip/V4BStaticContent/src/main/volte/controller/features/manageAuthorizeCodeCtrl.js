
var manageAuthorizeCodeCtrl = function($scope, $http, ngDialog, $compile, $state, manageAuthorizeCodeServices,Constants,Config,cache,$filter) {
    function getScheduleGroups() {
        //$scope.type = "schedule";
        //huntGroupServices.setOption( $scope.type );
        // $scope.vzGridTpl = "partials/features/vz-grid/vz.grid.manage-authorize-code.html";
        // getData();
    }

    function getData() {
    //     manageAuthorizeCodeServices.getData()
    //     .success(function (result) {
    //             /*$scope.collection = result.appResult.serviceResponse.codeEntries;*/
    //              $scope.collection = result.data.rows;
    //             var i = 0;
    //             angular.forEach($scope.collection, function(value, key) {
    //                 $scope.collection[i].isChecked = false;
    //                 i++;
    //             });
    //             $scope.numberOfCodes = $scope.collection.length;
    //               $scope.algorithm = result;
    //         })
    //         .error(function (error) {
    //             $scope.status = 'Unable to load hunt group data: ' + error.message;
    //         });
    }

    //  $scope.deleteSchedule = function() {
    //     var i = 0;
    //     var temp = [];
    //     angular.forEach($scope.collection, function(value, key) {
    //         if($scope.collection[i].isChecked == false) {
    //             temp.push($scope.collection[i]);
    //         }
    //         i++;
    //     });
    //     $scope.collection = temp;
    //     $scope.numberOfCodes = $scope.collection.length;
    // }
function declareVariables() {

        //Load Constants
        API = Constants.API.AUTHORIZE_CODE;

        //Define tpl path
        $scope.vzGridTpl = "partials/features/vz-grid/vz.grid.manage-authorize-code.html";

        $scope.modelModified = false;

        $scope.accountName = "";
        $scope.accountDescription = "";

    }

    function getAccountSummary() {

        manageAuthorizeCodeServices.setOption( API.AUTHORIZE_SUMMARY );
        manageAuthorizeCodeServices.getData()
            .success(function (result) {
                // console.log("Result - ", result);
                $scope.collection = result.appResult.serviceRepsonse.codeEntries;
                cache.put("authCodeList",$scope.collection);
             });

    }

    $scope.ngEnableSubmit = function() {

        if( (typeof($scope.accountName) != 'undefined' && $scope.accountName.length>2 && $scope.accountName.length<12)
                && (typeof($scope.accountDescription) != 'undefined' && $scope.accountDescription.length>1 && $scope.accountDescription.length<250) ) {
            $scope.modelModified = true;
        }

    }

    $scope.vzSubmitBtnStatusFn = function( decision ) {
        $rootScope.vzSubmitBtnStatus = !decision;
        return decision;
    }
    $scope.remove = function(){
        // $filter('filter')($scope.collection, {code: searchName})[0];
         manageAuthorizeCodeServices.setOption( API.DELETE);
       var namesList={
          "codeEntries": []
        }

       // deletedItems.codeEntries=[];
        for(var i=0;i<$scope.collection.length;i++)
        {
            if($scope.collection[i].isChecked==true)
            {
                namesList.codeEntries.push({"code":$scope.collection[i].code,"description":$scope.collection[i].description});
                //console.log(namesList);
                // $scope.collection.splice(i,1);
                //  i--;
            }
        }
        console.log(namesList.codeEntries);
        if(namesList.codeEntries.length>0)
        {
            manageAuthorizeCodeServices.postData(namesList).success(function (result)
            {
                 // $scope.showMsg = true;
                 // $scope.msgType = "success";
                 // $scope.msgTxt = "Deleted Successfully";
                try
                {
                    if(result.appHeader.statusCode == "OK")
                  {
                    for(var i=0;i<$scope.collection.length;i++)
                        {
                            if($scope.collection[i].isChecked==true)
                            {
                                $scope.collection.splice(i,1);
                                 i--;
                            }
                        }
                    $scope.msgType = "success";
                    $scope.msgTxt = "Deleted Successfully";
                    $scope.showMsg = true;
                    console.log( $scope.msgTxt);
                   }
                }
                catch(err){
                    //$scope.msgTxt = "Delete Unscuccesfull";
                    console.log(err.message);
                }
            }).error(function (error) {
               console.log("Failure - ", error);
            });
        }
        else{
            $scope.msgType = "error";
                    $scope.showMsg = true;
            $scope.msgTxt = "Please select a Record";
        }

       // console.log('$scope.collection'+$scope.collection);
    }

    $scope.submitCode = function() {
        $scope.createAccountCodeForm.$setPristine();
        var params = [];
        params.push({"code": $scope.accountName, "description": $scope.accountDescription});
        var sendRequestData = { "codeEntries": params };

        manageAuthorizeCodeServices.setOption( API.CREATE_ACCOUNT );
        manageAuthorizeCodeServices.postData( sendRequestData )
            .success(function (result) {
                if(result.appHeader.statusCode == "OK") {
                    $scope.msgType = "success";
                    $scope.msgTxt = "Added Successfully";
                    $scope.showMsg = true;
                }
                console.log("Result - ", result);
                $scope.collection = result.appResult.serviceRepsonse.codeEntries;
             });

    }
    function init() {

        //Initialize Variables
        $scope.collection = {};
        $scope.numberOfCodes;

        $scope.selectedCodes = {};
        declareVariables();

        getAccountSummary();
        $scope.AUTHORIZATION_CODE_TITLE = Config.AUTHORIZATION_CODE_TITLE;
        $scope.AUTHORIZATION_CODE_DESC = Config.AUTHORIZATION_CODE_DESC;
        $scope.MANAGE_AUTHORIZATION_CODES_TITLE=Config.MANAGE_AUTHORIZATION_CODES_TITLE
        //Load available Hunt Groups
    }

    init();
    //   $scope.createCode = function() {
    //     var selectedCodes = [],
    //     selectedCodesJSON = {};

    //     for (var i = 0; i < $scope.collection.length; i++) {
    //         if($scope.collection[i].isChecked) {
    //             selectedCodes.push({"code":$scope.collection[i].codes, "description":$scope.collection[i].codeDescription});
    //         }
    //     };

    //     selectedCodesJSON = {"codeEntries": selectedCodes}

    //     console.log(selectedCodesJSON);

    //     manageAccountCodeServices.postAccountCodes(selectedCodesJSON)
    //         .success(function(result) {

    //         })
    //         .error(function(error) {

    //         });
    // }

};


manageAuthorizeCodeCtrl.$inject = ["$scope", "$http", "ngDialog", "$compile", "$state", "manageAuthorizeCodeServices","Constants","Config","cache","$filter"];
angular.module( window.AppName ).controller("manageAuthorizeCodeCtrl", manageAuthorizeCodeCtrl);