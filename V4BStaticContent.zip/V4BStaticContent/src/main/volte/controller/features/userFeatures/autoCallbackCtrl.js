var autoCallbackCtrl = function($scope,$http,$rootScope,ngDialog,$compile,$state,autoCallbackService,enableDisableConst,automaticCallbackConst,Constants) {
    $scope.vzGridTpl = "partials/features/vz-grid/userFeatures/vz.grid.auto-callback.html";
    $scope.refresh = function() {
        $scope.manage_schedule_filter_selected = undefined;
        $scope.filter($scope.manage_schedule_filter_selected);
        $scope.callWaitingSearch = '';
        autoCallbackService.clientSearch('');
        autoCallbackService.loadList({}, true)
            .then(serviceResponseHandler)
            .catch(errorHandler)
            .then(function() {
                $scope.loadFlag = false;
            });
        // autoCallbackService.loadList({}, true)
        //     .then(serviceResponseHandler)
        //     .catch(errorHandler)
        //     .then(function() {
        //         // $scope.collection = result;
        //         //         $scope.$watchGroup(collection, function(newVal){
        //         //     console.log(newVal)
        //         // });
        //         $scope.loadFlag = false;
        // //         $scope.manage_schedule_filter_selected = undefined;
        // // $scope.filter($scope.manage_schedule_filter_selected);
        // // $scope.callWaitingSearch = '';
        //     });
    }
    $scope.enableAll = function() {
        var list = autoCallbackService.getList(),
            update = [],
            param = {
                "updateFeatures": {
                    "updateFeature": update
                }
            };
        //$scope.loadFlag = true;
        for (var i = 0, ln = list.length; i < ln; i++) {
            if (list[i].isChecked) {
                list[i].multiple = true;
                update.push({
                    "phoneNo": list[i].phoneNo,
                    "updateType": "Status",
                    "userName": list[i].userName,
                    "settingsInfo": {
                        "active": 'true'
                    }
                });
            }
        }
        autoCallbackService.enable(param)
            .then(function(response) {
                for (var i = 0, ln = list.length; i < ln; i++) {
                    if (list[i].isChecked) {
                        console.log('entered')
                        list[i].multiple = false;
                        list[i].settingsInfo.active = true;
                    }
                }
                successHandler("Operation Successful");
            })
            .catch(errorHandler)
            .then(function(){
                toggleSelect(false);
                $scope.loadFlag = false;
            });
            //$scope.togglestatus=false;
    };
    $scope.$on('toggleChange', function(event, data) {
        console.log('bnbnmbmn');
        console.log(data);
    });
    $scope.disableAll = function() {
            var list = autoCallbackService.getList(),
                del = [],
                param = {
                    "updateFeatures": {
                        "updateFeature": []
                    }
                };

            for (var i = 0, ln = list.length; i < ln; i++) {
                if (list[i].isChecked) {
                    list[i].multiple = true;
                    //list[i].settingsInfo.active = false;
                    //list[i].multiple = true;
                    param.updateFeatures.updateFeature.push({
                        "phoneNo": list[i].phoneNo,
                        "updateType": "Status",
                        "userName": list[i].userName,
                        "settingsInfo": {
                            "active": 'false'
                        }
                    });
                }
            }
            autoCallbackService.enable(param)
                .then(function(response) {
                    for (var i = 0, ln = list.length; i < ln; i++) {
                        console.log(list[i].isChecked+'actuve')
                        if (list[i].isChecked) {
                            console.log('entered')
                            list[i].multiple = false;
                            list[i].settingsInfo.active = false;
                        }
                    }
                    successHandler("Operation Successful");
                })
                .catch(function(reject){
                    errorHandler(reject);
                     for (var i = 0, ln = list.length; i < ln; i++) {
                        console.log(list[i].isChecked+'actuve')
                        if (list[i].isChecked) {
                            console.log('entered')
                            list[i].multiple = false;
                            //list[i].settingsInfo.active = false;
                        }
                    }
                })
                .then(function(){
                    toggleSelect(false);
                });
        }
        /**
         * Paginate previous page
         *
         * @method     prev
         */
    $scope.prev = function() {
        toggleSelect(false);
        autoCallbackService.prevPage()
            .then(serviceResponseHandler)
            .catch(errorHandler);
    };

    /**
     * Paginate next page
     *
     * @method     next
     */
    $scope.next = function() {
        toggleSelect(false);
        autoCallbackService.nextPage()
            .then(serviceResponseHandler)
            .catch(errorHandler);
    };

    /**
     * Update page size and refresh
     *
     * @method     setPageSize
     * @param      {Number}  value   Rows per page value
     */
    $scope.setPageSize = function(value) {
        toggleSelect(false);
        autoCallbackService.setPageSize(value)
            .then(serviceResponseHandler)
            .catch(errorHandler);
    };

    /**
     * Performs filter operation
     *
     * @method     filter
     * @param      {String}  filterBy  The type by which to filter against (business or holiday)
     */
    $scope.filter = function(filterBy) {
        //toggleSelect(false);
        console.log(filterBy)
        autoCallbackService.filter(filterBy)
            .then(serviceResponseHandler)
            .catch(errorHandler);
    };

    /**
     * Performs search operation
     *
     * @method     search
     * @param      {String}  searchQuery
     */
       $scope.search = function (searchQuery,searchFilter,$event) {
        console.log(searchFilter)
        if(autoCallbackService.getOperationType() ==='server' || autoCallbackService.getServerSearchValue())
        {
            var isClickedEnterVal = $event == undefined ? $event : $event.which;
           if(isClickedEnterVal === 13 ||isClickedEnterVal == undefined)
            {
                searchFunc(searchQuery,searchFilter);
            }
        }
        else
        {
           searchFunc(searchQuery,searchFilter);
        }
    };
    function searchFunc(searchQuery,searchFilter){
        autoCallbackService.search(searchQuery,searchFilter)
            .then(serviceResponseHandler)
            .catch(errorHandler);

        return searchQuery;
    }
    function errorHandler(err) {
        $scope.loadFlag = false;
        $scope.msgType = 'error';
        $scope.msgTxt = err.message || 'An unknown error has occured';
        $scope.showMsg = true;
    }

    function successHandler(message) {
        $scope.msgType = 'success';
        $scope.msgTxt = message;
        $scope.showMsg = true;
    }

    function serviceResponseHandler(response) {
        $scope.selectAll = false;
        $scope.collection = autoCallbackService.getList();
        console.log($scope.collection);
        $scope.count = autoCallbackService.getCount();
        $scope.pageSize = autoCallbackService.getPageSize();
        $scope.pagesLength = autoCallbackService.getPagesLength();
        $scope.currentPage = autoCallbackService.getCurrentPage();
        $scope.length = autoCallbackService.getLength();
        $scope.total = autoCallbackService.getTotal();
        $scope.noRecordsMessage = $scope.total === 0 ? "No Records Found" : "The schedule cannot be found.";
        $scope.serverSearch = autoCallbackService.getServerSearchValue();
        return response;
    }
    $scope.$watch('selectAll', toggleSelect);

    function toggleSelect(value) {
        console.log(value)
        var list = autoCallbackService.getList();
        console.log(list)
        for (var i = 0, ln = list.length; i < ln; i++) {
            list[i].isChecked = value;
        }
    }
    function loadList(){
       autoCallbackService.loadList({})
            .then(serviceResponseHandler)
            .catch(errorHandler)
            .then(function() {
                $scope.loading = false;
            });
        console.log($scope.collection);
    }
    function init() {
        //Initialize Variables
        $scope.loading = true;
        //$scope.loadFlag     =  true;
        $scope.AUTOMATIC_CALLBACK_TITLE = automaticCallbackConst.pageTitle;
        $scope.AUTOMATIC_CALLBACK_DESC = automaticCallbackConst.pageDesc;
        $scope.instructions = automaticCallbackConst.instructions;
        $scope.numberOfSchedules;
        $scope.manage_schedule_filter = enableDisableConst.MANAGE_FILTER;
        $scope.manage_schedule_filter_selected = undefined;
        $scope.featureName = "automatic_callback";
        $scope.searchFilterArr = [  {   name: "Phone Lines",
                                        value: "phoneNumber"
                                    }, {
                                        name: "User Name",
                                        value: "userName"
                                }];
        $scope.searchFilter = 'phoneNumber';
        // $scope.toggleSbtBtnStatus=false;
        //API = Constants.API.ANNONYMOUS_CALL_REJECTION;
        serviceResponseHandler();
        loadList();
    }

    init();

};


autoCallbackCtrl.$inject = ["$scope","$rootScope", "$http", "ngDialog", "$compile", "$state", "autoCallbackService","enableDisableConst","automaticCallbackConst","Constants"];
angular.module( window.AppName ).controller("autoCallbackCtrl", autoCallbackCtrl);