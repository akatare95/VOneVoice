var callingPlanCtrlUser = function($scope,$http,$rootScope,ngDialog,$compile,$state,callingPlanService,enableDisableConst,callingPlanConst,Constants) {
    $scope.vzGridTpl = "partials/features/userFeatures/callingPlan/vz-grid/vz.grid.callingPlan.html";
    $scope.refresh = function() {
        $scope.manage_schedule_filter_selected = undefined;
        //$scope.filter($scope.manage_schedule_filter_selected);
        $scope.callWaitingSearch = '';
        callingPlanService.clientSearch('');
        callingPlanService.loadList({}, true)
            .then(serviceResponseHandler)
            .catch(errorHandler)
            .then(function() {
                $scope.loadFlag = false;
            });
    }
        /**
         * Paginate previous page
         *
         * @method     prev
         */
    $scope.prev = function() {
        toggleSelect(false);
        callingPlanService.prevPage()
            .then(serviceResponseHandler)
            .catch(errorHandler);
    };

    /**
     * Paginate next page
     *
     * @method     next
     */
    $scope.next = function() {
        toggleSelect(false);
        callingPlanService.nextPage()
            .then(serviceResponseHandler)
            .catch(errorHandler);
    };

    /**
     * Update page size and refresh
     *
     * @method     setPageSize
     * @param      {Number}  value   Rows per page value
     */
    $scope.setPageSize = function(value) {
        toggleSelect(false);
        callingPlanService.setPageSize(value)
            .then(serviceResponseHandler)
            .catch(errorHandler);
    };

    /**
     * Performs filter operation
     *
     * @method     filter
     * @param      {String}  filterBy  The type by which to filter against (business or holiday)
     */

    /**
     * Performs search operation
     *
     * @method     search
     * @param      {String}  searchQuery
     */
    $scope.search = function (searchQuery,searchFilter,$event) {
        console.log(searchFilter)
        if(callingPlanService.getOperationType() ==='server' || callingPlanService.getServerSearchValue())
        {
            var isClickedEnterVal = $event == undefined ? $event : $event.which;
           if(isClickedEnterVal === 13 ||isClickedEnterVal == undefined)
            {
                searchFunc(searchQuery,searchFilter);
            }
        }
        else
        {
           searchFunc(searchQuery,searchFilter);
        }
    };
    function searchFunc(searchQuery,searchFilter){
        callingPlanService.search(searchQuery,searchFilter)
            .then(serviceResponseHandler)
            .catch(errorHandler);

        return searchQuery;
    }
    $scope.getLabel = function(label){
        if (label=="Authorization Code Required")
            {addText = "Use Authorization Code" } else { addText = label; }
      return addText;//.replace("test", "Use Authorization Code");
    };
    function errorHandler(err) {
        $scope.loadFlag = false;
        $scope.msgType = 'error';
        $scope.msgTxt = err.message || 'An unknown error has occured';
        $scope.showMsg = true;
    }

    function successHandler(message) {
        $scope.msgType = 'success';
        $scope.msgTxt = message;
        $scope.showMsg = true;
    }

    function serviceResponseHandler(response) {
        $scope.selectAll = false;
        $scope.collection = callingPlanService.getList();
        $scope.count = callingPlanService.getCount();
        $scope.pageSize = callingPlanService.getPageSize();
        $scope.pagesLength = callingPlanService.getPagesLength();
        $scope.currentPage = callingPlanService.getCurrentPage();
        $scope.length = callingPlanService.getLength();
        $scope.total = callingPlanService.getTotal();
        $scope.serverSearch = callingPlanService.getServerSearchValue();
        $scope.noRecordsMessage = $scope.total === 0 ? "No Records Found" : "The schedule cannot be found.";
        return response;
    }
    $scope.$watch('selectAll', toggleSelect);
    $scope.submitData=function(row) {
        var params = {
                        "updateFeatures": {
                            "updateFeature": [{
                                "phoneNo": row.phoneNo,
                                "updateType": "Status",
                                "settingsInfo": {}
                            }]
                        }
                    };
        //var option = Constants.API.PRE_ALERT_ANNOUNCEMENT.POSTNOFILE;
        var updateFeature = JSON.parse(JSON.stringify(row));
        updateFeature.settingsInfo.active="false";
        params.updateFeatures.updateFeature[0].settingsInfo=updateFeature.settingsInfo;
        volteServices.setOption(API.POST);
        volteServices.postData(params)
        .success(function (result) {
            //console.log('post call resp', JSON.stringify(result));
            if(result.appHeader.statusCode == "OK") {
                row.settingsInfo.active=false;
                console.log(result);
                success();
            } else {
                row.settingsInfo.active=true;
                $scope.msgType = "error";
                $scope.msgTxt = result.appHeader.statusMessage;
                $scope.showMsg = true;
            }
        })
        .error(function(){
            $scope.msgType = "error";
            $scope.msgTxt = "Error performing Operation";
            $scope.showMsg = true;
        });
    };
    function toggleSelect(value) {
        console.log(value)
        var list = callingPlanService.getList();
        console.log(list)
        for (var i = 0, ln = list.length; i < ln; i++) {
            list[i].isChecked = value;
        }
    }
    function loadList(){
        $scope.loading    =  true;
       callingPlanService.loadList({})
            .then(serviceResponseHandler)
            .catch(errorHandler)
            .then(function() {
                $scope.loading = false;
            });
        console.log($scope.collection);
    }
    $scope.closeDialog = function() {
      try {
        var windowIDs = ngDialog.getOpenDialogs();
        //console.log(windowIDs);
        ngDialog.close(windowIDs[1]);
      } catch(err) {
        //console.log('Error:', err);
      }
    };
   $scope.lookupDialogCallingPlan = function(row) {
        var rowTypeInfo={
            row: row
        };
        var new_dialog = ngDialog.open({
            template: 'partials/features/userFeatures/callingPlan/dialog/callingPlanDialog.html',
            className: 'ngdialog-theme-default user-calling-plan-dialog',
            closeByDocument: false,
            closeByEscape: false,
            scope: $scope,
            data:  rowTypeInfo,
            controller: 'callingPlanDialogCtrl'
        });
    }
    function getScheduleData() {
        //$scope.loadFlag     =  true;
        callingPlanService.getScheduleData({})
            .then(function(result) {
                $scope.biz_schedule = result.bzList;
                $scope.holiday_schedule = result.hoList;
            })
            .catch(errorHandler);
    }
    function init() {
        //Initialize Variables
        $scope.REMOTE_CALL_PICKUP_DESC = callingPlanConst.pageTitle_Desc;
        $scope.REMOTE_CALL_PICKUP_TITLE = callingPlanConst.pageTitle;
        $scope.instructions = callingPlanConst.instructions;
        $scope.type = "callingPlan";
        $scope.disable = false;
        $scope.delBox ={};
        $scope.searchFilterArr = [  {   name: "Phone Lines",
                                        value: "phoneNumber"
                                    }, {
                                        name: "User Name",
                                        value: "userName"
                                }];
        $scope.searchFilter = 'phoneNumber';
        $scope.userPermissionslist =[{ value: "Allow",name: "Allow"}, { value: "Authorization Code Required", name: "Use Authorization Code"}];
        //$scope.delBox[row] = false;
        $scope.forms = {};
        //Load Constants
        //API = Constants.API.CALLING_PLAN;
        //Define tpl path
        // $scope.vzGridTpl = "partials/features/userFeatures/callingPlan/vz-grid/vz.grid.callingPlan.html";
        $scope.modelModified = false;
        $scope.numberOfSchedules;
        $scope.manage_schedule_filter = enableDisableConst.MANAGE_FILTER;
        $scope.manage_schedule_filter_selected = undefined;
        //$scope.featureName="simultaneous_ring";
        // $scope.toggleSbtBtnStatus=false;
        //API = Constants.API.ANNONYMOUS_CALL_REJECTION;
        serviceResponseHandler();
        getScheduleData();
        loadList();
    }

    init();

};


callingPlanCtrlUser.$inject = ["$scope","$rootScope", "$http", "ngDialog", "$compile", "$state", "callingPlanService","enableDisableConst","callingPlanConst","Constants"];
angular.module( window.AppName ).controller("callingPlanCtrlUser", callingPlanCtrlUser);