var directedCallPickUpBargeinCtrl = function($scope,$http,$rootScope,ngDialog,$compile,$state,directedCallPickUpBargeinService,enableDisableConst,remoteCallPickupBargeInConst,Constants) {
    $scope.vzGridTpl = "partials/features/vz-grid/userFeatures/vz.grid.directedCallPickUpBargein.html";
    $scope.refresh = function() {
        $scope.dirCallPickUpSearch = '';
        directedCallPickUpBargeinService.clientSearch('');
        directedCallPickUpBargeinService.loadList({}, true)
            .then(serviceResponseHandler)
            .catch(errorHandler)
            .then(function() {
                $scope.loadFlag = false;
            });
        // $scope.callWaitingSearch = '';
    }
        /**
         * Paginate previous page
         *
         * @method     prev
         */
    $scope.prev = function() {
        toggleSelect(false);
        directedCallPickUpBargeinService.prevPage()
            .then(serviceResponseHandler)
            .catch(errorHandler);
    };

    /**
     * Paginate next page
     *
     * @method     next
     */
    $scope.next = function() {
        toggleSelect(false);
        directedCallPickUpBargeinService.nextPage()
            .then(serviceResponseHandler)
            .catch(errorHandler);
    };

    /**
     * Update page size and refresh
     *
     * @method     setPageSize
     * @param      {Number}  value   Rows per page value
     */
    $scope.setPageSize = function(value) {
        toggleSelect(false);
        directedCallPickUpBargeinService.setPageSize(value)
            .then(serviceResponseHandler)
            .catch(errorHandler);
    };

    /**
     * Performs filter operation
     *
     * @method     filter
     * @param      {String}  filterBy  The type by which to filter against (business or holiday)
     */

    /**
     * Performs search operation
     *
     * @method     search
     * @param      {String}  searchQuery
     */
    $scope.search = function (searchQuery,searchFilter,$event) {
        console.log(directedCallPickUpBargeinService.getOperationType() ==='server' , directedCallPickUpBargeinService.getServerSearchValue())
        if(directedCallPickUpBargeinService.getOperationType() ==='server' || directedCallPickUpBargeinService.getServerSearchValue())
        {
            var isClickedEnterVal = $event == undefined ? $event : $event.which;
           if(isClickedEnterVal === 13 ||isClickedEnterVal == undefined)
            {
                searchFunc(searchQuery,searchFilter);
            }
            // searchFunc(searchQuery,searchFilter);
        }
        else
        {
            console.log('else part')
           searchFunc(searchQuery,searchFilter);
        }
    };
    function searchFunc(searchQuery,searchFilter){
        directedCallPickUpBargeinService.search(searchQuery,searchFilter)
            .then(serviceResponseHandler)
            .catch(errorHandler);

        return searchQuery;
    }
    function errorHandler(err) {
        $scope.loadFlag = false;
        $scope.msgType = 'error';
        $scope.msgTxt = err.message || 'An unknown error has occured';
        $scope.showMsg = true;
    }

    function successHandler(message) {
        console.log(message)
        $scope.msgType = 'success';
        $scope.msgTxt = message;
        $scope.showMsg = true;
    }

    function serviceResponseHandler(response) {
        $scope.selectAll = false;
        $scope.collection = directedCallPickUpBargeinService.getList();
        $scope.count = directedCallPickUpBargeinService.getCount();
        $scope.pageSize = directedCallPickUpBargeinService.getPageSize();
        $scope.pagesLength = directedCallPickUpBargeinService.getPagesLength();
        $scope.currentPage = directedCallPickUpBargeinService.getCurrentPage();
        $scope.length = directedCallPickUpBargeinService.getLength();
        $scope.total = directedCallPickUpBargeinService.getTotal();
        $scope.noRecordsMessage = $scope.total === 0 ? "No Records Found" : "The schedule cannot be found.";
         $scope.serverSearch = directedCallPickUpBargeinService.getServerSearchValue();
        return response;
    }
    $scope.$watch('selectAll', toggleSelect);
    $scope.submitData=function(row) {
        var params = {
                        "updateFeatures": {
                            "updateFeature": [{
                                "phoneNo": row.phoneNo,
                                "updateType": "Status",
                                "settingsInfo": {}
                            }]
                        }
                    };
        //var option = Constants.API.PRE_ALERT_ANNOUNCEMENT.POSTNOFILE;
        var updateFeature = JSON.parse(JSON.stringify(row));
        updateFeature.settingsInfo.active="false";
        params.updateFeatures.updateFeature[0].settingsInfo=updateFeature.settingsInfo;
        directedCallPickUpBargeinService.update(params)
            .then(function(result) {
                console.log("inside update call")
               row.settingsInfo.active=false;
               successHandler("Successfully updated.")
            })
            .catch(errorHandler);
    };
    function toggleSelect(value) {
        console.log(value)
        var list = directedCallPickUpBargeinService.getList();
        console.log(list)
        for (var i = 0, ln = list.length; i < ln; i++) {
            list[i].isChecked = value;
        }
    }
    function loadList(){
       directedCallPickUpBargeinService.loadList({})
            .then(serviceResponseHandler)
            .catch(errorHandler)
            .then(function() {
                $scope.loading = false;
            });
        console.log($scope.collection);
    }
    $scope.closeDialog = function() {
      try {
        var windowIDs = ngDialog.getOpenDialogs();
        //console.log(windowIDs);
        ngDialog.close(windowIDs[1]);
      } catch(err) {
        //console.log('Error:', err);
      }
    };
    $scope.lookupDialogCallPickup = function(row,rowIndex,gearType) {
        row.isSubmitClicked = false;
        var rowTypeInfo={
            row: row,
            rowIndex : rowIndex,
            gearType : gearType
        };
        console.log($scope.collection);
        var new_dialog = ngDialog.open({ template: 'partials/components/dialog/userFeatures/directedCallBargeIn.html',
            closeByDocument: false,
            closeByEscape: false,
            className: 'ngdialog-theme-default remote-call-pickup-barge-in-modal',
            scope: $scope,
            data:  rowTypeInfo,
            controller:'directedCallPickUpDialogCtrl',
            preCloseCallback: function(){
                if(row.isSubmitClicked === false && gearType===true)
                {
                   if(!$scope.$$phase) {
                       $scope.$apply(function() {
                        row.settingsInfo.active = false;
                       });
                   }
                   else
                   {
                      row.settingsInfo.active = false;
                   }
                }
               return true;
            }
        });
    };
    function getScheduleData() {
        //$scope.loadFlag     =  true;
        directedCallPickUpBargeinService.getScheduleData({})
            .then(function(result) {
                $scope.biz_schedule = result.bzList;
                $scope.holiday_schedule = result.hoList;
            })
            .catch(errorHandler);
    }
    function init() {
        //Initialize Variables
        $scope.loading     =  true;
        $scope.REMOTE_CALL_PICKUP_TITLE =remoteCallPickupBargeInConst.pageTitle;
        $scope.instructions = remoteCallPickupBargeInConst.instructions;
        $scope.REMOTE_CALL_PICKUP_DESC = remoteCallPickupBargeInConst.pageDesc;
        $scope.featureName="directed_call_pickup";
        $scope.numberOfSchedules;
        $scope.manage_schedule_filter = enableDisableConst.MANAGE_FILTER;
        $scope.manage_schedule_filter_selected = undefined;
        $scope.searchFilterArr = [  {   name: "Phone Lines",
                                        value: "phoneNumber"
                                    }, {
                                        name: "User Name",
                                        value: "userName"
                                }];
        $scope.searchFilter = 'phoneNumber';
        //$scope.featureName="simultaneous_ring";
        // $scope.toggleSbtBtnStatus=false;
        //API = Constants.API.ANNONYMOUS_CALL_REJECTION;
        serviceResponseHandler();
        getScheduleData();
        loadList();
    }

    init();

};


directedCallPickUpBargeinCtrl.$inject = ["$scope","$rootScope", "$http", "ngDialog", "$compile", "$state", "directedCallPickUpBargeinService","enableDisableConst","remoteCallPickupBargeInConst","Constants"];
angular.module( window.AppName ).controller("directedCallPickUpBargeinCtrl", directedCallPickUpBargeinCtrl);