var simultaneousRingServiceCtrl = function($scope,$http,$rootScope,ngDialog,$compile,$state,simultaneousRingService,enableDisableConst,simultaneousRingConst,Constants) {
    $scope.vzGridTpl = "partials/features/vz-grid/userFeatures/vz.grid.simultaneous-RingService.html";
    $scope.refresh = function() {
        $scope.dirCallPickUpSearch = '';
        simultaneousRingService.clientSearch('');
        simultaneousRingService.loadList({}, true)
            .then(serviceResponseHandler)
            .catch(errorHandler)
            .then(function() {
                $scope.loadFlag = false;
            });
          //$scope.callWaitingSearch = '';
    }
        /**
         * Paginate previous page
         *
         * @method     prev
         */
    $scope.prev = function() {
        toggleSelect(false);
        simultaneousRingService.prevPage()
            .then(serviceResponseHandler)
            .catch(errorHandler);
    };

    /**
     * Paginate next page
     *
     * @method     next
     */
    $scope.next = function() {
        toggleSelect(false);
        simultaneousRingService.nextPage()
            .then(serviceResponseHandler)
            .catch(errorHandler);
    };

    /**
     * Update page size and refresh
     *
     * @method     setPageSize
     * @param      {Number}  value   Rows per page value
     */
    $scope.setPageSize = function(value) {
        toggleSelect(false);
        simultaneousRingService.setPageSize(value)
            .then(serviceResponseHandler)
            .catch(errorHandler);
    };

    /**
     * Performs filter operation
     *
     * @method     filter
     * @param      {String}  filterBy  The type by which to filter against (business or holiday)
     */

    /**
     * Performs search operation
     *
     * @method     search
     * @param      {String}  searchQuery
     */
    $scope.search = function (searchQuery,searchFilter,$event) {
        console.log(searchFilter)
        if(simultaneousRingService.getOperationType() ==='server' || simultaneousRingService.getServerSearchValue())
        {
            var isClickedEnterVal = $event == undefined ? $event : $event.which;
           if(isClickedEnterVal === 13 ||isClickedEnterVal == undefined)
            {
                searchFunc(searchQuery,searchFilter);
            }
        }
        else
        {
           searchFunc(searchQuery,searchFilter);
        }
    };
    function searchFunc(searchQuery,searchFilter){
        simultaneousRingService.search(searchQuery,searchFilter)
            .then(serviceResponseHandler)
            .catch(errorHandler);

        return searchQuery;
    }
    function errorHandler(err) {
        $scope.loadFlag = false;
        $scope.msgType = 'error';
        $scope.msgTxt = err.message || 'An unknown error has occured';
        $scope.showMsg = true;
    }

    function successHandler(message) {
        $scope.msgType = 'success';
        $scope.msgTxt = message;
        $scope.showMsg = true;
    }

    function serviceResponseHandler(response) {
        $scope.selectAll = false;
        $scope.collection = simultaneousRingService.getList();
        $scope.count = simultaneousRingService.getCount();
        $scope.pageSize = simultaneousRingService.getPageSize();
        $scope.pagesLength = simultaneousRingService.getPagesLength();
        $scope.currentPage = simultaneousRingService.getCurrentPage();
        $scope.length = simultaneousRingService.getLength();
        $scope.total = simultaneousRingService.getTotal();
        $scope.noRecordsMessage = $scope.total === 0 ? "No Records Found" : "The schedule cannot be found.";
         $scope.serverSearch = simultaneousRingService.getServerSearchValue();
        return response;
    }
    $scope.$watch('selectAll', toggleSelect);
    $scope.submitWhenToggleOff=function(row)
    {
        var params = {
                        "updateFeatures": {
                            "updateFeature": [{
                                "phoneNo": row.phoneNo,
                                "updateType": "Status",
                                "settingsInfo": {}
                            }]
                        }
                    };
        //var option = Constants.API.PRE_ALERT_ANNOUNCEMENT.POSTNOFILE;
        var updateFeature = JSON.parse(JSON.stringify(row));
        updateFeature.settingsInfo.active="false";
        params.updateFeatures.updateFeature[0].settingsInfo=updateFeature.settingsInfo;
        params.updateFeatures.updateFeature[0].criteriaInfo=updateFeature.criteriaInfo;
        console.log(params)
        simultaneousRingService.update(params)
            .then(function(result) {
               row.settingsInfo.active=false;
               successHandler("Successfully updated.")
            })
            .catch(errorHandler);
    }
    function toggleSelect(value) {
        console.log(value)
        var list = simultaneousRingService.getList();
        console.log(list)
        for (var i = 0, ln = list.length; i < ln; i++) {
            list[i].isChecked = value;
        }
    }
    function loadList(){
       simultaneousRingService.loadList({})
            .then(serviceResponseHandler)
            .catch(errorHandler)
            .then(function() {
                $scope.loading = false;
            });
        console.log($scope.collection);
    }
    $scope.closeDialog = function() {
      try {
        var windowIDs = ngDialog.getOpenDialogs();
        //console.log(windowIDs);
        ngDialog.close(windowIDs[1]);
      } catch(err) {
        //console.log('Error:', err);
      }
    };
    $scope.lookupDialogRingService = function(row,rowIndex,typeGear) {
      row.isSubmitClicked=false;
        var rowTypeInfo={
            row: row,
            rowIndex : rowIndex,
            gearType : typeGear
        };
         var new_dialog = ngDialog.open({
          template: 'partials/components/dialog/userFeatures/simultaneousRingService.html',
            closeByDocument: false,
            className: 'ngdialog-theme-default simultaneous-ring-service-dialog',
            closeByEscape: false,
            data:  rowTypeInfo,
            preCloseCallback: function(){
                console.log(row.isSubmitClicked,typeGear)
                if(row.isSubmitClicked==false && typeGear===true)
                {
                  if(!$scope.$$phase) {
                   $scope.$apply(function() {
                    row.settingsInfo.active = false;
                   });
                 }
                 else
                 {
                   row.settingsInfo.active = false;
                 }
                }
               return true;
            },
            scope:$scope,
            controller:'simultaneousRingDilaogCtrl'
        });
    };
    function getScheduleData() {
        //$scope.loadFlag     =  true;
        simultaneousRingService.getScheduleData({})
            .then(function(result) {
                $scope.biz_schedule = result.bzList;
                $scope.holiday_schedule = result.hoList;
            })
            .catch(errorHandler);
    }
    function init() {
        //Initialize Variables
        $scope.loading     =  true;
        $scope.SIMULTANEOUS_RING_SERVICE_TITLE=simultaneousRingConst.pageTitle;
        $scope.SIMULTANEOUS_RING_SERVICE_DESC=simultaneousRingConst.pageDesc;
        $scope.instructions = simultaneousRingConst.instructions;
        $scope.searchFilterArr = [  {   name: "Phone Lines",
                                        value: "phoneNumber"
                                    }, {
                                        name: "User Name",
                                        value: "userName"
                                }];
        $scope.searchFilter = 'phoneNumber';
        $scope.numberOfSchedules;
        $scope.manage_schedule_filter = enableDisableConst.MANAGE_FILTER;
        $scope.manage_schedule_filter_selected = undefined;
        $scope.featureName="simultaneous_ring";
        // $scope.toggleSbtBtnStatus=false;
        //API = Constants.API.ANNONYMOUS_CALL_REJECTION;
        serviceResponseHandler();
        getScheduleData();
        loadList();
    }

    init();

};


simultaneousRingServiceCtrl.$inject = ["$scope","$rootScope", "$http", "ngDialog", "$compile", "$state", "simultaneousRingService","enableDisableConst","simultaneousRingConst","Constants"];
angular.module( window.AppName ).controller("simultaneousRingServiceCtrl", simultaneousRingServiceCtrl);