var selectiveAcceptRejectionCtrlBackUp = function($scope,$http,$rootScope,ngDialog,$compile,$state,selectiveCallAcceptRejectionService,enableDisableConst,selectiveCallRejectionConst,Constants) {
    $scope.vzGridTpl = "partials/features/vz-grid/userFeatures/vz.grid.simultaneous-RingService.html";
    $scope.refresh = function() {
        $scope.filterBy = undefined;
        $scope.filter($scope.filterBy);
        selectiveCallAcceptRejectionService.loadList({}, true)
            .then(serviceResponseHandler)
            .catch(errorHandler)
            .then(function() {
                // $scope.collection = result;
                //         $scope.$watchGroup(collection, function(newVal){
                //     console.log(newVal)
                // });
                $scope.loadFlag = false;
            });
    }
        /**
         * Paginate previous page
         *
         * @method     prev
         */
    $scope.prev = function() {
        toggleSelect(false);
        selectiveCallAcceptRejectionService.prevPage()
            .then(serviceResponseHandler)
            .catch(errorHandler);
    };

    /**
     * Paginate next page
     *
     * @method     next
     */
    $scope.next = function() {
        toggleSelect(false);
        selectiveCallAcceptRejectionService.nextPage()
            .then(serviceResponseHandler)
            .catch(errorHandler);
    };

    /**
     * Update page size and refresh
     *
     * @method     setPageSize
     * @param      {Number}  value   Rows per page value
     */
    $scope.setPageSize = function(value) {
        toggleSelect(false);
        selectiveCallAcceptRejectionService.setPageSize(value)
            .then(serviceResponseHandler)
            .catch(errorHandler);
    };

    /**
     * Performs filter operation
     *
     * @method     filter
     * @param      {String}  filterBy  The type by which to filter against (business or holiday)
     */
    $scope.filter = function(filterBy) {
        //toggleSelect(false);
        console.log(filterBy)
        selectiveCallAcceptRejectionService.filter(filterBy)
            .then(serviceResponseHandler)
            .catch(errorHandler);
    };

    /**
     * Performs search operation
     *
     * @method     search
     * @param      {String}  searchQuery
     */
    $scope.search = function (searchQuery,$event) {
        //console.log(searchQuery)
        if(selectiveCallAcceptRejectionService.getOperationType() !=='server')
        {
            searchFunc(searchQuery);
        }
        else
        {
           if($event.which === 13)
            {
                searchFunc(searchQuery);
            }
        }
    };
    function searchFunc(searchQuery){
        var words = searchQuery.replace(/[^a-zA-Z0-9 ]/g, " ").split(" ");

        for (var i = 0, ln = words.length; i < ln; i++) {
            if (!words[i]) {
                words.splice(words.indexOf(words[i]), 1);
                ln = words.length;
                i--;
            }
        }

        searchQuery = words.join(" ");

        selectiveCallAcceptRejectionService.search(searchQuery)
            .then(serviceResponseHandler)
            .catch(errorHandler);

        return searchQuery;
    }
    function errorHandler(err) {
        $scope.loadFlag = false;
        $scope.msgType = 'error';
        $scope.msgTxt = err.message || 'An unknown error has occured';
        $scope.showMsg = true;
    }

    function successHandler(message) {
        $scope.msgType = 'success';
        $scope.msgTxt = message;
        $scope.showMsg = true;
    }

    function serviceResponseHandler(response) {
        $scope.selectAll = false;
        $scope.collection = selectiveCallAcceptRejectionService.getList();
        $scope.count = selectiveCallAcceptRejectionService.getCount();
        $scope.pageSize = selectiveCallAcceptRejectionService.getPageSize();
        $scope.pagesLength = selectiveCallAcceptRejectionService.getPagesLength();
        $scope.currentPage = selectiveCallAcceptRejectionService.getCurrentPage();
        $scope.length = selectiveCallAcceptRejectionService.getLength();
        $scope.total = selectiveCallAcceptRejectionService.getTotal();
        $scope.noRecordsMessage = $scope.total === 0 ? "No Records Found" : "The schedule cannot be found.";
        return response;
    }
    $scope.$watch('selectAll', toggleSelect);
    $scope.deleteSettings = function(row) {
        console.log("acceptance---");
        var option = ($scope.tabSelected=='acceptance')?Constants.API.SELECTIVE_CALL_ACCEPTANCE.POST:Constants.API.SELECTIVE_CALL_REJECTION.POST;
        var param = { "updateFeatures": { "updateFeature": [] }};
        param.updateFeatures.updateFeature.push({
            "updateType": "Criteria",
            "phoneNo":row.phoneNo,
            "criteriaInfo": []
        });
        angular.forEach(row.criteriaInfo, function(value, key) {
            $scope.selData[key] = {
                "timeSchedule": row.criteriaInfo[key].timeSchedule,
                "holidaySchedule": row.criteriaInfo[key].holidaySchedule,
                "blacklisted": "false",
                "criteriaName": row.criteriaInfo[key].criteriaName,
                "deleteCriteria":true
            };
        });
        param.updateFeatures.updateFeature[0].criteriaInfo = $scope.selData;
        volteServices.setOption( option );
        volteServices.postData(param).success(function(response) {
            if(response.appHeader.statusCode == "OK") {
                $scope.closeDialog();
                $scope.msgType = "success";
                $scope.msgTxt = 'Successfully Updated';
                $scope.showMsg = true;
            } else {
                $scope.closeDialog();
                $scope.msgType = "error";
                $scope.msgTxt = 'Record Updation Failed';
                $scope.showMsg = true;
            }
        }).error(function() {});
    }

    function toggleSelect(value) {
        console.log(value)
        var list = selectiveCallAcceptRejectionService.getList();
        console.log(list)
        for (var i = 0, ln = list.length; i < ln; i++) {
            list[i].isChecked = value;
        }
    }
    function loadList(){
       selectiveCallAcceptRejectionService.loadList({})
            .then(serviceResponseHandler)
            .catch(errorHandler)
            .then(function() {
                $scope.loadFlag = false;
            });
        console.log($scope.collection);
    }
    $scope.closeDialog = function() {
      try {
        var windowIDs = ngDialog.getOpenDialogs();
        //console.log(windowIDs);
        ngDialog.close(windowIDs[1]);
      } catch(err) {
        //console.log('Error:', err);
      }
    };
   $scope.lookupDialogCallRejection = function(row,rowIndex,gearType) {
        row.isSubmitClicked=false;
        var rowTypeInfo={
            row: row,
            rowIndex : rowIndex,
            gearType : gearType
        };
         var new_dialog = ngDialog.open({
          template: 'partials/features/userFeatures/selectiveCallRejection/dialog/callRejection.html',
            closeByDocument: false,
            className: 'ngdialog-theme-default selective-call-rejection-dialog',
            closeByEscape: false,
            data:  rowTypeInfo,
            preCloseCallback: function(){
                if(row.isSubmitClicked==false && gearType===true)
                {
                  if (!$scope.$$phase)
                  {
                     $scope.$apply(function() {
                      row.settingsInfo.active = false;
                     });
                  }
                  else
                  {
                    row.settingsInfo.active = false;
                  }
                }
               return true;
            },
            scope:$scope,
            controller:'callrejectionDialogCtrl'
        });
    }
    function getScheduleData() {
        $scope.loadFlag     =  true;
        selectiveCallAcceptRejectionService.getScheduleData({})
            .then(function(result) {
                $scope.biz_schedule = result.bzList;
                $scope.holiday_schedule = result.hoList;
            })
            .catch(errorHandler);
    }
    function init() {
        //Initialize Variables
        $scope.loadFlag     =  true;
        $scope.tabSelected = ($state.$current.name.indexOf('selective_call_acceptance') > -1)?'acceptance':'rejection';
        $scope.SELECTIVE_CALL_REJECTION_TITLE = selectiveCallRejectionConst.pageTitle;
        $scope.SELECTIVE_CALL_REJECTION_DESC = $state.current.url=="/sel-call-rejection"?selectiveCallRejectionConst.pageDesc:selectiveCallRejectionConst.pageAcceptanceDesc;
        $scope.instructions = selectiveCallRejectionConst.instructions;
        $scope.featureName = "selective_call_rejection";
        $scope.numberOfSchedules;
        $scope.manage_schedule_filter = enableDisableConst.MANAGE_FILTER;
        $scope.manage_schedule_filter_selected = undefined;
        //$scope.featureName="simultaneous_ring";
        // $scope.toggleSbtBtnStatus=false;
        //API = Constants.API.ANNONYMOUS_CALL_REJECTION;
        serviceResponseHandler();
        getScheduleData();
        loadList();
    }

    init();

};


selectiveAcceptRejectionCtrlBackUp.$inject = ["$scope","$rootScope", "$http", "ngDialog", "$compile", "$state", "selectiveCallAcceptRejectionService","enableDisableConst","selectiveCallRejectionConst","Constants"];
angular.module( window.AppName ).controller("selectiveAcceptRejectionCtrlBackUp", selectiveAcceptRejectionCtrlBackUp);