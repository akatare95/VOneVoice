(function() {
  var groupCtrl = function($scope, $http, callForwardingConst, callForwardingService, Constants, callForwardingConst)
  {
    var abstracts = $scope.abstracts;
    callForwardingService.setPageSize(10);
    function getEnabaleStatus() {
        callForwardingService.getEnabaleStatus({})
        .then(function(result) {
                    $scope.nightForwardingStatus = result.nightForwardingStatus.toUpperCase() == 'ON' ? true : false;
                    // successHandlerMsg('Successfully Updated');
                })
                .catch(errorHandlerMsg);
    }
    getEnabaleStatus();
    abstracts.getService = function() {
      return callForwardingService;
    };
    /**
     * Gets executed before the request gets proxied
     * to the service. Used to un-select all the records
     * that may have been selected BEFORE the operation
     * takes place (i.e. pagination)
     */
    abstracts.beforeLoad = function(operation) {
      console.log(operation)
      toggleSelect(false);

      if (operation === 'init') {
        $scope.loadFlag = true;
      }
    };
    $scope.enableAll = function() {
        var list = callForwardingService.getList(),
            update = [],
            param = {
                "updateFeatures": {
                    "updateFeature": update
                }
            };
        //$scope.loadFlag = true;
        for (var i = 0, ln = list.length; i < ln; i++) {
            if (list[i].isChecked) {
                list[i].multiple = true;
                update.push({
                    "phoneNo": list[i].phoneNo,
                    "updateType": "Status",
                    "userName": list[i].userName,
                    "settingsInfo": {
                        "active": 'true'
                    }
                });
            }
        }
        callForwardingService.enable(param)
            .then(function(response) {
                for (var i = 0, ln = list.length; i < ln; i++) {
                    if (list[i].isChecked) {
                        console.log('entered')
                        list[i].multiple = false;
                        list[i].settingsInfo.active = true;
                    }
                }
                successHandlerMsg("Operation Successful");
            })
            .catch(errorHandlerMsg)
            .then(function(){
                toggleSelect(false);
                $scope.loadFlag = false;
            });
            //$scope.togglestatus=false;
    };
    $scope.disableAll = function() {
            var list = callForwardingService.getList(),
                del = [],
                param = {
                    "updateFeatures": {
                        "updateFeature": []
                    }
                };

            for (var i = 0, ln = list.length; i < ln; i++) {
                if (list[i].isChecked) {
                    list[i].multiple = true;
                    //list[i].settingsInfo.active = false;
                    //list[i].multiple = true;
                    param.updateFeatures.updateFeature.push({
                        "phoneNo": list[i].phoneNo,
                        "updateType": "Status",
                        "userName": list[i].userName,
                        "settingsInfo": {
                            "active": 'false'
                        }
                    });
                }
            }
            callForwardingService.enable(param)
                .then(function(response) {
                    for (var i = 0, ln = list.length; i < ln; i++) {
                        console.log(list[i].isChecked+'actuve')
                        if (list[i].isChecked) {
                            console.log('entered')
                            list[i].multiple = false;
                            list[i].settingsInfo.active = false;
                        }
                    }
                    successHandlerMsg("Operation Successful");
                })
                .catch(function(reject){
                    errorHandlerMsg(reject);
                     for (var i = 0, ln = list.length; i < ln; i++) {
                        console.log(list[i].isChecked+'actuve')
                        if (list[i].isChecked) {
                            console.log('entered')
                            list[i].multiple = false;
                            //list[i].settingsInfo.active = false;
                        }
                    }
                })
                .then(function(){
                    toggleSelect(false);
                });
        }
    function setInstructions() {
      var instructions = callForwardingConst.groupForwardInstructions.instructions;
      abstracts.setInstructions(instructions);
    }

    /**
     * Gets executed after the request gets proxied
     * to the service. Used to un-select the master
     * checkbox
     */
    abstracts.onLoad = function(operation) {
      $scope.selectAll = false;

      if (operation === 'init') {
        $scope.loadFlag = false;
      }
    };
    abstracts.errorHandler = function(err) {
            errorHandlerMsg(err);
    };

    abstracts.successHandler = function(message) {
           successHandlerMsg(message);
    };
    function successHandlerMsg(msg)
    {
            $scope.showMsg = true;
            $scope.msgType = 'success';
            $scope.msgTxt = msg;
    }
    function errorHandlerMsg(err)
        {
            $scope.showMsg = true;
            $scope.msgType = 'error';
            $scope.msgTxt = err.message || "Error performing operation";
        }
    function toggleSelect(value) {
        console.log(value)
        var list = callForwardingService.getList();
        console.log(list)
        for (var i = 0, ln = list.length; i < ln; i++) {
            list[i].isChecked = value;
        }
    }
    $scope.searchFilterArr = [  {   name: "Phone Lines",
                                        value: "phoneNumber"
                                    }, {
                                        name: "User Name",
                                        value: "userName"
                                }];
    $scope.searchFilter = 'phoneNumber';
    $scope.filter = function(filterBy) {
      abstracts.filter(filterBy);
    };
    $scope.search = function(searchQuery,searchFilter,$event) {
            console.log('inside ng-change')
            abstracts.setSearch($scope.searchFilter);
            console.log(searchFilter)
            if(callForwardingService.getOperationType() === 'server' || callForwardingService.getServerSearchValue())
            {
                console.log(searchQuery);
                var isClickedEnterVal = $event == undefined ? $event : $event.which;
                console.log(isClickedEnterVal);
                if(isClickedEnterVal === 13 ||isClickedEnterVal == undefined)
                {
                    abstracts.search(searchQuery);
                }
            }
            else
            {
                abstracts.search(searchQuery);
            }
        //abstracts.search(search
    }
    $scope.setPageSize = function(value) {
            abstracts.setPageSize(value);
        };
    $scope.refresh = function() {
        $scope.manage_schedule_filter_selected = undefined;
        //$scope.filter($scope.manage_schedule_filter_selected);
        $scope.callWaitingSearch = '';
        abstracts.filter($scope.manage_schedule_filter_selected);
        abstracts.refresh();
      };
      $scope.submitStatus = function(row){
        var param = {"updateFeatures":{"updateFeature":[{
                "updateType":"Status",
                "phoneNo":row.phoneNo,
                "settingsInfo":{
                     "nightForwarding": (row.settingsInfo.active)?"Use Group":"Off",
                     "groupNightForwarding": "On"
                }
            }]}};
        callForwardingService.update(param)
                .then(function(result) {
                    console.log(result);
                    successHandlerMsg('Successfully Updated');
                })
                .catch(errorHandlerMsg);
      }
      // function initData () {
      //   $scope.loadFlag     =  false;
      //   $scope.instructions = callForwardingConst.alwaysInstructions.instructions;
      //   $scope.tooltips ="Forwards all calls to your number to another destination";
      //   // getThisData();
      // }
      // initData();
    setInstructions();
    abstracts.init();
  };

  groupCtrl.$inject = ['$scope', '$http', 'callForwardingConst', 'callForwardingService', 'Constants', 'callForwardingConst'];

  angular.module(window.AppName).controller('groupCtrl', groupCtrl);
})();