var musicOnHoldCtrlUser = function($scope,$http,$rootScope,ngDialog,$compile,$state,volteServices,CallWaitingConst,musiconHoldUserConst,Constants,musicOnHoldService) {
    $scope.vzGridTpl = "partials/features/userFeatures/musicOnHold/vz-grid/vz-grid-music-on-hold.html";
    function getData() {
        volteServices.setOption(API.GET);
        volteServices.getData()
            .success(function (result) {
                $scope.loadFlag     =  false;
                 if(result.appHeader.statusCode == "OK")
              {
                $scope.groupActive =result.appResult.serviceRepsonse.groupActive=='true'?true:false;
               console.log($scope.groupActive);
                $scope.collection = result.appResult.serviceRepsonse.featuresResponse;
                var i = 0;
                //console.log($scope.collection);
                angular.forEach($scope.collection, function(value, key) {
                    $scope.collection[i].settingsInfo.active=$scope.collection[i].settingsInfo.active=='true'?true:false;
                   $scope.collection[i].isChecked = false;
                   i++;
                });
                $scope.numberOfLines = $scope.collection.length;
            }
            else
            {
               try
                {
                           $scope.msgType="error";
                           $scope.msgTxt=result.appHeader.statusMessage;
                           $scope.showMsg=true;
                }
                catch(err){

                }
            }
            })
            .error(function (error) {
                $scope.status = 'Unable to load hunt group data: ' + error.message;
                //console.log($scope.collection);
            });
    }
    $scope.refresh=function(){
        getData();
    }
    $scope.setSearchText = function() {
        var filterInputTextval =  $scope.callWaitingSearch;

        if(filterInputTextval!=undefined){
            $scope.search = filterInputTextval.replace(/-/g, "");
        }
        //console.log("search - " + $scope.search );
    }
    $scope.enableAll=function()
    {
        // anonymusCallRejectionService.setOption(API.ENABLE);
        // anonymusCallRejectionService.getData().success(function(result)
        // {
        //      if(result.appHeader.statusCode == "OK")
        //      {
                var param = { "updateFeatures": { "updateFeature": [] }};
                for(var loop=0;loop<$scope.collection.length;loop++)
                {
                     if($scope.collection[loop].isChecked==true)
                     {
                         $scope.collection[loop].settingsInfo.active = true;
                         $scope.collection[loop].isChecked=false;
                         $scope.collection[loop].multiple = true;
                         param.updateFeatures.updateFeature.push({"phoneNo":$scope.collection[loop].phoneNo,"updateType":"Status","userName":$scope.collection[loop].userName,"settingsInfo":{"active":$scope.collection[loop].settingsInfo.active.toString()}});
                     }
                }
                 //console.log(JSON.stringify(param));
                 if( param.updateFeatures.updateFeature.length>0)
                 {
                     postLinkData(param);
                 }
                 else
                 {
                     $scope.showMsg=true;
                    $scope.msgType="error";
                           $scope.msgTxt="Please select a record";
                           console.log("$scope.showMsg"+$scope.showMsg)
                 }
        //     }
        // });
    }
    $scope.disableAll=function()
    {
        // anonymusCallRejectionService.setOption(API.DISABLE);
        // anonymusCallRejectionService.getData().success(function(result)
        // {
        //      if(result.appHeader.statusCode == "OK")
        //      {
                var param = { "updateFeatures": { "updateFeature": [] }};
                for(var loop=0;loop<$scope.collection.length;loop++)
                {
                    if($scope.collection[loop].isChecked==true)
                     {
                         $scope.collection[loop].settingsInfo.active = false;
                         $scope.collection[loop].isChecked=false;
                         $scope.collection[loop].multiple = true;
                         param.updateFeatures.updateFeature.push({"phoneNo":$scope.collection[loop].phoneNo,"updateType":"Status","userName":$scope.collection[loop].userName,"settingsInfo":{"active":$scope.collection[loop].settingsInfo.active.toString()}});
                    }
                }
                //console.log(JSON.stringify(param));
                 if( param.updateFeatures.updateFeature.length>0)
                 {
                     postLinkData(param);
                 }
                 else
                 {
                    $scope.msgType="error";
                           $scope.msgTxt="Please select a record";
                           $scope.showMsg=true;
                 }
                // postLinkData(param);
        //     }
        // });
    }
    function postLinkData(param){
        volteServices.setOption(API.POST);
        //console.log();
        volteServices.postData(param)
            .success(function (result) {
                // =result.updateFeaturesResponse.response;
                 if(result.appHeader.statusCode == "OK")
              {
                $scope.msgType="success";
                           $scope.msgTxt="Successfully updated";
                           $scope.showMsg=true;
              }
              else
              {
                 $scope.msgType="error";
                           $scope.msgTxt="Unable to Load data";
                           $scope.showMsg=true;
              }
            });

    }
    function checkStatus(){
         musicOnHoldService.musiconhold()
               .success(function (result) {
                    try {
                              var successResponse=result.appResult.serviceRepsonse;
                              //console.log("Su
                              $scope.isActive = successResponse.active;
                              console.log($scope.isActive);
                        }   catch(err) {}

                }).error(function (error) {});
    }

    $scope.filterFn = function(row) {
        if($scope.manage_schedule_filter_selected!=undefined)
        {
         console.log(row.settingsInfo.active,$scope.manage_schedule_filter_selected)
          return row.settingsInfo.active===$scope.manage_schedule_filter_selected;
        }
        else
        {
            return true;
        }
    }
    function init() {

        //Initialize Variables
        $scope.loadFlag     =  true;
        $scope.AUTOMATIC_CALLBACK_TITLE=musiconHoldUserConst.pageTitle;
        $scope.AUTOMATIC_CALLBACK_DESC=musiconHoldUserConst.pageDesc;
        $scope.instructions = musiconHoldUserConst.instructions;
        $scope.searchFilterArr = [  {   name: "Phone Lines",
                                        value: "phoneNumber"
                                    }, {
                                        name: "User Name",
                                        value: "userName"
                                }];
        $scope.searchFilter = 'phoneNumber';
        $scope.collection = {};
        $scope.numberOfSchedules;
        $scope.manage_schedule_filter = CallWaitingConst.MANAGE_FILTER;
        $scope.manage_schedule_filter_selected = undefined;
        $scope.featureName="music_on_hold_user";
        $scope.msgType=null;
        $scope.showMsg =false;
        $scope.msgTxt=null;
        $scope.bsft=false;
        // $scope.isActive=false;
        API = Constants.API.MUSIC_ON_HOLD_USER;
        checkStatus();
        //Load available Hunt Groups
        getData();
    }

    init();

};


musicOnHoldCtrlUser.$inject = ["$scope","$rootScope", "$http", "ngDialog", "$compile", "$state", "volteServices","CallWaitingConst","musiconHoldUserConst","Constants","musicOnHoldService"];
angular.module( window.AppName ).controller("musicOnHoldCtrlUser", musicOnHoldCtrlUser);