var preAlertAnnouncementCtrl = function($scope,$http,$rootScope,ngDialog,$compile,$state,preAlertAnnouncementService,enableDisableConst,preAlertingAnnouncementConst,Constants) {
    $scope.vzGridTpl = "partials/features/userFeatures/preAlerting/vz-grid/vz.grid.pre-alerting.html";
    $scope.refresh = function() {
        $scope.callWaitingSearch = '';
        preAlertAnnouncementService.clientSearch('');
        preAlertAnnouncementService.loadList({}, true)
            .then(serviceResponseHandler)
            .catch(errorHandler)
            .then(function() {
                $scope.loadFlag = false;
            });
        //$scope.filterBy = '';
        //$scope.callWaitingSearch = '';
        //abstracts.filter($scope.filterBy);
    }
        /**
         * Paginate previous page
         *
         * @method     prev
         */
    $scope.prev = function() {
        //toggleSelect(false);
        preAlertAnnouncementService.prevPage()
            .then(serviceResponseHandler)
            .catch(errorHandler);
    };

    /**
     * Paginate next page
     *
     * @method     next
     */
    $scope.next = function() {
        //toggleSelect(false);
        console.log('next')
        preAlertAnnouncementService.nextPage()
            .then(serviceResponseHandler)
            .catch(errorHandler);
    };

    /**
     * Update page size and refresh
     *
     * @method     setPageSize
     * @param      {Number}  value   Rows per page value
     */
    $scope.setPageSize = function(value) {
        //toggleSelect(false);
        preAlertAnnouncementService.setPageSize(value)
            .then(serviceResponseHandler)
            .catch(errorHandler);
    };

    /**
     * Performs filter operation
     *
     * @method     filter
     * @param      {String}  filterBy  The type by which to filter against (business or holiday)
     */

    /**
     * Performs search operation
     *
     * @method     search
     * @param      {String}  searchQuery
     */
    $scope.search = function (searchQuery,searchFilter,$event) {
        console.log(searchFilter)
        if(preAlertAnnouncementService.getOperationType() ==='server' || preAlertAnnouncementService.getServerSearchValue())
        {
            var isClickedEnterVal = $event == undefined ? $event : $event.which;
           if(isClickedEnterVal === 13 ||isClickedEnterVal == undefined)
            {
                searchFunc(searchQuery,searchFilter);
            }
        }
        else
        {
           searchFunc(searchQuery,searchFilter);
        }
    };
    function searchFunc(searchQuery,searchFilter){
        preAlertAnnouncementService.search(searchQuery,searchFilter)
            .then(serviceResponseHandler)
            .catch(errorHandler);

        return searchQuery;
    }
    function errorHandler(err) {
        $scope.loadFlag = false;
        $scope.msgType = 'error';
        $scope.msgTxt = err.message || 'An unknown error has occured';
        $scope.showMsg = true;
    }

    function successHandler(message) {
        $scope.msgType = 'success';
        $scope.msgTxt = message;
        $scope.showMsg = true;
    }

    function serviceResponseHandler(response) {
        $scope.selectAll = false;
        $scope.collection = preAlertAnnouncementService.getList();
        console.log($scope.collection)
        $scope.count = preAlertAnnouncementService.getCount();
        $scope.pageSize = preAlertAnnouncementService.getPageSize();
        console.log($scope.pageSize);
        $scope.pagesLength = preAlertAnnouncementService.getPagesLength();
        $scope.currentPage = preAlertAnnouncementService.getCurrentPage();
        $scope.length = preAlertAnnouncementService.getLength();
        $scope.total = preAlertAnnouncementService.getTotal();
        $scope.noRecordsMessage = $scope.total === 0 ? "No Records Found" : "The schedule cannot be found.";
        $scope.serverSearch = preAlertAnnouncementService.getServerSearchValue();
        return response;
    }
    //$scope.$watch('selectAll', toggleSelect);
    $scope.updateData=function(row){
        console.log(row);
        var params = {
                        "updateFeatures": {
                            "updateFeature": [{
                                "phoneNo": row.phoneNo,
                                "updateType": "Status",
                                "settingsInfo": {}
                            }]
                        }
                    };
        var option = Constants.API.PRE_ALERT_ANNOUNCEMENT.POST;
        var updateFeature = JSON.parse(JSON.stringify(row));
        updateFeature.settingsInfo.active="false";
        params.updateFeatures.updateFeature[0].settingsInfo=updateFeature.settingsInfo;
        params.updateFeatures.updateFeature[0].settingsInfo.audioFileDescription = undefined;
        params.updateFeatures.updateFeature[0].settingsInfo.audioMediaType = undefined;
        params.updateFeatures.updateFeature[0].criteriaInfo=updateFeature.criteriaInfo;
        preAlertAnnouncementService.update(params)
            .then(function(result) {
               row.settingsInfo.active=false;
               successHandler("Successfully updated.")
            })
            .catch(function(error){
              row.settingsInfo.active=true;
              errorHandler(error)
            });
    }
    function toggleSelect(value) {
        console.log(value)
        var list = preAlertAnnouncementService.getList();
        console.log(list)
        for (var i = 0, ln = list.length; i < ln; i++) {
            list[i].isChecked = value;
        }
    }
    function loadList(){
       preAlertAnnouncementService.loadList({})
            .then(serviceResponseHandler)
            .catch(errorHandler)
            .then(function() {
                $scope.loading = false;
            });
        console.log($scope.collection);
    }
    $scope.closeDialog = function() {
      try {
        var windowIDs = ngDialog.getOpenDialogs();
        //console.log(windowIDs);
        ngDialog.close(windowIDs[1]);
      } catch(err) {
        //console.log('Error:', err);
      }
    };
    $scope.setCustomFile = function() {
        console.log('inside custom')
        var new_dialog = ngDialog.open({
          template: 'partials/components/dialog/instructionsLink.html',
          closeByDocument: false,
          className: 'ngdialog-theme-default selective-call-rejection-dialog',
          closeByEscape: false,
          scope: $scope,
          controller: 'instructionsLinkCtrl'
        });
      }
    $scope.lookupDialogPreAlert = function(row,rowInd,type) {
        row.isSubmitClicked = false;
        var rowTypeInfo={
            row: row,
            rowIndex : rowInd,
            gearType : type
        };
        var new_dialog = ngDialog.open({
            template: 'partials/features/userFeatures/preAlerting/dialog/preAlerting.html',
            className: 'ngdialog-theme-default pre-alerting-announcement-dialog',
            closeByDocument: false,
            closeByEscape: false,
            preCloseCallback: function(){

                if(row.isSubmitClicked === false && type===true)
                {
                   if(!$scope.$$phase) {
                       $scope.$apply(function() {
                        row.settingsInfo.active = false;
                       });
                   }
                   else
                   {
                      row.settingsInfo.active = false;
                   }
                }
               return true;
            },
            scope: $scope,
            data:rowTypeInfo,
            controller:'preAlertDialogCtrl'
        });
    }
    function getScheduleData() {
        //$scope.loadFlag     =  true;
        preAlertAnnouncementService.getScheduleData({})
            .then(function(result) {
                $scope.biz_schedule = result.bzList;
                $scope.holiday_schedule = result.hoList;
            })
            .catch(errorHandler);
    }
    function init() {
        //Initialize Variables
        $scope.loading     =  true;
        $scope.PRE_ALERT_ANNOUNCEMENT_TITLE = preAlertingAnnouncementConst.pageTitle;
        $scope.PRE_ALERT_ANNOUNCEMENT_DESC = preAlertingAnnouncementConst.pageDesc;
        $scope.instructions = preAlertingAnnouncementConst.instructions;
        $scope.featureName="pre_alert_announcement";
        $scope.searchFilterArr = [  {   name: "Phone Lines",
                                        value: "phoneNumber"
                                    }, {
                                        name: "User Name",
                                        value: "userName"
                                }];
        $scope.searchFilter = 'phoneNumber';
        $scope.numberOfSchedules;
        $scope.manage_schedule_filter = enableDisableConst.MANAGE_FILTER;
        $scope.manage_schedule_filter_selected = undefined;
        //$scope.featureName="simultaneous_ring";
        // $scope.toggleSbtBtnStatus=false;
        //API = Constants.API.ANNONYMOUS_CALL_REJECTION;
        serviceResponseHandler();
        getScheduleData();
        loadList();
    }

    init();

};


preAlertAnnouncementCtrl.$inject = ["$scope","$rootScope", "$http", "ngDialog", "$compile", "$state", "preAlertAnnouncementService","enableDisableConst","preAlertingAnnouncementConst","Constants"];
angular.module( window.AppName ).controller("preAlertAnnouncementCtrl", preAlertAnnouncementCtrl);