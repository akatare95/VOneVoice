app.controller('selectiveCallAcceptRejectionCtrl', ["$scope", "$rootScope", "$http", "ngDialog", "$compile", "$state", "anonymusCallRejectionService", "enableDisableConst", "UserConfig", "volteServices", "Constants", "HuntGroupConst", "selectiveCallRejectionConst",
    function($scope, $http, $rootScope, ngDialog, $compile, $state, anonymusCallRejectionService, enableDisableConst, UserConfig, volteServices, Constants, HuntGroupConst, selectiveCallRejectionConst) {
        $scope.tplUrl = 'partials/features/userFeatures/selectiveCallRejection/vz-grid/vz.grid.selective-call-acceptance.html';
        $scope.tabSelected = 'acceptance';
        $scope.SELECTIVE_CALL_REJECTION_TITLE = selectiveCallRejectionConst.pageTitle;
        $scope.SELECTIVE_CALL_REJECTION_DESC = $scope.tabSelected=="acceptance"?selectiveCallRejectionConst.pageAcceptanceDesc:selectiveCallRejectionConst.pageDesc;
        var searchField;
        $scope.abstracts = {
            /**
             * Basic initializer
             */
            init: function() {
                var abstracts = $scope.abstracts,
                    service = abstracts.getService(),
                    params = {};

                $scope.searchQuery = service.getSearchQuery();
                $scope.filterBy = service.getFilter();
                $scope.selectAll = false;
                // abstracts.beforeLoad('init');
                $scope.loading = true;
                abstracts.serviceResponseHandler();
                //abstracts.setInstructions();
                service.loadList(params)
                    .then(abstracts.serviceResponseHandler)
                    .catch(abstracts.errorHandler)
                    .then(function() {
                        $scope.loading = false;
                        // abstracts.onLoad('init');
                        $scope.initialized = true;
                    });
                // volteServices.setOption( Constants.API.CALL_FORWARDING[$scope.tabSelected.toUpperCase()+'_GET'] );
                // volteServices.getData().success(function( response ){
                //    console.log(response)
                // });
            },

            /**
             * Getter for the individual service singleton
             *
             * @abstract
             * @returns {Service}
             */
            getService: function() {
                throw new Error("The getService() abstract method has not been implemented");
            },
            setInstructions: function(instructions) {
                $scope.instructions = instructions;
            },
            /**
             * Executes before making a service request
             *
             * @abstract
             */
            beforeLoad: function() {},

            /**
             * Executes after the service request gets processed
             *
             * @abstract
             */
            onLoad: function() {},

            /**
             * Process the returned values
             */
            serviceResponseHandler: function() {
                var abstracts = $scope.abstracts,
                    service = abstracts.getService();

                $scope.collection = service.getList();
                console.log($scope.collection);
                $scope.count = service.getCount();
                $scope.pageSize = service.getPageSize();
                console.log($scope.pageSize);
                $scope.pagesLength = service.getPagesLength();
                $scope.currentPage = service.getCurrentPage();
                console.log($scope.currentPage);
                $scope.length = service.getLength();
                $scope.total = service.getTotal();
            },

            /**
             * Basic Error Handler
             *
             * @abstract
             * @param {Error} error - The error instance
             */
            errorHandler: function() {
                throw new Error("The errorHandler() abstract method has not been implemented");
            },
            errorHandlerMsg: function(err) {
                $scope.showMsg = true;
                $scope.msgType = 'error';
                $scope.msgTxt = err.message || "Error performing operation";
            },

            /**
             * Basic Success Handler
             *
             * @abstract
             * @param {String} message - The success message
             */
            successHandler: function() {},
            successHandlerMsg: function(msg) {
                $scope.showMsg = true;
                $scope.msgType = 'success';
                $scope.msgTxt = msg;
            },

            /**
             * Event handler for the "reload" or "refresh" button that will force
             * the lines service to purge existing data and fetch new ones
             */
            refresh: function() {
                var abstracts = $scope.abstracts,
                    service = abstracts.getService();
                service.clientSearch('');
                abstracts.beforeLoad('refresh');
                service.reload()
                    .then(abstracts.serviceResponseHandler)
                    .catch(abstracts.errorHandler)
                    .then(function() {
                        abstracts.onLoad('refresh');
                    });
            },

            /**
             * Wrapper function for the configured service to get the previous page
             */
            prev: function() {
                console.log('prev');
                var abstracts = $scope.abstracts,
                    service = abstracts.getService();

                abstracts.beforeLoad('prev');

                service.prevPage()
                    .then(abstracts.serviceResponseHandler)
                    .catch(abstracts.errorHandler)
                    .then(function() {
                        console.log('prev');
                        abstracts.onLoad('prev');
                    });
            },
            closeDialog: function() {
                    try {
                        var windowIDs = ngDialog.getOpenDialogs();
                        ngDialog.close(windowIDs[1]);
                    } catch (err) {
                        //console.log('Error:', err);
                    }
            },

            /**
             * Wrapper function for the configured service to get the next page
             */
                next: function() {
                var abstracts = $scope.abstracts,
                    service = abstracts.getService();

                abstracts.beforeLoad('next');

                service.nextPage()
                    .then(abstracts.serviceResponseHandler)
                    .catch(abstracts.errorHandler)
                    .then(function() {
                        abstracts.onLoad('next');
                    });
            },

            /**
             * Sets the pagination page size
             */
            setPageSize: function(value) {
                var abstracts = $scope.abstracts,
                    service = abstracts.getService();

                abstracts.beforeLoad('pagesize');

                service.setPageSize(value)
                    .then(abstracts.serviceResponseHandler)
                    .catch(abstracts.errorHandler)
                    .then(function() {
                        abstracts.onLoad('pagesize');
                    });
            },

            /**
             * Search wrapper
             *
             * @param {String} query - The combined search query string
             */
            setSearch: function(searchQuery){
               searchField = searchQuery;
               console.log(searchField);
            },
            search: function(query) {
                var abstracts = $scope.abstracts,
                    service = abstracts.getService();
                abstracts.beforeLoad('search');

                service.search(query,searchField)
                    .then(abstracts.serviceResponseHandler)
                    .catch(abstracts.errorHandler)
                    .then(function() {
                        console.log(query);
                        abstracts.onLoad('search');
                    });
            },

            /**
             * Filter wrapper
             *
             * @param {String} filterBy - The string key by which to filter
             */
            filter: function(filterBy) {
                var abstracts = $scope.abstracts,
                    service = abstracts.getService();

                abstracts.beforeLoad('filter');

                service.filter(filterBy)
                    .then(abstracts.serviceResponseHandler)
                    .catch(abstracts.errorHandler)
                    .then(function() {
                        abstracts.onLoad('filter');
                    });
            },
            counterVal: function(val) {
                $scope.counterVal = val;
                return $scope.counterVal;
            }
        };
        // $scope.$watch('tabSelected',function(value){
        //    if(value == 'acceptance')
        //    {
        //      $scope.tplUrl = 'partials/features/userFeatures/selectiveCallRejection/vz-grid/vz.grid.selective-call-rejection.html';
        //    }
        //    else
        //    {
        //      $scope.tplUrl = 'partials/features/userFeatures/selectiveCallRejection/vz-grid/vz.grid.selective-call-rejection.html';
        //    }
        // });
        $scope.selectTab=function(tabSelected)
        {
          $scope.tplUrl = 'partials/features/userFeatures/selectiveCallRejection/vz-grid/vz.grid.selective-call-'+tabSelected+'.html';
          $scope.tabSelected = tabSelected;
          $scope.featureName = "call_forwarding_" + $scope.tabSelected;
          $scope.SELECTIVE_CALL_REJECTION_TITLE = selectiveCallRejectionConst.pageTitle;
          $scope.SELECTIVE_CALL_REJECTION_DESC = tabSelected=="acceptance"?selectiveCallRejectionConst.pageAcceptanceDesc:selectiveCallRejectionConst.pageDesc;
          $scope.searchFilterArr = [  {   name: "Phone Lines",
                                        value: "phoneNumber"
                                    }, {
                                        name: "User Name",
                                        value: "userName"
                                }];
          $scope.searchFilter = 'phoneNumber';
        }
        // $scope.selectTab = function(tabName) {
        // tabSelected=='acceptance'
        //     $scope.tplUrl = "partials/features/userFeatures/callForwarding/vz-grid/" + tabName + ".html";
        //     $scope.tabSelected = tabName;
        //     $scope.featureName = "call_forwarding_" + tabName;
        //     $scope.showMsg = false;
        // }
        function getScheduleData() {
        //$scope.loadFlag     =  true;
        volteServices.setOption( Constants.API.SCHEDULE.LIST );
        volteServices.getData().success(function( response ){
            // $scope.loadFlag     =  false;
            if( response.appHeader.statusCode == "OK")  {
                var scheduleList = response.appResult.serviceRepsonse.scheduleList;
                var bzList = [];
                var hoList = [];
                angular.forEach(scheduleList, function(value, key) {
                    if (value.scheduleType == 'HOLIDAY') {
                        hoList.push({'name':value.scheduleName, 'value':value.scheduleName});
                    } else {
                        bzList.push({'name':value.scheduleName, 'value':value.scheduleName});
                    }
                });
                $scope.biz_schedule = bzList;
                $scope.holiday_schedule = hoList;
            }
            else
            {
                $scope.biz_schedule = [];
                $scope.holiday_schedule = [];
                $scope.showMsg=true;
                $scope.msgType="error";
                $scope.msgTxt=response.appHeader.statusMessage;
            }
        }).error(function() {});
        }
        function init() {
            //Initialize Variables
            //$scope.tabSelected = ($state.$current.name.indexOf('selective_call_acceptance') > -1)?'acceptance':'rejection';
            $scope.featureName = "call_forwarding_" + $scope.tabSelected;
            getScheduleData();
            //$scope.collection = [];
            //$scope.manage_schedule_filter = enableDisableConst.MANAGE_FILTER;
            //$scope.loadFlag = true;
            //$scope.instructions = '';
            //  $scope.instructions = '';
            //  $scope.selectiveData=[];
            // $scope.CALL_FORWARDING_TITLE = selectiveCallRejectionConst.pageTitle;
            // $scope.CALL_FORWARDING_DESC = selectiveCallRejectionConst.pageDesc;
        }
        init();
    }
]);