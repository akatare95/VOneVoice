app.controller('callForwardingCtrl', ["$scope", "$rootScope", "$http", "ngDialog", "$compile", "$state", "anonymusCallRejectionService", "enableDisableConst", "UserConfig", "volteServices", "Constants", "HuntGroupConst", "callForwardingConst",
    function($scope, $http, $rootScope, ngDialog, $compile, $state, anonymusCallRejectionService, enableDisableConst, UserConfig, volteServices, Constants, HuntGroupConst, callForwardingConst) {
        $scope.tplUrl = 'partials/features/userFeatures/callForwarding/vz-grid/group.html';
        var searchField;
        $scope.abstracts = {
            /**
             * Basic initializer
             */
            init: function() {
                var abstracts = $scope.abstracts,
                    service = abstracts.getService(),
                    params = {};
                console.log('init');
                $scope.searchQuery = service.getSearchQuery();
                $scope.filterBy = service.getFilter();
                console.log($scope.collection);
                $scope.selectAll = false;
                //abstracts.beforeLoad('init');
                $scope.loading = true;
                abstracts.serviceResponseHandler();
                //abstracts.setInstructions();
                service.loadList(params)
                    .then(abstracts.serviceResponseHandler)
                    .catch(abstracts.errorHandler)
                    .then(function() {
                        $scope.loading = false;
                       // abstracts.onLoad('init');
                        $scope.initialized = true;
                    });
                // volteServices.setOption( Constants.API.CALL_FORWARDING[$scope.tabSelected.toUpperCase()+'_GET'] );
                // volteServices.getData().success(function( response ){
                //    console.log(response)
                // });
            },

            /**
             * Getter for the individual service singleton
             *
             * @abstract
             * @returns {Service}
             */
            getService: function() {
                throw new Error("The getService() abstract method has not been implemented");
            },
            setInstructions: function(instructions) {
                $scope.instructions = instructions;
            },
            /**
             * Executes before making a service request
             *
             * @abstract
             */
            beforeLoad: function() {},

            /**
             * Executes after the service request gets processed
             *
             * @abstract
             */
            onLoad: function() {},

            /**
             * Process the returned values
             */
            serviceResponseHandler: function() {
                var abstracts = $scope.abstracts,
                    service = abstracts.getService();

                $scope.collection = service.getList();
                console.log($scope.collection);
                $scope.count = service.getCount();
                $scope.pageSize = service.getPageSize();
                $scope.pagesLength = service.getPagesLength();
                $scope.currentPage = service.getCurrentPage();
                $scope.length = service.getLength();
                $scope.total = service.getTotal();
                $scope.serverSearch = service.getServerSearchValue();
                console.log($scope.serverSearch)
            },

            /**
             * Basic Error Handler
             *
             * @abstract
             * @param {Error} error - The error instance
             */
            errorHandler: function() {
                throw new Error("The errorHandler() abstract method has not been implemented");
            },
            errorHandlerMsg: function(err) {
                $scope.showMsg = true;
                $scope.msgType = 'error';
                $scope.msgTxt = err.message || "Error performing operation";
            },

            /**
             * Basic Success Handler
             *
             * @abstract
             * @param {String} message - The success message
             */
            successHandler: function() {},
            successHandlerMsg: function(msg) {
                $scope.showMsg = true;
                $scope.msgType = 'success';
                $scope.msgTxt = msg;
            },

            /**
             * Event handler for the "reload" or "refresh" button that will force
             * the lines service to purge existing data and fetch new ones
             */
            refresh: function() {
                var abstracts = $scope.abstracts,
                    service = abstracts.getService();
                service.clientSearch('');
                abstracts.beforeLoad('refresh');
                service.reload()
                    .then(abstracts.serviceResponseHandler)
                    .catch(abstracts.errorHandler)
                    .then(function() {
                        abstracts.onLoad('refresh');
                    });
            },

            /**
             * Wrapper function for the configured service to get the previous page
             */
            prev: function() {
                var abstracts = $scope.abstracts,
                    service = abstracts.getService();

                abstracts.beforeLoad('prev');

                service.prevPage()
                    .then(abstracts.serviceResponseHandler)
                    .catch(abstracts.errorHandler)
                    .then(function() {
                        abstracts.onLoad('prev');
                    });
            },
            closeDialog: function() {
                    try {
                        var windowIDs = ngDialog.getOpenDialogs();
                        ngDialog.close(windowIDs[1]);
                    } catch (err) {
                        //console.log('Error:', err);
                    }
            },

            /**
             * Wrapper function for the configured service to get the next page
             */
                next: function() {
                var abstracts = $scope.abstracts,
                    service = abstracts.getService();

                abstracts.beforeLoad('next');

                service.nextPage()
                    .then(abstracts.serviceResponseHandler)
                    .catch(abstracts.errorHandler)
                    .then(function() {
                        abstracts.onLoad('next');
                    });
            },

            /**
             * Sets the pagination page size
             */
            setPageSize: function(value) {
                var abstracts = $scope.abstracts,
                    service = abstracts.getService();

                abstracts.beforeLoad('pagesize');

                service.setPageSize(value)
                    .then(abstracts.serviceResponseHandler)
                    .catch(abstracts.errorHandler)
                    .then(function() {
                        abstracts.onLoad('pagesize');
                    });
            },

            /**
             * Search wrapper
             *
             * @param {String} query - The combined search query string
             */
            setSearch: function(searchQuery){
               searchField = searchQuery;
               console.log(searchField);
            },
            search: function(query) {
                var abstracts = $scope.abstracts,
                    service = abstracts.getService(),
                    words = query.replace(/[^a-zA-Z0-9 ]/g, " ").split(" ");

                for (var i = 0, ln = words.length; i < ln; i++) {
                    if (!words[i]) {
                        words.splice(words.indexOf(words[i]), 1);
                        ln = words.length;
                        i--;
                    }
                }

                query = words.join(" ");

                abstracts.beforeLoad('search');

                service.search(query,searchField)
                    .then(abstracts.serviceResponseHandler)
                    .catch(abstracts.errorHandler)
                    .then(function() {
                        abstracts.onLoad('search');
                    });
            },

            /**
             * Filter wrapper
             *
             * @param {String} filterBy - The string key by which to filter
             */
            filter: function(filterBy) {
                var abstracts = $scope.abstracts,
                    service = abstracts.getService();

                abstracts.beforeLoad('filter');

                service.filter(filterBy)
                    .then(abstracts.serviceResponseHandler)
                    .catch(abstracts.errorHandler)
                    .then(function() {
                        abstracts.onLoad('filter');
                    });
            },
            counterVal: function(val) {
                $scope.counterVal = val;
                return $scope.counterVal;
            }
        };
        $scope.selectTab = function(tabName) {
            $scope.tplUrl = "partials/features/userFeatures/callForwarding/vz-grid/" + tabName + ".html";
            $scope.tabSelected = tabName;
            $scope.featureName = "call_forwarding_" + tabName;
            $scope.showMsg = false;
        }

        $scope.groupLevelFeature = function() {
            console.log('Call or redirect to Group level feature ...');
            $state.go('features.enterprise.group_forwarding');
        }

        function getScheduleData() {
        //$scope.loadFlag     =  true;
        volteServices.setOption( Constants.API.SCHEDULE.LIST );
        volteServices.getData().success(function( response ){
            // $scope.loadFlag     =  false;
            if( response.appHeader.statusCode == "OK")  {
                var scheduleList = response.appResult.serviceRepsonse.scheduleList;
                var bzList = [];
                var hoList = [];
                angular.forEach(scheduleList, function(value, key) {
                    if (value.scheduleType == 'HOLIDAY') {
                        hoList.push({'name':value.scheduleName, 'value':value.scheduleName});
                    } else {
                        bzList.push({'name':value.scheduleName, 'value':value.scheduleName});
                    }
                });
                $scope.biz_schedule = bzList;
                $scope.holiday_schedule = hoList;
            }
            else
            {
                $scope.biz_schedule = [];
                $scope.holiday_schedule = [];
                $scope.showMsg=true;
                $scope.msgType="error";
                $scope.msgTxt=response.appHeader.statusMessage;
            }
        }).error(function() {});
        }
        function init() {
            //Initialize Variables
            $scope.tabSelected = 'group';
            $scope.featureName = "call_forwarding_" + $scope.tabSelected;
            getScheduleData();
            //$scope.collection = [];
            $scope.manage_schedule_filter = enableDisableConst.MANAGE_FILTER;
            //$scope.loadFlag = true;
            //$scope.instructions = '';
            //  $scope.instructions = '';
            //  $scope.selectiveData=[];
            $scope.CALL_FORWARDING_TITLE = callForwardingConst.pageTitle;
            $scope.CALL_FORWARDING_DESC = callForwardingConst.pageDesc;
        }
        init();
    }
]);
