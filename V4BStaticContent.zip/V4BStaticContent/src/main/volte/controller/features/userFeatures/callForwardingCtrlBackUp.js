//var callForwardingCtrl = function($scope,$http,$rootScope,ngDialog,$compile,$state,anonymusCallRejectionService,CallWaitingConst,UserConfig,volteServices,Constants,HuntGroupConst,callForwardingConst) {

    app.controller('callForwardBackUpCtrl',["$scope","$rootScope", "$http", "ngDialog", "$compile", "$state", "anonymusCallRejectionService","CallWaitingConst","UserConfig","volteServices","Constants","HuntGroupConst","callForwardingConst",
                                         function($scope,$http,$rootScope,ngDialog,$compile,$state,anonymusCallRejectionService,CallWaitingConst,UserConfig,volteServices,Constants,HuntGroupConst,callForwardingConst) {

    $scope.currentGridTpl = "partials/features/userFeatures/callForwarding/vz-grid/group.html";

    $scope.initCallForwarding = function(){
        $scope.collectionCallForwarding;
        init();
    }

    $scope.vzGridTpl = ""
    $scope.deleteIndex = 25;

 $scope.setSearchText = function() {
        var filterInputTextval =  $scope.callWaitingSearch;
        console.log(filterInputTextval);
        if(filterInputTextval!=undefined){
            $scope.search = filterInputTextval.replace(/-/g, "");
        }
        console.log("search - " + $scope.search );
    }
    function getEnabaleStatus() {

        volteServices.setOption( Constants.API.GROUP_FORWARDING.GET );
        volteServices.getData().success(function( response ){

            console.log("Response - " + JSON.stringify(response) );
            $scope.loadFlag     =  false;

            if( response.appHeader.statusCode == "OK")  {

                if( response.appResult.serviceRepsonse.nightForwardingStatus.toUpperCase() == 'ON' ){
                    $scope.nightForwardingStatus = true;
                } else {
                    $scope.nightForwardingStatus = false;
                }

                //Load available Hunt Groups
                clearCriteria();
                getData();
                getScheduleData();
                $scope.loadFlag     =  false;


            }

        });

    }
    // $scope.$watch('tabSelected',function(newVal,oldVal){
    //    if (newVal == "group")
    //     {
    //       $scope.instructions = callForwardingConst.groupForwardInstructions.instructions;
    //     }
    //     else
    //     {
    //       $scope.instructions = callForwardingConst.selectiveForwardInstructions.instructions;
    //     }
    // })
    function getData() {

        console.log("getting data from callforwarding");

        if ($scope.tabSelected == "group")
        {
          $scope.instructions = callForwardingConst.groupForwardInstructions.instructions;
          console.log($scope.instructions )
          $scope.tooltips ="Forwards select calls based on predefined criteria including specific numbers that might call you and schedules for the service to be active";}
        if ($scope.tabSelected == "selective")
        {
          $scope.instructions = callForwardingConst.selectiveForwardInstructions.instructions;
          $scope.tooltips ="Forwards select calls based on predefined criteria including specific numbers that might call you and schedules for the service to be active";}
        if ($scope.tabSelected == "always")
        {
          $scope.instructions = callForwardingConst.alwaysInstructions.instructions;
          $scope.tooltips ="Forwards all calls to your number to another destination";}
        if ($scope.tabSelected == "busy")
        {
          $scope.instructions = callForwardingConst.busyInstructions.instructions;
          $scope.tooltips ="Forwards calls to another destination when your line is busy";}
        if ($scope.tabSelected == "noAnswer")
        {
          $scope.instructions = callForwardingConst.noAnswerInstructions.instructions;
          $scope.tooltips ="Forwards calls to another destination when you don't answer your line after 5 or more rings";}

       console.log("Url "+Constants.API.CALL_FORWARDING[$scope.tabSelected.toUpperCase()+'_GET']);

        volteServices.setOption( Constants.API.CALL_FORWARDING[$scope.tabSelected.toUpperCase()+'_GET'] );
        volteServices.getData().success(function( response ){
           // $scope.loadFlag     =  false;
            if( response.appHeader.statusCode == "OK")  {
                var resp = response.appResult.serviceRepsonse;
                if ($scope.tabSelected == 'group') {
                    $scope.collection = resp.featuresResponse;
                    $scope.collectionCallForwarding = resp.featuresResponse;
                    $scope.groupData = resp;
                    var i = 0;
                    // changing string to boolean
                    angular.forEach($scope.collection, function(value, key) {
                       $scope.collection[i].settingsInfo.active=($scope.collection[i].settingsInfo.nightForwarding=='Use Group')?true:false;
                       i++;
                    });
                } else {
                    $scope.collection = resp.featuresResponse;
                    $scope.selectiveData = resp;
                    var i = 0;

                    // changing string to boolean
                    angular.forEach($scope.collection, function(value, key) {
                        $scope.collection[i].settingsInfo.active=($scope.collection[i].settingsInfo.active=='true')?true:false;
                       $scope.collection[i].isChecked = false;
                       i++;
                    });
                }
                if ($scope.collection == undefined) $scope.collection = [];
                $scope.numberOfLines = $scope.collection.length;
                $scope.collectionCallForwarding = $scope.collection;
                if ($scope.numberOfLines == 0) $scope.serverError = true;
            } else {
                $scope.serverError = true;
            }
        }).error(function() {
            $scope.serverError = true;
        });
    }
    $scope.refresh=function() {
        getData();
    }
     $scope.enableAll=function()
    {
        // anonymusCallRejectionService.setOption(API.ENABLE);
        // anonymusCallRejectionService.getData().success(function(result)
        // {
        //      if(result.appHeader.statusCode == "OK")
        //      {
             var param = { "updateFeatures": { "updateFeature": [] }};
                for(var loop=0;loop<$scope.collection.length;loop++)
                {
                     if($scope.collection[loop].isChecked==true)
                     {
                         $scope.collection[loop].settingsInfo.active = 'true';
                         //console.log('checking checkedval'+$scope.collection[loop].settingsInfo.active);
                         $scope.collection[loop].isChecked=false;
                         $scope.collection[loop].multiple = true;
                         param.updateFeatures.updateFeature.push({"phoneNo":$scope.collection[loop].phoneNo,"updateType":"Status","userName":$scope.collection[loop].userName,"settingsInfo":{"active":$scope.collection[loop].settingsInfo.active.toString()}});
                     }
                }
                 //console.log(JSON.stringify(param));
                  if( param.updateFeatures.updateFeature.length>0)
                 {
                     postLinkData(param);
                 }
                 else
                 {
                    $scope.msgType="error";
                           $scope.msgTxt="Please select a record";
                           $scope.showMsg=true;
                 }
                 //postLinkData(param);
        //     }
        // });
    }
    $scope.disableAll=function()
    {
        // anonymusCallRejectionService.setOption(API.DISABLE);
        // anonymusCallRejectionService.getData().success(function(result)
        // {
        //      if(result.appHeader.statusCode == "OK")
        //      {
 //            var updateParams={"updateFeatures":{"updateFeature":[{"updateType":"Status","phoneNo":"916-417-6646","userName":"NIAL
 // HENDERSON","settingsInfo":{"active":"false"}}]}}
                var param = { "updateFeatures": { "updateFeature": [] }};
                for(var loop=0;loop<$scope.collection.length;loop++)
                {
                    if($scope.collection[loop].isChecked==true)
                     {
                         $scope.collection[loop].settingsInfo.active = false;
                         $scope.collection[loop].isChecked=false;
                         $scope.collection[loop].multiple = true;
                         param.updateFeatures.updateFeature.push({"phoneNo":$scope.collection[loop].phoneNo,"updateType":"Status","userName":$scope.collection[loop].userName,"settingsInfo":{"active":$scope.collection[loop].settingsInfo.active.toString()}});
                    }
                }
                 //console.log(JSON.stringify(param));
                 if( param.updateFeatures.updateFeature.length>0)
                 {
                     postLinkData(param);
                 }
                 else
                 {
                    $scope.msgType="error";
                           $scope.msgTxt="Please select a record";
                           $scope.showMsg=true;
                 }
                  //postLinkData(param);
        //     }
        // });
    }
    function postLinkData(param){
        volteServices.setOption(Constants.API.CALL_FORWARDING.GROUP_POST);
        //console.log();
        volteServices.postData(param)
            .success(function (result) {

              if(result.appHeader.statusCode == "OK") {
                $scope.msgType="success";
                           $scope.msgTxt="Successfully updated";
                           $scope.showMsg=true;
              }
              else
              {
                 $scope.msgType="error";
                           $scope.msgTxt="Unable to Load data";
                           $scope.showMsg=true;
              }
            });

    }
    function getScheduleData() {
        $scope.loadFlag     =  true;
        volteServices.setOption( Constants.API.SCHEDULE.LIST );
        volteServices.getData().success(function( response ){
            $scope.loadFlag     =  false;
            if( response.appHeader.statusCode == "OK")  {
                var scheduleList = response.appResult.serviceRepsonse.scheduleList;
                var bzList = [];
                var hoList = [];
                angular.forEach(scheduleList, function(value, key) {
                    if (value.scheduleType == 'HOLIDAY') {
                        hoList.push({'name':value.scheduleName, 'value':value.scheduleName});
                    } else {
                        bzList.push({'name':value.scheduleName, 'value':value.scheduleName});
                    }
                });
                $scope.biz_schedule = bzList;
                $scope.holiday_schedule = hoList;
            }
            else
            {
                $scope.biz_schedule = [];
                $scope.holiday_schedule = [];
                $scope.showMsg=true;
                $scope.msgType="error";
                $scope.msgTxt=response.appHeader.statusMessage;
            }
        }).error(function() {});
    }
   $scope.updateDel=function()
   {
     $scope.deleteBox=true;
   }

    $scope.selectTab = function(tabName) {
        $scope.tabSelected = tabName;
        $scope.featureName="call_forwarding_"+tabName;
        getData();
        $scope.currentGridTpl = "partials/features/userFeatures/callForwarding/vz-grid/"+tabName+".html";
    }

    $scope.filterFn = function(row) {
        if ($scope.manage_schedule_filter_selected!=undefined) {
            return row.settingsInfo.active==$scope.manage_schedule_filter_selected;
        } else {
            return true;
        }
    }

    $scope.lookupDialogForwarding = function(row,rowIndex,gearType) {
        row.isSubmitClicked=false;
        console.log(row.featureId);
        if(row.featureId=='1009')
        {
          console.log('callForwardSelectiveDialogCtrl')
            $scope.lookupDialogSelectiveForwarding(row,rowIndex,gearType);
        }
        else
        {
          console.log('callForwardNonSelectiveDialogCtrl')
           $scope.lookupDialogNonSelectiveForwarding(row,rowIndex,gearType);
        }
    }
    $scope.lookupDialogSelectiveForwarding = function(row,rowIndex,gearType) {
        row.isSubmitClicked=false;
        var rowTypeInfo={
            row: row,
            rowIndex : rowIndex,
            gearType : gearType
        };
         var new_dialog = ngDialog.open({
          template: 'partials/features/userFeatures/callForwarding/dialog/settings.html',
            closeByDocument: false,
            className: 'ngdialog-theme-default selective-call-rejection-dialog',
            closeByEscape: false,
            data:  rowTypeInfo,
            preCloseCallback: function(){
                if(row.isSubmitClicked==false && gearType===true)
                {
                  if (!$scope.$$phase)
                  {
                     $scope.$apply(function() {
                      row.settingsInfo.active = false;
                     });
                  }
                  else
                  {
                    row.settingsInfo.active = false;
                  }
                }
               return true;
            },
            scope:$scope,
            controller:'callForwardSelectiveDialogCtrl'
        });
    }
    $scope.lookupDialogNonSelectiveForwarding = function(row,rowIndex,gearType) {
        row.isSubmitClicked=false;
        var rowTypeInfo={
            row: row,
            rowIndex : rowIndex,
            gearType : gearType,
            tabSelected :$scope.tabSelected
        };
         var new_dialog = ngDialog.open({
          template: 'partials/features/userFeatures/callForwarding/dialog/settings.html',
            closeByDocument: false,
            className: 'ngdialog-theme-default selective-call-rejection-dialog',
            closeByEscape: false,
            data:  rowTypeInfo,
            preCloseCallback: function(){
                if(row.isSubmitClicked==false && gearType===true)
                {
                  console.log('inside pre close');
                  if (!$scope.$$phase)
                  {
                     $scope.$apply(function() {
                      row.settingsInfo.active = false;
                     });
                  }
                  else
                  {
                    row.settingsInfo.active = false;
                  }
                }
               return true;
            },
            scope:$scope,
            controller:'callForwardNonSelectiveDialogCtrl'
        });
    }
    $scope.closeDialog = function() {
      try {
        var windowIDs = ngDialog.getOpenDialogs();
        ngDialog.close(windowIDs[1]);
      } catch(err) {
        //console.log('Error:', err);
      }
    }


    $scope.getRandomNumber = function(){
        //return Math.floor((Math.random()*6)+ 10000);
        return Math.floor(Math.random() * 90000) + 10000;
    }
    $scope.submitStatus = function(row, lineStatus) {
        if ($scope.tabSelected == 'group') {
            var param = {"updateFeatures":{"updateFeature":[{
                "updateType":"Status",
                "phoneNo":row.phoneNo,
                "settingsInfo":{
                     "nightForwarding": (lineStatus)?"Use Group":"Off",
                     "groupNightForwarding": "On"
                }
            }]}};
        } else {
           var updateFeature = JSON.parse(JSON.stringify(row));
            updateFeature.settingsInfo.active = "false";
            var param = {"updateFeatures":{"updateFeature":[{
                "updateType":"Status",
                "phoneNo":row.phoneNo
            }]}};
            param.updateFeatures.updateFeature[0].settingsInfo=updateFeature.settingsInfo;
            if (row.criteriaInfo) {
              param.updateFeatures.updateFeature[0].criteriaInfo = row.criteriaInfo;
            }
        }
        console.log(param)
        volteServices.setOption( Constants.API.CALL_FORWARDING[$scope.tabSelected.toUpperCase()+'_POST'] );
        volteServices.postData(param).success(function(response) {
            if(response.appHeader.statusCode == "OK") {
                $scope.closeDialog();
                $scope.msgType = "success";
                $scope.msgTxt = 'Successfully Updated';
                $scope.showMsg = true;
            } else {
                row.settingsInfo.active=true;
                //$scope.closeDialog();
                $scope.msgType = "error";
                $scope.msgTxt = 'Record Updation Failed';
                $scope.showMsg = true;
            }
        }).error(function() {});
    }

    // $scope.addForwardFrom = function() {
    //     if ($scope.selData[$scope.selectedOption].fromDnCriteria.phoneNumber.length < 10)
    //     {
    //         $scope.selData[$scope.selectedOption].fromDnCriteria.phoneNumber.push('');
    //         $scope.arrayStatus=false;
    //     }
    // }

    $scope.removeForwardFrom = function(index) {
        $scope.selData[$scope.selectedOption].fromDnCriteria.phoneNumber.splice(index, 1);
        $scope.arrayStatus=false;
    }

    $scope.updateDialog = function() {
        var requestObj = $scope.selData[$scope.selectedOption];
        volteServices.setOption( Constants.API.CALL_FORWARDING[$scope.tabSelected.toUpperCase()+'_POST'] );
        volteServices.postData( requestObj  ).success(function( response ){
             if(response.appHeader.statusCode == "OK") {
                success();
            } else {
                error();
            }
        }).error(function() {
            error( "Unable to process the request" );
        });
    }

    function clearCriteria() {
        $scope.selectedOption = 0;
        $scope.selData = [];
        $scope.selData[$scope.selectedOption] = {
            "timeSchedule": "",
            "holidaySchedule": "",
            "criteriaName": "Option"+$scope.selectedOption,
            "schedule":"always",
            "deleteCriteria": false,
            // "forwardToPhoneNumber": "",
            "fromDnCriteria": {
                "fromDnCriteriaSelection": "Any",
                "includeAnonymousCallers": "true",
                "includeUnavailableCallers": "true",
                "phoneNumber": []
            }
        };
        $scope.circleOptions = [];
        $scope.circleOptions[0] = {"name":'Option 1',"delBox":false};
        $scope.showAddOption=true;
       // $scope.activeAlways[$scope.selectedOption] = 'true';
    }

    function init() {
        //Initialize Variables
        $scope.loadFlag     =  true;
      //  $scope.selectiveData=[];
        $scope.CALL_FORWARDING_TITLE=callForwardingConst.pageTitle;
        $scope.CALL_FORWARDING_DESC=callForwardingConst.pageDesc;
        $scope.collection = {};
        //$scope.activeAlways = [];
        $scope.numberOfSchedules;
        //$scope.instructions = callForwardingConst.groupForwardInstructions.instructions;
        $scope.manage_schedule_filter = CallWaitingConst.MANAGE_FILTER;
        $scope.manage_schedule_filter_selected = undefined;
        $scope.featureName="call_forwarding_group";
        $scope.showAddOption = true;
        $scope.existNumber = false;
        $scope.phoneNumberSize = 1;
        $scope.tabSelected = 'group';
        $scope.forwardToPhoneNumber = '';
        $scope.selectRings = HuntGroupConst.SELECT_RINGS;
        $scope.setSearchText();
        if($scope.loadFeatureData==undefined){
            getEnabaleStatus();
        }



        $scope.voiceMail = "true";
    }
    init();
    //$scope.loadFlag     =  false;
$scope.tplUrl = 'partials/features/userFeatures/callForwarding/vz-grid/group.html';
    // $scope.$watch('tabSelected', function(value) {
    //   $scope.featureName="call_forwarding_"+value;
    //   switch (value) {
    //         case "group":
    //           $scope.tplUrl = 'partials/features/userFeatures/callForwarding/vz-grid/group.html';
    //           break;
    //         case "selective":
    //           $scope.tplUrl = 'partials/features/userFeatures/callForwarding/vz-grid/selective.html';
    //           break;
    //         case "always":
    //           $scope.tplUrl = 'partials/features/userFeatures/callForwarding/vz-grid/always.html';
    //           break;
    //         case "busy":
    //           $scope.tplUrl = 'partials/features/userFeatures/callForwarding/vz-grid/busy.html';
    //           break;
    //         case "noAnswer":
    //           $scope.tplUrl = 'partials/features/userFeatures/callForwarding/vz-grid/noAnswer.html';
    //           break;
    //       }
    // });
    $scope.selectTab = function(tabName) {
        $scope.tabSelected = tabName;
        $scope.featureName="call_forwarding_"+tabName;
        $scope.tplUrl = "partials/features/userFeatures/callForwarding/vz-grid/"+tabName+".html";
    }
    function init() {
        //Initialize Variables
        $scope.tabSelected = 'group';
        $scope.loadFlag     =  true;
        $scope.instructions ='';
      //  $scope.selectiveData=[];
        $scope.CALL_FORWARDING_TITLE=callForwardingConst.pageTitle;
        $scope.CALL_FORWARDING_DESC=callForwardingConst.pageDesc;
    }
    init();
    }]);

/*callForwardingCtrl.$inject = ["$scope","$rootScope", "$http", "ngDialog", "$compile", "$state", "anonymusCallRejectionService","CallWaitingConst","UserConfig","volteServices","Constants","HuntGroupConst","callForwardingConst"];
angular.module( window.AppName ).controller("callForwardingCtrl", callForwardingCtrl);
*/
