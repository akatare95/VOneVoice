(function() {
    var selectiveCallRejectionCtrl = function($scope, ngDialog, selectiveCallRejectionService, selectiveCallRejectionConst) {
        var abstracts = $scope.abstracts,
            settingsDialog;
        selectiveCallRejectionService.setPageSize(10);
        abstracts.getService = function() {
            return selectiveCallRejectionService;
        };
        /**
         * Gets executed before the request gets proxied
         * to the service. Used to un-select all the records
         * that may have been selected BEFORE the operation
         * takes place (i.e. pagination)
         */
        //abstracts.setCollection();
        abstracts.beforeLoad = function(operation) {
            toggleSelect(false);

            if (operation === 'init') {
                $scope.loadFlag = true;
            }
        };

        function setInstructions() {
            var instructions = selectiveCallRejectionConst.instructions;
            abstracts.setInstructions(instructions);
        }
        /**
         * Gets executed after the request gets proxied
         * to the service. Used to un-select the master
         * checkbox
         */
        abstracts.onLoad = function(operation) {
            $scope.selectAll = false;
            // $scope.collection = [];
            if (operation === 'init') {
                $scope.loadFlag = false;
            }
        };
        abstracts.filter();
        abstracts.errorHandler = function(err) {
            errorHandlerMsg(err);
        };

        abstracts.successHandler = function(message) {
           successHandlerMsg(message);
        };
        function successHandlerMsg(msg)
        {
            $scope.showMsg = true;
            $scope.msgType = 'success';
            $scope.msgTxt = msg;
        }
        function errorHandlerMsg(err)
        {
            $scope.showMsg = true;
            $scope.msgType = 'error';
            $scope.msgTxt = err.message || "Error performing operation";
        }
        function serviceResponseHandler(response) {
            $scope.selectAll = false;
            $scope.collection = selectiveCallRejectionService.getList();
            $scope.count = selectiveCallRejectionService.getCount();
            $scope.pageSize = selectiveCallRejectionService.getPageSize();
            $scope.pagesLength = selectiveCallRejectionService.getPagesLength();
            $scope.currentPage = selectiveCallRejectionService.getCurrentPage();
            $scope.length = selectiveCallRejectionService.getLength();
            $scope.total = selectiveCallRejectionService.getTotal();
            $scope.noRecordsMessage = $scope.total === 0 ? "No Records Found" : "The schedule cannot be found.";
            return response;
        }
        //$scope.$watch('searchQuery', abstracts.search); // TODO: Should wait for the "Enter" key
        //$scope.$watch('filterBy', abstracts.filter);
        //$scope.$watch('selectAll', toggleSelect);
        $scope.searchFilterArr = [  {   name: "Phone Lines",
                                        value: "phoneNumber"
                                    }, {
                                        name: "User Name",
                                        value: "userName"
                                }];
          $scope.searchFilter = 'phoneNumber';
        $scope.filter = function(filterBy) {
            abstracts.filter(filterBy);
        };
        $scope.search = function(searchQuery,searchFilter,$event) {
            console.log('inside ng-change')
            abstracts.setSearch($scope.searchFilter);
            console.log($scope.searchFilter)
            if(selectiveCallRejectionService.getOperationType() === 'server' || selectiveCallRejectionService.getServerSearchValue())
            {
               console.log(searchQuery);
                var isClickedEnterVal = $event == undefined ? $event : $event.which;
                console.log(isClickedEnterVal);
                if(isClickedEnterVal === 13 ||isClickedEnterVal == undefined)
                {
                    abstracts.search(searchQuery);
                }
            }
            else
            {
                abstracts.search(searchQuery);
            }
        //abstracts.search(searchQuery)
        };
        $scope.refresh = function() {
           abstracts.refresh();
            $scope.callWaitingSearch = '';
        }
        $scope.setPageSize = function(value) {
            abstracts.setPageSize(value);
        };
        $scope.closeDialog = function() {
            abstracts.closeDialog();
        };
        $scope.lookupDialogCallRejection = function(row,rowIndex,gearType) {
        row.isSubmitClicked=false;
        var rowTypeInfo={
            row: row,
            rowIndex : rowIndex,
            gearType : gearType
        };
         var new_dialog = ngDialog.open({
          template: 'partials/features/userFeatures/selectiveCallRejection/dialog/callRejection.html',
            closeByDocument: false,
            className: 'ngdialog-theme-default selective-call-rejection-dialog',
            closeByEscape: false,
            data:  rowTypeInfo,
            preCloseCallback: function(){
                if(row.isSubmitClicked==false && gearType===true)
                {
                  if (!$scope.$$phase)
                  {
                     $scope.$apply(function() {
                      row.settingsInfo.active = false;
                     });
                  }
                  else
                  {
                    row.settingsInfo.active = false;
                  }
                }
               return true;
            },
            scope:$scope,
            controller:'callrejectionDialogCtrl'
        });
    }
    $scope.deleteSettings = function(row) {
        console.log("acceptance---");
        //var option = ($scope.tabSelected=='acceptance')?Constants.API.SELECTIVE_CALL_ACCEPTANCE.POST:Constants.API.SELECTIVE_CALL_REJECTION.POST;
        var param = { "updateFeatures": { "updateFeature": [] }};
        param.updateFeatures.updateFeature.push({
            "updateType": "Criteria",
            "phoneNo":row.phoneNo,
            "criteriaInfo": []
        });
        $scope.selData = [];
        angular.forEach(row.criteriaInfo, function(value, key) {
            $scope.selData[key] = {
                "timeSchedule": row.criteriaInfo[key].timeSchedule,
                "holidaySchedule": row.criteriaInfo[key].holidaySchedule,
                "blacklisted": "false",
                "criteriaName": row.criteriaInfo[key].criteriaName,
                "deleteCriteria":true
            };
        });
        param.updateFeatures.updateFeature[0].criteriaInfo = $scope.selData;
        selectiveCallRejectionService.update(param)
                .then(function(result) {
                    successHandlerMsg('Successfully Updated');
                })
                .catch(errorHandlerMsg);
    }


        function toggleSelect(value) {
            var list = selectiveCallRejectionService.getList(),
                record;

            for (var i = 0, ln = list.length; i < ln; i++) {
                record = list[i];

                if ($scope.disableOnACL && !$scope.disableOnACL(record.type)) {
                    record.selected = value;
                }
            }
        }
        $scope.successHandler=function(message){
            $scope.showMsg = true;
            $scope.msgType = 'success';
            $scope.msgTxt = message;
        }

        $scope.errorHandler= function (err)
        {
            $scope.showMsg = true;
            $scope.msgType = 'error';
            $scope.msgTxt = err.message || "Error performing operation";
        }
        // function initData() {
        //     $scope.loadFlag = false;
        //     // $scope.instructions = selectiveCallRejectionConst.alwaysInstructions.instructions;
        //     //$scope.tooltips = "Forwards all calls to your number to another destination";
        //     // getThisData();
        // }

        setInstructions();
        // selectiveCallRejectionService.setPageSize(10);
        //initData();
        abstracts.init();
        //$scope.collection = selectiveCallRejectionService.getList();
    };

    selectiveCallRejectionCtrl.$inject = ['$scope', 'ngDialog', 'selectiveCallRejectionService', 'selectiveCallRejectionConst'];

    angular.module(window.AppName).controller('selectiveCallRejectionCtrl', selectiveCallRejectionCtrl);
})();
