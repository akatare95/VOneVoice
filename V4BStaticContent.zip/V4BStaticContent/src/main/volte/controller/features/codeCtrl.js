var codeCtrl = function($scope, $http, ngDialog, $compile, $state, featuresServices, codeConst){

    $scope.toggleTab = function() {
        $scope.tab = !$scope.tab;
    }

    $scope.displayFirstTab = function() {
        if( $scope.tab == true ) {
        return "vz-show";
        } else {
        return "vz-hide";
        }
    }

    $scope.displaySecondTab = function() {
        if( $scope.tab != true ) {
        return "vz-show";
        } else {
        return "vz-hide";
        }
    }

    $scope.activateFirstTab = function( index ) {
        if( $scope.tab == true ) {
        return "selected";
        } else {
        return "";
        }
    }

    $scope.activateSecondTab = function( index ) {
        if( $scope.tab == false ) {
        return "selected";
        } else {
        return "";
        }
    }

    $scope.colours = [{
        name: "1:00 A.M.",
        hex: "#F21B1B"
      }, {
        name: "2:00 A.M.",
        hex: "#1B66F2"
      }, {
        name: "1:00 A.M.",
        hex: "#07BA16"
      }];


    $scope.availableOptions = [
        {id:"0", name:"All"},
        {id:"1", name:"Active Lines"},
        {id:"2", name:"Disabled Lines"}
    ];


    $scope.colours = [{
        name: "Red",
        hex: "#F21B1B"
    }, {
        name: "Blue",
        hex: "#1B66F2"
    }, {
        name: "Green",
        hex: "#07BA16"
    }];
    $scope.colour = "";



    function getCodes() {
        $scope.type = "code";
        featuresServices.setOption( $scope.type );
        $scope.vzGridTpl = "partials/features/vz-grid/vz.grid.code.html";
        getData();
    }

    function getData() {
        featuresServices.getData()
            .success(function (result) {
                $scope.collection = result.data.rows;
            })
            .error(function (error) {
                $scope.status = 'Unable to load customer data: ' + error.message;
            });
    }

    function init() {

        //Initialize Variables
        $scope.collection = {};

        //Load the line information
        getCodes();

        $scope.vzGridCodeSearchTpl = "partials/features/vz-grid/vz.grid.code.search.html";
        $scope.vzTinyGridTpl = "partials/features/vz-grid/vz.tiny-grid.dial-plan.html"

        $scope.lineDeviceFilterOptions = {
            availableOptions : [
                                {"id":"0","name":"All"},
                                {"id":"1","name":"Active Lines"},
                                {"id":"2","name":"Disabled Lines"}
                             ],
                selectedOption: {id:"0", name:"All"}
        };

        $scope.pageTitle = codeConst.pageTitle;
        $scope.pageTitle_Desc = codeConst.pageTitle_Desc;

        $scope.createpageTitle = codeConst.createpageTitle;
        $scope.createpageTitle_Desc = codeConst.createpageTitle_Desc;
    }

    init();

};

codeCtrl.$inject = ["$scope", "$http", "ngDialog", "$compile", "$state", "featuresServices", "codeConst"];
angular.module( window.AppName ).controller("codeCtrl", codeCtrl);