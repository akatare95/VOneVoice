var featureConfigCtrl = function($scope, $rootScope, $state, $window, $document, featuresServices){

    $scope.featureSetup = [];

    $scope.onListHover = function(event, title, desc, link, type) {

          $scope.type = type;

          switch( type ) {
    		case "features":
    			$scope.enterpriseCircleTitle =  title;
    			$scope.enterpriseCircleDesc =  desc;
                $scope.enterpriseCircleLink = link;
                $scope.enterpriseCircleDisplay = true;
    			break;
    		case "users":
    			$scope.usersCircleTitle =  title;
    			$scope.usersCircleDesc =  desc;
                $scope.usersCircleLink = link;
                $scope.usersCircleDisplay = true;
    			break;
    	  }

          $scope.mobileDisplay = true;

          //console.log("Display - " + $scope.mobileDisplay);

    }

    $scope.onListLeave = function(event) {
        $scope.enterpriseCircleDisplay = false;
        $scope.usersCircleDisplay = false;
    }

    $scope.navigateTo = function( link ) {
        $state.go(link);
    }

    $scope.saveChange = function(index, status) {
        var featureName = $scope.enterpriseFeatures[index].key;
        featuresServices.updateFeatureSetup('{"'+featureName+'": '+status+'}')
            .success(function (result) {
                if (result.appHeader.statusCode == 'OK') {
                    //console.log('Status Updated Successfully');
                } else {
                    $scope.serverError = true;
                }
            })
            .error(function (error) {
                $scope.serverError = true;
                console.log( 'Unable to load customer data: ' + error.message );
            });
    }

    function getFeatureConfig() {
        featuresServices.getFeatureSetup()
            .success(function (result) {
                if (result.appHeader.statusCode == 'OK') {
                    var i = 0;
                    angular.forEach(result.appResult.serviceRepsonse, function(value, key) {
                        $scope.enterpriseFeatures[i].status = value;
                        $scope.enterpriseFeatures[i].key = key;
                        i++;
                    });
                } else {
                    $scope.serverError = true;
                }
            })
            .error(function (error) {
                $scope.serverError = true;
                console.log( 'Unable to load customer data: ' + error.message );
            });
    }

    function init() {
        DESCI = "";
    	$scope.enterpriseFeatures = [{title: "Schedule", desc: DESCI, link: "features.enterprise.schedule"}, {title: "Auto Attendant", desc: DESCI, link: "features.enterprise.auto_attendant"}, {title: "Hunt Group", desc: DESCI, link: "features.enterprise.hunt_group"}, {title: "Calling Line ID", desc: DESCI, link: "features.enterprise.calling_line_id"}, {title: "Custom Ringback", desc: DESCI, link: "features.enterprise.custom_ringback"}, {title: "Music On Hold", desc: DESCI, link: "features.enterprise.music_on_hold"}, {title: "Group Forwarding", desc: DESCI, link: "features.enterprise.group_forwarding"}, {title: "Code", desc: DESCI, link: "features.enterprise.code"}, {title: "Calling Plan", desc: DESCI, link: "features.enterprise.calling_plan"} ];
		$scope.userFeatures = [ {title: "Anonymous Call Rejection", desc: DESCI, link: "features.enterprise.anonymous_call_rejection"}, {title: "Automatic Callback", desc: DESCI, link: "features.enterprise.automatic_callback"}, {title: "Call Forwarding", desc: DESCI, link: "features.enterprise.call_forwarding"}, {title: "Directed Call Pickup with Barge In", desc: DESCI, link: "features.enterprise.dir_call_pickup"}, {title: "Call Waiting", desc: DESCI, link: "features.enterprise.call_waiting"}, {title: "Custom Ringback", desc: DESCI, link: "features.enterprise.custom_ringback"}, {title: "Call Notify", desc: DESCI, link: "features.enterprise.call_notify"}, {title: "Group Forwarding", desc: DESCI, link: "features.enterprise.group_forwarding"}, {title: "Simultaneous Ring Service", desc: DESCI, link: "features.enterprise.sim_ring_service"}, {title: "Pre Alerting Anouncement", desc: DESCI, link: "features.enterprise.pre_alert_anonuncement"} ];
        getFeatureConfig();
    }
    init();

};

featureConfigCtrl.$inject = ["$scope", "$rootScope", "$state", "$window", "$document", "featuresServices"];
angular.module( window.AppName ).controller("featureConfigCtrl", featureConfigCtrl);