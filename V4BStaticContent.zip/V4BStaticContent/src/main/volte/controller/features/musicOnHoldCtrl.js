var musicOnHoldCtrl= function($scope,musicOnHoldService,Constants,$rootScope,$timeout,musicOnHoldConst, $http,$filter) {

    scope = $scope;
    boot  = 0;

    $scope.enableSbtnBtnForCustom = function() {

        $scope.isValid=true;

        if( $scope.files.length == 0 ) {
          $scope.musicForm.$pristine = true;
        }

    }

    $scope.enableSubmitBtnForSystem = function() {
        console.log($scope.musicForm.$pristine)
        $scope.musicForm.$pristine = false;

    }

    scope.setFiles = function(element) {

        //This helps in preventing from redirction
        var fileStr=element.files[0].type.split("/");
        if(fileStr[fileStr.length-1].search("wav")!==-1||fileStr[fileStr.length-1].search("wma")!==-1)
        {
            //!$scope.musicForm.$pristine;
            if(!$scope.$$phase)
            {
              scope.$apply(function(scope) {

                if(element.files[0].size/1024 <= Constants.MAX_FILE_SIZE.MUSIC_ON_HOLD)  {

                    // Turn the FileList object into an Array
                    scope.files = []
                    for (var i = 0; i < element.files.length; i++) {
                      scope.files.push(element.files[i]);
                      $scope.theFile.name = element.files[i].name;
                    }

                    $scope.isValid=true;
                    $scope.musicForm.$pristine = false;
                    $scope.enableSubmit = true;
                    $scope.src=URL.createObjectURL(element.files[0]);
                    $scope.showMsg = false;

                } else {
                    $scope.msgType = "error";
                    $scope.msgTxt = "Please upload a file in the correct format. Please refer to the instructions. ";
                    $scope.showMsg = true;
                    $scope.musicForm.$setPristine();
                }

            });
            }
            else
            {
                if(element.files[0].size/1024 <= Constants.MAX_FILE_SIZE.MUSIC_ON_HOLD)  {

                    // Turn the FileList object into an Array
                    scope.files = []
                    for (var i = 0; i < element.files.length; i++) {
                      scope.files.push(element.files[i]);
                      $scope.theFile.name = element.files[i].name;
                    }

                    $scope.isValid=true;
                    $scope.musicForm.$pristine = false;
                    $scope.enableSubmit = true;
                    $scope.src=URL.createObjectURL(element.files[0]);
                    $scope.showMsg = false;

                } else {
                    $scope.msgType = "error";
                    $scope.msgTxt = "Please upload a file in the correct format. Please refer to the instructions.";
                    $scope.showMsg = true;
                    $scope.musicForm.$setPristine();
                }
            }

        } else {
            scope.$apply(function(scope) {

                $scope.msgType = "error";
                $scope.msgTxt = "Please choose a file with WAV or WMA extension only";
                $scope.showMsg = true;
                $scope.musicForm.$pristine = true;
                $scope.theFile.name = null;

                console.log($scope.showMsg);

             });
        }


    };

    function getData() {

        musicOnHoldService.musiconhold()
               .success(function (result) {
                   $scope.loadFlag     =  false;
                    try {

                              var successResponse=result.appResult.serviceRepsonse;
                              //console.log("Success music on hold- ",result);
                              $scope.messageSourceSelection = successResponse.messageSourceSelection.toUpperCase();
                              $scope.isActive = successResponse.active;

                              if( successResponse.messageSourceSelection.toUpperCase() == 'CUSTOM' ) {
                                $scope.theFile.name = successResponse.audioFileInfo.fileName;
                              }

                        }   catch(err) {}

                }).error(function (error) {});


    }

    function uploadFileFn() {

        var API = Constants.API.MUSIC_ON_HOLD;
        var msgSrcSelection = ($scope.messageSourceSelection) ? "SYSTEM" : "CUSTOM";

        var fd = new FormData()
        for (var i in scope.files) {
            if( i == 0)
                fd.append("multipartFile", scope.files[i]);
        }
        fd.append("messageSourceSelection", $scope.messageSourceSelection);
        fd.append("active", $scope.isActive);

        //'multipart/form-data'
        $rootScope.ajaxLoading = true;


        var xhr = new XMLHttpRequest();
        //xhr.upload.addEventListener("progress", uploadProgress, false)
        xhr.addEventListener("load", angular.bind(null, uploadProgress), false)
        //xhr.addEventListener("error", uploadFailed, false)
        //xhr.addEventListener("abort", uploadCanceled, false)
        window.addEventListener('error', angular.bind(null,uploadError), true);
        xhr.addEventListener("abort", angular.bind(null, uploadCanceled), false);
        xhr.open("POST", Constants.API_HOST + Constants.API.MUSIC_ON_HOLD.UPDATE );
        //xhr.setRequestHeader("Content-type", "multipart/form-data");
        scope.progressVisible = true;
        xhr.setRequestHeader("X-XSRF-TOKEN", _.last(String(document.cookie.match(/XSRF-Token=([^\s;]*);/gi)).split(';')[0].split('=')));
        xhr.send(fd);

    }

    function uploadError(evt) {

        /*$scope.$apply(function(){
            $rootScope.ajaxLoading = false;
            error( "Upload Failed!" );
        });*/

    }

    function uploadProgress(evt) {

        $scope.$apply(function() {

            //Close the dialog loader
            $rootScope.ajaxLoading = false;
            var result ;
            try {

                var xhrSatus = parseInt( evt.target.status );
                result = JSON.parse( evt.target.response );
                console.log(result);

                //Check the status of the target
                if( xhrSatus == 200 || xhrSatus == 302 ) {

                    //var result = JSON.parse( evt.target.response );

                    if( result.appResult.serviceRepsonse.errorCode == "0" || result.appResult.serviceRepsonse.errorCode == "00" ){

                        success();

                        //Keep the submit button in disabled mode
                        $scope.musicForm.$pristine = true;
                        $scope.enableSubmit = false;

                    } else {

                        //Incase if service is down then display the error message

                        //var msg = ( typeof(result.appResult.serviceRepsonse.message) !='' ) ? result.appResult.serviceRepsonse.message : "Upload Failed";
                        //error( msg );
                        error(result.appHeader.statusMessage);

                        //Enable the submit button
                        $scope.musicForm.$pristine = false;
                        $scope.enableSubmit = true;

                     }

                }   else {

                    //Incase if any error occured like 404 or 500 then display the error message

                    //Enable the submit button
                    $scope.musicForm.$pristine = false;

                    //error( "Upload Failed!" );
                    error(result.appHeader.statusMessage);



                }

            } catch( err ) {

                //Incase if any error occured in JS Response then we display the error response
                console.log("Error -  ", err );

                //Enable the submit button
                $scope.musicForm.$pristine = false;
                error(result.appHeader.statusMessage);


            }

        });



    }


    function uploadCanceled(evt) {

        var result = JSON.parse( evt.target.response );

        $scope.$apply(function(){
            $rootScope.ajaxLoading = false;
            var msg = "Unable to process request";
            error( msg );
        })
    }

    function uploadComplete( evt, $rootScope ) {
        $rootScope.ajaxLoading = false;
    }

    function success() {

        $scope.msgType  = "success";
        $scope.msgTxt   = "Successfully Updated";
        $scope.showMsg  = true;
        $scope.enableSubmit = false;
        $scope.musicForm.$pristine = !$scope.musicForm.$pristine;

    }

    function error( msg ) {

        var errmsg = msg || "Updation Failed!";

        $scope.msgType = "error";
        $scope.msgTxt = errmsg;
        if(!$scope.msgTxt || $scope.msgTxt==undefined){
            $scope.msgTxt = "Updation Failed!";
        }
        $scope.showMsg = true;
        $scope.enableSubmit = false;

    }


    $scope.vzSubmitBtnStatusFn = function( decision ) {
        $rootScope.vzSubmitBtnStatus = !decision;
        return decision;
    }


   $scope.onFileChange = function() {

        // alert("test");
        $scope.musicForm.$pristine = false;
         $scope.enableSubmit = true;

         var file=document.getElementById('file').files[0];
         if(file.size/1024 <= Constants.MAX_FILE_SIZE.MUSIC_ON_HOLD)
         {
           $scope.theFile=document.getElementById('file').files[0];
           console.log($scope.theFile);
           $scope.src=URL.createObjectURL($scope.theFile);
           //$scope.enableSubmit = true;
           $scope.isStreaming=false;
           $scope.isValid=true;
           $scope.showMsg = false;
         }
         else{

            $scope.msgType = "error";
            $scope.msgTxt = "Please upload a file in the correct format. Please refer to the instructions. ";
            $scope.showMsg = true;
         }

    }

    $scope.play=function($event){
        document.getElementById('audio_player').play();
        $scope.isStreaming=true;
    }

    $scope.setEnableSubmit=function(){
        $scope.enableSubmit = true;
        $scope.msgType = "";
        $scope.msgTxt = "";
    }

    $scope.pause=function(){
        document.getElementById('audio_player').pause();
        $scope.isStreaming=false;
    }

    $scope.updatePost=function( event ){
        event.preventDefault();
        $scope.enableSubmit = true;
        //$scope.musicForm.$setPristine();
        $scope.clickedForward=false;
        if( ($scope.notification1==false || $scope.notification2==false)){
            return;
        }
        else {

            //if( $scope.messageSourceSelection.toUpperCase() =='CUSTOM' &&  $scope.isActive === true )
            if( $scope.files.length > 0 && $scope.messageSourceSelection.toUpperCase() =='CUSTOM' &&  $scope.isActive === true) {
                uploadFileFn();
            } else {

                if( $scope.messageSourceSelection.toUpperCase() =='CUSTOM' )  {
                    var postData = {'active': $scope.isActive};
                } else {
                    var postData = {'messageSourceSelection': $scope.messageSourceSelection, 'active': $scope.isActive};
                }

                musicOnHoldService.updateWithOutFile(postData)
                    .success(function (result) {
                        try{
                            if(result.appHeader.statusCode == "OK") {
                               success();
                            } else {
                                $scope.musicForm.$pristine = !$scope.musicForm.$pristine;
                                error();
                            }
                        } catch(err) {
                            //console.log("Failure - "+err.message);
                        }
                    });
            }
        }

    }

    $scope.getStatus=function($event){

        //$scope.modelModified = false;
        $scope.musicForm.$pristine = false;
        $scope.enableSubmit = true;

        if($event.target.tagName=='LABEL') {
            console.log(angular.element($event.target)[0].previousSibling.onclick =  $scope.clickedForward=true );
        }

    }
    $scope.onUpload = function (event) {
        event.preventDefault();
        document.getElementById('fileToUpload').click();
       //$scope.musicForm.$pristine = false;
      //$scope.enableSubmit = true;
    }


    $scope.complete = function(content) {

        $scope.msgType = "success";
        $scope.msgTxt = "Updated Successfully";
        $scope.showMsg = true;

        // Hiding loading icon for Non-XHR request.
        $rootScope.ajaxLoading = false;
    }
    var errorUploading = function() {

        $scope.msgType = "error";
        $scope.msgTxt = "Error occurred while uploading file.";
        $scope.showMsg = true;

        // Hiding loading icon for Non-XHR request.
        $rootScope.ajaxLoading = false;
    }

    $scope.uploadLinkClick = function() {
        console.log('clicked');
    }

    function watch() {

        $scope.$watch('isActive',function() {

            if( boot > 2)     {

                if( $scope.messageSourceSelection == "SYSTEM" || ($scope.messageSourceSelection == "CUSTOM" && scope.files.length > 0)  )
                {
                    $scope.musicForm.$pristine = false;
                    $scope.enableSubmit = true;
                }

            }

            boot++;

        });

    }

    function init() {
        $scope.fileSizeLimit = parseInt(Constants.MAX_FILE_SIZE.MUSIC_ON_HOLD)/1000;
        $scope.pageTitle=musicOnHoldConst.pageTitle;
        $scope.pageDesc=musicOnHoldConst.pageTitle_Desc;
        // $scope.instructionDetails=musicOnHoldConst.instructions;
        $scope.modelModified = false;
        $scope.messageSourceSelection = null
        $scope.enableSubmit = false;
        $scope.loadFlag     =  true;
        $scope.instructions = musicOnHoldConst.instructions;

        // $scope.dataObj=null;
         $scope.theFile={
          'name':null
         };

        // $scope.theFile.name=$scope.messageSourceSelection+'.'+$scope.isActive;
        $scope.fileUploadUrl = Constants.API_HOST+Constants.API.MUSIC_ON_HOLD.UPDATE;
        $scope.src=null;
        $scope.isValid=true;
        $scope.clickedForward=false;
        $scope.files = [];

        getData();
        $scope.bsft=false;
        watch();

    }

    init();
};
musicOnHoldCtrl.$inject = ["$scope",'musicOnHoldService', 'Constants','$rootScope','$timeout','musicOnHoldConst', '$http','$filter'];
angular.module( window.AppName ).controller("musicOnHoldCtrl", musicOnHoldCtrl);
