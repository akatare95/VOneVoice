var callingPlanCtrl= function($scope,featuresServices,CallingPlanConst,callingPlanService,Config) {
    function geSchedule() {
        $scope.type = "callingPlan";
        featuresServices.setOption( $scope.type );
        $scope.vzGridTpl = "partials/features/vz-grid/vz.grid.calling-plan.html";
    }
   /* function getData() {
        //featuresServices.getData()
        //    .success(function (result) {
        //        //$scope.collection = result.data.rows;
        //
        //
        //    })
        //    .error(function (error) {
        //        $scope.status = 'Unable to load customer data: ' + error.message;
        //    });

            });
        var jsonStr = '{' +
            '"appHeader":    {' +
            '"statusCode": "OK",' +
            '"statusMessage": "Operation was successfull"' +
            '},' +
            '"appResult": {"serviceResponse":    {' +
            '"internalCalls": "Allow",' +
            '"selectiveList": "Allow",' +
            '"localCalls": "Allow",' +
            '"tollFreeCalls": "Disallow",' +
            '"internationalCalls": "Allow",' +
            '"directoryAssistance": "Allow",' +
            '"emergencyCalls": "Disallow",' +
            '"paidServices": "Disallow"' +
            '}}' +
            '}';

        var jsonObj = JSON.parse(jsonStr);
        var collectionObj = jsonObj.appResult.serviceResponse;
        var collection = [];
        for(var propKey in collectionObj) {
            if(collectionObj.hasOwnProperty(propKey)) {
                collection.push({
                    OutboundCalls : getLabels(propKey),
                    selection: collectionObj[propKey] === 'Disallow' ? 'Block': collectionObj[propKey] ,
                    description: 'Lorem Ipsum Dolor Lorem Ipsum Dolor Lorem Ipsum Dolor Lorem Ipsum Dolor Lorem Ipsum Dolor Lorem Ipsum Dolor Lorem Ipsum Dolor Lorem Ipsum Dolor'
                });
            }
        }

        $scope.collection = collection;
        function getLabels(labelKey) {
            switch (labelKey) {
                case 'internalCalls':
                    return 'Internal Calls';
                break;
                case 'selectiveList':
                    return 'Selective List';
                    break;
                case 'localCalls':
                    return 'Local Calls';
                    break;
                case 'tollFreeCalls':
                    return 'Toll Free Calls';
                    break;
                case 'internationalCalls':
                    return 'International Calls';
                    break;
                case 'directoryAssistance':
                    return 'Directory Assistance';
                    break;
                case 'emergencyCalls':
                    return 'Emergency Calls';
                    break;
                case 'paidServices':
                    return 'Paid Services';
                    break;
                default:
                    return '';
            }
        }
    }*/
geSchedule();
    $scope.devices = [
        {icon: "assets/images/iphone6-black.png", title: "Apple iPhone 6 32GB in Black", type: "apple_iphone_6"},
        {icon: "assets/images/bridged-with-admin.jpg", title: "", type: "bridge_with_admin"},
        {icon: "assets/images/yealink.png", title: "Yealink T48G IP Phone 3", type: "yealink"},
        {icon: "assets/images/ott-tablet.png", title: "OTT Tablet 1", type: "ott_table"},
        {icon: "assets/images/ott-tablet.png", title: "OTT Tablet 2", type: "ott_table"},
        {icon: "assets/images/ott-tablet-3.png", title: "OTT Tablet 3", type: "ott_table"},
        {icon: "assets/images/ott-tablet.png", title: "OTT Tablet 4", type: "ott_table"},
    ];


    $scope.selectedItems="";
    $scope.updatePost=function(){
        if($scope.callingPlanForm.$dirty)
        {
           for(var i=0;i<$scope.dataObj.outboundCalls.length;i++)
        {
            if($scope.dataObj.outboundCalls[i].value!=='Allow')
            {
                $scope.dataObj.outboundCalls[i].value='Authorization Code Required';
            }
            delete $scope.dataObj.outboundCalls[i].description;
        }
        console.log($scope.dataObj);
        $scope.callingPlanForm.$setPristine();
        callingPlanService.sendCallingPlanValues($scope.dataObj).success(function (result) {
            if(result.appHeader.statusCode == "OK") {
                $scope.msgType = "success";
                $scope.msgTxt = "Updated Successfully";
                $scope.showMsg = true;
                console.log( $scope.msgTxt);
            }
        }).error(function (error) {
           console.log("Failure - ", error);
        });
        }
    }
    function init(){
        $scope.CALLING_PLAN_TITLE=Config.CALLING_PLAN_TITLE;
        $scope.CALLING_PLAN_DESC=Config.CALLING_PLAN_DESC;
        $scope.callingplan_list = CallingPlanConst.callingplan_list;
        $scope.dataObj={
            "outboundCalls":[]};
            //var authCodeString;
        callingPlanService.callingPlanValues()
            .success(function (result) {
                try {
                console.log(result);
                var collectionObj = result.appResult.serviceRepsonse.outboundCalls;
                console.log(collectionObj);
                $scope.dataObj.outboundCalls=collectionObj;
                console.log($scope.dataObj.outboundCalls);
                var collection = [];
                for(var i=0;i<collectionObj.length;i++)
                {
                    collection.push({
                        OutboundCalls : getLabels(collectionObj[i].key),
                        //selection: collectionObj[i].value,
                        selection: collectionObj[i].value!='Allow'?'Allow with Auth code':collectionObj[i].value,
                       //selection: collectionObj[i].value=='Authorizationcoderequired'?'Allow with Auth code':collectionObj[i].value,

                        //description: 'Lorem Ipsum Dolor Lorem Ipsum Dolor Lorem Ipsum Dolor Lorem Ipsum Dolor Lorem Ipsum Dolor Lorem Ipsum Dolor Lorem Ipsum Dolor Lorem Ipsum Dolor'
                        description: collectionObj[i].description
                    });

                }
                //for(var propKey in collectionObj) {
                //if(collectionObj.hasOwnProperty(propKey)) {
                //    collection.push({
                //        OutboundCalls : getLabels(propKey),
                //        selection: collectionObj[propKey] === 'Disallow' ? 'Block': collectionObj[propKey] ,
                //        description: 'Lorem Ipsum Dolor Lorem Ipsum Dolor Lorem Ipsum Dolor Lorem Ipsum Dolor Lorem Ipsum Dolor Lorem Ipsum Dolor Lorem Ipsum Dolor Lorem Ipsum Dolor'
                //    });
                //  }
                //}
                $scope.collection = collection;
            }
            catch(err){
                console.log(err.message);
            }

            }).error(function (error) {
                console.log("Failure - ", error);
            });

    }

    init();

};

callingPlanCtrl.$inject = ["$scope",'featuresServices','CallingPlanConst','callingPlanService','Config'];
angular.module( window.AppName ).controller("callingPlanCtrl", callingPlanCtrl);

String.prototype.capitalizeFirstLetter = function() {
    return this.charAt(0).toUpperCase() + this.slice(1);
}

function getLabels(labelKey) {
    labelKey = labelKey.capitalizeFirstLetter();
    return labelKey.match(/[A-Z][a-z]+/g).join(" ");
}