    var createAuthorizeCodeCtrl = function($scope, $http, ngDialog, $compile, $state, $rootScope,createAuthorizeCodeServices,Config,cache,manageAuthorizeCodeServices,Constants,$filter) {
    var availableLinesChosen = [];
    var selectedLinesChosen = [];

    // function getAvailableLines() {
    //     //$scope.type = "schedule";
    //     //huntGroupServices.setOption( $scope.type );
    //     $scope.availableLinesTemplate = "partials/features/vz-grid/vz.grid.authorize-code-available-lines.html";
    //     //$scope.selectedLinesTemplate = "partials/features/vz-grid/vz.grid.hunt-group-selected-lines.html";
    //     //getData();
    // }

    // function getData() {
    //     createAuthorizeCodeServices.getData()
    //         .success(function (result) {
    //              $scope.availableLines = result.data.availableLines;
    //             $scope.availableLinesCount = $scope.availableLines.length;

    //             $scope.selectedLines = result.data.selectedLines;
    //             $scope.selectedLinesCount = $scope.selectedLines.length;
    //             $scope.models =
    //             {
    //             selected: null,
    //             lists:
    //             {
    //                 "availableLine": $scope.availableLines ,
    //                 "selectedLines": $scope.selectedLines
    //             }
    //               };

    //          })
    //         .error(function (error) {
    //             $scope.status = 'Unable to load data: ' + error.message;
    //         });
    // }
    function declareVariables() {

        API = Constants.API.AUTHORIZE_CODE;
        // $scope.option = API.;
   }
    function init() {



        //Initialize Variables
        // $scope.onlyNumbers = /^[0-9]+$/;
        $scope.availableAll=false;
        $scope.optionAll=false;
        $scope.selectAll=false;
        $scope.availableLines = [];
        $scope.availableLinesCount = 0;

        $scope.selectedLines = [];
        $scope.selectedLinesCount = 0;
        $scope.CREATE_AUTHORIZATION_CODES_TITLE=Config.CREATE_AUTHORIZATION_CODES_TITLE;
        $scope.AUTHORIZATION_CODE_DESC = Config.AUTHORIZATION_CODE_DESC;
        declareVariables();
        getStateParams();
         $scope.model=false;
        $scope.$watch('models',function(newVal,oldVal) {
            if(oldVal!==undefined)
            {
               console.log("model changed");
                $scope.model=true;
            }
        },true);
        $scope.$watch('availableLines',function(newVal,oldVal) {
         if($scope.availableLines.length==0)
         {
            $scope.availableAll=false;
         }
        },true);
        $scope.$watch('selectedLines',function(newVal,oldVal) {
         if($scope.selectedLines.length==0)
         {
            $scope.selectAll=false;
         }
        },true);
         // $rootScope.$on('record:dropped', function(){
         //  alert("123");

         //  });
        // $scope.getAvail=function()
        // {
        //     if($scope.allclear==true)
        //     {
        //         return false;
        //     }
        //     else if($scope.allset==true)
        //     {
        //         return true;
        //     }
        // }
        // $scope.$watch('availableLines',function(newVal,oldVal) {
        //     if(newVal)
        //     {
        //         $scope.availableAll=false;
        //     }
        //     else if( $scope.allset){
        //         $scope.availableAll=true;
        //     }
        // },true);
        // $scope.$watch('availableLines', function () {
        //         var allSet = true,
        //             allClear = true;
        //         angular.forEach($scope.availableLines, function (cb, index) {
        //             if (cb.isC) {
        //                 allClear = false;
        //             } else {
        //                 allSet = false;
        //             }
        //             console.log()
        //         });

        //         if ($scope.allselected !== undefined) {
        //             $scope.allselected = allSet;
        //         }
        //         if ($scope.allclear !== undefined) {
        //             $scope.allclear = allClear;
        //         }

        //         $element.prop('indeterminate', false);
        //         if (allSet) {
        //             $scope.master = true;
        //         } else if (allClear) {
        //             $scope.master = false;
        //         } else {
        //             $scope.master = false;
        //             $element.prop('indeterminate', true);
        //         }

        //     }, true);
        //Load Available Lines
        //getAvailableLines();

    }

    init();
    // $scope.watchScope=function(){

    // }
    $scope.selectAllAvailableLines = function(event) {
        var grid = document.getElementById('availableLinesGrid');
        var isSelectAllChecked = document.getElementById('select-all-available-lines').checked;

        //select all the available lines
        if($scope.availableAll) {
            for (var i = 0; i < angular.element(grid).find('li').length; i++) {
                angular.element(grid).find('li').eq(i).addClass('selected-line');
                availableLinesChosen.push($scope.availableLines[i]);
            };
        } else {
            for (var i = 0; i < angular.element(grid).find('li').length; i++) {
                angular.element(grid).find('li').eq(i).removeClass('selected-line');
                availableLinesChosen = [];
            };
        }

    }
    // $scope.checkStatus=function()
    // {
    //        $scope.$watch('availableLines',function(newVal,oldVal)
    //         {
    //         console.log(newVal,oldVal);

    //        });
    // }
    $scope.updateStatus=function(){
        if($scope.accountName!==undefined && $scope.authDescription!==undefined)
        {
              if($scope.accountName.length>=2 && $scope.authDescription.length>=2)
            {
                if($scope.createAccountCodeForm.authDesc.$pristine && $scope.createAccountCodeForm.accountName.$pristine && $scope.model==false)
                {
                    return true;
                }
                else{
                    return false;
                }

            }
            else{
                console.log('test');
                return true;
            }
        }
        else{
            return true;
        }

        // else if($scope.createAccountCodeForm.authDesc.$pristine){
        //     return true;
        // }
        // else if(!$scope.model)
        // {
        //   return true;
        // }
        //(createAccountCodeForm.accountName.$invalid) && createAccountCodeForm.authDesc.$pristine && model==false
    }
    $scope.onAvailableLinesClick = function(event, index) {
        var ele = event.currentTarget;
        //check whether an already chosen line is selected again
        //if so, clear the selection
        //else set selection
        console.log('test');
        if(angular.element(ele).hasClass('selected-line')) {
            angular.element(ele).removeClass('selected-line');
            availableLinesChosen.splice(availableLinesChosen.indexOf($scope.availableLines[index]), 1);
            //clear Select All checkbox selection, if any
            document.getElementById('select-all-available-lines').checked = false;
            $scope.availableAll=false;
            // $scope.allset = false;
        } else {
            angular.element(ele).addClass('selected-line');
            availableLinesChosen.push($scope.availableLines[index]);
            if(availableLinesChosen.length==$scope.availableLines.length)
            {
                $scope.availableAll=true;
            }
         // $scope.allclear=false;
        }
    }

    $scope.selectAllSelectedLines = function(event) {
        var grid = document.getElementById('selectedLinesGrid');
        var isSelectAllChecked = document.getElementById('select-all-selected-lines').checked;

        //select all the available lines
        if($scope.selectAll) {
            for (var i = 0; i < angular.element(grid).find('li').length; i++) {
                angular.element(grid).find('li').eq(i).addClass('selected-line');
                selectedLinesChosen.push($scope.selectedLines[i]);
            };
        } else {
            for (var i = 0; i < angular.element(grid).find('li').length; i++) {
                angular.element(grid).find('li').eq(i).removeClass('selected-line');
                selectedLinesChosen = [];
            };
            console.log(selectedLinesChosen);
        }

    }

    $scope.submitCode=function()
    {
        if($scope.resultStatus==false)
        {
            var params=
        {
            //"name": $scope.groupName,
            // "newName": "Test CallPickUp2",

        }
        console.log(params);
        if(searchName)
        {
          createAuthorizeCodeServices.setOption(API.UPDATE);
    //       authorizationCode": "18177166676",
    // "description": "Testdata",

           params.authorizationCode=$scope.accountName;
         params.description=$scope.authDescription;
         params.availableLines=$scope.availableLines;
           console.log(params)
           createAuthorizeCodeServices.getData(params)
            .success(function (result) {
               if(result.appHeader.statusCode == "OK") {
                    console.log(result);
                    $scope.msgType = "success";
                    $scope.msgTxt = "You have successfully updated authorization code";
                    $scope.thankuTxt="Thank You";
                    $scope.showMsg = true;
                }
                console.log("Result - ", result);
            })
            .error(function (error) {
                $scope.status = 'Unable to load data: ' + error.message;
            });
        }
        else{
         params.authorizationCode=$scope.accountName;
         params.description=$scope.authDescription;
         params.selectedLines=$scope.selectedLines;
         console.log(params);
         createAuthorizeCodeServices.setOption(API.CREATE_AUTHORIZE);
         createAuthorizeCodeServices.getData(params)
            .success(function (result) {
               console.log(result);
               if(result.appHeader.statusCode == "OK") {
                    console.log(result);
                    $scope.msgType = "success";
                    $scope.msgTxt = "You have successfully added authorization code";
                    $scope.thankuTxt="Thank You";
                    $scope.showMsg = true;
                }
                console.log("Result - ", result);
            })
            .error(function (error) {
                $scope.status = 'Unable to load data: ' + error.message;
            });
        }
        resetData();
        //$setPristine();
    }
    }
    function resetData()
    {
       $scope.createAccountCodeForm.authDesc.$setPristine();
       $scope.createAccountCodeForm.accountName.$setPristine();
       $scope.model==false;
    }
    $scope.vzSubmitBtnStatusFn = function( decision ) {
        $rootScope.vzSubmitBtnStatus = !decision;
        return decision;
    }
    $scope.onSelectedLinesClick = function(event, index) {
        var ele = event.currentTarget;
        //check whether an already chosen line is selected again
        //if so, clear the selection
        //else set selection
        if(angular.element(ele).hasClass('selected-line')) {
            angular.element(ele).removeClass('selected-line');
            selectedLinesChosen.splice(selectedLinesChosen.indexOf($scope.selectedLines[index]), 1);
            //clear Select All checkbox selection, if any
            document.getElementById('select-all-selected-lines').checked = false;
            $scope.selectAll=false;
        } else {
            angular.element(ele).addClass('selected-line');
            selectedLinesChosen.push($scope.selectedLines[index]);
            if(selectedLinesChosen.length==$scope.selectedLines.length)
            {
                $scope.selectAll=true;
            }
        }
    }

    $scope.fromAvailableLinesToSelectedLines = function(event) {
        //push chosen lines
        for (var i = 0; i < availableLinesChosen.length; i++) {
            $scope.selectedLines.push(availableLinesChosen[i]);

        };
        //after pushing the chosen lines
        //update Available Lines by deleting chosen lines
        for (var i = 0; i < availableLinesChosen.length; i++) {
            $scope.availableLines.splice($scope.availableLines.indexOf(availableLinesChosen[i]), 1);
        };

        availableLinesChosen = [];
        $rootScope.$broadcast('record:dropped');

        //updateLinesCount();
        //clear Select All checkbox selection, if any
        document.getElementById('select-all-available-lines').checked = false;
    }
    $scope.vzSubmitBtnStatusFn = function( decision ) {
        $rootScope.vzSubmitBtnStatus = !decision;
        return decision;
    }
    function getStateParams(){
        searchName = $state.params.code;
        var params;
        console.log(searchName);
        var authCodeList  = cache.get("authCodeList");
        if(searchName){
            if( authCodeList  ) {
                result = $filter('filter')(authCodeList, {code: searchName})[0];
                console.log(result);
                if( typeof(result) != 'undefined' ) {
                    $scope.accountName = result.code;
                    //console.log(result.name);
                    $scope.authDescription = result.description;
                }
               //getAvailableLines($scope.callPickUpGroupName);

            } else {
                manageAuthorizeCodeServices.setOption( API.AUTHORIZE_SUMMARY );
                manageAuthorizeCodeServices.getData()
                .success(function (result) {
                    //console.log("Result - ", result);
                    authCodeList = result.appResult.serviceRepsonse.codeEntries;
                    cache.put("authCodeList",authCodeList);
                    var result = $filter('filter')(authCodeList,{code: searchName})[0]; //$filter('filter')(accountList, function (d) {return d.code === '654321';})[0];
                    $scope.accountName = result.code;
                    $scope.authDescription = result.description;
             });
                //getAvailableLines($scope.callPickUpGroupName);
            }
            params={
                "authorizationCode": $scope.accountName
                         }
                          console.log("tets"+params);
            //getAvailableLines($scope.callPickUpGroupName);
            createAuthorizeCodeServices.setOption(API.MANAGE);
            getData(params);

        }
        else{
             //$scope.callPickUpGroupName = "";
              //$scope.availableLinesTemplate = "partials/features/vz-grid/vz.grid.create-group-pickup.html";
             //remoteCallPickUpServices.setOption(API.GET_NEW_AVAILABLE_LINES);
             params={};
             getlookUpData();
             //getNewAvailableLines();
        }
    }
    function getData(name) {
         //$scope.availableLinesTemplate = "partials/features/vz-grid/vz.grid.authorize-code-available-lines.html";
           $scope.availableLinesTemplate = "partials/features/vz-grid/vz.grid.authorize-code-available-lines.html";
            console.log(name);
            createAuthorizeCodeServices.getData(name)
            .success(function (result) {
                console.log(result);
                $scope.availableLines=result.appResult.serviceRepsonse.availableLines || {};
                //$scope.availableLines = result.appResult.serviceRepsonse.availableLines|| {};
                console.log($scope.availableLines);
                //$scope.availableLinesCount = $scope.availableLines.length;

                $scope.selectedLines =  result.appResult.serviceRepsonse.selectedLines || {};

                //$scope.optionalLines = result.appResult.serviceRepsonse.optionalUsagePhoneNumberList || {};

                $scope.models = {
                    selected: null,
                    lists: {
                        "availableLine": $scope.availableLines ,
                        "selectedLines": $scope.selectedLines
                    }
                };

            })
            .error(function (error) {
                $scope.status = 'Unable to load data: ' + error.message;
            });
    }
    function  getlookUpData()
    {
        $scope.availableLinesTemplate = "partials/features/vz-grid/vz.grid.authorize-code-available-lines.html";
          createAuthorizeCodeServices.setOption(API.AVAILABLE_LINES);
          var params={};
          createAuthorizeCodeServices.getData(params).success(function (result)
          {
            console.log(result);
            $scope.availableLines=result.appResult.serviceRepsonse.lineInfoList||[];
            $scope.selectedLines=[];
            console.log($scope.availableLines);
            $scope.models = {
                    selected: null,
                    lists: {
                        "availableLine": $scope.availableLines ,
                        "selectedLines": $scope.selectedLines
                    }
                };
                console.log($scope.models);
            })
          .error(function (error) {
                $scope.status = 'Unable to load data: ' + error.message;
            });
    }
    $scope.formatLineNumber = function(event) {

        var lineNumberInput = document.getElementById('lookupNo');
        lineNumber = lineNumberInput.value,
        charCode = (event.which) ? event.which : event.keyCode,
        acceptable = [48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 13, 32, 45, 46, 118, 8, 0];

        //restrict non-numeric inputs
        if(acceptable.indexOf(charCode) == -1) {
            lineNumber = lineNumber.replace(/\D/g, '');
        }
        //process formatting
        if(acceptable.indexOf(charCode) < 15) {
            lineNumber = lineNumber.replace(/\D/g, '');
            // if(lineNumber.length > 2) {
            //     lineNumber = lineNumber.substring(0,3) + '-' + lineNumber.substring(3);
            // }
            // if(lineNumber.length > 6) {
            //     lineNumber = lineNumber.substring(0,7) + '-' + lineNumber.substring(7);
            // }
        }
        //assign formatted value back to <input>
        angular.element(lineNumberInput).val(lineNumber);

  }
    $scope.fromSelectedLinesToAvailableLines = function(event) {
        //push chosen lines
        for (var i = 0; i < selectedLinesChosen.length; i++) {
            $scope.availableLines.push(selectedLinesChosen[i]);
        };
        //after pushing the chosen lines
        //update Selected Lines by deleting chosen lines
        for (var i = 0; i < selectedLinesChosen.length; i++) {
            $scope.selectedLines.splice($scope.selectedLines.indexOf(selectedLinesChosen[i]), 1);
        };

        selectedLinesChosen = [];
        updateLinesCount();
        //clear Select All checkbox selection, if any
        document.getElementById('select-all-selected-lines').checked = false;
    }

    // updateLinesCount = function() {
    //     $scope.availableLinesCount = $scope.availableLines.length;
    //     $scope.selectedLinesCount = $scope.selectedLines.length;
    // }
    $scope.moveUp=function()
    {
        var parent=document.getElementById('selectedLinesGrid');
        var list=document.getElementById('selectedLinesGrid').children;
        //console.log(list.children);
        for(var i=0;i<list.length;i++)
        {
               if(list[i].className.search('selected-line')!==-1 && list[i].previousElementSibling!==null )
               {
                    parent.insertBefore(list[i], list[i].previousElementSibling);
                    //angular.element(list[i-1]).removeClass('selected-line');
               }
               // angular.element(list[i]).removeClass('selected-line');
        }
        //angular.element(list[i]).removeClass('selected-line');
        selectedLinesChosen=[];
         //console.log(document.getElementById('select-all-available-lines').checked);
       // for(var i=0;i<$scope.selectedLines.length;i++)
       // {
       //   if($scope.selectedLines)
       // }
    }
     $scope.moveDown=function()
    {
        var parent=document.getElementById('selectedLinesGrid');
         var list=document.getElementById('selectedLinesGrid').children;
        //var list=parent.children();
        //console.log(list.children);
        for(var i=list.length-1;i>=0;i--)
        {
               if(list[i].className.search('selected-line')!==-1 && list[i].nextElementSibling!==null )
               {
                //console.log( list[i].nextElementSibling);
                    //list[0].insertAfter(list[1]);
                    parent.insertBefore(list[i].nextElementSibling, list[i]);
                    //angular.element(list[i+1]).removeClass('selected-line');
               }
                     //angular.element(list[i+1]).removeClass('selected-line');
                     //angular.element(list[i]).removeClass('selected-line');
               }

        selectedLinesChosen=[];
    }

    // $scope.scrollUpwards = function(event) {
    //     var availableLinesGridContainer = document.getElementById('availableLinesGridContainer');
    //     var selectedLinesGridContainer = document.getElementById('selectedLinesGridContainer');

    //     availableLinesGridContainer.scrollTop -= 42;
    //     selectedLinesGridContainer.scrollTop -= 42;
    // }

    // $scope.scrollDownwards = function(event) {
    //     var availableLinesGridContainer = document.getElementById('availableLinesGridContainer');
    //     var selectedLinesGridContainer = document.getElementById('selectedLinesGridContainer');

    //     availableLinesGridContainer.scrollTop += 42;
    //     selectedLinesGridContainer.scrollTop += 42;
    // }

    // $scope.sendAlgorithmDetails = function() {
    //     var algorithmSettings = [],
    //     selectedRings = $scope.rings_selected,
    //     advanceToNextNumber = document.getElementById('advance-to-next-number').checked;

    //     algorithmSettings.push(
    //         {'selectedRings': selectedRings, 'advanceToNextNumber': advanceToNextNumber}
    //     );

    //     console.log('Selected Lines: ' + $scope.selectedLines);
    //     console.log('Algorithm Settings: ' + algorithmSettings);
    //     alert('Selected Lines: ' + JSON.stringify($scope.selectedLines) + '\n\nAlgorithm Settings: ' + JSON.stringify(algorithmSettings));

    //     huntGroupServices.sendSelectedLines($scope.selectedLines)
    //         .success(function(result) {

    //         })
    //         .error(function(error) {

    //         });

    //     huntGroupServices.sendAlgorithmSettings(algorithmSettings)
    //         .success(function(result) {

    //         })
    //         .error(function(error) {

    //         });
    // }
};

createAuthorizeCodeCtrl.$inject = ["$scope", "$http", "ngDialog", "$compile", "$state","$rootScope","createAuthorizeCodeServices","Config","cache","manageAuthorizeCodeServices","Constants","$filter"];
angular.module( window.AppName ).controller("createAuthorizeCodeCtrl", createAuthorizeCodeCtrl);