(function() {
    var Controller = function($scope, manageScheduleService, scheduleConst) {
        function init() {
            //Initialize Variables
            $scope.pageTitle = scheduleConst.managepageTitle;
            $scope.pageDesc = scheduleConst.pageDesc;
            $scope.instructionDetails = scheduleConst.manageInstructions.instructions;
            $scope.tooltipinfo = scheduleConst.tooltipinfo;

            $scope.selectAll = false;
            $scope.searchQuery = manageScheduleService.getSearchQuery();
            $scope.filterBy = manageScheduleService.getFilter();

            serviceResponseHandler();
            loadList({});
        }

        /**
         * Wrapper function for service
         */
        function loadList () {
            $scope.loading = true;
            manageScheduleService.loadList.apply(this, arguments)
                .then(serviceResponseHandler)
                .catch(errorHandler)
                .then(function () {
                    $scope.loading = false;
                });
        }

        /**
         * Common service response handler to update $scope upon response
         *
         * @method     serviceResponseHandler
         * @param      {Object}  response  returned data
         * @return     {Object}  response object
         */
        function serviceResponseHandler (response) {
            $scope.selectAll = false;
            $scope.list = manageScheduleService.getList();
            $scope.count = manageScheduleService.getCount();
            $scope.pageSize = manageScheduleService.getPageSize();
            $scope.pagesLength = manageScheduleService.getPagesLength();
            $scope.currentPage = manageScheduleService.getCurrentPage();
            $scope.length = manageScheduleService.getLength();
            $scope.total = manageScheduleService.getTotal();

            $scope.noRecordsMessage = $scope.total === 0 ? "No Records Found" : "The schedule cannot be found.";

            return response;
        }

        /**
         * Common error response handler
         *
         * @method     errorHandler
         * @param      {Error}  err     Error instance with appropraite message to display
         */
        function errorHandler (err) {
            $scope.msgType = 'error';
            $scope.msgTxt = err.message || 'An unknown error has occured';
            $scope.showMsg = true;
        }

        /**
         * Common success response handler
         *
         * @method     successHandler
         * @param      {String}  message  Success message string
         */
        function successHandler (message) {
            $scope.msgType = 'success';
            $scope.msgTxt = message;
            $scope.showMsg = true;
        }

        /**
         * Paginate previous page
         *
         * @method     prev
         */
        $scope.prev = function () {
            toggleSelect(false);
            manageScheduleService.prevPage()
                .then(serviceResponseHandler)
                .catch(errorHandler);
        };

        /**
         * Paginate next page
         *
         * @method     next
         */
        $scope.next = function () {
            toggleSelect(false);
            manageScheduleService.nextPage()
                .then(serviceResponseHandler)
                .catch(errorHandler);
        };

        /**
         * Update page size and refresh
         *
         * @method     setPageSize
         * @param      {Number}  value   Rows per page value
         */
        $scope.setPageSize = function (value) {
            toggleSelect(false);
            manageScheduleService.setPageSize(value)
                .then(serviceResponseHandler)
                .catch(errorHandler);
        };

        /**
         * Performs filter operation
         *
         * @method     filter
         * @param      {String}  filterBy  The type by which to filter against (business or holiday)
         */
        $scope.filter = function (filterBy) {
            toggleSelect(false);
            manageScheduleService.filter(filterBy)
                .then(serviceResponseHandler)
                .catch(errorHandler);
        };

        /**
         * Performs search operation
         *
         * @method     search
         * @param      {String}  searchQuery
         */
        $scope.search = function (searchQuery) {
            var words = searchQuery.replace(/[^a-zA-Z0-9 ]/g, " ").split(" ");

            for (var i = 0, ln = words.length; i < ln; i++) {
                if (!words[i]) {
                    words.splice(words.indexOf(words[i]), 1);
                    ln = words.length;
                    i--;
                }
            }

            searchQuery = words.join(" ");

            manageScheduleService.search(searchQuery)
                .then(serviceResponseHandler)
                .catch(errorHandler);

            return searchQuery;
        };

        /**
         * Performs a delete operation and reloads the list
         *
         * @method     deleteSchedule
         */
        $scope.deleteSchedule = function () {
            var list = manageScheduleService.getList(),
                del = [],
                params = { scheduleList: del };

            for (var i = 0, ln = list.length; i < ln; i++) {
                if (list[i].selected) {
                    del.push(list[i]);
                }
            }

            manageScheduleService.delete(params)
                .then(serviceResponseHandler)
                .then(function (response) {
                    manageScheduleService.loadList({}, true)
                        .then(serviceResponseHandler)
                        .catch(errorHandler)
                        .then(function () {
                            successHandler(response.message);
                        });
                })
                .catch(errorHandler);
        };

        $scope.$watch('selectAll', toggleSelect);
        function toggleSelect (value) {
            var list = manageScheduleService.getList();

            for (var i = 0, ln = list.length; i < ln; i++) {
                list[i].selected = value;
            }
        }

        init();
    };


    Controller.$inject = ['$scope', 'manageScheduleService', 'scheduleConst'];

    angular.module(window.AppName).controller('manageScheduleCtrl', Controller);
})();