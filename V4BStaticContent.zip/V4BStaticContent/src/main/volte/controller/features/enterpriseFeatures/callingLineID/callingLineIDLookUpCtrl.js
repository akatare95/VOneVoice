var callingLineIDLookUpCtrl= function($scope, ngDialog, callingLineConst, Constants, callingPlanServices, cache) {

  function declareVariables() {

    API = Constants.API.COMMON;

    $scope.pageTitle = callingLineConst.pageTitle;
    $scope.pageTitle_Desc = callingLineConst.pageTitle_Desc;

    $scope.useUserPhoneNumberFlag = false;

    $scope.userFlagTrue = true;
  }

  $scope.formatLineNumber = function(event) {

        var lineNumberInput = document.getElementById('lookupNo');
        lineNumber = lineNumberInput.value,
        charCode = (event.which) ? event.which : event.keyCode,
        acceptable = [48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 13, 32, 45, 46, 118, 8, 0];

        //restrict non-numeric inputs
        if(acceptable.indexOf(charCode) == -1) {
            lineNumber = lineNumber.replace(/\D/g, '');
        }
        //process formatting
        if(acceptable.indexOf(charCode) < 15) {
            lineNumber = lineNumber.replace(/\D/g, '');
            if(lineNumber.length > 2) {
                lineNumber = lineNumber.substring(0,3) + '-' + lineNumber.substring(3);
            }
            if(lineNumber.length > 6) {
                lineNumber = lineNumber.substring(0,7) + '-' + lineNumber.substring(7);
            }
        }
        //assign formatted value back to <input>
        angular.element(lineNumberInput).val(lineNumber);

  }

  function getLookUpInfo() {

    callingPlanServices.setOption( API.LINE_LOOKUP );
    callingPlanServices.fetchData()
        .success(function (result) {
             console.log("Result - ", result);
        })
        .error(function (error) {
            $scope.status = 'Unable to load data: ' + error.message;
        });

  }

  $scope.submit = function() {

  }

  function init() {

      declareVariables();
      getLookUpInfo();

      console.log("1");

    }

    init();

    $scope.lookupDialog = function() {

		var new_dialog = ngDialog.open({ template: 'partials/components/dialog/lookupCallingLineID.html',
           closeByDocument: true,
           closeByEscape: true
      	});
	}
}
callingLineIDLookUpCtrl.$inject = ["$scope", "ngDialog","callingLineConst", "Constants", "callingPlanServices","cache"];
angular.module( window.AppName ).controller("callingLineIDLookUpCtrl", callingLineIDCtrl);