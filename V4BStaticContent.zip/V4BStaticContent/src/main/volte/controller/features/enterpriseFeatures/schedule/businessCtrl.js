(function() {
    var Controller = function($scope, $stateParams, $timeout, businessScheduleService, scheduleConst) {
        function init() {
            $scope.schedules = [];

            if ($scope.operation === 'update') {
                $scope.loading = true;
                $scope.pageTitle = scheduleConst.reviewBusinessPageTitle;
                $scope.pageDesc = scheduleConst.pageDesc;

                businessScheduleService.loadBusiness($stateParams.scheduleName)
                    .then(function (schedules) {
                        $scope.schedules = schedules.length ? schedules : [{ days: weekBuilder() }];
                        $scope.loading = false;
                        updateActivePreset();
                    })
                    .catch(errorHandler);
            } else {
                $scope.pageTitle = scheduleConst.businessPageTitle;
                $scope.pageDesc = scheduleConst.pageDesc;
                $scope.instructionDetails = scheduleConst.createNewBusinessInstructions.instructions;
                $scope.activePreset = '925'; // '247' | '925' | 'custom'
            }
        }

        function infoHandler (message) {
            $scope.msgType = 'escalamation';
            $scope.msgTxt = message;
            $scope.showMsg = true;
        }

        /**
         * Generic error handler
         *
         * @method     errorHandler
         * @param      {Error}  err     Error instance with the appropriate message
         * @return     {Error}
         */
        function errorHandler(err) {
            $scope.msgType = 'error';
            $scope.msgTxt = err.message || 'An unknown error has occured';
            $scope.showMsg = true;
            $scope.loading = false;
            return err;
        }

        /**
         * Updates the value of $scope.activePreset based upon the schedule content
         */
        function updateActivePreset() {
            var schedules = $scope.schedules,
                schedule = schedules[0];

            if (schedules.length === 1) {
                if (is247Preset(schedule)) {
                    $scope.activePreset = '247';
                } else if (is925Preset(schedule)) {
                    $scope.activePreset = '925';
                } else {
                    $scope.activePreset = 'custom';
                }
            } else {
                $scope.activePreset = 'custom';
            }
        }

        /**
         * Pill buttons handler
         *
         *  -------------------------
         * | 24 x 7 | 9 - 5 | Custom |
         *  -------------------------
         */
        $scope.$watch('activePreset', function (value) {
            switch (value) {
                case '247':
                    $scope.schedules = [{
                        days: weekBuilder(value)
                    }];
                    infoHandler("You have scheduled with 24x7 for Business Schedule");
                    break;
                case '925':
                    $scope.schedules = [{
                        days: weekBuilder(value)
                    }];
                    infoHandler("You have scheduled with 9-5 for Business Schedule");
                    break;
                default:
                    $scope.showMsg = false;
                    _.each($scope.schedules, function (schedule) {
                        _.each(schedule.days, function (day) {
                            dayBuilder(day);
                        });
                    });
                    break;
            }
        });

        /**
         * Delete row
         */
        $scope.onDeleteClick = function (schedule) {
            var schedules = $scope.schedules;

            schedules.splice(_.indexOf(schedules, schedule), 1);

            // Update global activePreset value
            updateActivePreset();
        };

        /**
         * Time change handler
         */
        $scope.onTimeChange = function (schedule, day) {
            var start = day.startTime,
                end = day.endTime,
                errorMessage = '';

            // Handle end time selection options
            if (_.isNumber(start)) {
                // Re-populate end time options
                day.endTimePlaceholder = 'Select';
                day.endTimes = timeBuilder();
            } else {
                // Disable end time
                day.endTimes = [];
                day.endTime = '';

                if (_.contains(['allday', 'closed'], start)) {
                    day.endTimePlaceholder = 'N/A';
                }
            }

            // Handle error
            if (_.isNumber(start) && _.isNumber(end) && start >= end) {
                errorMessage = 'The start time must be before the end time.';
            }
            day.errorMessage = errorMessage; // Show error message (if necessary)

            // Update global activePreset value
            updateActivePreset();
        };

        /**
         * New button hander
         */
        $scope.onNewClick = function () {
            $scope.schedules.push({
                days: weekBuilder()
            });

            // By definition this is not a valid preset
            $scope.activePreset = 'custom';
        };

        /**
         * Navigate back to schedule type selector
         */
        $scope.onCancel = function () {
            $scope.navigate('default');
        };

        /**
         * Do validation test and submit if successful
         *
         */
        $scope.onSubmit = function () {
            var isValid = true,
                errorMessage = "";

            $scope.showMsg = false;

            if ($scope.schedules.length) {
                _.each($scope.schedules, function (schedule) {
                    _.each(schedule.days, function (day) {
                        if (isValid) {
                            isValid = !day.errorMessage;
                            errorMessage = day.errorMessage;
                        }

                        if (isValid && !_.contains(['allday', 'closed'], day.startTime)) {
                            if (!day.startTime || !day.endTime) {
                                isValid = false;
                                errorMessage = day.errorMessage = "There are missing fields in your request";
                            }
                        }
                    });
                });
            } else {
                isValid = false;
                errorMessage = "There are no schedules to submit.";
            }

            // Submit
            if (isValid) {
                businessScheduleService.upsertBusiness($scope.operation, {
                    scheduleName: $scope.scheduleName,
                    oldScheduleName: $stateParams.scheduleName,
                    schedules: $scope.schedules
                })
                .then(function () {
                    $scope.navigate('success');
                }).catch(errorHandler);
            } else {
                errorHandler(new Error(errorMessage));
            }
        };

        init();
    };

    /**
     * Begin Utility Variables/Functions
     */
    var startDate = new Date(2016, 0, 1);

    /**
     * Builds the days of the week
     *
     * @method     weekBuilder
     */
    var weekBuilder = function (preset) {
        var days = [],
            year = startDate.getFullYear(),
            month = startDate.getMonth(),
            date = startDate.getDate();

        _.each(_.range(7), function (i) {
            var day = {};

            switch (preset) {
                case '247':
                    day.startTime = 'allday';
                    break;
                case '925':
                    // Close on weekends
                    if (i === 0 || i === 6) {
                        day.startTime = 'closed';
                    }

                    // Open from 9:00 to 5:00 on weekdays
                    else {
                        day.startTime = new Date(year, month, date, 9).getTime();
                        day.endTime = new Date(year, month, date, 17).getTime();
                    }
                    break;
            }

            day = dayBuilder(day);

            days.push(day);
        });

        return days;
    };

    var dayBuilder = function (day) {
        var startTimes = [
            { name: 'All Day', value: 'allday' },
            { name: 'Closed', value: 'closed' }
        ];

        day = _.defaults(day || {}, {
            startTime: '',
            endTime: '',
            startTimePlaceholder: 'Select',
            endTimePlaceholder: 'Select',
            startTimes: timeBuilder(startTimes),
            errorMessage: ''
        });

        if (_.contains(['allday', 'closed'], day.startTime)) {
            day.endTimes = [];
            day.endTimePlaceholder = 'N/A';
        } else {
            day.endTimes = timeBuilder([]);
        }

        return day;
    };

    /**
     * Populates the passed array with times { name: '9:00 a.m.', value: timestamp }
     */
    var timeBuilder = function (times) {
        times = times || [];

        times.push({
            name: '12:00 a.m.',
            value: new Date(startDate.getFullYear(), startDate.getMonth(), startDate.getDate()).getTime()
        });

        _.each(_.range(1, 24), function (hour) {
            var meridian = hour >= 12 ? 'p.m.' : 'a.m.',
                offset = hour > 12 ? -12 : 0,
                timestamp = new Date(startDate.getFullYear(), startDate.getMonth(), startDate.getDate(), hour).getTime();

            times.push({
                name: (hour + offset) + ':00 ' + meridian,
                value: timestamp
            });
        });

        return times;
    };

    /**
     * Checks to see if the passed schedule is an 24/7 schedule or not
     *
     * @method     is247Preset
     * @param      {Object}  schedule
     * @return     {Boolean}
     */
    var is247Preset = function (schedule) {
        // Are all startTime values === "allday"?
        return _.every(schedule.days, function (day) {
            return day.startTime === 'allday';
        });
    };

    /**
     * Checks to see if the passed schedule is a 9-5 schedule or not
     *
     * @method     is925Preset
     * @param      {Object}  schedule
     * @return     {Boolean}
     */
    var is925Preset = function (schedule) {
        var is925 = true,
            nine = new Date(startDate.getFullYear(), startDate.getMonth(), startDate.getDate(), 9).getTime(),
            five = new Date(startDate.getFullYear(), startDate.getMonth(), startDate.getDate(), 17).getTime();

        _.each(schedule.days, function (day, i, days) {
            if (is925) {
                if (i === 0 || i === days.length - 1) { // First and last (Sun and Sat) should be closed
                    is925 = day.startTime === 'closed';
                } else {
                    is925 = day.startTime === nine && day.endTime === five;
                }
            }
        });

        return is925;
    };

    Controller.$inject = ['$scope', '$stateParams', '$timeout', 'businessScheduleService', 'scheduleConst'];

    angular.module(window.AppName).controller('businessCtrl', Controller);
})();