var huntGroupReviewCtrl = function($scope, $http, ngDialog, $compile, $state, huntGroupReviewServices, huntGroupServices, huntGroupConst, cache) {

    function decareVariables() {

        $scope.vzGridTpl = "partials/features/vz-grid/vz.grid.hunt-group-review.html";

        $scope.selectedRings    =   "";

        $scope.huntGroupLineInfo = cache.get("huntgroup-lineid");
        console.log($scope.huntGroupLineInfo);
        $scope.huntGroupAlgorithmInfo = cache.get("huntgroup-algm");
       console.log($scope.huntGroupAlgorithmInfo);
        //console.log("Data V2- ", $scope.huntGroupAlgorithmInfo );
        //console.log($scope.huntGroupAlgorithmInfo);

    }

	function getHuntGroups() {
        //$scope.type = "schedule";
        //huntGroupServices.setOption( $scope.type );

        getData();
    }

    function getData() {
        huntGroupReviewServices.getData()
            .success(function (result) {
                //$scope.collection = result.data.rows;
                //$scope.numberOfSelectedlines = $scope.collection.length;
                $scope.huntGroupName = result.huntGroupDetails[0].huntGroupName;
                $scope.callingIdName = result.huntGroupDetails[0].callingIdName;
                $scope.timeZone = result.huntGroupDetails[0].timeZone;
                $scope.selectedRings = result.settings[0].selectedRings;
                //$scope.advanceToNextNumber = result.settings[0].advanceToNextNumber;
                document.getElementById('advance-to-next-number').checked = result.settings[0].advanceToNextNumber;
                $scope.algorithm = result;
            })
            .error(function (error) {
                $scope.status = 'Unable to load hunt group data: ' + error.message;
            });
    }

    function init() {

        decareVariables();

        if( typeof($scope.huntGroupLineInfo) == 'undefined') {
            $state.go( 'features.enterprise.hunt_group' );
            return;
        }

        $scope.huntGroupNumber = huntGroupServices.getHuntGroupNumber();
        $scope.huntGroupStatus = huntGroupServices.getHuntGroupStatus();
        //$scope.huntGroupInfo = huntGroupServices.getHuntGroupInfo();
        var algorithmDetails = huntGroupServices.getAlgorithmDetails();

        //alert(JSON.stringify($scope.algorithmDetails));
        //Initialize Variables
        $scope.collection = algorithmDetails.selectedLines;
        $scope.numberOfSelectedlines = algorithmDetails.selectedLines.length;

        //Load available Hunt Groups
        //getHuntGroups();
    }
    // pageTitle: "Hunt Group",
    // pageDesc:"Incoming calls to a company hunt group line  will ring  to a  group of users  as defined by the administrator. There are three ring sequences for the company to use.",
    // algorithmpageTitle:"Select Hunt Group Type (Algorithm)",
    // reviewpageTitle:"Review Hunt Group and Submit",
    // managepageTitle:"Manage Hunt Group"
    // detailsPageTitle:"Define Group Name and Number"
    $scope.pageTitle = huntGroupConst.reviewpageTitle;
    $scope.pageDesc= huntGroupConst.pageDesc;

    init();

    $scope.submitAlgorithm = function() {

        console.log("Next - " +$scope.huntGroupAlgorithmInfo.forwardTimeoutSeconds);
        //alert(JSON.stringify($scope.algorithm));
        var param = {
           "phoneNumber": $scope.huntGroupNumber,
           "huntGroupName":$scope.huntGroupLineInfo.huntGroupName,
           "callingLineIdName":$scope.huntGroupLineInfo.callingId,
           "policy":$scope.huntGroupAlgorithmInfo.policy,
           "noAnswerNumberOfRings":$scope.huntGroupAlgorithmInfo.noAnswerNumberOfRings,
           "timeZone":$scope.huntGroupLineInfo.timeZone,
           "geoTimeZone":"America/New_York",
           "active":$scope.huntGroupStatus,
           "isHuntAfterAnswer":$scope.advanceToNextNumber,
           "huntGroupMdninfoList":$scope.huntGroupAlgorithmInfo.selectedLines
        };
        if($scope.forwardAfterTimeout)
        {
            param.forwardAfterTimeout=$scope.forwardAfterTimeout;
            if(typeof(param.forwardTimeoutSeconds)!=undefined)
            {
                console.log('undefined');
            }
            param.forwardTimeoutSeconds=$scope.huntGroupAlgorithmInfo.forwardTimeoutSeconds=undefined?undefined:$scope.huntGroupAlgorithmInfo.forwardTimeoutSeconds;
            param.forwardToPhoneNumber=$scope.huntGroupAlgorithmInfo.forwardToPhoneNumber ;
        }
        huntGroupServices.modifyHuntGroupInfo( param )
            .success(function(result) {
                try {
                    if(result.appHeader.statusCode.toUpperCase() == "OK") {
                       $state.get('features.enterprise.hunt_group').data.successTxt = 'thankuTxt';
                       $state.go('features.enterprise.hunt_group', {obj:'thankuTxt'},{reload:true});
                        // $scope.msgType = "success";
                        // $scope.thankuTxt="Thank You";
                        // $scope.msgTxt = "You have successfully submitted the request for updating hunt group";
                        // $scope.showMsg = true;
                    } else {
                        $scope.msgType = "error";
                        $scope.thankuTxt="Error";
                        $scope.msgTxt = result.appHeader.statusMessage;
                        $scope.showMsg = true;
                    }
                } catch(err) {
                    console.log("Failure - "+err.message);
                }
            })
            .error(function(error) {
                console.log("Failure - "+err.message);
            });
    }

};


huntGroupReviewCtrl.$inject = ["$scope", "$http", "ngDialog", "$compile", "$state", "huntGroupReviewServices", "huntGroupServices", "huntGroupConst", "cache"];
angular.module( window.AppName ).controller("huntGroupReviewCtrl", huntGroupReviewCtrl);
