var updateAccountCodeCtrl = function($scope, $http, ngDialog, $compile, $state, manageAccountCodeServices, accountCodeServices, Constants, $rootScope, cache, $filter) {


    function getData() {}

    /*$scope.deleteSchedule = function() {
        var i = 0;
        var temp = [];
        angular.forEach($scope.collection, function(value, key) {
            if($scope.collection[i].isChecked == false) {
                temp.push($scope.collection[i]);
            }
            i++;
        });
        $scope.collection = temp;
        $scope.numberOfCodes = $scope.collection.length;
    }*/
 $scope.formatLineNumber = function(event) {

        var lineNumberInput = document.getElementById('lookupNo');
        lineNumber = lineNumberInput.value,
        charCode = (event.which) ? event.which : event.keyCode,
        acceptable = [48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 13, 32, 45, 46, 118, 8, 0];

        //restrict non-numeric inputs
        if(acceptable.indexOf(charCode) == -1) {
            lineNumber = lineNumber.replace(/\D/g, '');
        }
        //process formatting
        if(acceptable.indexOf(charCode) < 15) {
            lineNumber = lineNumber.replace(/\D/g, '');
            if(lineNumber.length > 2) {
                lineNumber = lineNumber.substring(0,3) + '-' + lineNumber.substring(3);
            }
            if(lineNumber.length > 6) {
                lineNumber = lineNumber.substring(0,7) + '-' + lineNumber.substring(7);
            }
        }
        //assign formatted value back to <input>
        angular.element(lineNumberInput).val(lineNumber);

  }
    function declareVariables() {

        //Load Constants
        API = Constants.API.ACCOUNT_CODE;

        //Define tpl path
        $scope.vzGridTpl = "partials/features/vz-grid/vz.grid.manage-account-code.html";

        $scope.modelModified = false;

        $scope.accountName = "";
        $scope.accountDescription = "";

    }

    function getAccountList() {

        var searchCode = $state.params.code;

        var accountList  = cache.get("account-list");

        if( accountList ) {
            result = $filter('filter')(accountList, {code: searchCode})[0];
            if( typeof(result) != 'undefined' ) {
                $scope.accountName = result.code;
                $scope.accountDescription = result.description;
            }

        } else {

            manageAccountCodeServices.setOption( API.ACCOUNT_SUMMARY );
            manageAccountCodeServices.getData()
            .success(function (result) {
                accountList = result.appResult.serviceRepsonse.codeEntries;
                cache.put("account-list",accountList);
                var result = $filter('filter')(accountList, {code: searchCode})[0]; //$filter('filter')(accountList, function (d) {return d.code === '654321';})[0];
                $scope.accountName = result.code;
                $scope.accountDescription = result.description;
             });


        }

    }
    $scope.remove = function(index){
        $scope.collection.splice(index, 1);
    }

    $scope.ngEnableSubmit = function() {

        if( (typeof($scope.accountName) != 'undefined' && $scope.accountName.length>=2 && $scope.accountName.length<12)
                && (typeof($scope.accountDescription) != 'undefined' && $scope.accountDescription.length>1 && $scope.accountDescription.length<250) ) {
            $scope.modelModified = true;
        }

    }

    $scope.vzSubmitBtnStatusFn = function( decision ) {
        $rootScope.vzSubmitBtnStatus = !decision;
        return decision;
    }

    $scope.submitCode = function() {

        $scope.createAccountCodeForm.$setPristine();

        var params = [];
        params.push({"code": $scope.accountName, "description": $scope.accountDescription});
        var sendRequestData = { "codeEntries": params };

        manageAccountCodeServices.setOption( API.CREATE_ACCOUNT );
        manageAccountCodeServices.postData( sendRequestData )
            .success(function (result) {
                if(result.appHeader.statusCode == "OK") {

                    $scope.msgType = "success";
                    $scope.msgTxt = "Successfully Created";
                    $scope.showMsg = true;

                } else {

                    $scope.msgType = "error";
                    $scope.msgTxt = "Error!";
                    $scope.showMsg = true;

                }

                //$scope.collection = result.appResult.serviceRepsonse.codeEntries;

             });

    }

    function init() {

        //Initialize Variables
        $scope.collection = {};
        $scope.numberOfCodes;
        $scope.selectedCodes = {};

        //Load available Hunt Groups
        //getScheduleGroups();

        declareVariables();

        getAccountList();

    }

    init();

};


updateAccountCodeCtrl.$inject = ["$scope", "$http", "ngDialog", "$compile", "$state", "manageAccountCodeServices", "accountCodeServices", "Constants", "$rootScope", "cache", "$filter"];
angular.module( window.AppName ).controller("updateAccountCodeCtrl", updateAccountCodeCtrl);