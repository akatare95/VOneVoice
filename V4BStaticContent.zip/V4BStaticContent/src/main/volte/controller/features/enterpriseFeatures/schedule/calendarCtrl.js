(function () {
    var Controller = function ($scope) {
        var activeDate = new Date(today.getFullYear(), 0);

        function init () {
            $scope.jumpTo = [
                $scope.activeDate.getFullYear(),// 1970,
                $scope.activeDate.getMonth()
            ].join('/');

            $scope.$on('eventchange', function (e, events) {
                $scope.$parent.events = $scope.events = events; // Make sure the parent has the same instance
                renderCalendar(0);
            });

            $scope.$on('refreshcalendar', function () {
                renderCalendar(0);
            });

            renderCalendar();
        }

        /**
         * Set global calendar date and refresh the calendar
         */
        $scope.$watch('jumpTo', function (val, old) {
            var exploded = val.split('/'),
                year = exploded[0],
                month = exploded[1];

            if (year >= 1970) {
                activeDate.setFullYear(year);
                activeDate.setMonth(month);
                renderCalendar(0);
            } else {
                $scope.$emit('error', new Error("The earliest holiday start date allowed is January 1, 1970."));
                $scope.jumpTo = old;
                return false;
            }
        });

        /**
         * Day click handler
         *
         * @method     onDayClick
         * @param      {Object}  day - Day object
         */
        $scope.onDayClick = function (day) {
            if (day.date) {
                $scope.$emit('dayclick', day);
            }
        };

        /**
         * Go to previous month
         */
        $scope.prev = function () {
            var year = activeDate.getFullYear();

            if (year > 1970) {
                renderCalendar(-1);
            } else {
                $scope.$emit('error', new Error("The earliest holiday start date allowed is January 1, 1970."));
                return false;
            }
        };

        /**
         * Go to next month
         */
        $scope.next = function () {
            renderCalendar(1);
        };

        /**
         * Renders the calendar based on the year and month value of calendarDate
         * Additionally, offset can be either an object to jump to the desired target month
         * If no argument is provided, it will default to Jan of the current year
         *
         * Example: offset = { year: 2001, month: 1 } // Goes to Feb, 2001
         *          offset = 1                        // Goes to the next month
         *          offset = -1                       // Goes to the previous month
         *
         * @param {Number|Object} offset - Can be either a monthly offset integer or an object
         */
        function renderCalendar(offset) {
            var year, month, weeks;

            // If numeric
            if (!isNaN(parseFloat(offset)) && isFinite(offset)) {
                year = activeDate.getFullYear();
                month = activeDate.getMonth() + offset;

                // Round the month/year up or down
                // depending on the offset
                if (month > 11) {
                    year++;
                    month = 0;
                } else if (month < 0) {
                    year--;
                    month = 11;
                }

                activeDate.setFullYear(year);
                activeDate.setMonth(month);
                weeks = getWeeks(year, month);

                // Process date for
                // * Today's date
                _.each(weeks, function (week) {
                    _.each(week, function (day) {
                        if (day.date) { // Could be placeholders w/o valid dates
                            day.month = month;
                            day.year = year;

                            // Is this today's date event?
                            day.today = (
                                day.year  === today.getFullYear() &&
                                day.month === today.getMonth() &&
                                day.date  === today.getDate()
                            );

                            $scope.$emit('dayrender', day);
                        }
                    });
                });

                $scope.year = year;
                $scope.month = months[month];
                $scope.weeks = weeks;
                $scope.jumpOptions = [];
                $scope.jumpTo = [year, month].join('/');

                _.each(_.range(-1, 2), function (yearOffset) {
                    _.each(_.range(12), function (month) {
                        if (year + yearOffset >= 1970) {
                            $scope.jumpOptions.push({
                                name: $scope.getMonth(month) + ', ' + (year + yearOffset),
                                value:  (year + yearOffset) + '/' + month
                            });
                        }
                    });
                });
            } else {
                year = (offset && offset.year) || today.getFullYear();
                month = (offset && offset.month) || 0;

                activeDate.setFullYear(year);
                activeDate.setMonth(month);
                renderCalendar(0);
            }
        }

        init();
    }; // End Controller

    /**
     * Begin Utility Variables/Functions
     */
    var today = new Date();
    var months = [
        'January',
        'February',
        'March',
        'April',
        'May',
        'June',
        'July',
        'August',
        'September',
        'October',
        'November',
        'December'
    ];

    /**
     * Generates an array of weeks given the provided year and month with the appropriate placeholders
     *
     * Example:
     *
     * var week = [
     *     [{ date: null }, { date: null }, { date: null }, { date: null }, { date: 1    }, { date: 2    }, { date: 3    }], // Week 1
     *     [{ date: 4    }, { date: 5    }, { date: 6    }, { date: 7    }, { date: 8    }, { date: 9    }, { date: 10   }], // Week 2
     *     [{ date: 11   }, { date: 12   }, { date: 13   }, { date: 14   }, { date: 15   }, { date: 16   }, { date: 17   }], // Week 3
     *     [{ date: 18   }, { date: 19   }, { date: 20   }, { date: 21   }, { date: 22   }, { date: 23   }, { date: 18   }], // Week 4
     *     [{ date: 25   }, { date: 26   }, { date: 27   }, { date: 28   }, { date: 29   }, { date: 30   }, { date: null }]  // Week 5
     * ];
     *
     * @param      {Number}  year - The target year
     * @param      {Number}  month - The target month (Note: Jan === 0)
     * @return     {Object[]}
     */
    var getWeeks = function (year, month) {
        var weeks = [],
            week = [],
            day = 0,
            date = 1,
            ln = parseInt(new Date(year, month + 1, 0).getDate(), 10);

        for (; date <= ln; date++) {
            // Pre-padding
            if (date === 1) {
                for (; day < new Date(year, month, date).getDay(); day++) {
                    week.push({ date: null });
                }
            }

            week.push({ date: date });

            day++;

            if (day % 7 === 0) {
                day = 0;
                weeks.push(week);
                week = [];
            } else if (date === ln) {
                // Post-padding
                for (; day < 7; day++) {
                    week.push({ date: null });
                }
                weeks.push(week);
            }
        }

        return weeks;
    };

    Controller.$inject = ['$scope', '$stateParams', 'holidayScheduleService', 'scheduleConst'];

    angular.module(window.AppName).controller('scheduleCalendarCtrl', Controller);
})();