var callingLineIDCtrl= function($scope, ngDialog, callingLineConst, Constants, callingPlanServices, cache, $filter, volteServices) {

  function declareVariables() {

    API = Constants.API.CALLING_LINE_ID;

    COMMON_API = Constants.API.COMMON;

    $scope.pageTitle = callingLineConst.pageTitle;
    $scope.pageTitle_Desc = callingLineConst.pageTitle_Desc;
    $scope.instructions = callingLineConst.instructions;
    $scope.useUserPhoneNumberFlag = true;
    $scope.userFlagTrue = true;
    $scope.phoneNumbers = {};
    $scope.allowCallingLineName = false;
  }

  function formatLineNumber( event ) {

    var lineNumberInput = document.getElementById('lookupNo');
    lineNumber = lineNumberInput.value,
    charCode = (event.which) ? event.which : event.keyCode,
    acceptable = [48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 13, 32, 45, 46, 118, 8, 0];

    //restrict non-numeric inputs
    if(acceptable.indexOf(charCode) == -1) {
        lineNumber = lineNumber.replace(/\D/g, '');
    }
    //process formatting
    if(acceptable.indexOf(charCode) < 15) {
        lineNumber = processLineFormatting( lineNumber );
    }

    //assign formatted value back to <input>
    angular.element(lineNumberInput).val(lineNumber);

  }

  function processLineFormatting( lineNumber ) {

    lineNumber = lineNumber.replace(/\D/g, '');
    if(lineNumber.length > 2) {
        lineNumber = lineNumber.substring(0,3) + '-' + lineNumber.substring(3);
    }
    if(lineNumber.length > 6) {
        lineNumber = lineNumber.substring(0,7) + '-' + lineNumber.substring(7);
    }
    return lineNumber;
  }

  $scope.isChecked  = function(event) {
    //console.log( "$useUserPhoneNumberFlag    "+ $scope.useUserPhoneNumberFlag)
    if ($scope.useUserPhoneNumberFlag == true)
    {
     // $scope.allowCallingLineName = false;
      $scope.callingLineName = false;
    }
    else
      {
      //  $scope.allowCallingLineName = true;
        $scope.callingLineName = true;
      }
     // console.log( "callingLineName after  --  "+ $scope.callingLineName);
  }

$scope.isCallingChecked  = function(event) {
  $scope.allowCallingLineName = event;
   ///onsole.log($scope.callingLineIDFrm.$pristine);
  //$scope.callingLineIDFrm.$pristine = false;

}

  $scope.formatLineNumber = function(event) {
    formatLineNumber( event );
  }

  $scope.filterFn = function( no, list ) {
    no =  ( no ) ? no.replace(/-/g, "") : no;

    //result = $filter('filter')(list, {code: no})[0];
    //console.log("Result - ", result);
    //console.log("Result - ", list);

    return no;
  }

  function getCallingPlanInfo() {

    callingPlanServices.setOption( API.GET );
    callingPlanServices.fetchData()
        .success(function (result) {
          $scope.loadFlag     =  false;
             //console.log("Result - ", result);
             //console.log("Use Phone Number - " + result.appResult.serviceRepsonse.useUserPhoneNumber);
          if (result.appHeader.statusCode == "OK") {
             $scope.useUserPhoneNumberFlag = result.appResult.serviceRepsonse.useUserPhoneNumber;
             $scope.lookupNo = result.appResult.serviceRepsonse.callingLineIdPhoneNumber;
             $scope.callingLineIdName = result.appResult.serviceRepsonse.callingLineIdName;
             $scope.allowCallingLineName = result.appResult.serviceRepsonse.allowCallingLineName;
           }
           else
           {
             $scope.hideContent=true;
           }

             //$scope.useUserPhoneNumberFlag = "true";

        })
        .error(function (error) {
            $scope.status = 'Unable to load data: ' + error.message;
        });


  }

  $scope.idSelectedVote = null;

  $scope.updateLookUpNo = function( no, $index ) {

    $scope.idSelectedVote = $index;
    no = processLineFormatting( no.phoneNumber );
    document.getElementById("lookupNo").value = no;

  }

  $scope.submit = function() {
    if(!$scope.callingLineIDFrm.$pristine)
    {
      var params = {};
     // console.log($scope.allowCallingLineName);

       if ($scope.allowCallingLineName == true)
        {
          if ($scope.callingLineIdName == "")
          {
            $scope.showMsgs = true;
            $scope.msgsType = "error";
            $scope.msgsTxt = "Calling Line ID Group Name must be set in order to use it.";
              return;
          }
        }
     // console.log("Checking the validity of Phone Number (if userUserPhoneNUmber is false) " + callingLineIdPhoneNumber);
      if(!$scope.useUserPhoneNumberFlag){
        var callingLineIdPhoneNumber = document.getElementById("lookupNo").value || undefined;
        if(!isAValidPhoneNumber(callingLineIdPhoneNumber))
        {
          $scope.showMsgs = true;
          $scope.msgsType = "error";
          $scope.msgsTxt = "This number is in use as the group calling line id. It can't be deleted. Please change the group calling line id number and then retry.";
          return;
        }
      }

    params.useUserPhoneNumber = $scope.useUserPhoneNumberFlag;
    params.allowCallingLineName = $scope.allowCallingLineName;
    params.callingLineIdName = $scope.callingLineIdName;


    if( !params.useUserPhoneNumber )
      params.callingLineIdPhoneNumber = ( document.getElementById("lookupNo").value != null ) ? document.getElementById("lookupNo").value : "";  // $scope.lookupNo;
    else
      params.callingLineIdPhoneNumber = "";


    callingPlanServices.setOption( API.MODIFY );
    callingPlanServices.postData( params )
        .success(function ( result ) {

          if(result.appHeader.statusCode == "OK") {

            $scope.callingLineIDFrm.$setPristine();
            $scope.showMsgs = true;
            $scope.msgsType = "success";
            $scope.msgsTxt = "Sucessfully updated";

         } else {

            $scope.showMsgs = true;
            $scope.msgsType = "error";
            $scope.msgsTxt = result.appHeader.statusMessage;

         }

        }).error(function(){

          $scope.showMsgs = true;
          $scope.msgsType = "error";
          $scope.msgsTxt = "Unable to update the request";

        });
    }


  }


  function getLookUpInfo() {

    //$scope.phoneNumbers = cache.get("lookup");

    //if( !$scope.phoneNumbers )
    {
      callingPlanServices.setOption( COMMON_API.LINE_LOOKUP );
      callingPlanServices.fetchData()
          .success(function ( result ) {

           $scope.phoneNumbers = result.appResult.serviceRepsonse.lineInfoList;
           //cache.put("lookup",$scope.phoneNumbers);

          });
    }

  }
  $scope.lookupDialog = function() {
    $scope.lookupSearch='';
           $scope.selectedValue='';
           $scope.erroMessage = '';
           var returnFlag = true;

              var digitsRegExp = new RegExp("^([0-9])*$");
              var alphaRegExp = new RegExp("^([A-Za-z])*$");
                $scope.phoneNumber = null;
                volteServices.setOption( Constants.API.COMMON.LINE_LOOKUP );
                volteServices.getData()
                    .success(function (result) {
                       $scope.loadFlag     =  false;
                        $scope.lookupNos = result.appResult.serviceRepsonse.lineInfoList;
                        console.log("Lookup - ", result.appResult.serviceRepsonse );
                });


                $scope.lookupDropdown = [
                    {name:"Phone Lines", value: "phoneLines"},
                    {name:"User Name", value: "userName"},
                ];

                $scope.checkDropDown = function() {
                  //console.log("dropdown value..."+selectedKeyConfig[item.key]);
                  console.log("dropdown value..."+$scope.selectedValue);
                  $scope.erroMessage = "";
                }

                $scope.checkInput = function() {
                  var userInput = $scope.lookupSearch;
                  var userSelect = "";
                  var errorMsgVal = "";
                  if($scope.selectedValue)
                    userSelect = $scope.selectedValue;
                  else
                    userSelect = "phoneLines";

                  if($scope.erroMessage)
                    errorMsgVal = $scope.erroMessage;
                  else
                    errorMsgVal = "";

                  //console.log("userSelect.."+userSelect);
                  //console.log("userInput.."+userInput);

                  if(userSelect == "userName"){
                      if (alphaRegExp.test(userInput)) {
                        errorMsgVal = "";
                        returnFlag = true;
                    }else{
                      errorMsgVal = "Invalid User Name";
                      returnFlag = false;
                    }
                  }
                  if(userSelect == "phoneLines"){
                    if (digitsRegExp.test(userInput)) {
                      errorMsgVal = "";
                      returnFlag = true;
                    }else{
                      errorMsgVal = "Invalid Phone Line";
                      returnFlag = false;
                    }
                  }

                  //console.log("Final error msg.."+errorMsgVal);
                  $scope.erroMessage = errorMsgVal;
                  return returnFlag;
                }

               // if(returnFlag){

                $scope.lookupSearchResp = function() {
                    return lookupSearch;
                }

                $scope.updateFromLookUp = function( record ) {
                    $scope.phoneNumber = record.phoneNumber;
                    //console.log("$scope.phoneNumber" + $scope.phoneNumber + " &&  record.phoneNumber" + $scope.phoneNumber = record.phoneNumber );
                }

                $scope.addToTextBox = function() {

                    if( $scope.lookupNos.length == 0  ) {
                        alert('There aren\'t any records to be added');
                    }

                    if( $scope.phoneNumber == null  ) {
                        alert("Please select a record");
                    }
                    if( $scope.phoneNumber != null  && $scope.lookupNos.length != 0 )
                    {
                       $scope.callingLineIDFrm.$pristine=false;
                    }
                    document.getElementById("lookupNo").value = processLineFormatting( $scope.phoneNumber );
                    var windowIDs = ngDialog.getOpenDialogs();
                    ngDialog.close(windowIDs[1]);

                }
    var new_dialog = ngDialog.open({ template: 'partials/components/dialog/lookupNightForwarding.html',


           className: 'ngDialog-theme-vz',
           closeByDocument: false,
           closeByEscape: false,
           scope:$scope

        });
  }

  $scope.closeDialog = function() {

      new_dialog.close();

  }

  function init() {
     $scope.callingLineName = "true";
      $scope.lookupSearch = "";
      $scope.loadFlag     =  true;
      declareVariables();
      getCallingPlanInfo();
      getLookUpInfo();
      //phoneNumbers
    }

    init();


 function isAValidPhoneNumber( phoneNumber ){

   console.log("Entered Phone number -> "  + phoneNumber);
   phoneNumber =  ( phoneNumber ) ? phoneNumber.replace(/-/g, "") : phoneNumber ;
   console.log("Processed Phone number -> "  + phoneNumber);
   len =  ( phoneNumber ) ? phoneNumber.length : 0;
   console.log("Length of new Phone number -> "  + len);
   return (len === 10) ;

 }


}

callingLineIDCtrl.$inject = ["$scope", "ngDialog","callingLineConst", "Constants", "callingPlanServices", "cache", "$filter", "volteServices"];
angular.module( window.AppName ).controller("callingLineIDCtrl", callingLineIDCtrl);
