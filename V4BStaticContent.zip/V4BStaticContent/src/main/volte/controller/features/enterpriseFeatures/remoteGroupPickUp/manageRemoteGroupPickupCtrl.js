 //var manageRemoteGroupPickupCtrl = function($scope, $http, ngDialog, $compile, $state, manageRemoteCallPickUpServices,Config,Constants, cache, $rootScope) {
//var manageRemoteGroupPickupCtrl = function($scope, $http, ngDialog, $compile, $state, manageRemoteCallPickUpServices,manageAccountCodeServices, accountCodeServices, $rootScope, cache,Config,Constants) {

var manageRemoteGroupPickupCtrl = function($scope, $http, ngDialog, $compile, $state, manageRemoteCallPickUpServices,Constants, $rootScope, cache,remoteGroupPickupConst) {

    function getScheduleGroups() {
        //$scope.type = "schedule";
        //huntGroupServices.setOption( $scope.type );
        //$scope.vzGridTpl = "partials/features/vz-grid/vz.grid.manage-account-code.html";
        //getData();
    }

    function getData() {

        /*manageAccountCodeServices.getData()
            .success(function (result) {
                $scope.collection = result.data.rows;
                $scope.numberOfCodes = $scope.collection.length;
            })
            .error(function (error) {
                $scope.status = 'Unable to load hunt group data: ' + error.message;
            });
        }
        .success(function (result) {
                $scope.collection = result.data.rows;
                var i = 0;
                angular.forEach($scope.collection, function(value, key) {
                    $scope.collection[i].isChecked = false;
                    i++;
                });
                $scope.numberOfCodes = $scope.collection.length;
                  $scope.algorithm = result;
            })
            .error(function (error) {
                $scope.status = 'Unable to load hunt group data: ' + error.message;
            });
        */

    }

    /*$scope.deleteSchedule = function() {
        var i = 0;
        var temp = [];
        angular.forEach($scope.collection, function(value, key) {
            if($scope.collection[i].isChecked == false) {
                temp.push($scope.collection[i]);
            }
            i++;
        });
        $scope.collection = temp;
        $scope.numberOfCodes = $scope.collection.length;
    }*/

    function declareVariables() {

        //Load Constants
        API = Constants.API.CALL_PICKUP_REMOTE;

        //Define tpl path
        $scope.vzGridTpl = "partials/features/vz-grid/vz.grid.remote-call-pickup.html";

        $scope.modelModified = false;

        $scope.accountName = "";
        $scope.accountDescription = "";

    }

    function getAccountSummary() {

        manageRemoteCallPickUpServices.setOption( API.CALL_PICKUP_SUMMARY );
        manageRemoteCallPickUpServices.getData()
            .success(function (result) {
                $scope.loadFlag     =  false;
                if (result.appHeader.statusCode == "OK") {
                    $scope.collection = result.appResult.serviceRepsonse.callPickUpList;
                    console.log($scope.collection);
                    cache.put("callPickUpList",$scope.collection);
                    //$scope.updateCache();
                    //cache.put("call-pick-up-list",$scope.collection);
                }
             });

    }
    $scope.navigateToManageUsers = function() {
        $state.go('features.enterprise.remote_group_pick_up.create-new-group');
        //cache.put("callPickUpList",$scope.collection);
    }
    // $scope.updateCache=function(){
    //     cache.put("call-pick-up-list",$scope.collection);
    // }
    $scope.remove = function(){
         manageRemoteCallPickUpServices.setOption(API.DELETE_LINES);
       var postData={
           "namesList": []
                     }

       //var deletedItems=
       // deletedItems.codeEntries=[];
        for(var i=0;i<$scope.collection.length;i++)
        {
            if($scope.collection[i].isChecked==true)
            {
               postData.namesList.push($scope.collection[i].name);
               console.log(postData);
                // $scope.collection.splice(i,1);
                //  i--;
            }
        }
        //console.log(deletedItems);
        if(postData.namesList.length>0)
        {
        manageRemoteCallPickUpServices.postData(postData).success(function (result)
        {
             // $scope.showMsg = true;
             // $scope.msgType = "success";
             // $scope.msgTxt = "Deleted Successfully";
            try
            {
                $scope.msgTxt = "Deleted Successfully";
                if(result.appHeader.statusCode == "OK")
              {
                for(var i=0;i<$scope.collection.length;i++)
                    {
                        if($scope.collection[i].isChecked==true)
                        {
                            $scope.collection.splice(i,1);
                             i--;
                        }
                    }
                $scope.msgType = "success";
                $scope.msgTxt = "Deleted Successfully";
                $scope.showMsg = true;
                console.log( $scope.msgTxt);
               }
            }
            catch(err){
                //$scope.msgTxt = "Delete Unscuccesfull";
                console.log(err.message);
            }
        }).error(function (error) {
           console.log("Failure - ", error);
        });
    }
    else{
        $scope.msgType = "error";
                $scope.msgTxt = "Please select a record";
                $scope.showMsg = true;
    }
       // console.log('$scope.collection'+$scope.collection);
    }

    $scope.ngEnableSubmit = function() {

        if( (typeof($scope.accountName) != 'undefined' && $scope.accountName.length>=2 && $scope.accountName.length<12)
                && (typeof($scope.accountDescription) != 'undefined' && $scope.accountDescription.length>1 && $scope.accountDescription.length<250) ) {
            $scope.modelModified = true;
        }

    }

    // $scope.navigateToManageUsers = function() {
    //     $state.go('features.enterprise.manageassigncode');
    // }

    $scope.vzSubmitBtnStatusFn = function( decision ) {
        $rootScope.vzSubmitBtnStatus = !decision;
        return decision;
    }

    $scope.submitCode = function() {
        $scope.createAccountCodeForm.$setPristine();
        var params = [];
        params.push({"code": $scope.accountName, "description": $scope.accountDescription});
        var sendRequestData = { "codeEntries": params };

        manageAccountCodeServices.setOption( API.CREATE_ACCOUNT );
        manageAccountCodeServices.postData( sendRequestData )
            .success(function (result) {
                if(result.appHeader.statusCode == "OK") {
                    $scope.msgType = "success";
                    $scope.msgTxt = "Added Successfully";
                    $scope.showMsg = true;
                }
                console.log("Result - ", result);
                $scope.collection = result.appResult.serviceRepsonse.codeEntries;
             });

    }

    function init() {
        $scope.loadFlag     =  true;
         $scope.manageRemotePageTitle=remoteGroupPickupConst.manageRemotePageTitle;
         $scope.pageDesc=remoteGroupPickupConst.pageDesc;
         $scope.instructions = remoteGroupPickupConst.instructions;
        //Initialize Variables
        $scope.collection = {};
        $scope.numberOfCodes;

        $scope.selectedCodes = {};

        //Load available Hunt Groups
        //getScheduleGroups();

        declareVariables();

        getAccountSummary();
    }

    init();

      /*$scope.createCode = function() {
        var selectedCodes = [],
        selectedCodesJSON = {};

        for (var i = 0; i < $scope.collection.length; i++) {
            if($scope.collection[i].isChecked) {
                selectedCodes.push({"code":$scope.collection[i].codes, "description":$scope.collection[i].codeDescription});
            }
        };

        selectedCodesJSON = {"codeEntries": selectedCodes}

        console.log(selectedCodesJSON);

        manageAccountCodeServices.postAccountCodes(selectedCodesJSON)
            .success(function(result) {

            })
            .error(function(error) {

            });
    }*/

};


manageRemoteGroupPickupCtrl.$inject = ["$scope", "$http", "ngDialog", "$compile", "$state","manageRemoteCallPickUpServices", "Constants", "$rootScope", "cache","remoteGroupPickupConst"];
angular.module( window.AppName ).controller("manageRemoteGroupPickupCtrl", manageRemoteGroupPickupCtrl);

// manageRemoteGroupPickupCtrl.$inject = ["$scope", "$http", "ngDialog", "$compile", "$state", "manageAccountCodeServices", "accountCodeServices", "Constants", "$rootScope", "cache","Config"];
// angular.module( window.AppName ).controller("manageRemoteGroupPickupCtrl", manageRemoteGroupPickupCtrl);

//  manageRemoteGroupPickupCtrl.$inject = ["$scope", "$http", "ngDialog", "$compile", "$state", "manageRemoteCallPickUpServices", "Config","Constants", "cache", "$rootScope"];
//  angular.module( window.AppName ).controller("manageRemoteGroupPickupCtrl", manageRemoteGroupPickupCtrl);
// // manageRemoteGroupPickupCtrl.$inject = ["$scope", "$http", "ngDialog", "$compile", "$state", "manageRemoteCallPickUpServices", "accountCodeServices", "$rootScope", "cache","Config", "Constants"];
// angular.module( window.AppName ).controller("manageRemoteGroupPickupCtrl", manageRemoteGroupPickupCtrl);
