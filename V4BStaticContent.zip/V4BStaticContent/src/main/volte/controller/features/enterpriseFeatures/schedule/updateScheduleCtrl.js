(function() {
    var Controller = function($scope, $state, $stateParams, scheduleConst) {
        function init () {
            var scheduleType = $stateParams.scheduleType.toLowerCase();

            $scope.operation = 'update';

            $scope.scheduleName = $stateParams.scheduleName;
            $scope.scheduleType = 'Business';
            $scope.navigate('default');

            switch (scheduleType) {
                case 'business':
                    $scope.scheduleType = 'Business';
                    break;
                case 'holiday':
                    $scope.scheduleType = 'Holiday';
                    break;
                default:
                    $state.go('features.enterprise.manageSchedule');
                    throw new Error("Unknown schedule type");
            }
        }

        $scope.navigate = function (destination) {
            switch (destination) {
                case 'updateholiday':
                    $scope.tplUrl = 'partials/features/enterpriseFeatures/schedule/holiday.html';
                    break;
                case 'updatebusiness':
                    $scope.tplUrl = 'partials/features/enterpriseFeatures/schedule/business.html';
                    break;
                case 'success':
                    $scope.tplUrl = 'partials/features/enterpriseFeatures/schedule/success.html';
                    $scope.pageDesc = scheduleConst.pageDesc;

                    if ($scope.scheduleType === 'Business') {
                        $scope.pageTitle = "Success";
                        $scope.msgType = 'success';
                        $scope.showMsg = true;
                        $scope.msgTxt = "Update Business Schedule Successful";
                    } else {
                        $scope.pageTitle = "Success";
                        $scope.msgType = 'success';
                        $scope.showMsg = true;
                        $scope.msgTxt = "Update Holiday Schedule Successful";
                    }

                    $scope.onBack = function () {
                        window.history.back();
                    };

                    break;
                default:
                    $scope.tplUrl = 'partials/features/enterpriseFeatures/schedule/schedule-name.html';
                    break;
            }
        };

        $scope.setName = function (name) {
            $scope.scheduleName = name;
        };
        $scope.setType = function (type) {
            $scope.scheduleType = type;
        };

        init();
    };

    Controller.$inject = ['$scope', '$state', '$stateParams', 'scheduleConst'];

    angular.module(window.AppName).controller('updateScheduleCtrl', Controller);
})();