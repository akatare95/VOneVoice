var createGroupPickupCtrl = function($scope, $http, ngDialog, $compile, $state, manageRemoteCallPickUpServices, remoteCallPickUpServices, Constants,remoteGroupPickupConst,cache,$filter) {

    var availableLinesChosen = [];
    var selectedLinesChosen = [];
    var optionalLinesChosen = [];

    function declareVariables() {

        API = Constants.API.CALL_PICKUP_REMOTE;
        $scope.option = API.CALL_PICKUP_SUMMARY;
   }
    function getStateParams(){
        searchName = $state.params.name;
        var params;
        $scope.availableLinesTemplate = "partials/features/vz-grid/vz.grid.create-group-pickup.html";
        //console.log($state.params.name.length);
       if($state.params.name)
        {


            $scope.callPickUpGroupName = searchName;
            remoteCallPickUpServices.setOption(API.GETINFO);
            remoteCallPickUpServices.getData( {name: $state.params.name} ).success(function (result) {

                if (result.appHeader.statusCode == "OK") {
                    console.log(result);
                    $scope.selectedLines =  result.appResult.serviceRepsonse.selectedLines || [];
                    $scope.availableLines =  result.appResult.serviceRepsonse.availableLines || [];

                    $scope.models = {
                        selected: null,
                        lists: {
                            "availableLine": $scope.availableLines ,
                            "selectedLines": $scope.selectedLines
                        }
                    };

                } else {

                    error(result.appHeader.statusMessage);
                    $scope.model=false;
                    $scope.hideContent=true;

                }

            })
            .error(function () {
                error(result.appHeader.statusMessage);
                $scope.model=false;
                $scope.hideContent=true;
                // $scope.status = 'Unable to load data: ' + error.message;
            });
        }
        else
        {
             //if($state.params.name.length<=0) {
             console.log("inside non search name");
          //$scope.callPickUpGroupName = "";
          getLookUpData();
        //}
        }
    }
    function getLookUpData()
    {
       // $scope.availableLinesTemplate = "partials/features/vz-grid/vz.grid.create-group-pickup.html";
          manageRemoteCallPickUpServices.setOption(API.AVAILABLE_LINES);
          manageRemoteCallPickUpServices.getData({}) .success(function (result)
          {
            console.log(result);
            if (result.appHeader.statusCode == "OK") {
            $scope.availableLines=result.appResult.serviceRepsonse.lineInfoList||[];
            $scope.selectedLines=[];
            console.log($scope.availableLines);
            $scope.models = {
                    selected: null,
                    lists: {
                        "availableLine": $scope.availableLines ,
                        "selectedLines": $scope.selectedLines
                    }
                };
                console.log($scope.models);
            }
            else
            {
               error(result.appHeader.statusMessage);
                $scope.model=false;
                $scope.hideContent=true;
            }
            })
          .error(function (error) {
                error(result.appHeader.statusMessage);
                $scope.model=false;
                $scope.hideContent=true;
                $scope.status = 'Unable to load data: ' + error.message;
            });
    }

    function getData(name) {
         $scope.availableLinesTemplate = "partials/features/vz-grid/vz.grid.create-group-pickup.html";
            remoteCallPickUpServices.setOption(API.GETINFO);
            remoteCallPickUpServices.getData(name)
            .success(function (result) {
                console.log(result);
                console.log($scope.availableLines);
                //$scope.availableLinesCount = $scope.availableLines.length;

                $scope.selectedLines =  result.appResult.serviceRepsonse.selectedLines || [];
                $scope.availableLines =  result.appResult.serviceRepsonse.availableLines || [];

                //$scope.optionalLines = result.appResult.serviceRepsonse.optionalUsagePhoneNumberList || {};

                $scope.models = {
                    selected: null,
                    lists: {
                        "availableLine": $scope.availableLines ,
                        "selectedLines": $scope.selectedLines
                    }
                };

            })
            .error(function (error) {
                // $scope.status = 'Unable to load data: ' + error.message;
                error(result.appHeader.statusMessage);
                $scope.model=false;
                $scope.hideContent=true;
            });
    }

    $scope.onAvailableLinesClick = function(event, index,item) {
        var ele = event.currentTarget;
        //check whether an already chosen line is selected again
        //if so, clear the selection
        //else set selection
        console.log(item);
        if(angular.element(ele).hasClass('selected-line')) {
            angular.element(ele).removeClass('selected-line');
            availableLinesChosen.splice(availableLinesChosen.indexOf($scope.availableLines[index]), 1);
            console.log(availableLinesChosen);
             // $scope.allset=false;
            // $scope.availableAll=false;
        } else {
            // angular.element(ele).addClass('selected-line');
            console.log('test'+index)
            //$scope.availableLines[index].lineNumber = $scope.availableLines[index].lineNumber;
            // $filter('filter')($scope.collection, {code: searchName})[0];
            availableLinesChosen.push(item);
            console.log(availableLinesChosen);
            // if(availableLinesChosen.length==$scope.availableLines.length)
            // {
            //     $scope.availableAll=true;
            // }
            // $scope.allclear=false;
        }
    }
    $scope.changeBgColor=function(item)
    {
        if(availableLinesChosen.indexOf(item)!==-1)
        {
            console.log('change bg color');
            return true;
        }
        else
        {
            return false;
        }
    }
    $scope.onSelectedLinesClick = function(event, index) {
        var ele = event.currentTarget;
        //check whether an already chosen line is selected again
        //if so, clear the selection
        //else set selection
        if(angular.element(ele).hasClass('selected-line')) {
            angular.element(ele).removeClass('selected-line');
            selectedLinesChosen.splice(selectedLinesChosen.indexOf($scope.selectedLines[index]), 1);
            $scope.selectAll=false;
        } else {
            angular.element(ele).addClass('selected-line');
           // $scope.selectedLines[index].lineNumber = $scope.selectedLines[index].lineNumber;
            selectedLinesChosen.push($scope.selectedLines[index]);
             if(selectedLinesChosen.length==$scope.selectedLines.length)
            {
                $scope.selectAll=true;
            }
        }
    }

    $scope.fromAvailableLinesToSelectedLines = function(event) {
        //push chosen lines
        for (var i = 0; i < availableLinesChosen.length; i++) {
            console.log($scope.selectedLines);
            $scope.selectedLines.push(availableLinesChosen[i]);

        };
        //after pushing the chosen lines
        //update Available Lines by deleting chosen lines
        for (var i = 0; i < availableLinesChosen.length; i++) {
            $scope.availableLines.splice($scope.availableLines.indexOf(availableLinesChosen[i]), 1);
        };

        availableLinesChosen = [];
        updateLinesCount();
    }

    $scope.fromSelectedLinesToAvailableLines = function(event) {
        //push chosen lines
        for (var i = 0; i < selectedLinesChosen.length; i++) {
            $scope.availableLines.push(selectedLinesChosen[i]);
        };
        //after pushing the chosen lines
        //update Selected Lines by deleting chosen lines
        for (var i = 0; i < selectedLinesChosen.length; i++) {
            $scope.selectedLines.splice($scope.selectedLines.indexOf(selectedLinesChosen[i]), 1);
        };

        selectedLinesChosen = [];
        updateLinesCount();
    }

     function success() {
            $scope.msgType = "success";
            $scope.msgTxt = "Updated Successfully";
            $scope.showMsg = true;
        }

    function error( msg ) {

        msg = msg || "Updation Failed!";

        $scope.msgType = "error";
        $scope.msgTxt = msg;
        $scope.showMsg = true;

    }

    $scope.test = function() {

        var params = {
           "codeType": "Account Code",
           "mandatoryUsagePhoneNumberList": $scope.selectedLines,
           "optionalUsagePhoneNumberList": $scope.optionalLines,
        };

        console.log("API - " +  API.MODIFY_ACCOUNT_CODE );

        accountCodeServices.setOption( API.MODIFY_ACCOUNT_CODE );
        accountCodeServices.postData( params )
            .success(function (result) {
                if(result.appHeader.statusCode == "OK") {
                    $scope.msgType = "success";
                    $scope.msgTxt = "Added Successfully";
                    $scope.showMsg = true;
                }
                $scope.collection = result.appResult.serviceRepsonse.codeEntries;
             });

    }

    $scope.submitCode = function() {
        console.log($scope.updateStatus());
        $scope.resultSts=$scope.updateStatus();
        if( $scope.resultSts == false ) {

            var params = {

                //"name": $scope.groupName,
                // "newName": "Test CallPickUp2",
                "selectedLines":$scope.selectedLines
            }

            if( searchName ) {

                params.newName=$scope.callPickUpGroupName;
                params.name=searchName;
                console.log(params);
                remoteCallPickUpServices.setOption(API. MODIFY_GROUP);
                remoteCallPickUpServices.getData(params)
                    .success(function (result) {

                       if( result.appHeader.statusCode == "OK" ) {

                            $scope.msgType = "success";
                            $scope.msgTxt = "Updated Successfully";
                            $scope.showMsg = true;

                        } else {
                            if(result.appHeader.statusCode == "4408")
                            {
                                $scope.msgType = "error";
                                $scope.msgTxt = " Group Name "+ $scope.callPickUpGroupName +" already exists";
                                $scope.showMsg = true;

                            }
                            else
                            {
                                $scope.msgType = "error";
                                $scope.msgTxt = result.appHeader.statusMessage;
                                $scope.showMsg = true;
                            }

                        }

                })
                .error(function (error) {
                    $scope.status = 'Unable to load data: ' + error.message;
                });
                resetData();
            }
            else{
             params.name=$scope.callPickUpGroupName;
             remoteCallPickUpServices.setOption(API.ADD_GROUP);
             remoteCallPickUpServices.getData(params)
                .success(function (result) {
                   console.log(result);
                   console.log('add');
                   if(result.appHeader.statusCode == "OK") {
                        console.log(result);
                        $scope.msgType = "success";
                        $scope.msgTxt = "Added Successfully";
                        $scope.showMsg = true;
                    }
                    else {
                            if(result.appHeader.statusCode == "4408")
                            {
                                $scope.msgType = "error";
                                $scope.msgTxt = " Group Name "+ $scope.callPickUpGroupName +" already exists";
                                $scope.showMsg = true;

                            }
                            else
                            {
                                $scope.msgType = "error";
                                $scope.msgTxt = result.appHeader.statusMessage;
                                $scope.showMsg = true;
                            }

                        }
                    console.log("Result - ", result);
                })
                .error(function (error) {
                    $scope.status = 'Unable to load data: ' + error.message;
                });
                resetData();
            }
        }
        function resetData()
        {
           $scope.createAccountCodeForm.callPickUpGroupName.$setPristine();
            $scope.model=false;
            // $scope.resultSts=true;
        }
    }
    updateLinesCount = function() {
        $scope.availableLinesCount = $scope.availableLines.length;
        $scope.selectedLinesCount = $scope.selectedLines.length;
        $scope.optionalLinesCount = $scope.optionalLines.length;
    }
    $scope.updateStatus=function()
    {
        // console.log($scope.callPickUpGroupName);
        // if ($scope.callPickUpGroupName!=undefined){
        //     if($scope.callPickUpGroupName.length>=2){
        //        if($scope.createAccountCodeForm.callPickUpGroupName.$pristine && $scope.model==false){
        //          return true;
        //        }
        //        else{
        //         return false;
        //        }
        //     }
        //     else {
        //         return true;
        //       }
        //     }
        //     else {
        //       return true;
        //     }
        console.log($scope.callPickUpGroupName);
        if ($scope.callPickUpGroupName!=undefined){
            if($scope.callPickUpGroupName.length>=2){
               if($scope.createAccountCodeForm.callPickUpGroupName.$pristine && $scope.model==false){
                 return true;
               }
               else{
                return false;
               }
            }
            else {
                return true;
              }
            }
            else {
              return true;
            }
    }
    function init() {
        var selectedName=cache.get("call-pick-up-list");


        //Initialize Variables
        var searchName;
        $scope.availableLines = [];
        $scope.availableLinesCount = 0;

        $scope.selectedLines = [];
        $scope.selectedLinesCount = 0;

        $scope.optionalLines = [];
        $scope.optionalLinesCount = 0;
        $scope.createNewGroupPageTitle=remoteGroupPickupConst.createNewGroupPageTitle;
        if($state.params.name)
        	$scope.createNewGroupPageTitle = "Modify Group";
        $scope.pageDesc=remoteGroupPickupConst.pageDesc;
        $scope.instructions = remoteGroupPickupConst.instructions;
        // $scope.CREATE_NEW_GROUP_TITLE=Config.CREATE_NEW_GROUP_TITLE;
        // $scope.REMOTE_GROUP_PICK_UP_DESC=Config.REMOTE_GROUP_PICK_UP_DESC;
        //Load Available Lines
        declareVariables();
        getStateParams();
        $scope.model=false;
        $scope.$watch('models',function(newVal,oldVal) {
            if(oldVal!==undefined)
            {
               console.log("model changed");
                $scope.model=true;
            }
        },true);
        // $scope.$watch('availableLines',function(newVal,oldVal) {
        //  if($scope.availableLines.length==0)
        //  {
        //     $scope.availableAll=false;
        //  }
        // },true);
        // $scope.$watch('selectedLines',function(newVal,oldVal) {
        //  if($scope.selectedLines.length==0)
        //  {
        //     $scope.selectAll=false;
        //  }
        // },true);

    }

    init();

};

createGroupPickupCtrl.$inject = ["$scope", "$http", "ngDialog", "$compile", "$state","manageRemoteCallPickUpServices", "remoteCallPickUpServices", "Constants","remoteGroupPickupConst","cache","$filter"];
angular.module( window.AppName ).controller("createGroupPickupCtrl", createGroupPickupCtrl);
