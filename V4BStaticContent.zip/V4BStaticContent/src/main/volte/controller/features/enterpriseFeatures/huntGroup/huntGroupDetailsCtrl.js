var huntGroupDetailsCtrl = function($scope, $http, ngDialog, $compile, $state,HuntGroupConst,huntGroupServices,huntGroupConst, cache, $rootScope, $window, volteServices, Constants) {

	//  pageTitle: "Hunt Group",
	// pageDesc:"Incoming calls to a company hunt group line  will ring  to a  group of users  as defined by the administrator. There are three ring sequences for the company to use.",
	// algorithmpageTitle:"Select Hunt Group Type (Algorithm)",
	// reviewpageTitle:"Review Hunt Group and Submit",
	// managepageTitle:"Manage Hunt Group"
	$scope.pageTitle = huntGroupConst.detailsPageTitle;
	$scope.pageDesc = huntGroupConst.pageDesc;
    $scope.instructions = huntGroupConst.instructions;
    $scope.instructionsDetails = huntGroupConst.instructionsDetails;
    $scope.gotoEpam = function(reasonTxt) {
    	var lineNumber = $scope.huntGroupNumber;
    	lineNumber = lineNumber.substr(0, 3) + "-" + lineNumber.substr(3, 3) + "-" + lineNumber.substr(6);
    	var params = {
			actionSelected: reasonTxt,
			line: lineNumber
		};

    	$http({
            url: Constants.API.LINES_PAGE.EPAM_PROCESS_ACTIONS,
            method: "POST",
            data: params,
            crossDomain: true,
            withCredentials: true,
            headers: {
                'Content-type': 'application/json'
            }
        }).success(function(response, status, headers, config) {
        	if (!response.errorStatus) {
        		$http({
                    url: Constants.API.LINES_PAGE.SELECT_STRING,
                    method: "POST",
                    data: params,
                    crossDomain: true,
                    withCredentials: true,
                    headers: {
                        'Content-type': 'application/json'
                    }
                }).success(function(response, status, headers, config) {
                	if (!response.errorStatus) {
						//$window.location.href = response.redirectUrl;

                        // Redirect with back URL
                        var currentUrlPath = window.location.href;
                        var redirectUrlPath = response.redirectUrl;
                        $window.location.href = redirectUrlWithReturnURL(redirectUrlPath, currentUrlPath, Constants.API.REDIRECT_URL_PATHS.split_At);

					} else {
						errorHandler(response.errorMessage);
					}
                }).error(function(response, status, headers, config) {
                    errorHandler();
                });
			} else {
				errorHandler(response.errorMessage);
			}
        }).error(function(response, status, headers, config) {
            errorHandler();
        });

		function errorHandler(errorMessage) {
			if (typeof errorMessage !== 'string') {
				errorMessage = undefined;
			}
			$scope.msgTxt = errorMessage || 'Unable to perform the transaction';
			$scope.msgType = 'error';
			$scope.showStatusMsg = true;
		}
    };
	function getEPAMLinkForDetails() {

        //var TokenGoBackURL   =   encodeURIComponent( window.location.href );
        var HREFArr          = window.location.href.split("#");
        var TokenGoBackURL   = HREFArr[0] + "#/features/enterprise/hunt-group-details/" + $state.params.lineNumber + "/";
            TokenGoBackURL   = encodeURIComponent( TokenGoBackURL );
        var TokenLineNumber  = $state.params.lineNumber;

        $scope.EPAMLink      = $rootScope.EPAMLink.replace("TokenGoBackURL",  TokenGoBackURL);
        $scope.EPAMLink      = $scope.EPAMLink.replace("TokenLineNumber", TokenLineNumber);

        // Redirect with back URL
        var currentUrlPath = window.location.href;
        var redirectUrlPath = $scope.EPAMLink;
        $scope.EPAMLink = redirectUrlWithReturnURL(redirectUrlPath, currentUrlPath, Constants.API.REDIRECT_URL_PATHS.split_At);

    }

	function init() {

		/*$scope.isActive = false;*/
		$scope.time_zone = HuntGroupConst.TIME_ZONE;
	    $scope.time_zone_selected= "";
		$scope.huntGroupNumber = $state.params.lineNumber;
		$scope.huntGroupStatus = $state.params.status;
		//console.log($state.params.status);
		$scope.huntGroupInfo = {};

		var lineNum = $state.params.lineNumber;

		//Nullify the cache
		cache.put("huntgroup-lineid", null);

		getEPAMLinkForDetails();

		//getting Hunt group info from backend API
		getHuntGroupInfo(lineNum);
	}

	var getHuntGroupInfo = function(lineNum) {

		var param = {'phoneNumber': lineNum};
		huntGroupServices.getHuntGroupInfo(param)
            .success(function (result) {
                try{
                	$scope.huntGroupInfo = result.appResult.serviceRepsonse;
                	console.log($scope.huntGroupInfo.forwardToPhoneNumber);
                } catch(err) {
                    console.log("Failure - "+err.message);
                }
            }).error(function (error) {
                console.log("Failure - ", error);
            });

	}

	$scope.postHuntGroupDetails = function() {

		var huntGroupName = document.getElementById('huntGroupName').value,
		callingIdName = document.getElementById('callingId').value,
		timeZone = $scope.time_zone_selected;

		huntGroupServices.setHuntGroupInfo($scope.huntGroupInfo);
		// if($scope.huntGroupInfo.forwardToPhoneNumber!=undefined)
		// {
  //           $scope.huntGroupInfo.forwardToPhoneNumber=$scope.huntGroupInfo.forwardToPhoneNumber.chartAt(0)=='+' && $scope.huntGroupInfo.forwardToPhoneNumber.chartAt(1)==1?$scope.huntGroupInfo.forwardToPhoneNumber.slice(2):$scope.huntGroupInfo.forwardToPhoneNumber;
		// }
		if($scope.huntGroupInfo.forwardToPhoneNumber!=undefined)
		{
          $scope.huntGroupInfo.forwardToPhoneNumber=$scope.huntGroupInfo.forwardToPhoneNumber.charAt(0)=='+' && $scope.huntGroupInfo.forwardToPhoneNumber.charAt(1)==1?$scope.huntGroupInfo.forwardToPhoneNumber.slice(2):$scope.huntGroupInfo.forwardToPhoneNumber;
		}
		console.log($scope.huntGroupInfo.forwardToPhoneNumber);
		var huntGroupLineDetail = {};

		huntGroupLineDetail.huntGroupName = $scope.huntGroupInfo.huntGroupName;
        huntGroupLineDetail.callingId = $scope.huntGroupInfo.callingLineIdName;
        huntGroupLineDetail.timeZone = $scope.huntGroupInfo.timeZone;
        huntGroupLineDetail.geoTimeZone = $scope.huntGroupInfo.geoTimeZone;
        huntGroupLineDetail.selectedLines = $scope.huntGroupInfo.huntGroupMdninfoList;
        huntGroupLineDetail.availableLines = $scope.huntGroupInfo.availableLines;
        huntGroupLineDetail.noAnswerNumberOfRings = $scope.huntGroupInfo.noAnswerNumberOfRings;
        huntGroupLineDetail.isHuntAfterNoAnswer = $scope.huntGroupInfo.huntAfterNoAnswer;
        huntGroupLineDetail.policy = $scope.huntGroupInfo.policy;
        huntGroupLineDetail.forwardAfterTimeout=$scope.huntGroupInfo.forwardAfterTimeout;
        huntGroupLineDetail.forwardTimeoutSeconds=$scope.huntGroupInfo.forwardTimeoutSeconds;
        huntGroupLineDetail.forwardToPhoneNumber=$scope.huntGroupInfo.forwardToPhoneNumber;
        huntGroupLineDetail.active=$scope.huntGroupStatus;
        huntGroupLineDetail.phoneNumber=$state.params.lineNumber;
        console.log(huntGroupLineDetail);
        //alert(JSON.stringify(huntGroupLineDetail));
        cache.put("huntgroup-lineid", huntGroupLineDetail);
        // $state.go( 'features.enterprise.hunt_group_algorithm' );

	}

	init();
};

huntGroupDetailsCtrl.$inject = ["$scope", "$http", "ngDialog", "$compile", "$state","HuntGroupConst","huntGroupServices","huntGroupConst", "cache", "$rootScope", "$window", "volteServices", "Constants"];
angular.module( window.AppName ).controller("huntGroupDetailsCtrl", huntGroupDetailsCtrl);