(function () {
    var Controller = function ($scope, $stateParams, holidayScheduleService) {
        function init () {
            // Global Flags
            $scope.recurring = false;
            $scope.allDay = true;
            var events = $scope.events = [];
            var recurIndex;

            // Parent controller (holidayCtrl) will broadcast these events
            $scope.$on('selected', function (e, day) {
                var event = _.pick(day, 'year', 'month', 'date');

                event.allDay = true; // By default
                events.push(event);

                updateEvent(event);
                //sortEvents();
                updateGlobals();
                $scope.$parent.events = events; // Make sure the parent has the same instance
            });

            $scope.$on('unselected', function (e, day) {
                var recurringMatcher = { recurring: true, month: day.month, date: day.date },
                    recurringMatcherFn = _.matcher(recurringMatcher),
                    recurringEvents = _.filter(events, recurringMatcherFn),
                    recurranceExists = !!recurringEvents.length,
                    index;

                if (recurranceExists) {
                    removeAllOccurrances(day);
                } else {
                    index = _.indexOf(events, _.find(events, _.matcher({
                        year: day.year,
                        month: day.month,
                        date: day.date
                    })));

                    if (index !== -1) {
                        events.splice(index, 1);
                    }
                }

                updateGlobals();
            });

            // Prepopulate if it's an update operation
            if ($scope.operation === 'update') {
                $scope.$emit('load', true);

                holidayScheduleService.loadHoliday($stateParams.scheduleName)
                    .then(function (response) {
                        $scope.$emit('load', false);
                        _.each(response, function (event) {
                            event.times = buildTimeSelector(event);

                            if (event.allDay) {
                                event.startTimePlaceholder = 'N/A';
                                event.endTimePlaceholder = 'N/A';
                            }

                            $scope.events.push(event);
                            $scope.$emit('eventrender', event, $scope.events);
                        });

                        //sortEvents();
                        updateGlobals();
                        $scope.$emit('refresh');
                    })
                    .catch(function (err) {
                        $scope.$emit('error', err);
                    });
            } else {
                //sortEvents();
                updateGlobals();
            }
        }

        /**
         * Updates the value of the follwing passively:
         *
         * - $scope.recurring
         * - $scope.allDay
         *
         * Requires that all the values of events[] pass the predicate test
         * in order for the global value to be true
         */
        function updateGlobals() {
            var events = $scope.events;

            $scope.allDay = events.length ? _.every(events, function (event) { return event.allDay; }) : false;
            $scope.recurring = events.length ? _.every(events, function (event) { return event.recurring; }) : false;
        }

        /**
         * Removes all occurrances of the specified date (both recurring and not)
         * from the events[] array
         *
         * @method     removeAllOccurrances
         * @param      {Object}  day     Example: { month: 0, date: 1 } == Jan, 1
         */
        function removeAllOccurrances(day) {
            var events = $scope.events,
                event, index;

            for (var i = 0, ln = events.length; i < ln; i++) {
                // Finds first occurrance
                event = _.find(events, _.matcher({ month: day.month, date: day.date }));

                // Get index of event
                index = _.indexOf(events, event);

                if (index !== -1) {
                    // Remove instance
                    recurIndex = index;
                    console.log(recurIndex);
                    events.splice(index, 1);

                    // Reset loop meta data
                    i--;
                    ln = events.length;
                }
            }
        }

        /**
         * Sorts selected events based on the order:
         * - recurring vs. specified
         * - year
         * - month
         * - day
         *
         * @method     sortEvents
         */
        function sortEvents() {
            var events = $scope.events,
                group = _.partition(events, _.matcher({ recurring: true })),
                recurring = sortByDateIgnoreYear(group[0]),
                exact = sortByDate(group[1]),
                sorted, event;

            sorted = _.union(recurring, exact);

            // Empty the array
            event = events.pop();
            while (event) {
                event = events.pop();
            }

            // Repopulate the array
            _.each(sorted, function (event) {
                events.push(event);
            });
        }

        /**
         * Updates the events with the relevant data
         *
         * @method     updateEvent
         * @param      {Object}  event
         */
        function updateEvent (event) {
            event.times = buildTimeSelector(event);
            event.startTimePlaceholder = (event.allDay ? 'N/A' : 'Select Start Time');
            event.endTimePlaceholder = (event.allDay ? 'N/A' : 'Select End Time');
            event.startTime = event.allDay ? event.startTime : null;
            event.endTime = event.allDay ? event.endTime : null;
            event.errorMessage = '';
        }

        /**
         * Validates start and end times
         */
        $scope.validateTime = function (event) {
            var errorMessage = '';

            if (event.startTime && event.endTime) {
                if (event.startTime >= event.endTime) {
                    errorMessage = 'The start time must be before the end time.';
                }
            }

            event.errorMessage = errorMessage;
        };

        /**
         * "All Day" checkbox handler
         *
         * @param {Object|undefined} - Assumes global change if no day is passed
         */
        $scope.onAllDayChange = function (event) {
            // Update single instance
            if (event) {
                updateGlobals();
                updateEvent(event);
            }

            // Update globally
            else {
                _.each($scope.events, function (event) {
                    event.allDay = $scope.allDay;
                    updateEvent(event);
                });
            }
        };

        /**
         * "Repeat Every Year" checkbox handler
         *
         * @param {Object|undefined} - Assumes global change if no day is passed
         */
        $scope.onRecurranceChange = function (day) {
            var events = $scope.events,
                event, repeats;

            // Skips over the first instance, but removes the rest
            function removeRepeats(event, index) {
                if (index > 0) {
                    events.splice(_.indexOf(events, event), 1);
                }
            }
           // debugger;
            // Update single instance
            if (day) {
                if (day.recurring) {
                    removeAllOccurrances(day); // Remove everything
                    event = _.pick(day, 'year', 'month', 'date', 'allDay', 'startTime', 'endTime');
                    event.recurring = true;

                    if (event.allDay) {
                        $scope.onAllDayChange(event);
                    } else {
                        event.times = buildTimeSelector(event);
                        event.startTimePlaceholder = 'Select Start Time';
                        event.endTimePlaceholder = 'Select End Time';
                    }
                    //events.push(event);
                    typeof(recurIndex) !== "undefined" ? events.splice(recurIndex, 0,event) : events.push(event) ;
                }
            }

            // Update globally
            else {
                // Remove repeated dates if recurring
                if ($scope.recurring) {
                    for (var i = 0, ln = events.length; i < ln; i++) {
                        event = events[i];
                        repeats = _.filter(events, _.matcher({ month: event.month, date: event.date }));
                        if (repeats.length > 1) {
                            _.each(repeats, removeRepeats);
                            ln = events.length;
                            i -= Math.max(0, repeats.length - 1);
                        }
                    }
                }

                // Update each event based on $scope.recurring value
                _.each(events, function (event) {
                    event.recurring = $scope.recurring;
                });
            }

            //sortEvents();
            updateGlobals();
            console.log($scope.events)
            $scope.$emit('recurrancechange', events);
        };

        init();
    }; // End Controller

    /**
     * Returns an array of objects used for the startTime and endTime
     * options representing each hour of the day
     *
     * @method     buildTimeSelector
     * @param      {Object}  date   Example: { year: 2016, month: 0, date: 1 }
     * @return     {Objects[]}   Example: [{ ... }, { name: '12:00 p.m.', value: new Date() }, { ... }]
     */
    var buildTimeSelector = function (day) {
        var times = [];

        if (day.allDay) {
            return times;
        }

        times.push({
            name: '12:00 a.m.',
            value: new Date(day.year, day.month, day.date).getTime()
        });

        _.each(_.range(1, 24), function (hour) {
            var meridian = hour >= 12 ? 'p.m.' : 'a.m.',
                offset = hour > 12 ? -12 : 0;

            times.push({
                name: (hour + offset) + ':00 ' + meridian,
                value: new Date(day.year, day.month, day.date, hour).getTime()
            });
        });

        return times;
    };

    /**
     * Returns an array sorted by date given an array of objects
     * with year, month and day keys
     *
     * @param      {Object[]}  dates   Example: [{ year: 2016, month: 0, date: 1 }]
     * @return     {Object[]} sorted
     */
    var sortByDate = function (dates) {
        var sorted = [];

        groupByYear(dates, function (dates) {
            groupByMonth(dates, function (dates) {
                _.each(_.sortBy(dates, 'date'), function (day) {
                    sorted.push(day);
                });
            });
        });

        return sorted;
    };

    /**
     * Returns an array sorted by date ignoring the year (Useful for recurring dates)
     *
     * @param      {Object[]}  dates   Example: [{ year: 2016, month: 0, date: 1 }]
     * @return     {Object[]} sorted
     */
    var sortByDateIgnoreYear = function (dates) {
        var sorted = [];

        groupByMonth(dates, function (dates) {
            _.each(_.sortBy(dates, 'date'), function (day) {
                sorted.push(day);
            });
        });

        return sorted;
    };

    /**
     * Iterates through the given dates sorted by year
     *
     * @param      {Object[]}  dates - Example: [{ year: 2016, month: 0, date: 1 }]
     * @param      {Function}  iteratee - First argument will be the date instance
     */
    var groupByYear = function (dates, iteratee) {
        var groupedByYear = _.groupBy(dates, 'year'),
            years = _.keys(groupedByYear).sort();

        _.each(years, function (year) {
            iteratee(groupedByYear[year]);
        });
    };

    /**
     * Iterates through the given dates sorted by month
     *
     * @param      {Object[]}  dates - Example: [{ year: 2016, month: 0, date: 1 }]
     * @param      {Function}  iteratee - First argument will be the date instance
     */
    var groupByMonth = function (dates, iteratee) {
        var groupedByMonth = _.groupBy(dates, 'month'),
            months = _.keys(groupedByMonth).sort();

        _.each(months, function (month) {
            iteratee(groupedByMonth[month]);
        });
    };

    Controller.$inject = ['$scope', '$stateParams', 'holidayScheduleService', 'scheduleConst'];

    angular.module(window.AppName).controller('scheduleEventsCtrl', Controller);
})();