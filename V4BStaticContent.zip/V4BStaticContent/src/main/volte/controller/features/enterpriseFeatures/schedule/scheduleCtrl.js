(function () {

var Controller = function ($scope) {
};

Controller.$inject = ['$scope'];

angular.module(window.AppName).controller('scheduleCtrl', Controller);

})();