
var huntCallingAlgorithmCtrl = function($scope, $http, ngDialog, $compile, $state,HuntGroupConst, huntGroupServices, huntGroupConst, vzCache, $rootScope, cache,volteServices,Constants,$document,$window) {

    var availableLinesChosen = [];
    var selectedLinesChosen = [];
     $scope.gotoEpam = function(reasonTxt) {
        var lineNumber = $scope.huntGroupAlgoDetails.phoneNumber;
        lineNumber = lineNumber.substr(0, 3) + "-" + lineNumber.substr(3, 3) + "-" + lineNumber.substr(6);
        var params = {
            actionSelected: reasonTxt,
            line: lineNumber
        };
        console.log(params);
        $http({
            url: Constants.API.LINES_PAGE.EPAM_PROCESS_ACTIONS,
            method: "POST",
            data: params,
            crossDomain: true,
            withCredentials: true,
            headers: {
                'Content-type': 'application/json'
            }
        }).success(function(response, status, headers, config) {
            if (!response.errorStatus) {
                $http({
                    url: Constants.API.LINES_PAGE.SELECT_STRING,
                    method: "POST",
                    data: params,
                    crossDomain: true,
                    withCredentials: true,
                    headers: {
                        'Content-type': 'application/json'
                    }
                }).success(function(response, status, headers, config) {
                    if (!response.errorStatus) {
                        //$window.location.href = response.redirectUrl;

                        // Redirect with back URL
                        var currentUrlPath = window.location.href;
                        var redirectUrlPath = response.redirectUrl;
                        $window.location.href = redirectUrlWithReturnURL(redirectUrlPath, currentUrlPath, Constants.API.REDIRECT_URL_PATHS.split_At);

                    } else {
                        errorHandler(response.errorMessage);
                    }
                }).error(function(response, status, headers, config) {
                    errorHandler();
                });
            } else {
                errorHandler(response.errorMessage);
            }
        }).error(function(response, status, headers, config) {
            errorHandler();
        });

        function errorHandler(errorMessage) {
            if (typeof errorMessage !== 'string') {
                errorMessage = undefined;
            }
            $scope.msgTxt = errorMessage || 'Unable to perform the transaction';
            $scope.msgType = 'error';
            $scope.showStatusMsg = true;
        }
    };
    function getEPAMLink() {

        var TokenGoBackURL   =   encodeURIComponent( window.location.href );
        var TokenLineNumber  =   $state.params.lineNumber;

        $scope.EPAMLink     = $scope.EPAMLink.replace("TokenGoBackURL",  TokenGoBackURL);
        $scope.EPAMLink     = $scope.EPAMLink.replace("TokenLineNumber", TokenLineNumber);

        // Redirect with back URL
        var currentUrlPath = window.location.href;
        var redirectUrlPath = $scope.EPAMLink;
        $scope.EPAMLink = redirectUrlWithReturnURL(redirectUrlPath, currentUrlPath, Constants.API.REDIRECT_URL_PATHS.split_At);

    }

    $scope.imgIcons = {'SIMULTANEOUS':'','CIRCULAR':'', 'REGULAR':'', 'UNIFORM':''};
    $scope.toggleIcon = function(sel, icon) {

        $scope.imgIcons = {'SIMULTANEOUS':'','CIRCULAR':'', 'REGULAR':'', 'UNIFORM':''};
        $scope.imgIcons[icon] = 'selected';
        console.log(icon);
        $scope.policy = icon;

    }

    function declareVariables() {

        $scope.availableLinesTemplate = "partials/features/vz-grid/vz.grid.hunt-group-available-lines.html";
        $scope.noAnswer={};
        //Initialize Variables
        $scope.availableLines = [];
        $scope.availableLinesCount = 0;

        $scope.selectedLines = [];
        $scope.selectedLinesCount = 0;

        //Nullify the cache
        cache.put("huntgroup-algm", null);
        getData();
        if(detailsCache!==undefined)
        {
          $scope.availableLinesCount = $scope.availableLines.length;
          $scope.imgIcons[$scope.policy] = 'selected';
        }
        else
        {
            return;
        }

    }
    $scope.lookupDialog = function() {

    var new_dialog = ngDialog.open({ template: 'partials/components/dialog/lookupNightForwarding.html',

           className: 'ngDialog-theme-vz',
           closeByDocument: false,
           closeByEscape: false,
           scope:$scope,
           controller: function($scope) {
           $scope.lookupSearch='';
                console.log($scope.lookupSearch)
                $scope.phoneNumber = null;

                volteServices.setOption( Constants.API.COMMON.LINE_LOOKUP );
                volteServices.getData()
                    .success(function (result) {
                        $scope.lookupNos = result.appResult.serviceRepsonse.lineInfoList;
                        console.log("Lookup - ", result.appResult.serviceRepsonse );
                });


                $scope.lookupDropdown = [
                    {name:"Phone Lines", value: "phoneLines"},
                    {name:"User Name", value: "userName"},
                ];

                $scope.lookupSearchResp = function() {
                    return lookupSearch;
                }

                $scope.updateFromLookUp = function( record ) {
                    $scope.phoneNumber = record.phoneNumber;
                    //console.log("$scope.phoneNumber" + $scope.phoneNumber + " &&  record.phoneNumber" + $scope.phoneNumber = record.phoneNumber );

                }

                $scope.addToTextBox = function() {

                    if( $scope.lookupNos.length == 0  ) {
                        alert('There aren\'t any records to be added');
                    }

                    if( $scope.phoneNumber == null  ) {
                        alert("Please select a record");
                    }
                    console.log($scope.forwardToPhoneNumber);
                    document.getElementById("huntGroupLookupNo").value = $scope.phoneNumber;
                    $scope.$parent.forwardToPhoneNumber=$scope.phoneNumber;
                    console.log($scope.$parent.forwardToPhoneNumber);
                    var windowIDs = ngDialog.getOpenDialogs();
                    ngDialog.close(windowIDs[1]);

                }
            }

        });
  }
     $scope.moveUp=function()
    {
        var parent=document.getElementById('selectedLinesGrid');
        var list=document.getElementById('selectedLinesGrid').children;
        // //console.log(list.children);
        // for(var i=list.length-1;i>=0;i--)
        // {
        //     // if(angular.element(angular.element(document.getElementById('selectedLinesGrid'))[0].children[0])[0].className.search('selected-line')>=0)
        //     // {
        //     //    parent.insertBefore(list[i], list[i].previousElementSibling);
        //     // }
        //     // angular.element(list[i]).removeClass('selected-line');
        //        if(list[i].className.search('selected-line')!==-1 && list[i].previousElementSibling!==null )
        //        {
        //             parent.insertBefore(list[i], list[i].previousElementSibling);
        //             //angular.element(list[i-1]).removeClass('selected-line');
        //        }
        //        // angular.element(list[i]).removeClass('selected-line');
        //        //$scope.
        // }

        //angular.element(list[i]).removeClass('selected-line');
        //selectedLinesChosen=[];
        for(var i = 0; i < selectedLinesChosen.length; i++) {
            var idx = $scope.selectedLines.indexOf(selectedLinesChosen[i])

            console.log(idx);
            if (idx > 0) {
                var itemToMove = $scope.selectedLines.splice(idx, 1)
                console.log(itemToMove[0])
                $scope.selectedLines.splice(idx-1, 0, itemToMove[0]);
            }
           // angular.element(list[idx]).removeClass('selected-line');
        }
        //selectedLinesChosen=[];
         //console.log(document.getElementById('select-all-available-lines').checked);
       // for(var i=0;i<$scope.selectedLines.length;i++)
       // {
       //   if($scope.selectedLines)
       // }
    }
     $scope.moveDown=function()
    {
        var parent=document.getElementById('selectedLinesGrid');
         var list=document.getElementById('selectedLinesGrid').children;
        //var list=parent.children();
        //console.log(list.children);
        console.log(selectedLinesChosen)
         for(var i = 0; i < selectedLinesChosen.length; i++) {
            var idx = $scope.selectedLines.indexOf(selectedLinesChosen[i])
            console.log(idx,$scope.selectedLines.length);
            if (idx < $scope.selectedLines.length-1) {
                var itemToMove = $scope.selectedLines.splice(idx, 1)
                console.log(itemToMove[0])
                $scope.selectedLines.splice(idx+1, 0, itemToMove[0]);
                // angular.element(list[idx+1]).removeClass('selected-line');
            }
            // angular.element(list[idx]).removeClass('selected-line');
        }
        //selectedLinesChosen=[];
    }
     $scope.dragoverCallback = function(item) {
        console.log(item)
        if($scope.selectedLines.length<15)
        {
            return item;
        }
        else
        {
           $scope.showMsg=true;
           $scope.msgTxt='Selected Lines exceeded more than 15 lines';
           $scope.msgType='error';
           return false;
        }
    };

    function getData() {

        detailsCache = cache.get("huntgroup-lineid");
        if(detailsCache==undefined)
        {
            $state.go( 'features.enterprise.hunt_group');
            return;
        }
        $scope.huntGroupAlgoDetails=detailsCache;
        console.log(detailsCache);
        if ($scope.huntGroupAlgoDetails.noAnswerNumberOfRings == undefined) {
            $scope.huntGroupAlgoDetails.noAnswerNumberOfRings = 5;
        }
        $scope.noanswerring=$scope.huntGroupAlgoDetails.noAnswerNumberOfRings;
        console.log($scope.noanswerring);
        $scope.forwardToPhoneNumber=detailsCache.forwardToPhoneNumber;
        $scope.modelData = {};
        /*
         $scope.modelData.forwardAfterTimeout=detailsCache.forwardAfterTimeout;
         making the value to true always should cahnge it later the above value
         */
        $scope.modelData.forwardAfterTimeout=true;
        $scope.modelData.callerLimits=Math.ceil(detailsCache.forwardTimeoutSeconds/60)==1?1+'Minute':Math.ceil(detailsCache.forwardTimeoutSeconds/60)+'Minutes';
        //console.log(detailsCache.forwardTimeoutSeconds);
        //$scope.callerLimit=detailsCache.forwardTimeoutSeconds;
        $scope.availableLines        = detailsCache.availableLines==undefined?[]:detailsCache.availableLines;
        $scope.selectedLines         = detailsCache.selectedLines==undefined?[]:detailsCache.selectedLines;
        $scope.numberOfRings = detailsCache.noAnswerNumberOfRings;
        /*
         $scope.isHuntAfterNoAnswer   = detailsCache.isHuntAfterNoAnswer;
         making the value to true always should cahnge it later the above value
         */
        $scope.isHuntAfterNoAnswer   = true;
        $scope.policy                = detailsCache.policy;
        $scope.disableHuntGroup=$scope.forwardAfterTimeout==true?true:false;
        $scope.models =
            {
                selected: null,
                lists:
                {
                    "availableLine": $scope.availableLines ,
                    "selectedLines": $scope.selectedLines
                }
            };

        //console.log( $scope.models);
        /*huntGroupServices.getAvailableLines({})
            .success(function (result) {
                $scope.availableLines = result.appResult.serviceRepsonse.lineTypeList;
                $scope.availableLinesCount = $scope.availableLines.length;
            })
            .error(function (error) {
                $scope.status = 'Unable to load data: ' + error.message;
            });*/

    }
    $scope.checkValue=function(){
     //console.log(parseInt($scope.modelData.callerLimits));
      if(parseInt($scope.modelData.callerLimits)>7200)
      {
        $scope.modelData.callerLimits='';
      }
    }
     function getHuntGroupDetails() {
        angular.element();
        huntGroupServices.setHuntGroupStatus(row.active);
        // huntGroupServices.setOption(API.HUNTGROUP_INFO);
        huntGroupServices.setHuntGroupNumber(row.phoneNumber);
        // huntGroupServices.setHuntGroupStatus($scope.selectedHuntGroupStatus);
    }

    $scope.vzSubmitBtnStatusFn = function( decision ) {
        $rootScope.vzSubmitBtnStatus = !decision;
        console.log(decision)
        return decision;
    }

    function getEPAMLinkForAlg() {

        var cachedDataForEPAM= cache.get("huntgroup-lineid");
        var HREFArr          = window.location.href.split("#");
        var TokenGoBackURL   = HREFArr[0] + "#/features/enterprise/hunt-group-algorithm/";
            TokenGoBackURL   = encodeURIComponent( TokenGoBackURL );
        var TokenLineNumber  = cachedDataForEPAM.phoneNumber;

        $scope.EPAMLink      = $rootScope.EPAMLink.replace("TokenGoBackURL",  TokenGoBackURL);
        $scope.EPAMLink      = $scope.EPAMLink.replace("TokenLineNumber", TokenLineNumber);

        // Redirect with back URL
        var currentUrlPath = window.location.href;
        var redirectUrlPath = $scope.EPAMLink;
        $scope.EPAMLink = redirectUrlWithReturnURL(redirectUrlPath, currentUrlPath, Constants.API.REDIRECT_URL_PATHS.split_At);

    }
    $scope.setFormScope=function(formScope)
    {
        this.formScope=formScope;
    }
    function init() {

        declareVariables();

        //getHuntGroupDetails();
        $scope.availableAll=false;
        $scope.huntForm={};
        $scope.noAnswer={};
        $scope.selectAll=false;
        //$scope.showBlockMsg={};
        $scope.showBlockMsg=false;
        $scope.select_rings = HuntGroupConst.SELECT_RINGS;
        $scope.enter_seconds = HuntGroupConst.ENTER_MINUTES;
        $scope.rings_selected = "";
        $scope.huntGroupNumber = huntGroupServices.getHuntGroupNumber();
        $scope.huntGroupStatus = huntGroupServices.getHuntGroupStatus();
        getEPAMLinkForAlg();

     /*   huntGroupServices.setHuntGroupStatus(row.isActive);
        // huntGroupServices.setOption(API.HUNTGROUP_INFO);
        huntGroupServices.setHuntGroupNumber(row.phoneNumber);*/
        $scope.model=true;
        $scope.pageTitle = huntGroupConst.algorithmpageTitle;
        $scope.pageDesc = huntGroupConst.pageDesc;
        $scope.instructions= huntGroupConst.instructions;
        $scope.instructionsSelectType = huntGroupConst.instructionsSelectType;
        $scope.$watch('models',function(newVal,oldVal) {
            console.log(oldVal);
           if(oldVal!==undefined)
           {
            if(oldVal!==newVal)
            {
              $scope.model=false;
             console.log(newVal,oldVal);
            }
           }
        },true);
         $scope.$watch('showMsg',function(newVal,oldVal){
           if($scope.showMsg==true && $scope.showBlockMsg==false)
           {
              $document.on('click', function($event) {
                 $scope.showMsg=false;
              });
           }
        })
         $scope.$watch('showBlockMsg',function(newVal,oldVal){
           // if($scope.showMsg==true && $scope.showBlockMsg.msgBlock==false)
           // {
           //    $document.on('click', function($event) {
           //       $scope.showMsg=false;
           //    });
           // }
           $scope.showBlockMsg=newVal;
        },true)

    }

    init();

    $scope.selectAllAvailableLines = function(event,availableAll) {
        var grid = document.getElementById('availableLinesGrid');
        var isSelectAllChecked = document.getElementById('select-all-available-lines').checked;

        //select all the available lines
        if(availableAll) {
            for (var i = 0; i < angular.element(grid).find('li').length; i++) {
                angular.element(grid).find('li').eq(i).addClass('selected-line');
                //alert($scope.availableLines[i]);
                availableLinesChosen.push($scope.availableLines[i]);
            };
        } else {
            for (var i = 0; i < angular.element(grid).find('li').length; i++) {
                angular.element(grid).find('li').eq(i).removeClass('selected-line');
                availableLinesChosen = [];
            };
        }

    }

    $scope.onAvailableLinesClick = function(event, index,row) {
        var ele = event.currentTarget;
        //check whether an already chosen line is selected again
        //if so, clear the selection
        //else set selection
        if(angular.element(ele).hasClass('selected-line')) {
            angular.element(ele).removeClass('selected-line');
            availableLinesChosen.splice(availableLinesChosen.indexOf(row), 1);
            //clear Select All checkbox selection, if any
            document.getElementById('select-all-available-lines').checked = false;
        } else {
            angular.element(ele).addClass('selected-line');
            availableLinesChosen.push(row);
        }
    }

    $scope.selectAllSelectedLines = function(event,selectAll) {

        var grid = document.getElementById('selectedLinesGrid');
        var isSelectAllChecked = document.getElementById('select-all-selected-lines').checked;

        //select all the available lines
        console.log($scope.selectAll+'$scope.selectAll')
        if(selectAll) {
            for (var i = 0; i < angular.element(grid).find('li').length; i++) {
                angular.element(grid).find('li').eq(i).addClass('selected-line');
                selectedLinesChosen.push($scope.selectedLines[i]);
            };
        } else {
            for (var i = 0; i < angular.element(grid).find('li').length; i++) {
                angular.element(grid).find('li').eq(i).removeClass('selected-line');
                selectedLinesChosen = [];
            };
        }

    }

    $scope.onSelectedLinesClick = function(event, index, row) {
        var ele = event.currentTarget;
        //check whether an already chosen line is selected again
        //if so, clear the selection
        //else set selection
        if(angular.element(ele).hasClass('selected-line')) {
            angular.element(ele).removeClass('selected-line');
            selectedLinesChosen.splice(selectedLinesChosen.indexOf(row), 1);
            //clear Select All checkbox selection, if any
            document.getElementById('select-all-selected-lines').checked = false;
        } else {
            angular.element(ele).addClass('selected-line');
            selectedLinesChosen.push(row);
        }
    }

    $scope.fromAvailableLinesToSelectedLines = function(event) {
        //push chosen lines
        for (var i = 0; i < availableLinesChosen.length; i++) {
            //alert(JSON.stringify(availableLinesChosen[i]));
            if($scope.selectedLines.length<15)
            {
               $scope.selectedLines.push(availableLinesChosen[i]);
            }
            else
            {
               //$scope.availableLines.push(availableLinesChosen[i]);
               console.log(i);
               availableLinesChosen.splice(i,1);
               i--;
               // console.log($scope.availableLines,)
               $scope.showMsg=true;
               $scope.msgTxt='Selected Lines exceeded more than 15 lines';
               $scope.msgType='error';
            }
        };
        //after pushing the chosen lines
        //update Available Lines by deleting chosen lines
        for (var i = 0; i < availableLinesChosen.length; i++) {
            $scope.availableLines.splice($scope.availableLines.indexOf(availableLinesChosen[i]), 1);
        };

        availableLinesChosen = [];
        updateLinesCount();
        //clear Select All checkbox selection, if any
        document.getElementById('select-all-available-lines').checked = false;
    }

    $scope.fromSelectedLinesToAvailableLines = function(event) {
        //push chosen lines
        for (var i = 0; i < selectedLinesChosen.length; i++) {
            $scope.availableLines.push(selectedLinesChosen[i]);
        };
        //after pushing the chosen lines
        //update Selected Lines by deleting chosen lines
        for (var i = 0; i < selectedLinesChosen.length; i++) {
            $scope.selectedLines.splice($scope.selectedLines.indexOf(selectedLinesChosen[i]), 1);
        };

        selectedLinesChosen = [];
        updateLinesCount();
        //clear Select All checkbox selection, if any
        document.getElementById('select-all-selected-lines').checked = false;
    }

    updateLinesCount = function() {
        $scope.availableLinesCount = $scope.availableLines.length;
        $scope.selectedLinesCount = $scope.selectedLines.length;
    }
     $scope.disableFunc = function(number){
        if(!number || number.length<10)
        {
            console.log(number ,  $scope.huntForm.huntGroupAlgoForm.$invalid)
            $scope.huntForm.huntGroupAlgoForm.$invalid = true;
        }
        // $scope.huntForm.huntGroupAlgoForm
        $scope.forwardToPhoneNumber = number;
     };
    $scope.sendAlgorithmDetails = function() {
       //this.formScope.huntGroupAlgoForm.$setPristine();
        // if(!$scope.forwardToPhoneNumber)
        // {
        //     $scope.msgType = "error";
        //     $scope.thankuTxt="Error";
        //     $scope.msgTxt = "result.appHeader.statusMessage";
        //     $scope.showMsg = true;
        // }else
        // {
            var algorithmSettings = [],
            selectedRings = $scope.rings_selected,
            advanceToNextNumber = document.getElementById('advance-to-next-number').checked;
            console.log($scope.huntGroupAlgoDetails.noAnswerNumberOfRings);
            var param = {
               "phoneNumber": $scope.huntGroupAlgoDetails.phoneNumber,
               "huntGroupName":$scope.huntGroupAlgoDetails.huntGroupName,
               "callingLineIdName":$scope.huntGroupAlgoDetails.callingId,
               "timeZone":$scope.huntGroupAlgoDetails.timeZone,
               "geoTimeZone":$scope.huntGroupAlgoDetails.geoTimeZone,
               "active":$scope.huntGroupAlgoDetails.active=='Active'?true:($scope.huntGroupAlgoDetails.active=='Suspended'?false:''),
               "policy":$scope.policy,
               "noAnswerNumberOfRings":$scope.huntGroupAlgoDetails.noAnswerNumberOfRings,
               "huntAfterNoAnswer":advanceToNextNumber,
               "huntGroupMdninfoList":$scope.selectedLines,
               "forwardTimeoutSeconds":detailsCache.forwardTimeoutSeconds
            };
        console.log(param,$scope.callerLimits);
        //console.log($scope.noAnswerNumberOfRing);
        //$scope.isHuntAfterNoAnswer = detailsCache.isHuntAfterNoAnswer;
        //$scope.policy = detailsCache.policy;
        //console.log(huntgroupAlgm);
        console.log($scope.modelData.forwardAfterTimeout)
        if($scope.modelData.forwardAfterTimeout)
        {
            param.forwardAfterTimeout=$scope.modelData.forwardAfterTimeout;
            console.log('sendAlgorithmDetails - forwardToPhoneNumber - ' + $scope.forwardToPhoneNumber);
            if($scope.forwardToPhoneNumber!==undefined)
            {
                param.forwardToPhoneNumber=$scope.forwardToPhoneNumber;
               // if($scope.forwardToPhoneNumber.length>=10)
               // {
               //   param.forwardToPhoneNumber=$scope.forwardToPhoneNumber;
               // }
            }
            if( $scope.modelData.callerLimits!==undefined)
            {
                var checkMinutes=$scope.modelData.callerLimits.toString().search("Minute");
                console.log(checkMinutes)
                if(checkMinutes!==-1)
                {
                    var strngConvert= $scope.modelData.callerLimits.toString().replace("Minutes", "")||str.replace("Minute", "");
                    param.forwardTimeoutSeconds= parseInt(strngConvert)*60;
                }
                else
                {
                    param.forwardTimeoutSeconds= $scope.modelData.callerLimits;
                }
                // param.forwardTimeoutSeconds= $scope.modelData.callerLimits;
               // if(parseInt($scope.modelData.callerLimits)<=7200)
               // {
               //  param.forwardTimeoutSeconds= parseInt($scope.modelData.callerLimits);
               // }
            }
        }
        huntGroupServices.modifyHuntGroupInfo( param )
            .success(function(result) {
                try {
                    if(result.appHeader.statusCode.toUpperCase() == "OK") {
                        if(result.appHeader.statusCode.toUpperCase() == "OK") {
                           $state.get('features.enterprise.hunt_group').data.successTxt = 'thankuTxt';
                           $state.go('features.enterprise.hunt_group', {obj:'thankuTxt'},{reload:true});
                        } else {
                            $scope.msgType = "error";
                            $scope.thankuTxt="Error";
                            $scope.msgTxt = result.appHeader.statusMessage;
                            $scope.showMsg = true;
                        }
                    } else {
                        $scope.msgType = "error";
                        // $scope.thankuTxt="Error";
                        $scope.msgTxt = result.appHeader.statusMessage;
                        $scope.showMsg = true;
                        $scope.showBlockMsg=false;
                        $scope.huntForm.huntGroupAlgoForm.$pristine=true;
                        console.log($scope.huntForm.huntGroupAlgoForm);
                        $scope.model=true;
                        //$scope.huntGroupAlgoForm.$pristine=true;
                    }
                } catch(err) {
                    console.log("Failure - "+err.message);
                }
            })
            .error(function(error) {
                console.log("Failure - "+err.message);
            });
        // }
        // cache.put("huntgroup-algm",huntgroupAlgm);

        // huntGroupServices.setAlgorithmDetails({'selectedLines':[], 'algorithmSettings':algorithmSettings});

    }
};

huntCallingAlgorithmCtrl.$inject = ["$scope", "$http", "ngDialog", "$compile", "$state","HuntGroupConst","huntGroupServices", "huntGroupConst", "vzCache", "$rootScope", "cache","volteServices","Constants","$document","$window"];
angular.module( window.AppName ).controller("huntCallingAlgorithmCtrl", huntCallingAlgorithmCtrl);
