(function() {
    var Controller = function($scope, $stateParams, manageScheduleService, scheduleConst) {
        var loadingPromise;
        var loading = false;
        var hasException = false;

        function init() {
            //Initialize Variables
            if ($scope.operation === 'update') {
                $scope.pageTitle = $scope.scheduleType === 'Business' ?
                    scheduleConst.reviewBusinessPageTitle :
                    scheduleConst.reviewHolidayPageTitle;
            } else {
                $scope.pageTitle = scheduleConst.scheduleTypePageTitle;
                $scope.instructionDetails = scheduleConst.scheduleNameInstructions.instructions;
            }

            $scope.pageDesc = scheduleConst.pageDesc;
            $scope.nameError = '';
            $scope.msgTxt = '';
            $scope.msgType = '';
            $scope.showMsg = false;

            loadList();
        }

        /**
         * Generic list loader
         *
         * @method     loadList
         */
        function loadList() {
            var params = {};

            loadingPromise = loadingPromise || manageScheduleService.loadList(params);
            loading = true;

            loadingPromise.catch(errorHandler)
                .then(function(response) {
                    loadingPromise = null;
                    loading = false;
                    hasException = response instanceof Error;
                    return response;
                });
        }

        /**
         * Generic error handler
         *
         * @method     errorHandler
         * @param      {Error}  err     Error instance with the appropriate message
         * @return     {Error}
         */
        function errorHandler(err) {
            $scope.msgType = 'error';
            $scope.msgTxt = err.message || 'An unknown error has occured';
            $scope.showMsg = true;
            $scope.loading = false;
            return err;
        }

        /**
         * Checks for existing records with the same name
         * and will proceed() if there's no conflict
         *
         * @method     checkForConflict
         */
        function checkForConflict() {
            var scheduleType = $scope.scheduleType.toUpperCase(),
                scheduleName = $scope.scheduleName;

            $scope.loading = false;

            manageScheduleService.get({
                // scheduleType: scheduleType, // Is it type specific?
                scheduleName: scheduleName
            })
            .then(function(records) {
                if ($scope.operation === 'create') {
                    if (records.length) {
                        $scope.nameError = "A schedule by that name already exists";
                    } else {
                        proceed();
                    }
                } else if ($scope.operation === 'update') {
                    manageScheduleService.get({
                        scheduleName: $stateParams.scheduleName
                    }).then(function (requestedSchedules) {
                        // Check for presence from list
                        if (requestedSchedules.length === 0 || requestedSchedules[0].scheduleType.toUpperCase() !== scheduleType) {
                            errorHandler(new Error("The requested schedule could not be found"));
                        }

                        else {
                            if ($stateParams.scheduleName === scheduleName || records.length === 0) {
                                proceed();
                            } else {
                                $scope.nameError = "A schedule by that name already exists";
                            }
                        }
                    });
                } else {
                    // This should never really happen unless the parent controller
                    // is using an invalid $scope.operation name
                    throw new Error("Unknown operation requested");
                }
            })
            .catch(errorHandler);
        }

        /**
         * Execute parent $scope's navigate() to change the template value
         *
         * @method     proceed
         */
        function proceed() {
            $scope.setType($scope.scheduleType);
            $scope.setName($scope.scheduleName);

            $scope.navigate($scope.operation + $scope.scheduleType.toLowerCase());
        }

        /**
         * Goes back
         *
         * @method     onCancel
         */
        $scope.onCancel = function() {
            window.history.back();
        };

        /**
         * Waits for the response from loadList() and then checkForConflict()
         * once the response returns successfully. If it's already loaded, it
         * will checkForConflict() immediately.
         *
         * @method     onSubmit
         */
        $scope.onSubmit = function() {
            var name = $scope.scheduleName;

            $scope.showMsg = false;
            $scope.nameError = '';

            if (!name) {
                $scope.nameError = "Schedule name is a required field";
                return;
            } else if (/^[a-z0-9\-_]+$/gi.test(name)) {
                if (hasException) {
                    loadList();
                }

                if (!loading) {
                    checkForConflict();
                } else {
                    $scope.loading = true; // Display loading mask
                    loadingPromise.then(checkForConflict);
                }
            } else {
                $scope.nameError = "Schedule name contains illegal characters";
            }
        };

        init();
    };

    Controller.$inject = ['$scope', '$stateParams', 'manageScheduleService', 'scheduleConst'];

    angular.module(window.AppName).controller('scheduleNameCtrl', Controller);
})();