(function() {
    /**
     * Holiday Schedule Controller
     */
    var Controller = function($scope, $stateParams, holidayScheduleService, scheduleConst) {
        function init() {
            $scope.events = [];
            $scope.activeDate = new Date();

            if ($scope.operation === 'update') {
                $scope.pageTitle = scheduleConst.reviewHolidayPageTitle;
            } else {
                $scope.instructionDetails = scheduleConst.createNewHolidayInstructions.instructions;
                $scope.pageTitle = scheduleConst.holidayPageTitle;
            }

            $scope.pageDesc = scheduleConst.pageDesc;
        }

        /**
         * Generic error handler
         *
         * @method     errorHandler
         * @param      {Error}  err     Error instance with the appropriate message
         * @return     {Error}
         */
        function errorHandler (err) {
            $scope.msgType = 'error';
            $scope.msgTxt = err.message || 'An unknown error has occured';
            $scope.showMsg = true;
            $scope.loading = false;

            return err;
        }

        // Combine the calendar and events together
        $scope.$on('recurrancechange', function (e, events) {
            $scope.events = events;

            // scheduleCalendarCtrl listens for "eventchange"
            $scope.$broadcast('eventchange', events);
        });
        $scope.$on('eventrender', function (e, event, events) {
            $scope.events = events;
        });
        $scope.$on('dayclick', function (e, day) {
            // scheduleEventsCtrl listens for "selected" and "unselected"
            $scope.$broadcast((day.selected = !day.selected) ? 'selected': 'unselected', day);
        });
        $scope.$on('dayrender', function (e, day) {
            // Should this be a selected item?
            var events = $scope.events,
                filtered, recurring, exactMatch;

            // First filter by month & date only
            filtered = _.filter(events, _.matcher({
                month: day.month,
                date: day.date
            }));

            if (filtered.length) {
                recurring = !!_.find(filtered, _.matcher({ recurring: true })); // Are there any recurring items?
                exactMatch = !!_.find(filtered, _.matcher({ year: day.year }));

                if (recurring || exactMatch) {
                    day.selected = true;
                }
            }
        });
        $scope.$on('refresh', function () {
            $scope.$broadcast('refreshcalendar');
            // $scope.$broadcast('refreshevents');
        });
        $scope.$on('load', function (e, loading) {
            $scope.loading = loading;
        });
        $scope.$on('error', function (e, err) {
            errorHandler(err);
        });


        /**
         * Converts month index to English month equivalent
         *
         * @param      {Number}  index   Month index
         * @return     {String}  month (ex: "January", "February", etc)
         */
        $scope.getMonth = function (index) {
            return months[index];
        };

        /**
         * Navigate back to schedule type selector
         */
        $scope.onCancel = function () {
            $scope.navigate('default');
        };

        /**
         * Do validation test and submit if successful
         *
         */
        $scope.onSubmit = function () {
            var isValid = true;

            $scope.showMsg = false;

            if ($scope.events.length) {
                isValid = _.every($scope.events, function (event) {
                    if (!event.allDay) {
                        if ((!event.startTime || !event.endTime)) {
                            event.errorMessage = 'Both start time and end time are required fields';
                            return false;
                        } else {
                            if (event.startTime > event.endTime) {
                                // Error message should already be there
                                return false;
                            }
                        }
                    }
                    return true;
                });
            } else {
                isValid = false;
                errorHandler(new Error("No dates have been selected"));
            }

            if (isValid) {
                holidayScheduleService.upsertHoliday($scope.operation, {
                    scheduleName: $scope.scheduleName,
                    oldScheduleName: $stateParams.scheduleName,
                    events: $scope.events
                })
                .then(function () {
                    $scope.navigate('success');
                }).catch(errorHandler);
            }
        };

        init();
    }; // End of Controller

    /**
     * Begin Utility Variables/Functions
     */
    var months = [
        'January',
        'February',
        'March',
        'April',
        'May',
        'June',
        'July',
        'August',
        'September',
        'October',
        'November',
        'December'
    ];

    Controller.$inject = ['$scope', '$stateParams', 'holidayScheduleService', 'scheduleConst'];

    angular.module(window.AppName).controller('holidayCtrl', Controller);
})();