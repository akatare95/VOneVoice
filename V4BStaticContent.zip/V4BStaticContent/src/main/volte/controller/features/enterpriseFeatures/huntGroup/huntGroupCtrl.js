var huntGroupCtrl = function($scope, $http, ngDialog, $compile, $state, huntGroupServices,huntGroupConst,Constants, cache, $rootScope) {

	function declareVariables() {

        //Load Constants
        API = Constants.API.HUNT_GROUP;

        //Define tpl path
        $scope.vzGridTpl = "partials/features/vz-grid/vz.grid.manage-hunt-group.html";

        if( typeof($rootScope.huntGroupLineDetail) != 'undefined') {
            $rootScope.huntGroupLineDetail = {};
        }

    }


    function getData() {

        huntGroupServices.getHuntGroupList()
            .success(function (result) {
                $scope.loadFlag     =  false;
                if( result.appHeader.statusCode == "OK")  {

                    $scope.collection = result.appResult.serviceRepsonse.huntGroupList;
                    $scope.numberOfHuntGroups = $scope.collection.length;
                    if($state.current.data.successTxt !== 'thankuTxt')
                    {
                      $scope.msgType = null;
                      $scope.thankuTxt=null;
                      $scope.msgTxt = null;
                      $scope.showMsg = false;
                    }
                    else
                    {
                      $scope.msgType = "success";
                      $scope.thankuTxt="Thank You";
                      $scope.msgTxt = "Your request has been successfully submitted.";
                      $scope.showMsg = true;
                      $state.current.data.successTxt = null;
                    }
                    //Reset Huntgroup Line Detail
                    $rootScope.huntGroupLineDetail = {};
                }
             });

    }

/*
    $scope.purchaseHuntGroup = function() {

    	//window.location = $rootScope.huntGroupUrl;


        var getHostDetailsArr =    [];
        var subdomain         =    null;

        getHostDetailsArr     =    getHostDetails();
        console.log("getHostDetailsArr" ,getHostDetailsArr );

        console.log("Total parts in the host URL..." , getHostDetailsArr.length);

        // Production Env. where HOSTNAME is v4b.verizonwireless.com
        if(3 == getHostDetailsArr.length){
        	window.location = 'https://b2b.verizonwireless.com/b2b/commerce/amsecure/index.go?ssPath=HG';
        }else{
        	subdomain  =    getHostDetailsArr[0].slice(3);
            console.log("subdomain" , subdomain);
            if( subdomain ) {
                window.location = 'https://b2b' + subdomain + '.sdc.vzwcorp.com/b2b/commerce/amsecure/index.go?ssPath=HG';
            } else {
                $scope.msgType = "error";
                $scope.msgTxt  = "Unable to redirect! Please contact Administrator";
                $scope.showMsg = true;
            }
        }

    }
*/
    $scope.purchaseHuntGroup = function() {
        var currentUrlPath = window.location.href;
        var appendPath = Constants.API.REDIRECT_URL_PATHS.commerce + '?' + Constants.API.REDIRECT_URL_PATHS.paramHG;
        var redirectUrlPath = prepareRedirectUrlPath(Constants.API.REDIRECT_URL_PATHS.prod, Constants.API.REDIRECT_URL_PATHS.dev, appendPath, true);
        window.location = redirectUrlWithReturnURL(redirectUrlPath, currentUrlPath, Constants.API.REDIRECT_URL_PATHS.split_At);
    }

    $scope.getHuntGroupDetails = function(row) {

        huntGroupServices.setHuntGroupStatus( row.active );
        huntGroupServices.setHuntGroupNumber( row.phoneNumber );
    }

    $scope.postHuntGroupDetails = function() {

        $rootScope.huntGroupLineDetail.huntGroupName = $scope.huntGroupName;
        $rootScope.huntGroupLineDetail.callingId = $scope.callingId;
        $rootScope.huntGroupLineDetail.timeZone = $scope.timeZone;

        cache.put("huntgroup-lineid","test");

    }

    function init() {

        //alert(huntGroupConst.HUNT_GROUP_TITLE);

        //Initialize Variables
        $scope.loadFlag     =  true;
        $scope.collection = {};
        $scope.numberOfHuntGroups;
        $scope.selectedHuntGroupNumber;
        $scope.selectedHuntGroupStatus;

        //Load available Hunt Groups
       // getHuntGroups();
        $scope.managepageTitle = huntGroupConst.managepageTitle;
        $scope.pageDesc = huntGroupConst.pageDesc;
        $scope.instructionsManage = huntGroupConst.instructionsManage;
        $scope.instructions = huntGroupConst.instructions;
        declareVariables();
        getData();

    }

    init();


};

huntGroupCtrl.$inject = ["$scope", "$http", "ngDialog", "$compile", "$state", "huntGroupServices", "huntGroupConst","Constants", "cache", "$rootScope"];
angular.module( window.AppName ).controller("huntGroupCtrl", huntGroupCtrl);
