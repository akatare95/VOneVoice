(function() {
    var Controller = function($scope, scheduleConst) {
        function init () {
            $scope.operation = 'create';

            $scope.scheduleName = '';
            $scope.scheduleType = 'Business';
            $scope.navigate('default');
        }

        $scope.navigate = function (destination) {
            switch (destination) {
                case 'createholiday':
                    $scope.tplUrl = 'partials/features/enterpriseFeatures/schedule/holiday.html';
                    break;
                case 'createbusiness':
                    $scope.tplUrl = 'partials/features/enterpriseFeatures/schedule/business.html';
                    break;
                case 'success':
                    $scope.tplUrl = 'partials/features/enterpriseFeatures/schedule/success.html';
                    $scope.pageDesc = scheduleConst.pageDesc;
                    $scope.instructions = scheduleConst.manageInstructions.instructions;
                    if ($scope.scheduleType === 'Business') {
                        $scope.pageTitle = "Success";
                        $scope.msgType = 'success';
                        $scope.showMsg = true;
                        $scope.msgTxt = "Create Business Schedule Successful";
                    } else {
                        $scope.pageTitle = "Success";
                        $scope.msgType = 'success';
                        $scope.showMsg = true;
                        $scope.msgTxt = "Create Holiday Schedule Successful";
                    }

                    $scope.onBack = function () {
                        window.history.back();
                    };

                    break;
                default:
                    $scope.tplUrl = 'partials/features/enterpriseFeatures/schedule/schedule-type.html';
                    break;
            }
        };

        $scope.setName = function (name) {
            $scope.scheduleName = name;
        };
        $scope.setType = function (type) {
            $scope.scheduleType = type;
        };

        init();
    };

    Controller.$inject = ['$scope', 'scheduleConst'];

    angular.module(window.AppName).controller('createScheduleCtrl', Controller);
})();