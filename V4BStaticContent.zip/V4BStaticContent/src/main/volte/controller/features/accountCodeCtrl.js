var accountCodeCtrl = function($scope, $http, ngDialog, $compile, $state, accountCodeServices, Constants,accountCodeConst) {

    var availableLinesChosen = [];
    var selectedLinesChosen = [];
    var optionalLinesChosen = [];

    function declareVariables() {

        API = Constants.API.ACCOUNT_CODE;
        $scope.option = API.ACCOUNT_SUMMARY;

    }

    function getAccountSummary() {

        //console.log("API - " + API.ACCOUNT_SUMMARY );
        accountCodeServices.setOption( API.ACCOUNT_SUMMARY );
        accountCodeServices.fetchData()
            .success(function (result) {

            })
            .error(function (error) {
                $scope.status = 'Unable to load data: ' + error.message;
            });

    }

    $scope.setExcludeEmployee = function() {
        if ($scope.excludeEmployee) {
            $scope.employeeFilter = 'Employee';
        } else {
            $scope.employeeFilter = 'Other';
        }
    }

	$scope.cancelAssign = function() {
        var redirectionLink =   "features.enterprise.account_code";
        $state.go( redirectionLink, {}, { reload: true });

    }


    function getAvailableLines() {
        //$scope.type = "schedule";
        //huntGroupServices.setOption( $scope.type );
        $scope.availableLinesTemplate = "partials/features/vz-grid/vz.grid.account-code-available-lines.html";
        //$scope.selectedLinesTemplate = "partials/features/vz-grid/vz.grid.hunt-group-selected-lines.html";
        getData();
    }

    function getData() {

        accountCodeServices.setOption( API.AVAILABLE_LINES );
        accountCodeServices.getData()
            .success(function (result) {

                $scope.availableLines = result.appResult.serviceRepsonse.availableLines                || [];
                $scope.selectedLines =  result.appResult.serviceRepsonse.mandatoryUsagePhoneNumberList || [];
                $scope.optionalLines = result.appResult.serviceRepsonse.optionalUsagePhoneNumberList   || [];

                $scope.models = {
                    selected: null,
                    lists: {
                        "availableLine": $scope.availableLines ,
                        "selectedLines": $scope.selectedLines,
                        "optionalLines": $scope.optionalLines
                    }
                };

            })
            .error(function (error) {
                $scope.status = 'Unable to load data: ' + error.message;
            });
    }
         $scope.selectAllAvailableLines = function(event) {
                var grid = document.getElementById('availableLinesGrid');
                var isSelectAllChecked = document.getElementById('select-all-available-lines').checked;
                console.log(isSelectAllChecked);

                //select all the available lines
                if($scope.availableAll) {
                    for (var i = 0; i < angular.element(grid).find('li').length; i++) {
                        angular.element(grid).find('li').eq(i).addClass('selected-line');
                        availableLinesChosen.push($scope.availableLines[i]);
                    };
                } else {
                    for (var i = 0; i < angular.element(grid).find('li').length; i++) {
                        angular.element(grid).find('li').eq(i).removeClass('selected-line');
                        availableLinesChosen = [];
                    };
                }

            }
        $scope.selectAllSelectedLines = function(event) {
        var grid = document.getElementById('selectedLinesGrid');
        var isSelectAllChecked = document.getElementById('select-all-selected-lines').checked;

        //select all the available lines
        if($scope.selectAll) {
            for (var i = 0; i < angular.element(grid).find('li').length; i++) {
                angular.element(grid).find('li').eq(i).addClass('selected-line');
                selectedLinesChosen.push($scope.selectedLines[i]);
            };
        } else {
            for (var i = 0; i < angular.element(grid).find('li').length; i++) {
                angular.element(grid).find('li').eq(i).removeClass('selected-line');
                selectedLinesChosen = [];
            };
            //console.log(selectedLinesChosen);
        }
    }

    $scope.selectAllOptionalLines = function(event) {
        var grid = document.getElementById('optionalLinesGrid');
        var isSelectAllChecked = document.getElementById('select-all-optional-lines').checked;

        //select all the available lines
        if($scope.optionAll) {
            for (var i = 0; i < angular.element(grid).find('li').length; i++) {
                angular.element(grid).find('li').eq(i).addClass('selected-line');
                optionalLinesChosen.push($scope.optionalLines[i]);
            };
        } else {
            for (var i = 0; i < angular.element(grid).find('li').length; i++) {
                angular.element(grid).find('li').eq(i).removeClass('selected-line');
                optionalLinesChosen = [];
            };
            //console.log(optionalLinesChosen);
        }

    }
    $scope.onAvailableLinesClick = function(event, index, row) {
        var ele = event.currentTarget;
        //check whether an already chosen line is selected again
        //if so, clear the selection
        //else set selection
        if(angular.element(ele).hasClass('selected-line')){
            console.log('rem-test'+index)
            angular.element(ele).removeClass('selected-line');
            availableLinesChosen.splice(availableLinesChosen.indexOf(row), 1);
            $scope.availableAll=false;
        } else {
            angular.element(ele).addClass('selected-line');
            //$scope.availableLines[index].lineNumber = $scope.availableLines[index].lineNumber;
            availableLinesChosen.push(row);
            if(availableLinesChosen.length==$scope.availableLines.length)
            {
                $scope.availableAll=true;
                console.log("select all");
            }
        }
    }

    $scope.onSelectedLinesClick = function(event, index) {
        var ele = event.currentTarget;
        //check whether an already chosen line is selected again
        //if so, clear the selection
        //else set selection
        if(angular.element(ele).hasClass('selected-line')) {
            angular.element(ele).removeClass('selected-line');
            selectedLinesChosen.splice(selectedLinesChosen.indexOf($scope.selectedLines[index]), 1);
            $scope.selectAll=false;
        } else {
            angular.element(ele).addClass('selected-line');
            $scope.selectedLines[index].lineNumber = $scope.selectedLines[index].lineNumber;
            selectedLinesChosen.push($scope.selectedLines[index]);
            if(selectedLinesChosen.length==$scope.selectedLines.length)
            {
                $scope.selectAll=true;
            }
        }
    }

    $scope.onOptionalLinesClick = function(event, index) {
        var ele = event.currentTarget;
        //check whether an already chosen line is selected again
        //if so, clear the selection
        //else set selection
        if(angular.element(ele).hasClass('selected-line')) {
            angular.element(ele).removeClass('selected-line');
            optionalLinesChosen.splice(optionalLinesChosen.indexOf($scope.optionalLines[index]), 1);
             $scope.optionAll=false;
        } else {
            angular.element(ele).addClass('selected-line');
            $scope.optionalLines[index].lineNumber = $scope.optionalLines[index].lineNumber;
            optionalLinesChosen.push($scope.optionalLines[index]);
             if(optionalLinesChosen.length==$scope.optionalLines.length)
            {
                $scope.optionAll=true;
            }
        }
    }

    $scope.fromAvailableLinesToSelectedLines = function(event) {
        //push chosen lines
        console.log(availableLinesChosen);
        for (var i = 0; i < availableLinesChosen.length; i++) {
            $scope.selectedLines.push(availableLinesChosen[i]);

        };
        //after pushing the chosen lines
        //update Available Lines by deleting chosen lines
        for (var i = 0; i < availableLinesChosen.length; i++) {
            $scope.availableLines.splice($scope.availableLines.indexOf(availableLinesChosen[i]), 1);
        };

        availableLinesChosen = [];
        updateLinesCount();
    }

    $scope.fromSelectedLinesToAvailableLines = function(event) {
        //push chosen lines
        for (var i = 0; i < selectedLinesChosen.length; i++) {
            $scope.availableLines.push(selectedLinesChosen[i]);
        };
        //after pushing the chosen lines
        //update Selected Lines by deleting chosen lines
        for (var i = 0; i < selectedLinesChosen.length; i++) {
            $scope.selectedLines.splice($scope.selectedLines.indexOf(selectedLinesChosen[i]), 1);
        };

        selectedLinesChosen = [];
        updateLinesCount();
    }
    $scope.fromSelectedLinesToOptionalLines = function(event) {
        //push chosen lines
        for (var i = 0; i < selectedLinesChosen.length; i++) {
            $scope.optionalLines.push(selectedLinesChosen[i]);
        };
        //after pushing the chosen lines
        //update Selected Lines by deleting chosen lines
        for (var i = 0; i < selectedLinesChosen.length; i++) {
            $scope.selectedLines.splice($scope.selectedLines.indexOf(selectedLinesChosen[i]), 1);
        };

        selectedLinesChosen = [];
        updateLinesCount();
    }
    $scope.fromOptionalLinesToSelectedLines = function(event) {
        //push chosen lines
        for (var i = 0; i < optionalLinesChosen.length; i++) {
            $scope.selectedLines.push(optionalLinesChosen[i]);
        };
        //after pushing the chosen lines
        //update Selected Lines by deleting chosen lines
        for (var i = 0; i < optionalLinesChosen.length; i++) {
            $scope.optionalLines.splice($scope.optionalLines.indexOf(optionalLinesChosen[i]), 1);
        };

        optionalLinesChosen = [];
        updateLinesCount();
    }
    $scope.fromAvailableLinesToOptionalLines = function(event) {
        //push chosen lines
        for (var i = 0; i < availableLinesChosen.length; i++) {
            $scope.optionalLines.push(availableLinesChosen[i]);

        };
        //after pushing the chosen lines
        //update Available Lines by deleting chosen lines
        for (var i = 0; i < availableLinesChosen.length; i++) {
            $scope.availableLines.splice($scope.availableLines.indexOf(availableLinesChosen[i]), 1);
        };

        availableLinesChosen = [];
        updateLinesCount();
    }

    $scope.fromOptionalLinesToAvailableLines = function(event) {
        //push chosen lines
        for (var i = 0; i < optionalLinesChosen.length; i++) {
            $scope.availableLines.push(optionalLinesChosen[i]);
        };
        //after pushing the chosen lines
        //update Selected Lines by deleting chosen lines
        for (var i = 0; i < optionalLinesChosen.length; i++) {
            $scope.optionalLines.splice($scope.optionalLines.indexOf(optionalLinesChosen[i]), 1);
        };

        optionalLinesChosen = [];
        updateLinesCount();
    }

    $scope.scrollTop = function() {
        var containerToScroll = document.getElementById('selectedLinesContainer'),
        containerHeight = document.getElementById('selectedLinesContainer').offsetHeight;
        //angular.element(containerToScroll)[0].scrollTop = containerHeight - 20;
    }

    $scope.scrollBottom = function() {
        var containerToScroll = document.getElementById('selectedLinesContainer'),
        containerHeight = document.getElementById('selectedLinesContainer').offsetHeight;
        angular.element(containerToScroll)[0].scrollTop = 40;
    }

    updateLinesCount = function() {
        $scope.availableLinesCount = $scope.availableLines.length;
        $scope.selectedLinesCount = $scope.selectedLines.length;
        $scope.optionalLinesCount = $scope.optionalLines.length;
    }

    $scope.test = function() {

        if($scope.model==true) {
             var params = {
               "codeType": "Account Code",
               "mandatoryUsagePhoneNumberList": $scope.selectedLines.length ? $scope.selectedLines :undefined,
               "optionalUsagePhoneNumberList": $scope.optionalLines.length ? $scope.optionalLines : undefined,
            };

            console.log("API - " +  API.MODIFY_ACCOUNT_CODE );

            accountCodeServices.setOption( API.MODIFY_ACCOUNT_CODE );
            accountCodeServices.postData( params )
                .success(function (result) {
                    if(result.appHeader.statusCode == "OK") {
                        $scope.msgType = "success";
                        $scope.msgTxt = "Added Successfully";
                        $scope.showMsg = true;
                        $scope.model=false;
                    }
                    $scope.collection = result.appResult.serviceRepsonse.codeEntries;
                 });

        }
    }

    $scope.manageAccountCode = function() {

        var params = {
           "codeType": "Account Code",
           "mandatoryUsagePhoneNumberList": $scope.selectedLines,
           "optionalUsagePhoneNumberList": $scope.optionalLines,
        };

        console.log("API - " +  API.MODIFY_ACCOUNT_CODE );

        accountCodeServices.setOption( API.MODIFY_ACCOUNT_CODE );
        accountCodeServices.postData( params )
            .success(function (result) {
                if(result.appHeader.statusCode == "OK") {
                    $scope.msgType = "success";
                    $scope.msgTxt = "Added Successfully";
                    $scope.showMsg = true;
                }
                $scope.collection = result.appResult.serviceRepsonse.codeEntries;
             });

    }

    function init() {

        //Initialize Variables
        $scope.availableAll=false;
        $scope.optionAll=false;
        $scope.selectAll=false;
        $scope.availableLines = [];
        $scope.availableLinesCount = 0;

        $scope.selectedLines = [];
        $scope.selectedLinesCount = 0;

        $scope.optionalLines = [];
        $scope.optionalLinesCount = 0;
        $scope.pageDesc=accountCodeConst.pageDesc;
        $scope.manageAssignPageTitle=accountCodeConst.manageAssignPageTitle;
        $scope.instructions=accountCodeConst.instructions;
        $scope.assignInstructions = accountCodeConst.assignInstructions;
        $scope.excludeEmployee = false;
        $scope.employeeFilter = 'Other';
        //Load Available Lines
        declareVariables();

        getAvailableLines();
        $scope.model=false;
        // $scope.$watch('availableAll',function(){

        // })
        $scope.$watch('models',function(newVal,oldVal) {
            if(oldVal!==undefined)
            {
               console.log("model changed");
                $scope.model=true;
            }
        },true);
        $scope.$watch('availableLines',function(newVal,oldVal) {
         if($scope.availableLines.length==0)
         {
            $scope.availableAll=false;
         }
        },true);
        $scope.$watch('selectedLines',function(newVal,oldVal) {
         if($scope.selectedLines.length==0)
         {
            $scope.selectAll=false;
         }
        },true);
         $scope.$watch('optionalLines',function(newVal,oldVal) {
         if($scope.optionalLines.length==0)
         {
            $scope.optionAll=false;
         }
        },true);


    }

    init();

};

accountCodeCtrl.$inject = ["$scope", "$http", "ngDialog", "$compile", "$state", "accountCodeServices", "Constants","accountCodeConst"];
angular.module( window.AppName ).controller("accountCodeCtrl", accountCodeCtrl);
