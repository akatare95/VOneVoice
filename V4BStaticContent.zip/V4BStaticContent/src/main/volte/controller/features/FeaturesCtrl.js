(function() {
    var FeaturesCtrl = function($scope, $rootScope, $state,  $cacheFactory, $window, $document, featuresServices, Config, UserConfig, ngDialog) {
        var localCache = $cacheFactory.get('features') || $cacheFactory('features'),
            _activeFeature = localCache.get('activeFeature') || 'enterprise';

        $scope.activeFeature = _activeFeature;

        $rootScope.title = $state.current.title;

        console.log('activeFeature', _activeFeature);

        $scope.onToggleBtnClick = function(type) {
            if (type) {
                $scope.activeFeature = type;
            } else {
                $scope.activeFeature = $scope.activeFeature === 'enterprise' ? 'user' : 'enterprise';
            }

            _activeFeature = $scope.activeFeature;
            localCache.put('activeFeature', _activeFeature);
        };


        $scope.onCarouselPaginate = function(type, direction) {
            var carousel = document.getElementById(type + '-carousel'),
                start = new Date().getTime(),
                offset, currentX, targetX;

            direction = parseInt(direction, 10);

            if (carousel) {
                offset = direction > 0 ? carousel.offsetWidth : -carousel.offsetWidth;
                currentX = carousel.scrollLeft;
                targetX = Math.max(Math.min(currentX + offset, carousel.scrollWidth - carousel.offsetWidth), 0);

                // Try to animate
                if (requestAnimationFrame) {
                    requestAnimationFrame(tweener);
                } else {
                    carousel.scrollLeft = targetX;
                }
            } else {
                throw new Error("The requested element does not exist: " + type + '-carousel');
            }

            function tweener() {
                var delta = 75,
                    now = new Date().getTime(),
                    expired = now - start >= 1000,
                    x = Math[direction > 0 ? 'min' : 'max'](carousel.scrollLeft + (direction > 0 ? delta : -delta), targetX);

                carousel.scrollLeft = x;

                if (!expired && x !== targetX) {
                    requestAnimationFrame(tweener);
                }
            }
        };
        $scope.featureAccessCode = function() {
            var new_dialog = ngDialog
                .open({
                    template: 'partials/components/dialog/featureAccessCode.html',
                    closeByDocument: false,
                    closeByEscape: false,
                    scope:$scope,
                    controller: 'featureAccessCodesCtrl'
                });
        }
        $scope.onItemPaginate = function(type, direction) {
            var list, activeLink, prev, next;

            direction = parseInt(direction, 10);

            if (type === 'user') {
                activeLink = $scope.usersCircleLink;
                list = $scope.userFeatures;
            } else {
                activeLink = $scope.enterpriseCircleLink;
                list = $scope.enterpriseFeatures;
            }

            // Get prev and next
            for (var i = 0, ln = list.length; i < ln; i++) {
                if (list[i].link === activeLink) {
                    prev = list[i - 1];
                    next = list[i + 1];
                    break;
                }
            }

            // Set circle values
            if (direction > 0) {
                if (next) {
                    $scope.onFeatureClick(null, next.title, next.desc, next.link, type, next.scroll);
                }
            } else {
                if (prev) {
                    $scope.onFeatureClick(null, prev.title, prev.desc, prev.link, type, prev.scroll);
                }
            }

            setTimeout(function() {
                // Focus carousel item
                scrollToActive(type, direction);
            }, 10);
        };

        function scrollToActive(type, direction) {
            var carousel = document.getElementById(type + '-carousel'),
                active = carousel.getElementsByClassName('active')[0],
                x = active.offsetLeft,
                targetX = x - carousel.offsetWidth / 2 + active.offsetWidth / 2,
                start = new Date().getTime();

            if (carousel) {
                // Try to animate
                if (requestAnimationFrame) {
                    requestAnimationFrame(tweener);
                } else {
                    carousel.scrollLeft = targetX;
                }
            } else {
                throw new Error("The requested element does not exist: " + type + '-carousel');
            }

            function tweener() {
                var delta = 75,
                    now = new Date().getTime(),
                    expired = now - start >= 1000,
                    x = Math[direction > 0 ? 'min' : 'max'](carousel.scrollLeft + (direction > 0 ? delta : -delta), targetX);

                carousel.scrollLeft = x;

                if (!expired && x !== targetX) {
                    requestAnimationFrame(tweener);
                }
            }
        }

        $scope.onFeatureClick = function(event, title, desc, link, type, scroll) {

            _activeFeature = $scope.type = type;
            localCache.put('activeFeature', _activeFeature);

            console.log('activeFeature', _activeFeature);

            switch (type) {
                case "enterprise":
                    $scope.enterpriseCircleTitle = title;
                    $scope.enterpriseCircleDesc = desc;
                    $scope.enterpriseCircleLink = link;
                    $scope.enterpriseCircleImg = scroll;
                    $scope.enterpriseCircleDisplay = true;
                    break;
                case "user":
                    $scope.usersCircleTitle = title;
                    $scope.usersCircleDesc = desc;
                    $scope.usersCircleLink = link;
                    $scope.usersCircleImg = scroll;
                    $scope.usersCircleDisplay = true;
                    break;
            }

            $scope.mobileDisplay = true;

            //console.log("Display - " + $scope.mobileDisplay);

        };

        $scope.navigateTo = function(link) {
            $state.go(link);
        };

        function getFeatureConfig() {
            try {

                featuresServices.getFeatureSetup()
                    .success(function(result) {
                        if (result.appHeader.statusCode == 'OK') {
                            var i = 0;
                            angular.forEach(result.appResult.serviceRepsonse, function(value, key) {
                                if (!value) {
                                    $scope.enterpriseFeatures.splice(i, 1);
                                }
                                i++;
                            });
                        } else {
                            $scope.serverError = true;
                        }

                    })
                    .error(function(error) {
                        $scope.serverError = true;
                        console.log('Unable to load customer data: ' + error.message);
                    });

            } catch (err) {
                console.log("Error - " + err.message);
            }
        }

        function instanitateEnterpriseListing() {
            $scope.enterpriseFeatures = [{
                    title: Config.ACCOUNT_CODE_TITLE,
                    desc: Config.ACCOUNT_CODE_DESC,
                    link: "features.enterprise.account_code",
                    scroll: 'account_code_scroll',
                    authorized: $rootScope.accessibility.ACCOUNT_CODE
                },
                //{title: Config.AUTHORIZATION_CODE_TITLE, desc: Config.AUTHORIZATION_CODE_DESC, link: "features.enterprise.authorize_code", scroll:'auth_code_scroll'},
                {
                    title: Config.AUTOMATED_RECEPTIONIST_TITLE,
                    desc: Config.AUTOMATED_RECEPTIONIST_DESC,
                    link: "features.enterprise.auto_attendant",
                    scroll: 'auto_attendant_scroll',
                    authorized: $rootScope.accessibility.AUTO_ATTENDANT
                }, {
                    title: Config.HUNT_GROUP_TITLE,
                    desc: Config.HUNT_GROUP_DESC,
                    link: "features.enterprise.hunt_group",
                    scroll: 'hunt_group_scroll',
                    authorized: $rootScope.accessibility.HUNT_GROUP
                },
                //{title: Config.CALLING_PLAN_TITLE, desc: Config.CALLING_PLAN_DESC, link: "features.enterprise.calling_plan", scroll:'calling_plan_scroll'},
                {
                    title: Config.GROUP_FORWARDING_TITLE,
                    desc: Config.GROUP_FORWARDING_DESC,
                    link: "features.enterprise.group_forwarding",
                    scroll: 'group_forwarding_scroll',
                    authorized: $rootScope.accessibility.GROUP_FORWARDING
                }, {
                    title: Config.CALLING_LINE_ID_TITLE,
                    desc: Config.CALLING_LINE_ID_DESC,
                    link: "features.enterprise.calling_line_id",
                    scroll: 'calling_lineid_scroll',
                    authorized: $rootScope.accessibility.CALLING_LINE_ID
                }, {
                    title: Config.CUSTOM_RINGBACK_TITLE,
                    desc: Config.CUSTOM_RINGBACK_DESC,
                    link: "features.enterprise.custom_ringback",
                    scroll: 'custom_ringback_scroll',
                    authorized: $rootScope.accessibility.CUSTOM_RINGBACK
                }, {
                    title: Config.REMOTE_GROUP_PICK_UP_TITLE,
                    desc: Config.REMOTE_GROUP_PICK_UP_DESC,
                    link: "features.enterprise.remote_group_pick_up",
                    scroll: 'remote_group_pick_up_scroll',
                    authorized: $rootScope.accessibility.REMOTE_GROUP_PICKUP
                }, {
                    title: Config.SCHEDULE_TITLE,
                    desc: Config.SCHEDULE_DESC,
                    link: "features.enterprise.manageSchedule",
                    scroll: 'schedule_scroll',
                    authorized: $rootScope.accessibility.SCHEDULE
                }
                // , {
                //         title: Config.MUSIC_ON_HOLD_TITLE,
                //         desc: Config.MUSIC_ON_HOLD_DESC,
                //         link: "features.enterprise.music_on_hold",
                //         scroll: 'music_on_hold_scroll',
                //         authorized: $rootScope.accessibility.MUSIC_ON_HOLD
                //     }
            ];
            $scope.enterpriseCircleTitle = $scope.enterpriseFeatures[0].title;
            $scope.enterpriseCircleDesc = $scope.enterpriseFeatures[0].desc;
            $scope.enterpriseCircleLink = $scope.enterpriseFeatures[0].link;
            $scope.enterpriseCircleImg = $scope.enterpriseFeatures[0].scroll;
            $scope.enterpriseCircleDisplay = true;

            $scope.eFeature1 = $scope.enterpriseFeatures.slice(0, 5);
            $scope.eFeature2 = $scope.enterpriseFeatures.slice(5, $scope.enterpriseFeatures.length);

        }

        function init() {
            $scope.enterpriseFeatures = [];

            var accessWatch = $scope.$watch('accessibility', function(newVal, oldVal) {

                if (typeof(oldVal) != 'undefined' || typeof(newVal) != 'undefined') {

                    instanitateEnterpriseListing();

                    accessWatch();

                }

            });

            $scope.usersCircleDisplay = true;

            $scope.userFeatures = [{
                    title: UserConfig.ANNONYMOUS_CALL_REJECTION_TITLE,
                    desc: UserConfig.ANNONYMOUS_CALL_REJECTION_DESC,
                    link: "features.user.anonymous_call_rejection",
                    scroll: 'anonymous_call_scroll'
                }, {
                    title: UserConfig.AUTOMATIC_CALLBACK_TITLE,
                    desc: UserConfig.AUTOMATIC_CALLBACK_DESC,
                    link: "features.user.automatic_callback",
                    scroll: 'automatic_callback_scroll'
                }, {
                    title: UserConfig.CALL_FORWARDING_TITLE,
                    desc: UserConfig.CALL_FORWARDING_DESC,
                    link: "features.user.call_forwarding",
                    scroll: 'call_forwarding_scroll'
                }, {
                    title: UserConfig.CALL_WAITING_TITLE,
                    desc: UserConfig.CALL_WAITING_DESC,
                    link: "features.user.call_waiting",
                    scroll: 'call_waiting_scroll'
                }, {
                    title: UserConfig.REMOTE_CALL_PICKUP_BARGE_IN_TITLE,
                    desc: UserConfig.REMOTE_CALL_PICKUP_BARGE_IN_DESC,
                    link: "features.user.dir_call_pickup",
                    scroll: 'remote_call_pickup_bargein_scroll'
                },
                //{title: "Custom Ringback", desc: DESCI, link: "features.enterprise.custom_ringback"},
                //{title: "Call Notify", desc: DESCI, link: "features.enterprise.call_notify"},
                //{title: "Group Forwarding", desc: DESCI, link: "features.enterprise.group_forwarding"},
                {
                    title: UserConfig.SIMULTANEOUS_RING_SERVICE_TITLE,
                    desc: UserConfig.SIMULTANEOUS_RING_SERVICE_DESC,
                    link: "features.user.sim_ring_service",
                    scroll: 'simultaneous_ring_service_scroll'
                }, {
                    title: UserConfig.SELECTIVE_CALL_REJECTION_TITLE,
                    desc: UserConfig.SELECTIVE_CALL_REJECTION_DESC,
                    link: "features.user.selective_call_acceptance",
                    scroll: 'selective_call_acceptance_scroll'
                }, {
                    title: UserConfig.PRE_ALERTING_ANNOUNCEMENT_TITLE,
                    desc: UserConfig.PRE_ALERTING_ANNOUNCEMENT_DESC,
                    link: "features.user.pre_alert_announcement",
                    scroll: 'pre_alerting_scroll'
                }, {
                    title: UserConfig.CALLER_ID_BLOCK_TITLE,
                    desc: UserConfig.CALLER_ID_BLOCK_DESC,
                    link: "features.user.caller_id_block",
                    scroll: 'caller_ID_block_scroll'
                }, {
                    title: UserConfig.CALLING_PLAN_TITLE,
                    desc: UserConfig.CALLING_PLAN_DESC,
                    link: "features.user.calling_plan",
                    scroll: 'calling_plan_scroll'
                }
                //,{
                //     title: UserConfig.MUSIC_ON_HOLD_TITLE,
                //     desc: UserConfig.MUSIC_ON_HOLD_DESC,
                //     link: "features.user.music_on_hold_user",
                //     scroll: 'music_on_hold_scroll'
                // }, {
                //     title: UserConfig.BARGE_IN_EXEMPT_TITLE,
                //     desc: UserConfig.BARGE_IN_EXEMPT_DESC,
                //     link: "features.user.barge_InExempt",
                //     scroll: 'barge_in_exempt_scroll'
                // }

            ];

            $scope.uFeature1 = $scope.userFeatures.slice(0, 6);
            $scope.uFeature2 = $scope.userFeatures.slice(6, $scope.userFeatures.length);

            $scope.usersCircleTitle = $scope.userFeatures[0].title;
            $scope.usersCircleDesc = $scope.userFeatures[0].desc;
            $scope.usersCircleLink = $scope.userFeatures[0].link;
            $scope.usersCircleImg = $scope.userFeatures[0].scroll;
            //$scope.usersCircleDisplay = false;

            $scope.mobileDisplay = false;

            getFeatureConfig();


           /*
            function tabSwitch (type)
            {
                if (type === 'enterprise')
                {

                }
            }
            */

        }


        init();

    };





    /**
     * requestAnimationFrame shim
     */
    var vendors = ['ms', 'moz', 'webkit', 'o'],
        requestAnimationFrame;

    if (!window.requestAnimationFrame) {
        for (var i = 0, ln = vendors.length; i < ln; i++) {
            requestAnimationFrame = requestAnimationFrame || window[vendors[i] + 'RequestAnimationFrame'];
        }
    } else {
        requestAnimationFrame = window.requestAnimationFrame;
    }

    FeaturesCtrl.$inject = ["$scope", "$rootScope", "$state", "$cacheFactory", "$window", "$document", "featuresServices", "Config", "UserConfig", "ngDialog"];
    angular.module(window.AppName).controller("FeaturesCtrl", FeaturesCtrl);

})();