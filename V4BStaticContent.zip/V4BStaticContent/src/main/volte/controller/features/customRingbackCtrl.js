var customRingbackCtrl = function($scope, $rootScope, customRingbackServices, customRingbackConst, Constants, $timeout, Config, $http, ngDialog) {

  scope = $scope;


  /*function validation() {
    this.enableSbtBtnForFileChange = function() {}
  }

  var validationObj = new validation();
  validationObj.enableSbtBtnForFileChange();*/
  $scope.enableSbtnBtnForCustom = function() {

    $scope.isValid = true;

    if (scope.files.length == 0) {
      console.log("File Changed 1");
      $scope.customForm.$pristine = true;
    }

  }

  $scope.enableSubmitBtnForSystem = function() {
    console.log($scope.customForm.$pristine)
    $scope.customForm.$pristine = false;

  }


  //Upload Functionalities starts here
  function uploadFileFn() {

    var API = Constants.API.CUSTOM_RINGBACK;
    //var audioSelection = ($scope.audioSelection) ? "SYSTEM" : "CUSTOM";

    var fd = new FormData()
    for (var i in scope.files) {
      fd.append("multipartFile", scope.files[i]);
    }
    fd.append('audioSelection', $scope.audioSelection);


    $rootScope.ajaxLoading = true;


    var xhr = new XMLHttpRequest();
    xhr.addEventListener("load", angular.bind(null, uploadProgress), false)
    window.addEventListener('error', angular.bind(null, uploadError), true);
    xhr.addEventListener("abort", angular.bind(null, uploadCanceled), false);
    xhr.open("POST", Constants.API_HOST + Constants.API.CUSTOM_RINGBACK.UPDATE);
    scope.progressVisible = true;
    xhr.setRequestHeader("X-XSRF-TOKEN", _.last(String(document.cookie.match(/XSRF-Token=([^\s;]*);/gi)).split(';')[0].split('=')));
    xhr.send(fd);

  }

  function uploadError(evt) {

    /*$scope.$apply(function(){
        $rootScope.ajaxLoading = false;
        error( "Upload Failed!" );
    });*/

  }

  function uploadProgress(evt) {

    $scope.$apply(function() {

      //Close the dialog loader
      $rootScope.ajaxLoading = false;

      try {


        var xhrSatus = parseInt(evt.target.status);

        //Check the status of the target
        if (xhrSatus == 200 || xhrSatus == 302) {

          var result = JSON.parse(evt.target.response);

          if (result.appResult.serviceRepsonse.errorCode == "0" || result.appResult.serviceRepsonse.errorCode == "00") {

            success();

            //Keep the submit button in disabled mode
            $scope.customForm.$pristine = true;

          } else {

            //Incase if service is down then display the error message

            var msg = (typeof(result.appResult.serviceRepsonse.message) != '') ? result.appResult.serviceRepsonse.message : "Upload Failed";
            error(msg);

            //Enable the submit button
            $scope.customForm.$pristine = false;

          }

        } else {

          //Incase if any error occured like 404 or 500 then display the error message

          //Enable the submit button
          $scope.customForm.$pristine = false;

          error("Upload Failed!");

        }

      } catch (err) {

        //Incase if any error occured in JS Response then we display the error response
        console.log("Error -  ", err);

        //Enable the submit button
        $scope.customForm.$pristine = false;

        error("Upload Failed!");

      }

    });



  }


  function uploadCanceled(evt) {

    var result = JSON.parse(evt.target.response);

    $scope.$apply(function() {
      $rootScope.ajaxLoading = false;
      var msg = "Unable to process request";
      error(msg);
    })
  }

  function uploadComplete(evt, $rootScope) {
    $rootScope.ajaxLoading = false;
  }


  function success() {
    scope.msgType = "success";
    scope.msgTxt = "Updated Successfully";
    scope.showMsg = true;
  }

  function error(msg) {

    msg = msg || "Updation Failed!";

    scope.msgType = "error";
    scope.msgTxt = msg;
    scope.showMsg = true;
  }

  scope.setFiles = function(element) {
    var doSetFiles = function() {
      if (element.files[0].size / 1024 <= Constants.MAX_FILE_SIZE.CUSTOM_RINGBACK) {
        scope.files = []
        for (var i = 0; i < element.files.length; i++) {
          scope.files.push(element.files[i]);
          $scope.theFile.name = element.files[i].name;
        }
        $scope.src = URL.createObjectURL(element.files[0]);
        scope.progressVisible = false;
        $scope.isValid = true;
        $scope.showMsg = false;
        //Enable the submit btn
        $scope.customForm.$pristine = false;
      } else {
        $scope.msgType = "error";
        $scope.msgTxt = " The audio file you have uploaded is too large for us to process.  Please reduce the file size to 1MB or less and try again";
        $scope.showMsg = true;
        $scope.customForm.$setPristine();
      }
    };


    var fileStr = element.files[0].type.split("/");
    if (fileStr[fileStr.length - 1].search("wav") !== -1 || fileStr[fileStr.length - 1].search("wma") !== -1) {
      if ($scope.$$phase) {
        doSetFiles();
      } else {
        $scope.$apply(function() {
          doSetFiles();
        });
      }
    } else {
      scope.$apply(function() {

        $scope.msgType = "error";
        $scope.msgTxt = "Please choose a file with WAV or WMA extension only";
        $scope.showMsg = true;
        $scope.customForm.$pristine = true;
        $scope.theFile.name = null;
      });
    }
  }

  //Upload Functionalities ends here

  $scope.vzSubmitBtnStatusFn = function(decision) {
    $rootScope.vzSubmitBtnStatus = !decision;
    return decision;
  }

  $scope.onFileChange = function() {

    $scope.customForm.$pristine = false;
    var file = document.getElementById('file').files[0];
    if (file.size / 1024 <= Constants.MAX_FILE_SIZE.CUSTOM_RINGBACK) {

      $scope.theFile = document.getElementById('file').files[0];
      //console.log($scope.theFile);
      $scope.src = URL.createObjectURL($scope.theFile);
      $scope.isStreaming = false;
      $scope.isValid = true;
      $scope.showMsg = false;
    } else {
      $scope.msgType = "error";
      $scope.msgTxt = "Please choose a file less than " + $scope.fileSizeLimit + "MB.";
      $scope.showMsg = true;
    }
  }

  $scope.play = function($event) {
    document.getElementById('audio_player').play();
    $scope.isStreaming = true;
  }
  $scope.pause = function() {
    document.getElementById('audio_player').pause();
    $scope.isStreaming = false;
  }
  $scope.onUpload = function(event) {
    event.preventDefault();
    document.getElementById('fileToUpload').click();
  }
  $scope.updatePost = function(event) {

    event.preventDefault();

    $scope.customForm.$setPristine();
    if (($scope.notification1 == false || $scope.notification2 == false)) {
      return;
    } else {
      //var fd = new FormData();
      if ($scope.audioSelection == 'CUSTOM') {
        uploadFileFn();
      } else {
        var postData = {
          'audioSelection': $scope.audioSelection
        };
        customRingbackServices.updateWithOutFile(postData)
          .success(function(result) {

            $rootScope.vzSubmitBtnStatus = false;

            try {
              if (result.appHeader.statusCode == "OK") {
                success();
              } else {
                error();
              }
            } catch (err) {
              //console.log("Failure - "+ err.message);
            }

          }).error(function() {
            $rootScope.vzSubmitBtnStatus = false;
          });
      }
    }

  }

  $scope.complete = function(content) {

    scope.msgType = "success";
    scope.msgTxt = "Updated Successfully";
    scope.showMsg = true;

    // Hiding loading icon for Non-XHR request.
    $rootScope.ajaxLoading = false;
  }

  var errorUploading = function() {

    //console.log('Error while uploading file');
    scope.msgType = "error";
    scope.msgTxt = "Error occurred while uploading file.";
    scope.showMsg = true;

    // Hiding loading icon for Non-XHR request.
    $rootScope.ajaxLoading = false;

  }

$scope.setCustomFile = function() {
    console.log('inside custom')
    var new_dialog = ngDialog.open({
      template: 'partials/components/dialog/instructionsLink.html',
      closeByDocument: false,
      className: 'ngdialog-theme-default selective-call-rejection-dialog',
      closeByEscape: false,
      scope: $scope,
      controller: 'instructionsLinkCtrl'
    });
  }
  function init() {

    $scope.fileSizeLimit = parseInt(Constants.MAX_FILE_SIZE.CUSTOM_RINGBACK) / 1000;
    $scope.pageTitle = customRingbackConst.pageTitle;
    $scope.pageDesc = customRingbackConst.pageTitle_Desc;
    $scope.instructionsUpload = customRingbackConst.instructionsUpload;
    $scope.instructions = customRingbackConst.instructions;
    $scope.theFile = {
      name: ""
    };
    $scope.fileUploadUrl = Constants.API_HOST + Constants.API.CUSTOM_RINGBACK.UPDATE;
    $scope.src = null;
    $scope.isValid = true;
    $scope.files = [];

    customRingbackServices.getcustomRingbackServices().success(function(result) {

      try {
        var response = result.appResult.serviceRepsonse;
        $scope.audioSelection = response.audioSelection.toUpperCase();
        if (response.audioSelection.toUpperCase() == 'CUSTOM') {
          $scope.theFile.name = response.audioFileInfo.fileName;
        }

      } catch (err) {}

    }).error(function(error) {});

  }

  init();
};

customRingbackCtrl.$inject = ['$scope', '$rootScope', 'customRingbackServices', 'customRingbackConst', 'Constants', '$timeout', 'Config', '$http', 'ngDialog'];
angular.module(window.AppName).controller("customRingbackCtrl", customRingbackCtrl);