var manageAccountCodeCtrl = function($scope, $http, ngDialog, $compile, $state, manageAccountCodeServices, accountCodeServices, Constants, $rootScope, cache,accountCodeConst,$document, $filter) {

    function declareVariables() {

        //Load Constants
        API = Constants.API.ACCOUNT_CODE;

        //Define tpl path
        $scope.vzGridTpl = "partials/features/vz-grid/vz.grid.manage-account-code.html";

        $scope.modelModified = false;

        $scope.accountName = "";
        $scope.accountDescription = "";

    }

    function getAccountSummary() {

        manageAccountCodeServices.setOption( API.ACCOUNT_SUMMARY );
        manageAccountCodeServices.getData()
            .success(function (result) {

                $scope.loadFlag     =  false;

                if( result.appHeader.statusCode == "OK")  {

                    $scope.collection   = result.appResult.serviceRepsonse.codeEntries;
                    cache.put("account-list",$scope.collection);
                    if($state.current.data.successTxt !== 'thankuTxt')
                    {
                      $scope.msgType = null;
                      $scope.thankuTxt=null;
                      $scope.msgTxt = null;
                      $scope.showMsg = false;
                    }
                    else
                    {
                      $scope.msgType = "success";
                      $scope.thankuTxt="Thank You";
                      $scope.msgTxt = "You have successfully submitted the request for creating an account code";
                      $scope.showMsg = true;
                      $state.current.data.successTxt = null;
                    }
                }

             }).error(function (error) {
                $scope.status = 'Unable to load data: ' + error.message;
            });;

    }

    $scope.goBackToManage = function() {

        var redirectionLink =   "features.enterprise.account_code";
        $state.go( redirectionLink, {}, { reload: true });

    }

    $scope.filterWildCards = function(input) {

        if( input ) {

            var result =  input.replace(/\*/g, "");
            return result;

        }

    }


    $scope.formatLineNumber = function(event) {

        var lineNumberInput = document.getElementById('lookupNo');
        lineNumber = lineNumberInput.value,
        charCode = (event.which) ? event.which : event.keyCode,
        acceptable = [48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 13, 32, 45, 46, 118, 8, 0];

        //restrict non-numeric inputs
        if(acceptable.indexOf(charCode) == -1) {
            lineNumber = lineNumber.replace(/\D/g, '');
        }
        //process formatting
        if(acceptable.indexOf(charCode) < 15) {
            lineNumber = lineNumber.replace(/\D/g, '');
        }
        //assign formatted value back to <input>
        angular.element(lineNumberInput).val(lineNumber);

  }
  $scope.vzSubmitBtnStatusFn = function( decision ) {
        $rootScope.vzSubmitBtnStatus = !decision;
        return decision;
    }
    $scope.remove = function(){
        $scope.thankuTxt = null;
        if($scope.collection.length>0)
        {
               manageAccountCodeServices.setOption( API.DELETE_LINES);
           var deletedItems={};
           deletedItems.codeEntries=[];
            for(var i=0;i<$scope.collection.length;i++)
            {
                if($scope.collection[i].isChecked==true)
                {
                    deletedItems.codeEntries.push({'code':$scope.collection[i].code});
                    // $scope.collection.splice(i,1);
                    //  i--;
                }
            }
            console.log(deletedItems);
            if(deletedItems.codeEntries.length>0)
            {
            manageAccountCodeServices.postData(deletedItems).success(function (result)
            {
                try
                {
                    if(result.appHeader.statusCode == "OK")
                  {
                    for(var i=0;i<$scope.collection.length;i++)
                            {
                                if($scope.collection[i].isChecked==true)
                                {
                                    $scope.collection.splice(i,1);
                                     i--;
                                }
                            }
                    $scope.msgType = "success";
                    $scope.msgTxt = "Deleted Successfully";
                    $scope.showMsg = true;
                    console.log( $scope.msgTxt);
                   }
                }
                catch(err){
                    console.log(err.message);
                }
            }).error(function (error) {
               console.log("Failure - ", error);
            });
          }
            else{
                $scope.msgType = "error";
                        $scope.showMsg = true;
                $scope.msgTxt = "Please select a Record";
            }
        }
        else{
            $scope.msgType = "error";
            $scope.showMsg = true;
            $scope.msgTxt = "No records to delete";
        }
       // console.log('$scope.collection'+$scope.collection);
    }

    $scope.ngEnableSubmit = function() {

        if( (typeof($scope.accountName) != 'undefined' && $scope.accountName.length>=2 && $scope.accountName.length<12)
                && (typeof($scope.accountDescription) != 'undefined' && $scope.accountDescription.length>1 && $scope.accountDescription.length<250) ) {
            $scope.modelModified = true;
        }

    }

    $scope.navigateToManageUsers = function() {
        console.log('navigateToManageUsers')
        $state.go('features.enterprise.account_code.assign_code');
    }

    $scope.updateStatus = function() {

       if($scope.accountDescription!==undefined &&  $scope.accountName!==undefined && $scope.accountDescription.length>=2 && $scope.accountName.length>=2 ) {
          if( $scope.createAccountCodeForm.$pristine ) {
            return true;
          } else {
            return false;
          }

       } else {
          return true;
       }
    }

    $scope.submitCode = function() {

        if( !alphanumericWithSpace($scope.accountDescription) ) {

            $scope.msgType = "error";
            $scope.msgTxt  = "Enter an alphanumeric value";
            $scope.showMsg = true;
            $scope.createAccountCodeForm.accountDescription.$pristine=true;
            $scope.createAccountCodeForm.$pristine=true;
            return;

        }

        $scope.alphanumericVal=false;
        $scope.createAccountCodeForm.$setPristine();

        var params = [];
        params.push({"code": $scope.accountName, "description": $scope.accountDescription});
        var sendRequestData = { "codeEntries": params };

        for(var loop=0; loop < $scope.collection.length; loop++ ) {

            if( $scope.collection[loop].code == $scope.accountName) {
              $scope.msgType = "error";
              $scope.msgTxt  = "Duplicate Account Code";
              $scope.showMsg = true;
              return;
            }

        }

        manageAccountCodeServices.setOption( API.CREATE_ACCOUNT );
        manageAccountCodeServices.postData( sendRequestData )
            .success(function (result) {

                if(result.appHeader.statusCode == "OK") {
                    $state.get('features.enterprise.account_code').data.successTxt = 'thankuTxt';
                    $state.go('features.enterprise.account_code', {obj:'thankuTxt'},{reload:true});
                } else {
                    $scope.msgType = "error";
                    $scope.msgTxt = result.appHeader.statusMessage;
                    $scope.showMsg = true;
                    //$state.go('features.enterprise.account_code');
                }

                console.log("Updated data is fetched...");
                //getAccountSummary();
                $scope.loadFlag  =  true;

             });

    }

    function init() {

        //Enable the loader
        $scope.loadFlag     =  true;
        console.log('init');
        $scope.pageDesc=accountCodeConst.pageDesc;
        $scope.manageAccountPageTitle=accountCodeConst.manageAccountPageTitle;
        $scope.createAccountPageTitle=accountCodeConst.createAccountPageTitle;
        $scope.instructions=accountCodeConst.instructions;
        $scope.collection = {};
        $scope.numberOfCodes;
        $scope.$watch('showMsg',function(oldVal,newVal){
            if($scope.showMsg==true)
            {
                $document.on('click', function($event) {
                 $scope.showMsg=false;
                });
            }
        })
        $scope.selectedCodes = {};

        declareVariables();
        if($state.current.url !== "/create-account-code")
        {
           getAccountSummary();
        }
        console.log($state);
    }

    init();

};


manageAccountCodeCtrl.$inject = ["$scope", "$http", "ngDialog", "$compile", "$state", "manageAccountCodeServices", "accountCodeServices", "Constants", "$rootScope", "cache","accountCodeConst","$document", "$filter"];
angular.module( window.AppName ).controller("manageAccountCodeCtrl", manageAccountCodeCtrl);
