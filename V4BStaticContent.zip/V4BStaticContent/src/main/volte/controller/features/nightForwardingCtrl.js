var nightForwardingCtrl = function($scope, ngDialog,Config, GroupForwardingConst, groupForwardingService, groupForwardingConst,volteServices,Constants, $document){

    var selectedTemp    = [];
    var availableTemp   = [];
    watchStatusLoop     = 0;

    $scope.enableSubmitBtn = function() {
        ////if( typeof($scope.forwardToPhoneNumber) == 'undefined' )
    	var enableFlag = false;
    	var toggleValue = document.getElementById("cmn-toggle-4").checked;
    	console.log("toggleValue changed to : "+toggleValue);
    	if(toggleValue != false){
        if( typeof($scope.forwardToPhoneNumber) == 'undefined' || (typeof($scope.forwardToPhoneNumber) != 'undefined' && $scope.forwardToPhoneNumber.length == 0) )
        	enableFlag = true;
    	}

    	console.log("enableFlag  : "+enableFlag);

        return enableFlag;

        /*    $scope.groupForwardingFrm.$pristine = true;
        return $scope.groupForwardingFrm.$pristine;*/

    }

    $scope.$watch('forwardToPhoneNumber', function(newVal, oldVal){

        if( typeof(newVal) == 'undefined' )
            return;

        if( newVal.length == 12 )
            $scope.groupForwardingFrm.$pristine =   false;
        else
            $scope.groupForwardingFrm.$pristine =   true;

   });

    function watchGroupForwardStatus() {

        $scope.$watch('nightForwardingStatus',function(newValue, oldValue){

            watchStatusLoop++;

            if( watchStatusLoop > 1 ) {

                //$scope.groupForwardingFrm.$pristine = false;

            }

            console.log("Watch - " + watchStatusLoop);

        });

    }

    $scope.submitData = function() {

        var bizSchedule = $scope.biz_schedule_selected;
        var holidaySchedule = $scope.holiday_schedule_selected;
        var forwardTo = document.getElementById("lookupNo").value .replace(/-/g, ""); ///$scope.forwardToPhoneNumber;
        var groupForwardingDetails = {};

        //Selected Lines
        var selectedLinesArr=[];
        if ( typeof selectedTemp != 'undefined' && selectedTemp.length > 0) {

            var selectedLinesTemp = $scope.selectedLines;
            var tempArr = selectedTemp;//JSON.parse(selectedTemp);

            angular.forEach(selectedLinesTemp, function(value, key) {
                var addFlag = true;
                angular.forEach(tempArr, function(ivalue, ikey) {
                    if (tempArr[ikey].phoneNumber == selectedLinesTemp[key].phoneNumber) {
                        addFlag = false;
                        //delete selectedLinesTemp[key];
                    }
                });

                if (addFlag) selectedLinesArr.push(selectedLinesTemp[key]);

            });

        } else {
            var selectedLinesArr = $scope.selectedLines;
        }


        //Available Lines
        var availableLinesArr=[];
        if ( typeof selectedTemp != 'undefined' && selectedTemp.length > 0) {


            var tempArr = JSON.parse(selectedTemp);
            angular.forEach(tempArr, function(jvalue, jkey) {
                angular.forEach($scope.availableLines, function(kvalue, kkey) {
                    if (tempArr[jkey].phoneNumber == $scope.availableLines[kkey].phoneNumber) {
                        availableLinesArr.push({"phoneNumber":tempArr[jkey].phoneNumber});
                    }
                });
            });
            //console.log('after loop', JSON.stringify(selectedLinesArr));
        }

        var nightForwardingStatus = ($scope.nightForwardingStatus) ? "ON" : "OFF";
        var buzzHrs=$scope.predefined==true?{"name":bizSchedule}:{name:''};
        var holzHrs=$scope.predefined==true?{"name":holidaySchedule}:{name:''};
        groupForwardingDetails ={
            "businessHours":buzzHrs ,
            "holidaySchedule": holzHrs,
            "forwardToPhoneNumber": forwardTo,
            "selectedLines": selectedLinesArr,
            "availableLines": availableLinesArr,
            "nightForwardingStatus": nightForwardingStatus
        };


        groupForwardingService.sendGroupForwardingDetails( groupForwardingDetails )
            .success(function(result) {
                if(result.appHeader.statusCode == "OK") {
                    $scope.msgType = "success";
                    $scope.msgTxt = 'Successfully Updated';
                    $scope.showMsg = true;
                    $scope.groupForwardingFrm.$pristine = true;
                } else {
                    $scope.msgType = "error";
                    $scope.msgTxt  = result.appHeader.statusMessage;
                    $scope.showMsg = true;
                    $scope.groupForwardingFrm.$pristine = true;
                }
            })
            .error(function(error) {

                $scope.msgType = "error";
                $scope.msgTxt  = error.message;
                $scope.showMsg = true;

            });

    }

    $scope.changebg = function(){
        if( $scope.isActive ) {
           return true;
        } else {
           return false;
        }
    }

    $scope.closeDialog = function() {

        try {
            var windowIDs = ngDialog.getOpenDialogs();
            ngDialog.close(windowIDs[1]);
        } catch(err) {}

    }

    $scope.lookupDialog = function() {

        var new_dialog = ngDialog.open({

            template: 'partials/components/dialog/lookupNightForwarding.html',
            className: 'ngDialog-theme-vz',
            closeByDocument: false,
            closeByEscape: false,
            scope: $scope,
            controller: function($scope, $rootScope) {

                $scope.phoneNumber = null;

                volteServices.setOption( Constants.API.COMMON.LINE_LOOKUP );
                volteServices.getData()
                    .success(function (result) {
                    	$scope.loadFlag     =  false;
                        $scope.lookupNos = result.appResult.serviceRepsonse.lineInfoList;
                        console.log("Lookup - ", result.appResult.serviceRepsonse );
                });


                $scope.lookupDropdown = [
                    {name:"Phone Lines", value: "phoneLines"},
                    {name:"User Name", value: "userName"},
                ];

                $scope.lookupSearchResp = function() {
                    return lookupSearch;
                }

                $scope.updateFromLookUp = function( record ) {
                    $scope.phoneNumber = record.phoneNumber;
                    //console.log("$scope.phoneNumber" + $scope.phoneNumber + " &&  record.phoneNumber" + $scope.phoneNumber = record.phoneNumber );

                }

                $scope.addToTextBox = function() {

                    if( $scope.lookupNos.length == 0  ) {
                        alert('There aren\'t any records to be added');
                    }

                    if( $scope.phoneNumber == null  ) {
                        alert("Please select a record");
                    }

                    var lineNumberInput = document.getElementById('lookupNo');
                    angular.element(lineNumberInput).val( processLineFormatting( $scope.phoneNumber ) );
                    $rootScope.forwardToPhoneNumber = processLineFormatting( $scope.phoneNumber );


                    var windowIDs = ngDialog.getOpenDialogs();
                    ngDialog.close(windowIDs[1]);

                }
            }

        });
    }

    $scope.getFunction=function(){
        console.log(document.getElementsByClassName("forward")[0]);
    }

    var availableLinesChosen = [];
    var selectedLinesChosen = [];
    var selectedIndex=[];

    function formatLineNumber( event ) {

        var lineNumberInput = document.getElementById('lookupNo');
        lineNumber = lineNumberInput.value,
        charCode = (event.which) ? event.which : event.keyCode,
        acceptable = [48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 13, 32, 45, 46, 118, 8, 0];

        //restrict non-numeric inputs
        if(acceptable.indexOf(charCode) == -1) {
            lineNumber = lineNumber.replace(/\D/g, '');
        }
        //process formatting
        if(acceptable.indexOf(charCode) < 15) {
            lineNumber = processLineFormatting( lineNumber );
        }

        //assign formatted value back to <input>
        //angular.lineNumberInput( element ).val(lineNumber);
        angular.element( lineNumberInput ).val(lineNumber);

    }


    function processLineFormatting( lineNumber ) {

        lineNumber = lineNumber.replace(/\D/g, '');
        if(lineNumber.length > 2) {
            lineNumber = lineNumber.substring(0,3) + '-' + lineNumber.substring(3);
        }
        if(lineNumber.length > 6) {
            lineNumber = lineNumber.substring(0,7) + '-' + lineNumber.substring(7);
        }

        return lineNumber;

      }

      $scope.formatLineNumber = function(event) {
        formatLineNumber( event );
      }

    $scope.filterFn = function( no, list ) {

        no =  ( no ) ? no.replace(/-/g, "") : no;

        //result = $filter('filter')(list, {code: no})[0];
        //console.log("Result - ", result);
        //console.log("Result - ", list);

        return no;
    }

    $scope.selectAllAvailableLines = function(event) {

        var grid = document.getElementById('availableLinesGrid');
        var isSelectAllChecked = document.getElementById('select-all-available-lines').checked;

        //select all the available lines
        if($scope.availableAll) {
            for (var i = 0; i < angular.element(grid).find('li').length; i++) {
                angular.element(grid).find('li').eq(i).addClass('selected-line');
                availableLinesChosen.push($scope.availableLines[i]);
            };
        } else {
            for (var i = 0; i < angular.element(grid).find('li').length; i++) {
                angular.element(grid).find('li').eq(i).removeClass('selected-line');
                availableLinesChosen = [];
            };
        }

    }

    $scope.onAvailableLinesClick = function(event, index, row) {

        var ele = event.currentTarget;

        //check whether an already chosen line is selected again
        //if so, clear the selection
        //else set selection
        if(angular.element(ele).hasClass('selected-line')) {
            console.log('rem-test'+index)
            angular.element(ele).removeClass('selected-line');
            availableLinesChosen.splice(availableLinesChosen.indexOf(row), 1);

             $scope.availableAll=false;
        } else {

            angular.element(ele).addClass('selected-line');
            //$scope.availableLines[index].lineNumber = $scope.availableLines[index].lineNumber;
            availableLinesChosen.push(row);

            if(availableLinesChosen.length==$scope.availableLines.length) {
                $scope.availableAll=true;
                console.log("select all");
            }


            //clear Select All checkbox selection, if any
            // } else {
            //  angular.element(ele).addClass('selected-line');
            //  availableLinesChosen.push($scope.availableLines[index]);
        }

    }

    $scope.selectAllSelectedLines = function(event) {
        var grid = document.getElementById('selectedLinesGrid');
        var isSelectAllChecked = document.getElementById('select-all-selected-lines').checked;

        //select all the available lines
        if($scope.selectAll) {
            for (var i = 0; i < angular.element(grid).find('li').length; i++) {
                angular.element(grid).find('li').eq(i).addClass('selected-line');
                selectedLinesChosen.push($scope.selectedLines[i]);
            };
        } else {
            for (var i = 0; i < angular.element(grid).find('li').length; i++) {
                angular.element(grid).find('li').eq(i).removeClass('selected-line');
                selectedLinesChosen = [];
            };
        }

    }

    $scope.onSelectedLinesClick = function(event, index, row) {

        var ele = event.currentTarget;

        if(angular.element(ele).hasClass('selected-line')) {
            angular.element(ele).removeClass('selected-line');
            selectedLinesChosen.splice(selectedLinesChosen.indexOf(row), 1);
            $scope.selectAll=false;

        } else {

            angular.element(ele).addClass('selected-line');
            //$scope.selectedLines[index].lineNumber = $scope.selectedLines[index].lineNumber;
            selectedLinesChosen.push(row);
            if(selectedLinesChosen.length==$scope.selectedLines.length)  {
                $scope.selectAll=true;
            }

        }
    }

    $scope.moveUp = function() {

        var parent=document.getElementById('selectedLinesGrid');
        var list=document.getElementById('selectedLinesGrid').children;

        for(var i=0;i<list.length;i++)
        {
               if(list[i].className.search('selected-line')!==-1 && list[i].previousElementSibling!==null )
               {
                    parent.insertBefore(list[i], list[i].previousElementSibling);
                    angular.element(list[i-1]).removeClass('selected-line');
               }
               angular.element(list[i]).removeClass('selected-line');
        }
        selectedLinesChosen=[];
    }

    $scope.moveDown=function()
    {
        var parent=document.getElementById('selectedLinesGrid');
         var list=document.getElementById('selectedLinesGrid').children;
        for(var i=list.length-1;i>=0;i--)
        {
            if(list[i].className.search('selected-line')!==-1 && list[i].nextElementSibling!==null )
            {
                parent.insertBefore(list[i].nextElementSibling, list[i]);
                angular.element(list[i+1]).removeClass('selected-line');
            }

            //angular.element(list[i+1]).removeClass('selected-line');
            angular.element(list[i]).removeClass('selected-line');
        }

        selectedLinesChosen=[];
    }

    $scope.fromAvailableLinesToSelectedLines = function(event) {

        $scope.groupForwardingFrm.$pristine = false;

        //push chosen lines
        for (var i = 0; i < availableLinesChosen.length; i++) {
            $scope.selectedLines.push(availableLinesChosen[i]);

        };
        //after pushing the chosen lines
        //update Available Lines by deleting chosen lines
        for (var i = 0; i < availableLinesChosen.length; i++) {
            $scope.availableLines.splice($scope.availableLines.indexOf(availableLinesChosen[i]), 1);
        };

        availableLinesChosen = [];
        updateLinesCount();

        //clear Select All checkbox selection, if any
        document.getElementById('select-all-available-lines').checked = false;
    }

    $scope.fromSelectedLinesToAvailableLines = function(event) {

        $scope.groupForwardingFrm.$pristine = false;

        //push chosen lines
        for (var i = 0; i < selectedLinesChosen.length; i++) {
            $scope.availableLines.push(selectedLinesChosen[i]);
        };

        //after pushing the chosen lines
        //update Selected Lines by deleting chosen lines
        for (var i = 0; i < selectedLinesChosen.length; i++) {
            $scope.selectedLines.splice($scope.selectedLines.indexOf(selectedLinesChosen[i]), 1);
        };

        selectedLinesChosen = [];
        updateLinesCount();

        //clear Select All checkbox selection, if any
        document.getElementById('select-all-selected-lines').checked = false;
    }

    updateLinesCount = function() {
        $scope.availableLinesCount = $scope.availableLines.length;
        $scope.selectedLinesCount = $scope.selectedLines.length;
    }

    function getData() {

        volteServices.setOption( Constants.API.SCHEDULE.LIST );
        volteServices.getData().success(function( response ){
        	$scope.loadFlag     =  false;
            if( response.appHeader.statusCode == "OK" ) {

                var scheduleList = response.appResult.serviceRepsonse.scheduleList;
                var loop = 0;
                var bzList = [];
                var hoList = [];

                angular.forEach(scheduleList, function(value, key) {

                    if (value.scheduleType.toUpperCase() == 'HOLIDAY') {
                        hoList.push({'name':value.scheduleName, 'value':value.scheduleName});
                    } else {
                        bzList.push({'name':value.scheduleName, 'value':value.scheduleName});
                    }

                    loop++;

                });

                $scope.biz_schedule = bzList;
                $scope.holiday_schedule = hoList;

              //   if ($scope.biz_schedule.length !=0)
              //     {
              //     $scope.Always =  false;
              //      // $scope.predefined = true;
              //       }
              //     else
              //     {

              //     $scope.Always =  true;
              //     // $scope.predefined = false;
              // }

                //start watching groupforwarding
                watchGroupForwardStatus();

            }

        }).error(function() {});

    }

    function init() {

        $scope.isActive             = false;
        $scope.availableAll         =  false;
        $scope.selectAll            =  false;

        $scope.Always =  true;
        $scope.predefined =  false;

        $scope.loadFlag     =  true;
       //$scope.forwardToPhoneNumber =  "";

        $scope.biz_schedule         = GroupForwardingConst.BIZ_SCHEDULE;
        $scope.biz_schedule_selected = "";

        $scope.holiday_schedule     = GroupForwardingConst.HOLIDAY_SCHEDULE;
        $scope.holiday_schedule_selected = "";
        $scope.selectedradio        =     "true";

        $scope.availableLinesTemplate = "partials/features/vz-grid/vz.grid.hunt-group-available-lines.html";

        //Initialize Variables
        $scope.availableLines = [];
        $scope.availableLinesCount = 0;

        $scope.selectedLines = [];
        $scope.selectedLinesCount = 0;


        $scope.lookupSearch = "";

        //Load schedule list dropdowns
        getData();

        $scope.lookupNo = "";

        groupForwardingService.groupForwardingValues()
           .success(function (result) {

                if( result.appHeader.statusCode == "OK")  {

                   var successResponse=result.appResult.serviceRepsonse;

                   //console.log(result);
                   if(!successResponse.businessHours && !successResponse.businessHours)
                   {
                     $scope.Always=true;
                   }
                   else
                   {
                     $scope.Always=false;
                   }
                   if (successResponse.businessHours != undefined)
                        $scope.biz_schedule_selected = successResponse.businessHours.name;

                   if (successResponse.holidaySchedule != undefined)
                        $scope.holiday_schedule_selected = successResponse.holidaySchedule.name;

                   if (successResponse.forwardToPhoneNumber != undefined && successResponse.forwardToPhoneNumber != "null")
                        $scope.forwardToPhoneNumber = successResponse.forwardToPhoneNumber;

                   if(successResponse.selectedLines != undefined) {
                        selectedTemp = JSON.stringify(successResponse.selectedLines);
                        $scope.selectedLines = successResponse.selectedLines || [];
                    }

                    $scope.availableLines = successResponse.availableLines || [];
                    availableTemp = JSON.stringify(successResponse.availableLines);

                   $scope.models =
                    {
                        selected: null,
                        lists:
                        {
                            "availableLine": $scope.availableLines,
                            "selectedLines": $scope.selectedLines
                        }
                    };

                    $scope.nightForwardingStatus = successResponse.nightForwardingStatus;

                    if($scope.nightForwardingStatus.toUpperCase() == 'ON'){
                        $scope.nightForwardingStatus = true;
                    } else {
                        $scope.nightForwardingStatus = false;
                    }
                }

            });

    }

    init();
    $scope.pageTitle = groupForwardingConst.pageTitle;
    $scope.pageTitle_Desc = groupForwardingConst.pageTitle_Desc;
    $scope.instructions = groupForwardingConst.instructions;
};

nightForwardingCtrl.$inject = ["$scope", "ngDialog", "GroupForwardingConst", "Config","groupForwardingService", "groupForwardingConst","volteServices","Constants", "$document"];
angular.module( window.AppName ).controller("nightForwardingCtrl", nightForwardingCtrl);
