var automatedReceptionsitCtrl = function($scope,$rootScope,$state,ngDialog,autoAttendantConst,HuntGroupConst,autoAttendantService,volteServices,cache,Constants, $http, $window){
    scope = $scope;
    $scope.gotoEpam = function(reasonTxt) {
    	var lineNumber = $scope.phoneNumber;
    	lineNumber = lineNumber.substr(0, 3) + "-" + lineNumber.substr(3, 3) + "-" + lineNumber.substr(6);
    	var params = {
			actionSelected: reasonTxt,
			line: lineNumber
		};

    	$http({
            url: Constants.API.LINES_PAGE.EPAM_PROCESS_ACTIONS,
            method: "POST",
            data: params,
            crossDomain: true,
            withCredentials: true,
            headers: {
                'Content-type': 'application/json'
            }
        }).success(function(response, status, headers, config) {
        	if (!response.errorStatus) {
        		$http({
                    url: Constants.API.LINES_PAGE.SELECT_STRING,
                    method: "POST",
                    data: params,
                    crossDomain: true,
                    withCredentials: true,
                    headers: {
                        'Content-type': 'application/json'
                    }
                }).success(function(response, status, headers, config) {
                	if (!response.errorStatus) {
						//$window.location.href = response.redirectUrl;

                        // Redirect with back URL
                        var currentUrlPath = window.location.href;
                        var redirectUrlPath = response.redirectUrl;
                        $window.location.href = redirectUrlWithReturnURL(redirectUrlPath, currentUrlPath, Constants.API.REDIRECT_URL_PATHS.split_At);

					} else {
						errorHandler(response.errorMessage);
					}
                }).error(function(response, status, headers, config) {
                    errorHandler();
                });
			} else {
				errorHandler(response.errorMessage);
			}
        }).error(function(response, status, headers, config) {
            errorHandler();
        });

		function errorHandler(errorMessage) {
			if (typeof errorMessage !== 'string') {
				errorMessage = undefined;
			}
			$scope.msgTxt = errorMessage || 'Unable to perform the transaction';
			$scope.msgType = 'error';
			$scope.showStatusMsg = true;
            $scope.thankuTxt = null;
		}
    };
    $scope.toggleTab = function() {
        $scope.tab = !$scope.tab;
    }

    $scope.showBusinessSection = function(){
       var returnFlag = true;

    if($scope.businessTab){
        returnFlag = true;
    }
    if($scope.holidayTab){
        returnFlag = false;
    }

    return returnFlag;
   }

    $scope.displayFirstTab = function() {

        if( $scope.tab == true ) {
            return "vz-show";
        } else {
            return "vz-hide";
        }
    }

    $scope.displaySecondTab = function() {

        //initiateErrorMsgs();
        if( $scope.tab != true ) {
            return "vz-show";
        } else {
            return "vz-hide";
        }
    }

    $scope.activateFirstTab = function( index ) {

        if( $scope.tab == true ) {
            return "selected";
        } else {
            return "";
        }
    }

    $scope.activateSecondTab = function( index ) {
        if( $scope.tab == false ) {
            return "selected";
        } else {
            return "";
        }
    }

    function getEPAMLinkForDetails() {

        //var TokenGoBackURL   =   encodeURIComponent( window.location.href );
        var HREFArr          = window.location.href.split("#");
        var TokenGoBackURL   = HREFArr[0] + "#/features/enterprise/auto-attendant-detail/" + $state.params.lineNumber;
            TokenGoBackURL   = encodeURIComponent( TokenGoBackURL );
        var TokenLineNumber  = $state.params.lineNumber;

        $scope.EPAMLink      =  $rootScope.EPAMLink.replace("TokenGoBackURL",  TokenGoBackURL);
        $scope.EPAMLink      = $scope.EPAMLink.replace("TokenLineNumber", TokenLineNumber);

        // Redirect with back URL
        var currentUrlPath = window.location.href;
        var redirectUrlPath = $scope.EPAMLink;
        $scope.EPAMLink = redirectUrlWithReturnURL(redirectUrlPath, currentUrlPath, Constants.API.REDIRECT_URL_PATHS.split_At);

    }

    function getEPAMLinkForSetup() {

        //var TokenGoBackURL   =   encodeURIComponent( window.location.href );
        var HREFArr          = window.location.href.split("#");
        var TokenGoBackURL   = HREFArr[0] + "#/features/enterprise/auto-attendant-setup";
            TokenGoBackURL   = encodeURIComponent( TokenGoBackURL );
        var TokenLineNumber  = $scope.phoneNumber;

        //console.log("Go Back URL = " + TokenGoBackURL + " &&  Root Scope = " + $rootScope.EPAMLink );

        $scope.EPAMLink      =  $rootScope.EPAMLink.replace("TokenGoBackURL",  TokenGoBackURL);
        $scope.EPAMLink      = $scope.EPAMLink.replace("TokenLineNumber", TokenLineNumber);

        // Redirect with back URL
        var currentUrlPath = window.location.href;
        var redirectUrlPath = $scope.EPAMLink;
        $scope.EPAMLink = redirectUrlWithReturnURL(redirectUrlPath, currentUrlPath, Constants.API.REDIRECT_URL_PATHS.split_At);

    }


    var getList = function() {
        //console.log('inside getList');
        autoAttendantService.getList()
            .success(function (result) {
                if( result.appHeader.statusCode == "OK")  {
                    $scope.attendants = result.appResult.serviceRepsonse.autoAttendantList;
                    console.log($state.current.data.successTxt);
                    if($state.current.data.successTxt !== 'thankuTxt')
                    {
                      $scope.msgType = null;
                      $scope.thankuTxt=null;
                      $scope.msgTxt = null;
                      $scope.showMsg = false;
                    }
                    else
                    {
                      $scope.msgType = "success";
                      $scope.thankuTxt="Thank You";
                      $scope.msgTxt = "You have successfully submitted your Automated Receptionist request.";
                      $scope.showMsg = true;
                      $state.current.data.successTxt = null;
                    }
                } else {
                    $scope.attendants = [];
                }
            })
            .error(function (error) {
                $scope.status = 'Unable to load data: ' + error.message;
            });

    }

    var getInfo = function() {

        $scope.phoneNumber = $state.params.lineNumber;
        cache.put('auto-attendant-line', $scope.phoneNumber);

        /*var info = cache.get('auto-attendant-info-'+$scope.phoneNumber);
        if (info == undefined) {*/
            var reqObj = {"phoneNumber": $scope.phoneNumber};
            autoAttendantService.getInfo(reqObj)
                .success(function (result) {

                    if( result.appHeader.statusCode == "OK")  {

                        console.log("Result - " + JSON.stringify(result.appResult.serviceRepsonse.afterHoursMenu) );

                        $scope.getInfoResponse = result.appResult.serviceRepsonse;
                        cache.put('auto-attendant-info-'+$scope.phoneNumber, $scope.getInfoResponse);
                        $scope.timeZoneName = getTimeZone($scope.getInfoResponse.timeZone, 'name');
                    } else {
                        $scope.getInfoResponse = [];
                    }
                })
                .error(function (error) {
                    $scope.status = 'Unable to load data: ' + error.message;
                });
        /*} else {
            $scope.getInfoResponse = info;
        }*/
    }
/*
    $scope.purchaseAutoAttendant = function() {

    	//window.location = $rootScope.autoAttendantUrl;

        var getHostDetailsArr =    [];
        var subdomain         =    null;

        getHostDetailsArr     =    getHostDetails();
        console.log("getHostDetailsArr" ,getHostDetailsArr );

        console.log("Total parts in the host URL..." , getHostDetailsArr.length);

        // Production Env. where HOSTNAME is v4b.verizonwireless.com
        if(3 == getHostDetailsArr.length){
        	window.location = 'https://b2b.verizonwireless.com/b2b/commerce/amsecure/index.go?ssPath=AA';
        }else{
        	subdomain  =    getHostDetailsArr[0].slice(3);
            console.log("subdomain" , subdomain);
            if( subdomain ) {
                window.location = 'https://b2b' + subdomain + '.sdc.vzwcorp.com/b2b/commerce/amsecure/index.go?ssPath=AA';
            } else {
                $scope.msgType = "error";
                $scope.msgTxt  = "Unable to redirect! Please contact Administrator";
                $scope.showMsg = true;
            }
        }

    }
*/
    $scope.purchaseAutoAttendant = function() {
        var currentUrlPath = window.location.href;
        var appendPath = Constants.API.REDIRECT_URL_PATHS.commerce + '?' + Constants.API.REDIRECT_URL_PATHS.paramAA;
        var redirectUrlPath = prepareRedirectUrlPath(Constants.API.REDIRECT_URL_PATHS.prod, Constants.API.REDIRECT_URL_PATHS.dev, appendPath, true);
        window.location = redirectUrlWithReturnURL(redirectUrlPath, currentUrlPath, Constants.API.REDIRECT_URL_PATHS.split_At);
    }
/*
    $scope.purchaseHuntGroup = function() {

    	//window.location = $rootScope.huntGroupUrl;

        var getHostDetailsArr =    [];
        var subdomain         =    null;

        getHostDetailsArr     =    getHostDetails();
        console.log("getHostDetailsArr" ,getHostDetailsArr );

        console.log("Total parts in the host URL..." , getHostDetailsArr.length);

        // Production Env. where HOSTNAME is v4b.verizonwireless.com
        if(3 == getHostDetailsArr.length){
        	window.location = 'https://b2b.verizonwireless.com/b2b/commerce/amsecure/index.go?ssPath=HG';
        }else{
        	subdomain  =    getHostDetailsArr[0].slice(3);
            console.log("subdomain" , subdomain);
            if( subdomain ) {
                window.location = 'https://b2b' + subdomain + '.sdc.vzwcorp.com/b2b/commerce/amsecure/index.go?ssPath=HG';
            } else {
                $scope.msgType = "error";
                $scope.msgTxt  = "Unable to redirect! Please contact Administrator";
                $scope.showMsg = true;
            }
        }

    }
*/
    $scope.purchaseHuntGroup = function() {
        var currentUrlPath = window.location.href;
        var appendPath = Constants.API.REDIRECT_URL_PATHS.commerce + '?' + Constants.API.REDIRECT_URL_PATHS.paramHG;
        var redirectUrlPath = prepareRedirectUrlPath(Constants.API.REDIRECT_URL_PATHS.prod, Constants.API.REDIRECT_URL_PATHS.dev, appendPath, true);
        window.location = redirectUrlWithReturnURL(redirectUrlPath, currentUrlPath, Constants.API.REDIRECT_URL_PATHS.split_At);
    }

    scope.setFiles = function(element, fileOpt) {
        var doSetFiles = function() {
            if (element.files[0].size / 1024 <= Constants.MAX_FILE_SIZE.AUTO_ATTENDANT_GREETING) {
                for (var i = 0; i < element.files.length; i++) {
                    scope.files[ fileOpt ].push(element.files[i]);
                    $scope.theFile[ fileOpt ].name = element.files[i].name;
                    if (fileOpt == 'business') {
                        $scope.businessSrc = URL.createObjectURL(element.files[i]);
                    } else {
                        $scope.holidaySrc = URL.createObjectURL(element.files[i]);
                    }
                }

                scope.progressVisible = false;
                $scope.isValid = true;
                $scope.showMsg = false;

                //Enable the submit btn
                $scope.autoAttendantForm.$pristine = false;
            } else {
                $scope.thankuTxt = null;
                $scope.msgType = "error";
                $scope.msgTxt = "The audio file you have uploaded is too large for us to process.  Please reduce the file size to 2MB or less and try again.";
                $scope.showMsg = true;
                $scope.customForm.$setPristine();
            }
        };


        var fileStr=element.files[0].type.split("/");
        if(fileStr[fileStr.length-1].search("wav")!==-1||fileStr[fileStr.length-1].search("wma")!==-1)
        {
            if ($scope.$$phase) {
                doSetFiles();
            } else {
                $scope.$apply(function() {
                    doSetFiles();
                });
            }
        } else {
            scope.$apply(function(scope) {
                $scope.fileOpt = fileOpt;
                $scope.thankuTxt = null;
                $scope.msgType = "error";
                $scope.msgTxt = "Please choose a file with WAV or WMA extension only";
                $scope.showMsg = true;
                $scope.autoAttendantForm.$pristine = true;
                $scope.theFile.name = null;
             });
        }
    }

    $scope.updateInfo = function() {
        $rootScope.vzSubmitBtnStatus = false;
        cache.put('auto-attendant-info-'+$scope.phoneNumber, $scope.getInfoResponse);
        $state.go('features.enterprise.auto_attendant_setup');
    }

    $scope.goBackToManage = function() {

        var redirectionLink =   "features.enterprise.auto_attendant";
        $state.go( redirectionLink, {}, { reload: true });

    }

    var loadSetup = function() {

        $scope.biz_schedule = cache.get('bz-schedule-list');
        $scope.holiday_schedule = cache.get('holiday-schedule-list');
        $scope.phoneNumber = cache.get('auto-attendant-line');
        if($scope.phoneNumber == undefined) {
            $state.go('features.enterprise.auto_attendant');
        }

        $scope.getInfoResponse = cache.get('auto-attendant-info-'+$scope.phoneNumber);

        $scope.selectedKeyConfig = {"1": "", "2": "", "3":"", "4": "", "5":"", "6":"", "7":"", "8":"", "9":"", "0":"", "*":"", "#":""};
        $scope.selectedTransferConfig = {"1": "", "2": "", "3":"", "4": "", "5":"", "6":"", "7":"", "8":"", "9":"", "0":"", "*":"", "#":""};
        $scope.holidayKeyConfig = {"1": "", "2": "", "3":"", "4": "", "5":"", "6":"", "7":"", "8":"", "9":"", "0":"", "*":"", "#":""};
        $scope.holidayTransferConfig = {"1": "", "2": "", "3":"", "4": "", "5":"", "6":"", "7":"", "8":"", "9":"", "0":"", "*":"", "#":""};

        //console.log(" Data -- " + JSON.stringify($scope.getInfoResponse.) );

        //$scope.businessAudioTitle = $scope.getInfoResponse.businessHoursMenu.audioFileInfo.fileName;

        var arr = [];
        if ($scope.getInfoResponse.businessHoursMenu != undefined)
        {
           $scope.bizAudioSelection=$scope.getInfoResponse.businessHoursMenu.announcementSelection;
            angular.forEach($scope.getInfoResponse.businessHoursMenu.keyConfigurations, function (row) {

                console.log("Row - " + JSON.stringify( row ) );

                arr[row.key] = row.entry;
                $scope.selectedKeyConfig[row.key] = row.entry.keyAction;
                if (row.entry.phoneNumber!=undefined) {
                    $scope.selectedTransferConfig[row.key] = row.entry.phoneNumber;
                }
            });
             console.log(arr);
        }

        $scope.gridData = {'routingOptions':$scope.routingOptions, 'keyTemp':arr};

        arr = [];
        if ($scope.getInfoResponse.afterHoursMenu != undefined)
        {
          $scope.holidayAudioSelection=$scope.getInfoResponse.afterHoursMenu.announcementSelection;
          angular.forEach($scope.getInfoResponse.afterHoursMenu.keyConfigurations, function (row) {
            arr[row.key] = row.entry;
            $scope.holidayKeyConfig[row.key] = row.entry.keyAction;
            if (row.entry.phoneNumber!=undefined) {
                $scope.holidayTransferConfig[row.key] = row.entry.phoneNumber;
            }
          });
          console.log(arr);
        }

        $scope.sameAsBusiness = cache.get('same-as-business');

        $scope.hgridData = {'routingOptions':$scope.routingOptions, 'keyTemp':arr};

    }

    function getScheduleData() {
        volteServices.setOption( Constants.API.SCHEDULE.LIST );
        volteServices.getData().success(function( response ){
            $scope.loadFlag     =  false;
            if( response.appHeader.statusCode == "OK")  {
                var scheduleList = response.appResult.serviceRepsonse.scheduleList;
                var bzList = [];
                var hoList = [];
                angular.forEach(scheduleList, function(value, key) {
                    if (value.scheduleType == 'HOLIDAY') {
                        hoList.push({'name':value.scheduleName, 'value':value.scheduleName});
                    } else {
                        bzList.push({'name':value.scheduleName, 'value':value.scheduleName});
                    }
                });
                cache.put('bz-schedule-list', bzList);
                cache.put('holiday-schedule-list', hoList);
            }
        }).error(function() {});
    }

    function saveFormData() {
        cache.put("auto-attendant-setup-files", scope.files);
        //console.log("Files - ", scope.files);
    }

    $scope.navigateToReview = function() {

        $scope.getInfoResponse.businessHoursMenu = {};
        $scope.getInfoResponse.afterHoursMenu = {};
        $scope.getInfoResponse.businessHoursMenu.keyConfigurations = [];
        $scope.getInfoResponse.afterHoursMenu.keyConfigurations = [];

        var tempArr = [];
        angular.forEach($scope.selectedKeyConfig, function (eachValue, eachKey) {
            if(eachValue != "") {
                if ($scope.selectedTransferConfig[eachKey]!="") {
                    tempArr.push({"key":eachKey, "entry":{ "keyAction":eachValue, "phoneNumber":$scope.selectedTransferConfig[eachKey]}});
                } else {
                    tempArr.push({"key":eachKey, "entry":{ "keyAction":eachValue}});
                }
            }
        });
        $scope.getInfoResponse.businessHoursMenu.keyConfigurations = tempArr;

        if (!$scope.sameAsBusiness) {
            tempArr = [];
            angular.forEach($scope.holidayKeyConfig, function (eachValue, eachKey) {
                if(eachValue != "") {
                    if ($scope.holidayTransferConfig[eachKey]!="") {
                        tempArr.push({"key":eachKey, "entry":{ "keyAction":eachValue, "phoneNumber":$scope.holidayTransferConfig[eachKey]}});
                    } else {
                        tempArr.push({"key":eachKey, "entry":{ "keyAction":eachValue}});
                    }
                }
            });
            $scope.getInfoResponse.afterHoursMenu.keyConfigurations = tempArr;
        } else {
            $scope.getInfoResponse.afterHoursMenu.keyConfigurations = $scope.getInfoResponse.businessHoursMenu.keyConfigurations;
        }
        $scope.getInfoResponse.businessHoursMenu.announcementSelection = $scope.holidayAudioSelection;
        $scope.getInfoResponse.afterHoursMenu.announcementSelection = $scope.bizAudioSelection;

        cache.put('same-as-business', $scope.sameAsBusiness);

        cache.put('auto-attendant-info-'+$scope.phoneNumber, $scope.getInfoResponse);

        saveFormData();

        $state.go('features.enterprise.auto_attendant_review');

    }

    $scope.changeTab = function() {
        // Appropriate flags are modified to display second tab for After Hours & Holidays
        // Refer HTML code for second tab
        $scope.showMsg = false;
        $scope.businessTab=false;
        $scope.holidayTab=true;
        $scope.tab = false;
    }

    var loadReview = function() {

        scope.files = cache.get("auto-attendant-setup-files");

        //Nullify the memory
        cache.put("auto-attendant-setup-files", null)

        //console.log("Data - ", scope.files );

        $scope.phoneNumber = cache.get('auto-attendant-line');
        if($scope.phoneNumber == undefined) {
            $state.go('features.enterprise.auto_attendant');
        }
        $scope.getInfoResponse = cache.get('auto-attendant-info-'+$scope.phoneNumber);
        $scope.timeZoneName = getTimeZone($scope.getInfoResponse.timeZone, 'name');
        if (scope.files['business'].length!=0) {
            $scope.getInfoResponse.businessHoursMenu.announcementSelection = 'CUSTOM';
            $scope.fileNameReview = scope.files['business'][0].name;
        }
        if (scope.files['holiday'].length!=0) {
            $scope.holidayfileNameReview = scope.files['holiday'][0].name;
        }
        var arr = [];
        angular.forEach($scope.getInfoResponse.businessHoursMenu.keyConfigurations, function (row) {
            arr[row.key] = row.entry;
        });
        $scope.businessGridData = {'routingOptions':$scope.routingOptions, 'keyTemp':arr};
        arr = [];
        angular.forEach($scope.getInfoResponse.afterHoursMenu.keyConfigurations, function (row) {
            arr[row.key] = row.entry;
        });
        $scope.holidayGridData = {'routingOptions':$scope.routingOptions, 'keyTemp':arr};
    }

    function modifyWithFile() {

        var fd = new FormData()

        //console.log(scope.files["holiday"]);
        //console.log(scope.files["business"]);

        var businessAudioFile = null;
        var holidayAudioFile = null;
        for (var i in scope.files["holiday"]) {
            $scope.getInfoResponse.afterHoursMenu.announcementSelection = 'CUSTOM';
            holidayAudioFile = scope.files["holiday"][i];
        }

        for (var i in scope.files["business"]) {
            $scope.getInfoResponse.businessHoursMenu.announcementSelection = 'CUSTOM';
            businessAudioFile = scope.files["business"][i];
        }
        delete $scope.getInfoResponse.errorCode;
        delete $scope.getInfoResponse.message;
        delete $scope.getInfoResponse.referenceId;

        //console.log(JSON.stringify({"autoAttendantname":$scope.getInfoResponse.autoAttendantname,"callingLineIdName":$scope.getInfoResponse.callingLineIdName,"timeZone":"America/New_York", "businessScheduleName":$scope.getInfoResponse.businessScheduleName,"holidayScheduleName":$scope.getInfoResponse.holidayScheduleName, "afterHoursMenu":$scope.getInfoResponse.afterHoursMenu, "businessHoursMenu":$scope.getInfoResponse.businessHoursMenu,"active":false}));
        var restructureJSON = JSON.stringify({"autoAttendantname":$scope.getInfoResponse.autoAttendantname,"phoneNumber":$scope.phoneNumber,"callingLineIdName":$scope.getInfoResponse.callingLineIdName,"timeZone":"America/New_York", "businessScheduleName":$scope.getInfoResponse.businessScheduleName,"holidayScheduleName":$scope.getInfoResponse.holidayScheduleName, "afterHoursMenu":$scope.getInfoResponse.afterHoursMenu, "businessHoursMenu":$scope.getInfoResponse.businessHoursMenu,"active":false});
        //fd.append('modifyAutoAttendantRequest', encodeURIComponent( JSON.stringify({"autoAttendantname":$scope.getInfoResponse.autoAttendantname,"callingLineIdName":$scope.getInfoResponse.callingLineIdName,"phoneNumber":$scope.phoneNumber, "timeZone":$scope.getInfoResponse.timeZone, "businessScheduleName":$scope.getInfoResponse.businessScheduleName,"holidayScheduleName":$scope.getInfoResponse.holidayScheduleName, "afterHoursMenu":$scope.getInfoResponse.afterHoursMenu, "businessHoursMenu":$scope.getInfoResponse.businessHoursMenu,"active":false}) ));
        fd.append('modifyAutoAttendantRequest', encodeURIComponent( restructureJSON.replace(/"transferTo":/g, '"phoneNumber":')  ));

        console.log("gng to upload");
        if (businessAudioFile != null) {
            console.log("File 1");
            fd.append('multiPartFileBusiness', businessAudioFile);
        }

        console.log("File 2");

        if (holidayAudioFile != null) {
            console.log("File 3");
            fd.append('multiPartFileAfterHours', holidayAudioFile);
        }

        //'multipart/form-data'
        $rootScope.ajaxLoading = true;

        var xhr = new XMLHttpRequest();
        //xhr.upload.addEventListener("progress", uploadProgress, false)
        xhr.addEventListener("load", angular.bind(null, uploadProgress), false)
        //xhr.addEventListener("error", uploadFailed, false)
        //xhr.addEventListener("abort", uploadCanceled, false)
        window.addEventListener('error', angular.bind(null,uploadError), true);
        xhr.addEventListener("abort", angular.bind(null, uploadCanceled), false);
        xhr.open("POST", Constants.API_HOST + Constants.API.AUTO_ATTENDANT.MODIFY );
        //xhr.setRequestHeader("Content-type", "multipart/form-data");
        scope.progressVisible = true;
        xhr.setRequestHeader("X-XSRF-TOKEN", _.last(String(document.cookie.match(/XSRF-Token=([^\s;]*);/gi)).split(';')[0].split('=')));
        xhr.send(fd);

    }

    $scope.submitReview = function() {
        $scope.phoneNumber = cache.get('auto-attendant-line');

        if ( scope.files['business'].length!=0 || scope.files['holiday'].length!=0 ) {
            modifyWithFile();
        } else {
            console.log($scope.getInfoResponse.afterHoursMenu);

            var param = $scope.getInfoResponse;

            delete param.errorCode;
            delete param.message;
            delete param.referenceId;

            param.afterHoursMenu    = $scope.getInfoResponse.afterHoursMenu;
            param.businessHoursMenu = $scope.getInfoResponse.afterHoursMenu;

            var getInfoResponse       = JSON.stringify( $scope.getInfoResponse );
            getInfoResponse           = getInfoResponse.replace(/"transferTo":/g, '"phoneNumber":');
            $scope.getInfoResponse    = JSON.parse( getInfoResponse );

            $scope.getInfoResponse.phoneNumber = $scope.phoneNumber;

            autoAttendantService.modifyWithoutFile( $scope.getInfoResponse )
                .success(function (result) {
                    try {
                        if(result.appHeader.statusCode == "OK") {
                            $state.get('features.enterprise.auto_attendant').data.successTxt = 'thankuTxt';
                            $state.go('features.enterprise.auto_attendant', {obj:'thankuTxt'},{reload:true});
                            // console.log($scope.getInfoResponse);
                            // $scope.msgType = "success";
                            // $scope.thankuTxt="Thank You";
                            // $scope.msgTxt = "You have successfully submitted the request for updating automated receptionist.";
                            // $scope.showMsg = true;
                        } else {
                            $scope.thankuTxt = null;
                            $scope.msgType = "error";
                            $scope.msgTxt = result.appHeader.statusMessage;
                            $scope.showMsg = true;
                        }
                    } catch(err) {
                        //console.log("Failure - "+err.message);
                    }
                })
                .error(function (error) {
                    $scope.status = 'Unable to load data: ' + error.message;
                });
        }
    }

    function uploadError(evt) {

        /*$scope.$apply(function(){
            $rootScope.ajaxLoading = false;
            error( "Upload Failed!" );
        });*/

    }

    function uploadProgress(evt) {

        $scope.$apply(function() {

            //Close the dialog loader
            $rootScope.ajaxLoading = false;

            try {

                var xhrSatus = parseInt( evt.target.status );

                //Check the status of the target
                if( xhrSatus == 200 || xhrSatus == 302 ) {

                    var result = JSON.parse( evt.target.response );

                    //console.log(JSON.stringify(result));

                    if( result.appHeader.statusCode == "OK" || result.appResult.serviceRepsonse.errorCode == "0" || result.appResult.serviceRepsonse.errorCode == "00" ){

                        success();

                        //Keep the submit button in disabled mode
                        //$scope.autoAttendantForm.$pristine = true;

                    } else {

                        //Incase if service is down then display the error message

                        var msg = ( typeof(result.appResult.serviceRepsonse.message) !='' ) ? result.appResult.serviceRepsonse.message : "Upload Failed";
                        error( msg );

                        //Enable the submit button
                        //$scope.autoAttendantForm.$pristine = false;

                     }

                }   else {

                    //Incase if any error occured like 404 or 500 then display the error message

                    //Enable the submit button
                    //$scope.autoAttendantForm.$pristine = false;

                    error( "Upload Failed!" );

                }

            } catch( err ) {

                //Incase if any error occured in JS Response then we display the error response
                //console.log("Error -  ", err );

                //Enable the submit button
                //$scope.autoAttendantForm.$pristine = false;

                error( "Upload Failed!" );

            }

        });



    }

    function error( msg ) {

        msg = msg || "Updation Failed!";
        scope.thankuTxt = null;
        scope.msgType = "error";
        scope.msgTxt = msg;
        scope.showMsg = true;

    }

    function success() {

        $scope.msgType  =   "success";
        $scope.thankuTxt=   "Thank You";
        $scope.msgTxt   =   "You have successfully submitted the request for updating automated receptionist.";
        $scope.showMsg  =   true;

        $scope.autoAttendantForm.$pristine = !$scope.autoAttendantForm.$pristine;

    }

    function uploadCanceled(evt) {

        var result = JSON.parse( evt.target.response );

        $scope.$apply(function(){
            $rootScope.ajaxLoading = false;
            var msg = "Unable to process request";
            error( msg );
        })
    }

    function uploadComplete( evt, $rootScope ) {
        $rootScope.ajaxLoading = false;
    }

    $scope.updateLookUpNo = function( no ) {
        $scope.lookupNo = no;
        document.getElementById("lookupNo").value = no;
    }

    $scope.submit = function() {
        var params = {};
        params.useUserPhoneNumber = true;
        params.isBlockCallingNameForExternalCalls = false;
        params.callingLineIdName = "Line1";
        params.callingLineIdPhoneNumber = "89899";

        callingPlanServices.setOption( API.MODIFY );
        callingPlanServices.postData( params )
        .success(function (result) {
        });
    }

    $scope.closeDialog = function() {

        try {

            // document.getElementById("lookupNo").value = no;
            var windowIDs = ngDialog.getOpenDialogs();

            //console.log(windowIDs);
            ngDialog.close(windowIDs[1]);

        } catch(err) {}

    }

    $scope.lookupDialog = function(key, configType) {

        var new_dialog = ngDialog.open({ template: 'partials/components/dialog/lookupNightForwarding.html',

           className: 'ngDialog-theme-vz',
           closeByDocument: false,
           closeByEscape: false,
           scope: $scope,
           controller: function($scope) {

                $scope.phoneNumber = null;
                $scope.lookupSearch = '';

                volteServices.setOption( Constants.API.COMMON.LINE_LOOKUP );
                volteServices.getData()
                    .success(function (result) {
                        $scope.loadFlag     =  false;
                        $scope.lookupNos = result.appResult.serviceRepsonse.lineInfoList;
                        console.log("Lookup - ", result.appResult.serviceRepsonse );
                });


                $scope.lookupDropdown = [
                    {name:"Phone Lines", value: "phoneLines"},
                    {name:"User Name", value: "userName"},
                ];

                $scope.lookupSearchResp = function() {
                    return lookupSearch;
                }

                $scope.updateFromLookUp = function( record ) {
                    $scope.phoneNumber = record.phoneNumber;
                    //console.log("$scope.phoneNumber" + $scope.phoneNumber + " &&  record.phoneNumber" + $scope.phoneNumber = record.phoneNumber );

                }

                $scope.addToTextBox = function() {

                    if( $scope.lookupNos.length == 0  ) {
                        alert('There aren\'t any records to be added');
                    }

                    if( $scope.phoneNumber == null  ) {
                        alert("Please select a record");
                    }
                    if (configType == 'business') {
                        $scope.selectedTransferConfig[key] = $scope.phoneNumber;
                    } else {
                        $scope.holidayTransferConfig[key] = $scope.phoneNumber;
                    }
                    var windowIDs = ngDialog.getOpenDialogs();
                    ngDialog.close(windowIDs[1]);
                }
            }
        });
    }

    $scope.vzSubmitBtnStatusFn = function( decision ) {
        $rootScope.vzSubmitBtnStatus = !decision;
        return decision;
    }

    $scope.ngEnableSubmit = function() {
        if( (typeof($scope.getInfoResponse.autoAttendantname) != 'undefined' && $scope.getInfoResponse.autoAttendantname != '')
            && (typeof($scope.getInfoResponse.callingLineIdName) != 'undefined' && $scope.getInfoResponse.callingLineIdName != '')
            && (typeof($scope.getInfoResponse.timeZone) != 'undefined' && $scope.getInfoResponse.timeZone!='Select') ) {
            $scope.modelModified = true;
        } else {
            $scope.modelModified = false;
        }

    }

  $scope.formatLineNumber = function(event) {

        var lineNumberInput = document.getElementById('lookupNo');
        lineNumber = lineNumberInput.value,
        charCode = (event.which) ? event.which : event.keyCode,
        acceptable = [48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 13, 32, 45, 46, 118, 8, 0];

        //restrict non-numeric inputs
        if(acceptable.indexOf(charCode) == -1) {
            lineNumber = lineNumber.replace(/\D/g, '');
        }
        //process formatting
        if(acceptable.indexOf(charCode) < 15) {
            lineNumber = lineNumber.replace(/\D/g, '');
            if(lineNumber.length > 2) {
                lineNumber = lineNumber.substring(0,3) + '-' + lineNumber.substring(3);
            }
            if(lineNumber.length > 6) {
                lineNumber = lineNumber.substring(0,7) + '-' + lineNumber.substring(7);
            }
        }
        //assign formatted value back to <input>
        angular.element(lineNumberInput).val(lineNumber);

  }

  function getLookUpInfo() {

    callingPlanServices.setOption( API.LINE_LOOKUP );
    callingPlanServices.fetchData()
        .success(function (result) {
             console.log("Result - ", result);
        })
        .error(function (error) {
            $scope.status = 'Unable to load data: ' + error.message;
        });

  }

    $scope.onUploadBusiness = function (event) {
        event.preventDefault();
        document.getElementById('fileToUpload1').click();
    }

    $scope.onUploadHoliday = function (event) {
        event.preventDefault();
        document.getElementById('fileToUpload2').click();
    }

    $scope.play=function(type){
        if (type == 'business') {
            document.getElementById('audio_player_business').play();
            $scope.isStreamingBusiness=true;
        } else {
            document.getElementById('audio_player_holiday').play();
            $scope.isStreamingHoliday=true;
        }
    }

    $scope.pause=function(type){
        if (type == 'business') {
            document.getElementById('audio_player_business').pause();
            $scope.isStreamingBusiness=false;
        } else {
            document.getElementById('audio_player_holiday').pause();
            $scope.isStreamingHoliday=false;
        }
    }

    var getTimeZone = function(timeZone, keyType) {
        var result = timeZone;
        angular.forEach($scope.time_zone, function (row) {
            if (keyType == 'name') {
                if (timeZone == row.value) result = row.name;
            } else {
                if (timeZone == row.name) result = row.value;
            }
        });
        return result;
    }
    $scope.setCustomFile=function(){
        console.log('inside custom')
        var new_dialog = ngDialog.open({
                            template: 'partials/components/dialog/instructionsLink.html',
                            closeByDocument: false,
                            className: 'ngdialog-theme-default selective-call-rejection-dialog',
                            closeByEscape: false,
                            scope: $scope,
                            controller:'instructionsLinkCtrl'
                        });
    }
    function init() {

        $scope.loadFlag     =  true;
        $scope.fileSizeLimit = parseInt(Constants.MAX_FILE_SIZE.AUTO_ATTENDANT_GREETING)/1000;
        $scope.biz_schedule = [];
        $scope.holiday_schedule = [];
        $scope.biz_schedule_selected = 'Select';
        $scope.bizAudioSelection = "SYSTEM";
        $scope.bizAudioSelectionFile = "";

        $scope.holidayAudioSelection = "SYSTEM";
        $scope.holidayAudioSelectionFile = "";
        //getScheduleData();

        $scope.theFile = [];
        $scope.theFile['business'] = {
          'name':null
         };
        $scope.theFile['holiday'] = {
          'name':null
         };
        $scope.businessSrc = null;
        $scope.holidaySrc = null;

        // Turn the FileList object into an Array
        scope.files = [];
        scope.files["business"] = [];
        scope.files["holiday"] = [];

        $scope.showMsg = false;
        $scope.modelModified = true;
        $scope.selectedTransferConfig = {"1": "", "2": "", "3":"", "4": "", "5":"", "6":"", "7":"", "8":"", "9":"", "0":"", "*":"", "#":""};
        $scope.routingOptions = [
            {"key": "1", "selected": true, "transfer_to": ""},
            {"key": "2", "selected": true, "transfer_to": ""},
            {"key": "3", "selected": true, "transfer_to": ""},
            {"key": "4", "selected": true, "transfer_to": ""},
            {"key": "5", "selected": true, "transfer_to": ""},
            {"key": "6", "selected": true, "transfer_to": ""},
            {"key": "7", "selected": true, "transfer_to": ""},
            {"key": "8", "selected": false, "transfer_to": ""},
            {"key": "9", "selected": false, "transfer_to": ""},
            {"key": "0", "selected": false, "transfer_to": ""},
            {"key": "*", "selected": false, "transfer_to": ""},
            {"key": "#", "selected": false, "transfer_to": ""}
        ];

        var pageName = $state.current.data.pageName;
        switch(pageName) {
            case 'auto-attendant':
                getList();
                getScheduleData();
                break;
            case 'auto-attendant-detail':


                //Get EPAM Link
                getEPAMLinkForDetails();

                getInfo();

                break;
            case 'auto-attendant-setup':

                loadSetup();

                //Get EPAM Link
                getEPAMLinkForSetup();

                //getScheduleData();
                break;
            case 'auto-attendant-review':
                loadReview();
                break;
            default:
                return false;
                break;
        }
        $scope.fileOpt = 'business';
        $scope.reviewData = {
            name: 'Customer Service',
            callingId: 'Loremipsum',
            greeting: 'System Default',
            timeZone: '(UTC-05:00) Eastern Time(US & Canada)',
            status: 'Active',
            lineNumber: '987-654-3213'
        };

        $scope.business = [{
                key: 1,
                routing: 'Transfer Without Prompt',
                transfer: '345 645 9988'
            },{
                key: 2,
                routing: 'Transfer With Prompt',
                transfer: '777 777 8458'
            },{
                key: 3,
                routing: 'Transfer To Operator',
                transfer: '345 632 7754'
            },{
                key: 4,
                routing: 'Extension Dialing',
                transfer: ''
            },{
                key: 5,
                routing: 'Name Dialing',
                transfer: ''
            },{
                key: 6,
                routing: 'Repeat Menu',
                transfer: ''
            },{
                key: 7,
                routing: 'Exit',
                transfer: ''
            },{
                key: 8,
                routing: 'Not Used',
                transfer: ''
            },{
                key: 9,
                routing: 'Not Used',
                transfer: ''
            },{
                key: 0,
                routing: 'Not Used',
                transfer: ''
            },{
                key: '*',
                routing: 'Not Used',
                transfer: ''
            },{
                key: '#',
                routing: 'Not Used',
                transfer: ''
        }];

        $scope.holiday = $scope.business;


        $scope.type = "callingPlan";
        $scope.vzGridTpl = "partials/features/vz-grid/vz.grid.auto-attendant-review.html";
        $scope.vzManageTpl = "partials/features/vz-grid/vz.grid.auto-attendant-manage.html";
        $scope.vzRoutingTpl = "partials/features/vz-grid/vz.grid.auto-attendant-setup.html";
        $scope.collection = [
            {"OutboundCalls": "Internal Calls", "selection": "Allow", "description": "Lorem Ipsum Dolor Lorem Ipsum Dolor Lorem Ipsum Dolor Lorem Ipsum Dolor Lorem Ipsum Dolor Lorem Ipsum Dolor Lorem Ipsum Dolor Lorem Ipsum Dolor"},
            {"OutboundCalls": "Selective List", "selection": "Block", "description": "Lorem Ipsum Dolor"},
            {"OutboundCalls": "Local Calls", "selection": "Block", "description": "Lorem Ipsum Dolor"},
            {"OutboundCalls": "Toll Free Calls", "selection": "Allow", "description": "Lorem Ipsum Dolor"},
            {"OutboundCalls": "International Calls", "selection": "Authorization Code", "description": "Lorem Ipsum Dolor"},
            {"OutboundCalls": "Directory Assistance", "selection": "Block", "description": "Lorem Ipsum Dolor"},
            {"OutboundCalls": "Emergency Calls", "selection": "Allow", "description": "Lorem Ip"},
            {"OutboundCalls": "Paid Services", "selection": "Authorization Code", "description": "Lorem Ipsum Dolor"}
        ];
        $scope.time_zone = HuntGroupConst.TIME_ZONE;
        $scope.routingDropdown = [
            {name: "Select", value: ""},
            {name: "Transfer Without Prompt", value: "Transfer Without Prompt"},
            {name: "Transfer With Prompt", value: "Transfer With Prompt"},
            {name: "Transfer To Operator", value: "Transfer To Operator"},
            {name: "Extension Dialing", value: "Extension Dialing"},
            //{name: "Name Dialing", value: "Name Dialing"},
            {name: "Repeat Menu", value: "Repeat Menu"},
            {name: "Exit", value: "Exit"}
        ];
        $scope.routingWithLookup = ["Transfer Without Prompt", "Transfer With Prompt", "Transfer To Operator"];
        if ($scope.sameAsBusiness == undefined) {
            $scope.sameAsBusiness = true;
        }
        $scope.businessTab = true;
        $scope.holidayTab = false;
        $scope.time_zone_selected = "";
        $scope.managePageTitle = autoAttendantConst.managePageTitle;
        $scope.pageDesc = autoAttendantConst.pageDesc;
        $scope.detailPageTitle = autoAttendantConst.detailPageTitle;
        $scope.reviewPageTitle = autoAttendantConst.reviewPageTitle;
        $scope.instructionsManage = autoAttendantConst.instructionsManage;
        $scope.instructionsDetails = autoAttendantConst.instructionsDetails;
        $scope.instructionsBusinessHoliday = autoAttendantConst.instructionsBusinessHoliday;
        $scope.instructions = autoAttendantConst.instructions;
        $scope.patternsPageTitle = autoAttendantConst.patternsPageTitle;
        $scope.autopageTitle = autoAttendantConst.autopageTitle;
        //getInstruction();
    }
    init();

}
automatedReceptionsitCtrl.$inject = ["$scope","$rootScope","$state","ngDialog","autoAttendantConst","HuntGroupConst",'autoAttendantService','volteServices','cache','Constants', '$http', '$window'];
angular.module( window.AppName ).controller("automatedReceptionsitCtrl", automatedReceptionsitCtrl);
