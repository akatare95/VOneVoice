var accountAssignCtrl = function($scope,$state) {
	console.log($state);
	 $state.go('features.enterprise.assign_account_code.assign_code');
	 console.log('account assign')
};
accountAssignCtrl.$inject = ["$scope","$state"];
angular.module( window.AppName ).controller("accountAssignCtrl", accountAssignCtrl);