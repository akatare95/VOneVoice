//angular.module( window.AppName ).controller('DevicesNav', function($scope, $http, $state, $stateParams, $state){
var DevicesNav = function($scope, $http, $state, $stateParams, $state){

	$scope.viewOptions = ["All","Deskphones","Smartphones","OTT Devices"];

};

DashboardNav.$inject = ["$scope", "$http", "$state", "$stateParams", "$state"];
angular.module( window.AppName ).controller("DevicesNav", DevicesNav);