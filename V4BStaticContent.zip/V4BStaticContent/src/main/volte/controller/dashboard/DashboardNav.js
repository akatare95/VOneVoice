var DashboardNav = function($scope, $http, $state, $stateParams){

	$scope.viewOptions = ["All","Critical","Updates","Information"];

};

DashboardNav.$inject = ["$scope", "$http", "$state", "$stateParams"];
angular.module( window.AppName ).controller("DashboardNav", DashboardNav);