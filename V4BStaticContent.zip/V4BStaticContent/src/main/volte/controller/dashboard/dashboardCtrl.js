var DashboardCtrl = function($scope, $state, $http, $cacheFactory, ngDialog, $timeout, $rootScope, $compile, asyncLoadData, volteServices, Constants, cache, $window, lineServices, $q, devicesService, linesService){

    var innerRadius = "50%";
    var pieOuterRadius = "43%";

    $scope.linesCount = 0;
    $scope.devicesCount = 0;
    $scope.disableLinesNdevices = true;
    deviceSummaryList = [];
    $scope.gotoTxnHistory = function() {
        $window.location.href = $scope.NavLink;
    };
    $scope.filterFn = function(input) {

        if( input ) {

            var result =  input.replace(/-/g, "");
            return result;

        }

    }



    function convertMetricsToPercentage( arr ) {
        return arr.map(function(item) {
            return Math.round(item/totalDeviceCountForBarGraph * 100, 2);
        });
    }

     function convertToPercentage( base, totol ) {
      var percentageArr;
       percentageArr = ( base * 100 ) / totol;
        //console.log("Array - ", percentageArr);
        return percentageArr;
    }
    var totalDeviceCountForBarGraph = 0;
    function configurePieChart( stats , lineCountResp ) {

        //Get Hyperlink for the Dashboard
        if( window.EPAMLink.indexOf() ) {
            var transLinkArr  = window.EPAMLink.split("?");
            $scope.NavLink    = transLinkArr[0] + "#transactionHistory";
        } else {
            $scope.NavLink    = window.EPAMLink + "#transactionHistory";
        }

        // Commented bacause it causes "Page not found" error
        // Back URL not needed for EPAM
        // Redirect with back URL
/*
        var currentUrlPath = window.location.href;
        var redirectUrlPath = $scope.NavLink;
        $scope.NavLink = redirectUrlWithReturnURL(redirectUrlPath, currentUrlPath, Constants.API.REDIRECT_URL_PATHS.split_At);
*/
        var eleu = stats.eleu;
        var cleu = stats.cleu;

        var linesPieEmp  = eleu.smartPhones + eleu.deskPhones + eleu.ott;
        var linesPieCorp = cleu.smartPhones + cleu.deskPhones + cleu.ott;

        var devicesPieSmartphones = eleu.smartPhones + cleu.smartPhones;
        var devicesPieDeskphones = eleu.deskPhones + cleu.deskPhones;
        var devicesPieOTT = eleu.ott + cleu.ott;
        $scope.linesCount = linesPieEmp + linesPieCorp;
        $scope.devicesCount = devicesPieSmartphones + devicesPieDeskphones + devicesPieOTT;

        $scope.eleu = {};
        $scope.eleu.smartPhones = eleu.smartPhones;
        $scope.eleu.deskPhones = eleu.deskPhones;
        $scope.eleu.ott = eleu.ott;
        $scope.eleuTotalLines = eleu.smartPhones + eleu.deskPhones + eleu.ott;


        $scope.cleu = {};
        $scope.cleu.smartPhones = cleu.smartPhones;
        $scope.cleu.deskPhones = cleu.deskPhones;
        $scope.cleu.ott = cleu.ott;
        $scope.cleuTotalLines = cleu.smartPhones + cleu.deskPhones + cleu.ott;

        $scope.cleueleuTotalLines = $scope.eleuTotalLines + $scope.cleuTotalLines;

        var devicesPieSmartphones = eleu.smartPhones + cleu.smartPhones;
        var devicesPieDeskphones = eleu.deskPhones + cleu.deskPhones;
        var devicesPieOTT = eleu.ott + cleu.ott;

        $scope.linesCount = linesPieEmp + linesPieCorp;
        $scope.devicesCount = devicesPieSmartphones + devicesPieDeskphones + devicesPieOTT;

        $scope.eleu = {};
        $scope.eleu.smartPhones = eleu.smartPhones;
        $scope.eleu.deskPhones = eleu.deskPhones;
        $scope.eleu.ott = eleu.ott;
        $scope.eleuTotalLines = eleu.smartPhones + eleu.deskPhones + eleu.ott;

        $scope.cleu = {};
        $scope.cleu.smartPhones = cleu.smartPhones;
        $scope.cleu.deskPhones = cleu.deskPhones;
        $scope.cleu.ott = cleu.ott;
        $scope.cleuTotalLines = cleu.smartPhones + cleu.deskPhones + cleu.ott;

        totalDeviceCountForBarGraph = $scope.eleuTotalLines +  $scope.cleuTotalLines;


        $scope.horzBarSmartphonePerArr = convertMetricsToPercentage( [eleu.smartPhones,  cleu.smartPhones] );
        $scope.horzBarDeskphonePerArr  = convertMetricsToPercentage( [eleu.deskPhones,  cleu.deskPhones] );
        $scope.horzBarOTTPerArr        = convertMetricsToPercentage( [eleu.ott,  cleu.ott] );

        $scope.linesPieChartData = [{
            color:'#abe0f9',
            label : "Corporate",
            value : lineCountResp.cleuCount
        }, {
            color:'#66cbab',
            label : "Employee",
            value : lineCountResp.eleuCount
        }];
        $scope.devicesPieChartData = [{
            color:'#cd1909',
            label : "Smartphones",
            value : devicesPieSmartphones
        },{
            color:'#f69269',
            label : "Desk Phones",
            value : devicesPieDeskphones
        },{
            color:'#f9d362',
            label : "Mobile Clients",
            value : devicesPieOTT
        }];
    }

    function loadLinesnDevices() {
          linesService.loadList({})
                    .then(function(result){
                        $scope.disableLinesNdevices = false;
                        //console.log(result.total);
                        $scope.LinesnDevices = result.total || [];
                        $scope.moreLineRecords = result.threshold;
                    })
                    .catch(function(){
                        $scope.showMsg = true;
                        $scope.msgType = 'error';
                        $scope.msgTxt = "Phone Number doesn't exist.";
                    });
    }

    $scope.updateSearch = function( row ) {
        $scope.searchLine = row.lineNumber;
        $scope.showAutoForLine = false;
    };

    $scope.navigateToLinesNDevices = function( line, feature ) {
        var resetval;
        $scope.showMsg = false;
        cache.put("show-type", resetval);
        formattedLine = line.replace(/-/g, "");
        var linesfilteredArray = $scope.LinesnDevices
                .filter(function(record) {
                    return record.lineNumber == formattedLine || record.userName == formattedLine;
                });
        if(linesfilteredArray.length > 0)
        {
           linesService.setSearch(formattedLine);
           //linesService.search(formattedLine);
           cache.put("fromOverviewPage",'lines');
           $state.go("line-devices");
        }
        else
        {
            devicesService.loadList({})
                    .then(function(result){
                        $scope.DevicesList = result.total || [];
                        $scope.moreDeviceRecords = result.threshold;
                        filterFromDeviceList();
                    })
                    .catch(function(){
                        $scope.showMsg = true;
                        $scope.msgType = 'error';
                        $scope.msgTxt = "Phone Number doesn't exist..";
                    });
        }
    };
    function filterFromDeviceList(){
        if($scope.DevicesList.length>0)
                    {
                       var devicesfilteredArray = $scope.DevicesList
                        .filter(function(record) {
                            return  record.userName == formattedLine || record.deviceId == formattedLine;
                        });
                        if(devicesfilteredArray.length > 0 )
                        {
                           devicesService.setSearch(formattedLine);
                           //devicesService.search(formattedLine);
                           cache.put("fromOverviewPage",'devices');
                           $state.go("line-devices");
                        }
                        else
                        {
                            $scope.showMsg = true;
                            $scope.msgType = 'error';
                            $scope.msgTxt = "Phone Number doesn't exist...";
                        }
                    }
                    else
                    {
                        $scope.showMsg = true;
                        $scope.msgType = 'error';
                        $scope.msgTxt = "Phone Number doesn't exist...";
                    }
    }
    $scope.navigateToDevices = function() {
        devicesService.filter('deskphone');
        cache.put("fromOverviewPage",'devices');
        $state.go("line-devices");
    };

    $scope.navigateToLines = function() {
        devicesService.filter('deskphone');
        cache.put("fromOverviewPage",'lines');
        $state.go("line-devices");
    }

    $scope.navigateToResources = function() {
        //devicesService.filter('deskphone');
        cache.put("fromOverviewPage",'resources');
        $state.go("resources");
    }

    $scope.navigateToFeatures = function (activeFeature) {
        var featureCache = $cacheFactory.get('features') || $cacheFactory('features');

        featureCache.put('activeFeature', activeFeature);

        $state.go('features');
    };
/*
    $scope.addExistingLine = function(){
         console.log(getHostDetails());
        var getHostDetailsArr =    [];
        var subdomain         =    null;

        getHostDetailsArr     =    getHostDetails();
        if(getHostDetailsArr.length == 3){
            window.location = 'https://b2b.verizonwireless.com/epam/app/ng/secure/entry.go#/lineSelection';
        }else{
            console.log(subdomain);
            subdomain  =    getHostDetailsArr[0].slice(3);
            if( subdomain ) {
            window.location = 'https://b2b' + subdomain + '.sdc.vzwcorp.com/epam/app/ng/secure/entry.go#/lineSelection';
            }else {
                    $scope.msgType = "error";
                    $scope.msgTxt  = "Unable to redirect! Please contact Administrator";
                    $scope.showMsg = true;
                }
        }
       // cache.put("fromOverviewPage",'lines');
       // $state.go("line-devices");
    }
*/
    $scope.addExistingLine = function() {
        var currentUrlPath = window.location.href;
        var appendPath = Constants.API.REDIRECT_URL_PATHS.epam + '#/lineSelection';
        var redirectUrlPath = prepareRedirectUrlPath(Constants.API.REDIRECT_URL_PATHS.prod, Constants.API.REDIRECT_URL_PATHS.dev, appendPath, true);
        window.location = redirectUrlWithReturnURL(redirectUrlPath, currentUrlPath, Constants.API.REDIRECT_URL_PATHS.split_At);
    }

    $scope.addExistingDevice = function(){
      cache.put("fromOverviewPage",'devices');
      $state.go("line-devices");
    }
/*
    $scope.purchaseAutoAttendant = function() {
        console.log($rootScope.autoAttendantUrl)
        //window.location = $rootScope.autoAttendantUrl;

        var getHostDetailsArr =    [];
        var subdomain         =    null;

        getHostDetailsArr     =    getHostDetails();
        console.log("getHostDetailsArr" ,getHostDetailsArr );

        console.log("Total parts in the host URL..." , getHostDetailsArr.length);

        // Production Env. where HOSTNAME is v4b.verizonwireless.com
        if(3 == getHostDetailsArr.length){
            window.location = 'https://b2b.verizonwireless.com/b2b/commerce/amsecure/index.go?ssPath=AA';
        }else{
            subdomain  =    getHostDetailsArr[0].slice(3);
            console.log("subdomain" , subdomain);
            if( subdomain ) {
                window.location = 'https://b2b' + subdomain + '.sdc.vzwcorp.com/b2b/commerce/amsecure/index.go?ssPath=AA';
            } else {
                $scope.msgType = "error";
                $scope.msgTxt  = "Unable to redirect! Please contact Administrator";
                $scope.showMsg = true;
            }

        }


    }
*/
    $scope.purchaseAutoAttendant = function() {
        var currentUrlPath = window.location.href;
        var appendPath = Constants.API.REDIRECT_URL_PATHS.commerce + '?' + Constants.API.REDIRECT_URL_PATHS.paramAA;
        var redirectUrlPath = prepareRedirectUrlPath(Constants.API.REDIRECT_URL_PATHS.prod, Constants.API.REDIRECT_URL_PATHS.dev, appendPath, true);
        window.location = redirectUrlWithReturnURL(redirectUrlPath, currentUrlPath, Constants.API.REDIRECT_URL_PATHS.split_At);
    }
/*
    $scope.purchaseHuntGroup = function() {

        //window.location = $rootScope.huntGroupUrl;

        var getHostDetailsArr =    [];
        var subdomain         =    null;

        getHostDetailsArr     =    getHostDetails();
        console.log("getHostDetailsArr" ,getHostDetailsArr );

        console.log("Total parts in the host URL..." , getHostDetailsArr.length);

        // Production Env. where HOSTNAME is v4b.verizonwireless.com
        if(3 == getHostDetailsArr.length){
            window.location = 'https://b2b.verizonwireless.com/b2b/commerce/amsecure/index.go?ssPath=HG';
        }else{
            subdomain  =    getHostDetailsArr[0].slice(3);
            console.log("subdomain" , subdomain);
            if( subdomain ) {
                window.location = 'https://b2b' + subdomain + '.sdc.vzwcorp.com/b2b/commerce/amsecure/index.go?ssPath=HG';
            } else {
                $scope.msgType = "error";
                $scope.msgTxt  = "Unable to redirect! Please contact Administrator";
                $scope.showMsg = true;
            }
        }


    }
*/
    $scope.purchaseHuntGroup = function() {
        var currentUrlPath = window.location.href;
        var appendPath = Constants.API.REDIRECT_URL_PATHS.commerce + '?' + Constants.API.REDIRECT_URL_PATHS.paramHG;
        var redirectUrlPath = prepareRedirectUrlPath(Constants.API.REDIRECT_URL_PATHS.prod, Constants.API.REDIRECT_URL_PATHS.dev, appendPath, true);
        window.location = redirectUrlWithReturnURL(redirectUrlPath, currentUrlPath, Constants.API.REDIRECT_URL_PATHS.split_At);
    }

    $scope.addNewVolteLine = function() {
        ngDialog.open({
            template: 'partials/components/dialog/addNewDevice.html',
            closeByDocument: false,
            closeByEscape: false,
            scope: $scope,
            controller:'addNewDeviceCtrl'
        });

        // window.location = $rootScope.addNewVolteLineUrl;

        // var getHostDetailsArr =    [];
        // var subdomain         =    null;

        // getHostDetailsArr     =    getHostDetails();
        // console.log("getHostDetailsArr" ,getHostDetailsArr );

        // console.log("Total parts in the host URL..." , getHostDetailsArr.length);

        // // Production Env. where HOSTNAME is v4b.verizonwireless.com
        // if(3 == getHostDetailsArr.length){
        //     window.location = 'https://b2b.verizonwireless.com/b2b/commerce/amsecure/index.go?ssPath=NSE';
        // }else{
        //     subdomain  =    getHostDetailsArr[0].slice(3);
        //     console.log("subdomain" , subdomain);
        //     if( subdomain ) {
        //         window.location = 'https://b2b' + subdomain + '.sdc.vzwcorp.com/b2b/commerce/amsecure/index.go?ssPath=NSE';
        //     } else {
        //         $scope.msgType = "error";
        //         $scope.msgTxt  = "Unable to redirect! Please contact Administrator";
        //         $scope.showMsg = true;
        //     }

        // }

    }




    /*  New Function for selection which feature page to display  (HD)*/

/*
    var featuresSelectTab = function (type)
    {
        if(type)
        {
            $rootScope._activeFeature = type ;

        }


    }
*/






    function configDashboard() {
        var lineCountResp, overviewCountResp;
        volteServices.setOption( Constants.API.DASHBOARD.COUNT );
        $q.all([
            lineServices.getLineCount().success(function(response) {
                lineCountResp = response;
            }),
            volteServices.getData().success(function( response) {
                overviewCountResp = response;
            })]).then(function() {
                if( overviewCountResp.appHeader.statusCode === "OK" && lineCountResp.appHeader.statusCode === 'OK') {
                    overviewCountResp = overviewCountResp.appResult.serviceRepsonse;
                    lineCountResp = lineCountResp.appResult.serviceRepsonse;

                    $scope.notification = {};
                    $scope.notification.huntGroup = overviewCountResp.newLinesNotification.huntGroup;
                    $scope.notification.autoAttendent = overviewCountResp.newLinesNotification.autoAttendent;
                    $scope.notification.huntGroupTotal = overviewCountResp.totalHG ;
                    $scope.notification.autoAttendentTotal = overviewCountResp.totalAA ;
                    $scope.notification.newLines = overviewCountResp.newLinesNotification.newLines;
                     $scope.notification.pendingLines = overviewCountResp.pendingEleuLines ? overviewCountResp.pendingEleuLines + " Lines-Request Pending" : '';

                    configurePieChart( overviewCountResp, lineCountResp );
                } else {
                    errorHandlerFn();
                }
            }, errorHandlerFn);
        function errorHandlerFn() {
            $scope.noDevicesBreakdown = true;
        }
    }

    configDashboard();
    loadLinesnDevices();
};

DashboardCtrl.$inject = ["$scope", "$state", "$http", "$cacheFactory", "ngDialog", "$timeout", "$rootScope", "$compile", "asyncLoadData", "volteServices", "Constants", "cache", "$window", 'lineServices.deprecated', '$q', "devicesService", "linesService"];
angular.module( window.AppName ).controller("DashboardCtrl", DashboardCtrl);
