var preAuthorizeCtrl = function($scope, $rootScope, $http, ngDialog, $compile, $state, featuresServices, AuthorizeConst, preAuthorizeServices, $filter){

    var duplicateNums = [];
    var selectedLines = [];
    $scope.msgType = "success";
    $scope.msgTxt = '';
    $scope.showMsg = false;
    $scope.viewRequestCount = 0;
    $scope.selected = [];
    $scope.sendRequestNos = [];

    $scope.filterFn = function(input) {

        var result =  phonenumber( input ) ? input.replace(/-/g, "") : input;
        return result;

    }

    $scope.vzSndSubmitBtnStatusFn = function( decision ) {

        try {
            if( typeof($scope.sendRequestNos)!='undefined' && $scope.sendRequestNos.length > 0 ) {
               $rootScope.vzSubmitBtnStatus = true;
            }
        } catch(err) {}

        return decision;

    }

    $scope.vzSubmitBtnStatusFn = function( decision ) {
        try {
            if( typeof($scope.requestData)!='undefined' && $scope.requestData.length > 0 ) {
                //console.log("sentlist = ", $scope.requestData);
                $rootScope.vzSubmitBtnStatus = true;
            }
        } catch(err) {}
        return decision;
    }

    $scope.toggleTab = function() {
        $scope.tab = !$scope.tab;
    }

    $scope.displayFirstTab = function() {

        if( $scope.tab == true ) {
            return "vz-show";
        } else {
            return "vz-hide";
        }
    }

    $scope.displaySecondTab = function() {

        //initiateErrorMsgs();
        if( $scope.tab != true ) {
            return "vz-show";
        } else {
            return "vz-hide";
        }
    }

    $scope.activateFirstTab = function( index ) {

        if( $scope.tab == true ) {
            return "selected";
        } else {
            return "";
        }
    }

    $scope.activateSecondTab = function( index ) {
        if( $scope.tab == false ) {
            return "selected";
        } else {
            return "";
        }
    }

    $scope.activateAddBtn = function( phoneNoLen ) {

        var empPhoneNo = document.getElementById("employee-phone-number").value;
        if( empPhoneNo.length == 12 )
            return false;

        return true;
    }

    $scope.$watch(function() {
      return $scope.sendRequestNos.length;
    }, function(newValue, oldValue) {

        if(  $scope.sendRequestNos.length == 19 ) {
            initiateErrorMsgs();
        }

    });

    function limitLines() {
        $scope.msgType = "error";
        $scope.msgTxt = "You have selected the maximum limit of 20 lines;  if you have more than 20 requests to resend, please do them in groups of 20 lines or less at a time";
        $scope.showMsg = true;
    }

    function initiateErrorMsgs() {
        $scope.msgType = "";
        $scope.msgTxt = "";
        $scope.showMsg = null;
    }

    $scope.authorize = function(event) {

        event.preventDefault();

        if( $scope.sendRequestNos.length >= 20 ) {
            limitLines();
            return;
        }

        var empPhoneNumberInput = document.getElementById('employee-phone-number');
        empPhoneNo = empPhoneNumberInput.value;

        var addToArray=true;
        for(var i=0;i<$scope.sendRequestNos.length;i++){
            if($scope.sendRequestNos[i].mdn===empPhoneNo){
                addToArray=false;
                $scope.msgType = "error";
                $scope.msgTxt = empPhoneNo +' has been added already!';
                $scope.showMsg = true;
                return false;
            }
        }

        empPhoneNoFormat = new RegExp(/^\d{3}-\d{3}-\d{4}$/);
        if (!empPhoneNoFormat.test(empPhoneNo) || !addToArray) {
            $scope.msgType = "error";
            $scope.msgTxt = empPhoneNo +' is not valid';
            $scope.showMsg = true;
        } else {
            mtn = empPhoneNo.replace(/[`~!@#$%^&*()_|+\-=?;:'",.<>\{\}\[\]\\\/]/gi, '');
            preAuthorizeServices.mtnValidate( mtn )
                .success(function (result) {

                    if (result.appHeader.statusCode == "OK") {

                        if( result.appResult.serviceRepsonse.service.serviceHeader.errorCode != "0" && result.appResult.serviceRepsonse.service.serviceHeader.errorCode != "00" ) {

                            $scope.msgType = "error";
                            $scope.msgTxt = empPhoneNo + " is invalid";
                            $scope.showMsg = true;

                            return true;
                        }

                        var isValid = result.appResult.serviceRepsonse.service.serviceBody.serviceResponse.mtnDetail;

                        if( isValid == null || isValid == 'null' || isValid.length == 0) {

                            var response = result.appResult.serviceRepsonse.service.serviceHeader;
                            $scope.msgType = "error";
                            $scope.msgTxt = response.errorMessage;
                            $scope.showMsg = true;

                        } else {

                            // Checking status codes
                            // Active    :   A, AR, AC, AT
                            // Suspended :   S, B
                            // Inactive  :   D, T, R, C
                            // ECPD Liability check with ecpdLiabilityTypeCode

                            var mtnStatusCode = isValid.mtnStatusCode.toUpperCase();

                            if (isValid.ecpdLiabilityTypeCode.toUpperCase() == 'E') {

                                $scope.msgType = "error";
                                $scope.showMsg = true;

                                switch(mtnStatusCode) {
                                    case 'A':
                                    case 'AR':
                                    case 'AC':
                                    case 'AT':
                                        $scope.msgType = "success";
                                        $scope.msgTxt = empPhoneNo +' has been validated successfully';
                                        var empName = "";
                                        var empEmail = "" ;
                                        empName = (isValid.basicCbrInfo.contactName.firstName == null || isValid.basicCbrInfo.contactName.lastName == null)?'':isValid.basicCbrInfo.contactName.lastName+', '+isValid.basicCbrInfo.contactName.firstName;
                                        empEmail = (isValid.basicCbrInfo.emailId == null) ? '': isValid.basicCbrInfo.emailId ;
                                        empPhoneNumberInput.value='';
                                        //Push the data to the collection
                                        $scope.sendRequestNos.push(
                                            {"mdn": empPhoneNo, "name": empName, "email" :empEmail}
                                        );
                                        break;
                                    case 'S':
                                    case 'B':
                                        $scope.msgTxt = empPhoneNo + ' is Suspended';
                                        break;
                                    case 'D':
                                    case 'T':
                                    case 'R':
                                    case 'C':
                                        $scope.msgTxt = empPhoneNo + ' is Deactivated';
                                        break;
                                }





                            } else if (isValid.ecpdLiabilityTypeCode.toUpperCase() == 'C') {
                                $scope.msgType = "error";
                                $scope.msgTxt = empPhoneNo +' is a Corporate Line';
                                $scope.showMsg = true;
                            } else if (isValid.ecpdLiabilityTypeCode.toUpperCase() == null || (isValid.ecpdLiabilityTypeCode.toUpperCase() != null && isValid.ecpdLiabilityTypeCode.trim() == '')) {
                                $scope.msgType = "error";
                                $scope.msgTxt = empPhoneNo +' is not eligible';
                                $scope.showMsg = true;
                            } else {
                                $scope.msgType = "error";
                                $scope.msgTxt = empPhoneNo +' is either Suspended Or Inactive';
                                $scope.showMsg = true;
                            }
                        }

                    } else {
                        $scope.msgType = "error";
                        $scope.msgTxt = empPhoneNo + ' is not valid. ';
                        $scope.showMsg = true;
                    }
                }).error(function (error) {
                    $scope.msgType = "error";
                    $scope.msgTxt = empPhoneNo + ' is invalid. ';
                    $scope.showMsg = true;
                });


            //
        }
    }

    $scope.sendRequest = function() {

        var requestNumbers = [];
        angular.forEach( $scope.sendRequestNos, function (row, index) {
            requestNumbers.push({"mdn": row.mdn.replace(/-/g, ""), "name": row.name, "email" : row.email});
        });
        var sendRequestData = { "mdnDetailList": { "mdnDetailItem": requestNumbers } };

        preAuthorizeServices.resendRequest(sendRequestData)
            .then(function (result) {
                console.log(result);
                $scope.msgType = 'success';
                $scope.msgTxt = "Authorization Request Sent. Click on View Request Sent for more information.";
                $scope.showMsg = true;
               // successHandler("Authorization Request Sent. Click on View Request Sent for more information.");
                 console.log( $scope.msgType,$scope.msgTxt, $scope.showMsg);
                // if (result.appHeader.statusCode == "OK") {
                //     $scope.msgType = "success";
                //     $scope.msgTxt = "Authorization Request Sent. Click on View Request Sent for more information.";
                //     $scope.showMsg = true;
                //     $scope.sendRequestNos = [];
                // } else {
                //     $scope.msgType = "error";
                //     $scope.msgTxt = 'Error sending authorization request';
                //     $scope.showMsg = true;
                // }
            }).catch(function(reject){
                    errorHandler('Error sending authorization request');
            }).then(function(){
                    toggleSelect(false);
            });
        //     .error(function (error) {
        //         $scope.msgType = "error";
        //         $scope.msgTxt = 'Error sending authorization request';
        //         $scope.showMsg = true;
        // });

    }

    $scope.checkSelected = function() {
        $scope.requestData = [];
        angular.forEach( $scope.sentlist, function (row, index) {
            if( row.isChecked ) {
                $scope.requestData.push( row );
            }
        });
    }

    $scope.resendRequest = function() {

            /*$scope.requestData = [];
            angular.forEach( $scope.sentlist, function (row, index) {
                if( row.isChecked ) {
                    $scope.requestData.push( row );
                }
            });*/

            var requestNumbers = [];
            console.log(preAuthorizeServices.getList())
            angular.forEach( preAuthorizeServices.getList(), function (row, index) {
                //requestNumbers.push({"mdn": row.mdn.replace(/-/g, ""), "name": row.name});
                if( row.isChecked && row.status == 'Processing') {
                    console.log("*********push")
                    requestNumbers.push({"mdn": row.phoneNumber.replace(/-/g, ""), "name": row.name});
                }
            });
            $scope.requestData = { "mdnDetailList": { "mdnDetailItem": requestNumbers } };

            preAuthorizeServices.resendRequest( $scope.requestData )
            .then(function(response) {
                console.log(response)
                    successHandler("Authorization Request Sent.");
                })
                .catch(function(reject){
                    errorHandler(reject);
                })
                .then(function(){
                    toggleSelect(false);
                });
                // .success(function (result) {

                //     if (result.appHeader.statusCode == "OK") {
                //         $scope.msgType = "success";
                //         $scope.msgTxt = "Authorization Request Sent.";
                //         $scope.showMsg = true;
                //     } else {
                //         $scope.msgType = "error";
                //         $scope.msgTxt = 'Error sending authorization request';
                //         $scope.showMsg = true;
                //     }

                //     try {
                //         getViewRequestNos();
                //     }   catch(err) {}

                // }).error(function (error) {
                //     $scope.msgType = "error";
                //     $scope.msgTxt = 'Error sending authorization request';
                //     $scope.showMsg = true;
                // });

    }

    $scope.formatLineNumber = function(event) {
        var lineNumberInput = document.getElementById('employee-phone-number'),
        lineNumber = lineNumberInput.value,
        charCode = (event.which) ? event.which : event.keyCode,
        acceptable = [48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 13, 32, 45, 46, 118, 8, 0];

        //console.log('Code: ' + charCode);
        //restrict non-numeric inputs
        if(acceptable.indexOf(charCode) == -1) {
            lineNumber = lineNumber.replace(/\D/g, '');
        }
        //process formatting
        if(acceptable.indexOf(charCode) < 15) {
            lineNumber = lineNumber.replace(/\D/g, '');
            if(lineNumber.length > 2) {
                lineNumber = lineNumber.substring(0,3) + '-' + lineNumber.substring(3);
            }
            if(lineNumber.length > 6) {
                lineNumber = lineNumber.substring(0,7) + '-' + lineNumber.substring(7);
            }
        }
        //assign formatted value back to <input>
        angular.element(lineNumberInput).val(lineNumber);
    }

    $scope.onDeletePhoneLine = function (event, array, index) {
        remove(array, index);
    }

    $scope.remove = function(array, index){
        array.splice(index, 1);
    }

    $scope.refreshTab2 = function() {

        getViewRequestNos();

        try {
            document.getElementById("employee-phone-number").value = "";
        } catch(err) {}

    }
    $scope.filter = function(filterBy)
    {
          preAuthorizeServices.filter(filterBy)
            .then(serviceResponseHandler)
            .catch(errorHandler);
    }
    function getViewRequestNos() {

        //authorizeServices.setOption( Constants.API.AUTHORIZE_PAGE.VIEW_REQUEST_NOS );
         preAuthorizeServices.loadList({})
            .then(serviceResponseHandler)
            .catch(errorHandler)
            .then(function() {
                $scope.loadFlag = false;
            });
        // $scope.type = "code";
        // featuresServices.setOption( $scope.type );
        $scope.vzGridTpl = "partials/authorize/vz-grid/vz.grid.preauthorize.html";
        $scope.vzGridAddEmplTpl = "partials/authorize/vz-grid/vz.grid.preauthorize.addEmp.html";
        //getData();
    }
    function toggleSelect(value) {
        console.log(value)
        var list = preAuthorizeServices.getList();
        console.log(list)
        for (var i = 0, ln = list.length; i < ln; i++) {
            // if(list[i].status == 'Processing')
            list[i].isChecked = value;
        }
    }
    $scope.prev = function() {
        toggleSelect(false);
        preAuthorizeServices.prevPage()
            .then(serviceResponseHandler)
            .catch(errorHandler);
    };

    /**
     * Paginate next page
     *
     * @method     next
     */
    $scope.next = function() {
        toggleSelect(false);
        preAuthorizeServices.nextPage()
            .then(serviceResponseHandler)
            .catch(errorHandler);
    };


    $scope.setPageSize = function(value) {
        //toggleSelect(false);
        preAuthorizeServices.setPageSize(value)
            .then(serviceResponseHandler)
            .catch(errorHandler);
    };


    function fixShortDate(dateTxt) {
        var re = new RegExp(/(\d{6})(\d{2})?/);
        if (re.test(dateTxt)) {
            if (dateTxt.length == 8) {
                dateTxt = dateTxt.substring(0, 2) + '-' + dateTxt.substring(2, 4) + '-' + dateTxt.substring(4, 8)
            }
            if (dateTxt.length == 6) {
                if (dateTxt.substring(4, 6) < 20) {
                    dateTxt = dateTxt.substring(0, 2) + '-' + dateTxt.substring(2, 4) + '-20' + dateTxt.substring(4, 6);
                } else {
                    dateTxt = dateTxt.substring(0, 2) + '-' + dateTxt.substring(2, 4) + '-19' + dateTxt.substring(4, 6);
                }
            }
        }
        return dateTxt;
    }
    function serviceResponseHandler(response) {
        $scope.selectAll = false;
        $scope.collection = preAuthorizeServices.getList();
        $scope.sentlist = preAuthorizeServices.getList();
        defaultSet        = angular.copy( $scope.collection );
        $scope.pageSize = preAuthorizeServices.getPageSize();
        $scope.pagesLength = preAuthorizeServices.getPagesLength();
        $scope.currentPage = preAuthorizeServices.getCurrentPage();
        $scope.length = preAuthorizeServices.getLength();
        $scope.total = preAuthorizeServices.getTotal();
        $scope.noRecordsMessage = $scope.total === 0 ? "No Records Found" : "The schedule cannot be found.";
        $scope.serverSearch = false;
        $scope.serverSearch = preAuthorizeServices.getServerSearchValue();
        // $scope.isEnableAll = isEnabled();
        // $scope.isDisableAll = isDisabled();
        // console.log('sdfsff' + $scope.isEnableAll, $scope.isDisableAll)
        // console.log('enabled' + $scope.isAllEnabled);
        return response;
    }

     $scope.search = function (searchQuery,searchFilter,$event) {
        if(preAuthorizeServices.getOperationType() ==='server' || preAuthorizeServices.getServerSearchValue())
        {
            var isClickedEnterVal = $event == undefined ? $event : $event.which;
           if(isClickedEnterVal === 13 ||isClickedEnterVal == undefined)
            {
                searchFunc(searchQuery,searchFilter);
            }
        }
        else
        {
          searchFunc(searchQuery,searchFilter);
        }
    };

    function searchFunc(searchQuery,searchFilter){
        preAuthorizeServices.search(searchQuery,searchFilter)
            .then(serviceResponseHandler)
            .catch(errorHandler);

        return searchQuery;
    }



    function errorHandler(err) {
        $scope.loadFlag = false;
        $scope.msgType = 'error';
        $scope.msgTxt = err.message || 'An unknown error has occured';
        $scope.showMsg = true;
    }

    function successHandler(message) {
        $scope.msgType = 'success';
        $scope.msgTxt = message;
        $scope.showMsg = true;
    }
    function init() {

        //Initialize Variables
        $scope.collection = {};
        $scope.sentlist = {};
        $scope.addedLinesCollection = {};
        serviceResponseHandler();
        //Load the line information
        getViewRequestNos();

        $scope.isInvalidPhoneNumber = false;

        $scope.vzGridCodeSearchTpl = "partials/authorize/vz-grid/vz.grid.preauthorize.search.html";

        $scope.view_request_filter = AuthorizeConst.VIEW_REQUEST_FILTER;
        $scope.view_request_filter_selected = "";
    }

    init();

};

preAuthorizeCtrl.$inject = ["$scope", "$rootScope", "$http", "ngDialog", "$compile", "$state", "featuresServices", "AuthorizeConst", "preAuthorizeServices", "$filter"];
angular.module( window.AppName ).controller("preAuthorizeCtrl", preAuthorizeCtrl);