/*
*   authorizeCtrl - This controller takes care of the sections and messages which needs to be displayed with respective to the user roles
*
*/
var authorizeCtrl = function($scope, $rootScope, AuthorizeConst, Config, onboardServices){

    /*
    *  Initiate the life cycle of the variables
    *
    */
    function declareVariables() {

        //Page Title
        $scope.title = Config.TITLE;

        //Used for decision making in displayin the functionalities for the respective user roles
        $scope.enableOnboard = false;
        $scope.ur_a = false;
        $scope.ur_o = false;
        $scope.el_n = false;

        //$scope.messageForOtherRoles = "";

        //Initialize this variable with congrats message for SPOC so after the successful ajax request or vbid is available we dont need to do any updates on text
        //$scope.contactMsg = AuthorizeConst.MSG_CONGRATS_FOR_SPOC;

        //Initialize this variable with success message
        $scope.contactMsg = AuthorizeConst.SUCCESS_MSG_DETAIL;

        //Initialize this variable with not authorized message
        $scope.messageForOtherRoles = AuthorizeConst.NOT_AUTHORIZED_MSG_DETAIL;

        //Load the dropdown with the state names
        $scope.states_list = AuthorizeConst.STATE_LIST;
        $scope.state_list_selected = "";

        $scope.showOptions = true;

        //Statuses
        INITIAL = 'I';
        PENDING = 'P';
        ACTIVE = 'A';
        NO = 'N';
        E = 'E';

        //Roles
        SPOC = 'S';
        ADMIN = 'A';

    }


    /*
    *  Enroll Functionality for SPOC users
    *
    */
    $scope.enrollUser = function() {

        var stateCd = document.getElementById("state").getAttribute("data-value");

        if( stateCd.length < 2 ) {
            alert("Please select a state");
            return;
        }

        onboardServices.enroll( stateCd )
        	.success(function (result) {

                if (result.appHeader.statusCode == "OK") {
            		$scope.showOptions = false;
                    $scope.showmessage = true;
            		$scope.desc = AuthorizeConst.SUCCESS_MSG;
                } else {
                    $scope.showOptions = false;
                    $scope.showmessage = false;
                    $scope.showMessageText = "Unable to send request. Please try again later.";
                    $scope.desc = AuthorizeConst.FAILURE_MSG;
                }

        	}).error(function (error) {
        		$scope.showOptions = false;
                $scope.showmessage = false;
                $scope.showMessageText = "Sorry, Server is under maintenance please try again later.";
        		$scope.desc = AuthorizeConst.FAILURE_MSG;
        	});

    }


    /*
    *  Implemeting the rule set based on the ECPD profile
    *
    */
    function validateECPD() {

        var msgForOtherRolesCommon = function() {
            $scope.desc = AuthorizeConst.NOT_AUTHORIZED_MSG;
            $scope.enableOnboard = false;
            $scope.showOptions = false;
            $scope.showmessage = true;
        }

        var msgContactForOtherRoles = function() {
            $scope.el_err = true;
            //$scope.messageForOtherRoles = AuthorizeConst.MSG_CONTACT_FOR_OTHER_ROLES;
            msgForOtherRolesCommon();
        }

        var msgForContactingSPOC = function() {
            $scope.el_err = true;
            //$scope.messageForOtherRoles = AuthorizeConst.MSG_CONTACT_FOR_SPOC;
            //$scope.messageForOtherRolesExt = AuthorizeConst.MSG_CONTACT_FOR_SPOC_EXT;
            msgForOtherRolesCommon();
        }

        var msgForUnauthorizedUsers = function() {
            $scope.el_n = true;
            //$scope.messageForOtherRoles = AuthorizeConst.MSG_FOR_UNAUTHORIZED_USERS;
            //$scope.messageForOtherRolesExt = AuthorizeConst.MSG_FOR_UNAUTHORIZED_USERS_EXT;
            msgForOtherRolesCommon();
        }

        var msgForUnauthorizedRoles = function() {
            $scope.ur_o = true;
            //$scope.messageForOtherRoles = AuthorizeConst.MSG_FOR_UNAUTHORIZED_ROLES;
            //$scope.messageForOtherRolesExt = AuthorizeConst.MSG_FOR_UNAUTHORIZED_ROLES_EXT;
            msgForOtherRolesCommon();
        }

        var initativeStatusForSPOC = function() {
            $scope.desc = AuthorizeConst.DESC;
            $scope.showOptions = true;
            $scope.enableOnboard = true;
        }

        var congratsMsgForSPOC = function() {
            $scope.enableOnboard = true;
            $scope.desc = AuthorizeConst.SUCCESS_MSG;
            $scope.showOptions = false;
            $scope.showmessage = true;
        }

        var congratsMsgForADMIN = function() {
            $scope.enableOnboard = true;
            //$scope.contactMsg = AuthorizeConst.MSG_CONGRATS_FOR_ADMIN;
            $scope.desc = AuthorizeConst.SUCCESS_MSG;
            $scope.showOptions = false;
            $scope.showmessage = true;
            //console.log("msg - " + AuthorizeConst.MSG_CONGRATS_FOR_ADMIN);
        }

        //If the profile info is not available then dont proceed
        if( typeof($rootScope.userProfile) != 'undefined' ) {

            var eligibility =  $rootScope.userProfile.v4BElegibleInd;
            var role        =  $rootScope.userProfile.role;
            var provisionStatus = $rootScope.userProfile.v4BProvisioningStatus;
            var v4BID       =  $rootScope.userProfile.v4BID;

            eligibility     = ( eligibility )     ? eligibility.toUpperCase()     : null;
            role            = ( role )            ? role.toUpperCase()            : null;
            provisionStatus = ( provisionStatus ) ? provisionStatus.toUpperCase() : null;

            //If the user is not eligible then return
            if( eligibility == NO ) {
                //msgForUnauthorizedUsers();
                $scope.el_n = true;
                //$scope.messageForOtherRoles = Config.TITLE + " Access Not Allowed";
                msgForOtherRolesCommon();
                return false;
            }

            //If the status is not valid then display the error message
            if( provisionStatus == NO || provisionStatus == E ) {
                $scope.el_err = true;
                //$scope.messageForOtherRoles = AuthorizeConst.MSG_FOR_ERROR_PROVISIONAL_STATUS;
                msgForOtherRolesCommon();
                return false;
            }

            switch( role ) {

                //SPOC
                case SPOC:

                    //provisionStatus.length == 0
                    //If V4BID is not available then enable onboarding and show the state or it is in progress
                    if( typeof(v4BID) != 'undefined' && v4BID.length > 0 )
                    {
                        switch( provisionStatus ) {
                            case INITIAL:
                            case PENDING:
                                congratsMsgForSPOC();
                                break;
                            default:
                                msgForUnauthorizedRoles();
                                break;
                        }

                    } else {
                        initativeStatusForSPOC();
                    }

                    break;

                //Admin
                case ADMIN:

                    //If the uer have a V4BID then congrats message
                    ( typeof(v4BID) != 'undefined' && v4BID.length > 0 ) ? congratsMsgForADMIN() : msgForContactingSPOC();

                    break;

                //Other Roles - Mark as not authorized
                default:

                    switch( provisionStatus ) {
                        case INITIAL:
                        case PENDING:
                            msgContactForOtherRoles();
                            break;
                        default:
                            msgForUnauthorizedUsers();
                            break;
                    }
                    break;
            }   //End of switch

        }   //End of checking the auth part

    }


    /*
    *  Implement Navigate Function
    *
    */
    $scope.navigate = function( option ) {

        window.open('https://www.verizonwireless.com/biz/solutions-and-services/one-talk/','_blank');

    }

    /*
    *  Initiate the functionalities
    *
    */
    function init() {

       declareVariables();

       validateECPD();

    }

    init();

};

authorizeCtrl.$inject = ["$scope", "$rootScope", "AuthorizeConst", "Config", "onboardServices"];
angular.module( window.AppName ).controller("authorizeCtrl", authorizeCtrl);
