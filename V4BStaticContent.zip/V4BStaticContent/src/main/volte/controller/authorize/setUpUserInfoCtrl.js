var setUpUserInfoCtrl = function($scope,$rootScope, $http, $window, $location, ngDialog,$compile,$state,CallWaitingConst,setUpUserConst,setUpUserInfoService,SetUpUserInfoConst, volteServices, Constants) {

    $scope.vzGridTpl = "partials/authorize/vz-grid/vz.grid.setup.uploaduserinfo.html";

    defaultSet   = {};

    $scope.submitBtn = function() {
        uploadFileFn();
    }

    $scope.Browse = function() {
        document.getElementById('fileToUpload').click();
    }

    $scope.updatedValue = function(dropDownRange){
    	$scope.dropDownRangeValue = dropDownRange;
    }



    function uploadFileFn() {

        var API = Constants.API.MUSIC_ON_HOLD;
        var fd = new FormData();

        for (var i in $scope.files) {
            fd.append("bulkUserUpdateFile", $scope.files[i]);
            break;
        }

        fd.append("active", 1);

        $rootScope.ajaxLoading = true;

        var xhr = new XMLHttpRequest();
        xhr.addEventListener("load", angular.bind(null, uploadProgress), false)
        window.addEventListener('error', angular.bind(null,uploadError), true);
        xhr.addEventListener("abort", angular.bind(null, uploadCanceled), false);
        xhr.open("POST", Constants.API_HOST + Constants.API.SETUPUSERINFO_PAGE.UPLOAD_FILE );
        $scope.progressVisible = true;
        xhr.setRequestHeader("X-XSRF-TOKEN", _.last(String(document.cookie.match(/XSRF-Token=([^\s;]*);/gi)).split(';')[0].split('=')));
        xhr.send(fd);

    }


    function uploadError(evt) {

        /*$scope.$apply(function(){
            $rootScope.ajaxLoading = false;
            error( "Upload Failed!" );
        });*/

    }

    function uploadProgress(evt) {

        $scope.$apply(function() {

            //Close the dialog loader
            $rootScope.ajaxLoading = false;

            try {

               /* var xhrSatus = parseInt( evt.target.status );

                //Check the status of the target
                if( xhrSatus == 200 || xhrSatus == 302 ) {*/

                    var result = JSON.parse( evt.target.response );
                    var uploadSuccessful = result.appResult.serviceRepsonse.respList.every(function(item) {
                    	return item.errorCode == "0" || item.errorCode == "00";
                    });
                    if (uploadSuccessful) {

                        success();

                        //Keep the submit button in disabled mode
                        //$scope.musicForm.$pristine = true;

                    } else {

                        //Incase if service is down then display the error message

                        var msg = ( typeof(result.appResult.serviceRepsonse.message) !='' ) ? result.appResult.serviceRepsonse.message : "Upload Failed";
                        error( msg );

                        //Enable the submit button
                        //$scope.musicForm.$pristine = false;

                     }

                    /* }  else {

                    //Incase if any error occured like 404 or 500 then display the error message

                    //Enable the submit button
                    //$scope.musicForm.$pristine = false;

                    error( "Upload Failed!" );

                }*/

            } catch( err ) {

                //Incase if any error occured in JS Response then we display the error response
                console.log("Error -  ", err );

                //Enable the submit button
                //$scope.musicForm.$pristine = false;

                error( "Upload Failed!" );

            }

        });



    }


    function uploadCanceled(evt) {

        var result = JSON.parse( evt.target.response );

        $scope.$apply(function(){
            $rootScope.ajaxLoading = false;
            var msg = "Unable to process request";
            error( msg );
        })
    }

    function uploadComplete( evt, $rootScope ) {
        $rootScope.ajaxLoading = false;
    }

    function success() {

        $scope.msgType  = "success";
        $scope.msgTxt   = "Successfully Uploaded";
        $scope.showMsg  = true;

        $scope.fileName = null;

         $scope.tab = true;

    }

    function error( msg ) {

        msg = msg || "Upload Failed!";

        $scope.msgType = "error";
        $scope.msgTxt  = msg;
        $scope.showMsg = true;

    }

    $scope.downloadTemplate = function( event ) {
        event.preventDefault();
        window.open('./partials/template/template.xlsx');
    }

    $scope.removeFilename = function() {
         document.getElementById('vzMusicForm').reset();
        $scope.fileName = null;
    }

    $scope.getFileInfo = function( element ) {
        if(!$scope.$$phase)
        {
            $scope.$apply(function(){
            getFile(element);
            });
        }
        else
        {
            getFile(element);
        }

    }
    function getFile(element){
       $scope.fileName = element.files[0].name;
       var filenameVal = $scope.fileName
        if(!(filenameVal.indexOf(".xls")>=0 || filenameVal.indexOf(".xlsx")>=0) ){
            $scope.msgType = "error";
            $scope.msgTxt = "The file type must be xls or xlsx.  Please select the correct file and try again";
            $scope.showMsg = true;
            $scope.fileName = null
        }else{
        $scope.files = []
        for (var i = 0; i < element.files.length; i++) {

          $scope.files.push( element.files[i] );
          $scope.theFile.name = element.files[i].name;

        }
        $scope.isValid=true;
        $scope.src=URL.createObjectURL(element.files[0]);
        }
    }
    $scope.setFiles = function( element ) {

        //This helps in preventing from redirction
        var fileStr=element.files[0].type.split("/");
        //if(fileStr[fileStr.length-1].search("wav")!==-1||fileStr[fileStr.length-1].search("wma")!==-1||fileStr[fileStr.length-1].search("xls")!==-1)
        {

            console.log("Files - ", element.files);

            //!$scope.musicForm.$pristine;
            $scope.$apply(function( $scope ) {

                if(element.files[0].size/1024 <= Constants.MAX_FILE_SIZE.MUSIC_ON_HOLD)  {

                    // Turn the FileList object into an Array
                    $scope.files = []
                    for (var i = 0; i < element.files.length; i++) {

                      $scope.files.push( element.files[i] );
                      $scope.theFile.name = element.files[i].name;

                    }

                    $scope.isValid=true;
                    //$scope.musicForm.$pristine = false;
                    $scope.src=URL.createObjectURL(element.files[0]);
                    //$scope.showMsg = false;

                } else {
                    $scope.msgType = "error";
                    $scope.msgTxt = "The audio file you have uploaded is too large for us to process.  Please reduce the file size to 5MB or less and try again";
                    $scope.showMsg = true;
                    //$scope.musicForm.$setPristine();
                }

            });

        }
        /*else {

            $scope.$apply(function(scope) {

                $scope.msgType = "error";
                $scope.msgTxt = "Please choose a file with WAV or WMA extension only";
                $scope.showMsg = true;
                //$scope.musicForm.$pristine = true;
                $scope.theFile.name = null;

                console.log($scope.showMsg);

             });
        }*/


    };

    $scope.callgetData = function(dateRangUpdateVal,searchVal,filterBy){
        $scope.manage_schedule_filter_selected = dateRangUpdateVal;
        console.log(searchVal,filterBy);
        var params = {"dateRange":dateRangUpdateVal};
        var searchFilter ={"searchFieldValue":searchVal,"lineNumber":"N","userName":"N","status":"N","deviceId":"N"};
        if(!!searchVal){
            filterBy == 'userName'?searchFilter.userName = 'Y':searchFilter.lineNumber = 'Y';
            params.searchFilter = searchFilter;
        }
    	getData(params,true);
    }

    function getData(params,forceCall) {
        //var params = {"filter": {"status": "","type": "","searchKeyword": ""},"paging": {"offset": -1 ,"limit": -1}, "sort": {"name": "","direction": ""},"dateRange":dateRangUpdateVal};
        setUpUserInfoService.loadList(params,forceCall)
            .then(serviceResponseHandler)
            .catch(errorHandler)
            .then(function() {
                $scope.loadFlag = false;
            });
        console.log($scope.collection);
      //  $rootScope.ajaxLoading = false;
   	 //	$scope.progressVisible = false;

    }

    $scope.lookupDialog = function(phoneNumber) {

        var newScope = $scope.$new();
        newScope.phoneNo =phoneNumber;
        console.log($rootScope.phoneNo);
        var new_dialog = ngDialog.open({ template: 'partials/components/dialog/userFeatures/directedCallBargeIn.html',
            closeByDocument: false,
            closeByEscape: false,
            scope: newScope
        });

    }

    $scope.displayFirstTab = function() {

        if( $scope.tab == true ) {
            return "vz-show";
        } else {
            return "vz-hide";
        }
    }

    $scope.displaySecondTab = function() {

        //initiateErrorMsgs();
        if( $scope.tab != true ) {
            return "vz-show";
        } else {
            return "vz-hide";
        }
    }

    $scope.activateFirstTab = function( index ) {

        if( $scope.tab == true ) {
            return "selected";
        } else {
            return "";
        }
    }

    $scope.activateSecondTab = function( index ) {

        if( $scope.tab == false ) {
            return "selected";
        } else {
            return "";
        }
    }


    /*$scope.downloadDataFile = function( event, option ) {

        if( !option ) {
            window.open('./partials/template/template.xlsx');
        } else {
            var params  = {};
            params.excelType = "exportTypePreAuth";

            volteServices.setOption( Constants.API.SETUPUSERINFO_PAGE.DOWNLOAD_ICON );
            volteServices.postData( params ).success(function( response ){

                if(response.appHeader.statusCode == "OK") {
                    console.log("Get Line Data : Success");
                } else {
                    $scope.msgType  = "error";
                    $scope.msgTxt   = result.appHeader.statusMessage;
                    $scope.showMsg  = true;

                }

            });
        }

    }*/

    $scope.downloadDataFile = function( event, option ) {
    	//alert("upload_filter_selected>>"+$scope.dropDownRangeValue);

        if( !option ) {
            //window.open('./partials/template/User_Information_Template.xls');
        	$scope.downloadFile();
        } else {
        	$scope.downloadFile($scope.dropDownRangeValue);
        }

    }



	    $scope.downloadFile = function(downloadRangeSel) {
	    	//alert("downloadRangeSel>>"+downloadRangeSel);
	    	//$scope.loadFlag = true;
    	var params  = {};
        params.excelType = "exportTypeUserInfo";
        params.dateRange = downloadRangeSel;
        var dateVal = new Date();

        var userInfoForDownloadList=[];
        for(var i=0;i<$scope.collection.length;i++){
           if($scope.collection[i].Selected == true)
           {
        	   userInfoForDownloadList.push({
                          "lineNumber": $scope.collection[i].lineNumber,
                          "userName":$scope.collection[i].userName,
                          "subscriberEmail":$scope.collection[i].subscriberEmail,
                          "contactNumber":$scope.collection[i].contactNumber,
                          "ext":$scope.collection[i].ext,
                          "callingIdName":$scope.collection[i].callingIdName
                        });
           }
        };
        params.userInfoData = userInfoForDownloadList;

        $http({
    	    url: window.APP_HOST + Constants.API.SETUPUSERINFO_PAGE.DOWNLOAD_ICON,
    	    method: "POST",
    	    data: params, //this is your json data string
    	    headers: {
    	       'Content-type': 'application/json'
    	    },
    	    responseType: 'arraybuffer'
    	}).success(function (data, status, headers, config) {
    		$scope.loadFlag = false;
    	    var blob = new Blob([data], {type: "application/vnd.ms-excel;charset=utf-8"});
    	    saveAs(blob, 'DownloadList_exportTypeUserInfo.xls');
    	    //saveAs(blob, 'DownloadList_' + $scope.downloadType + dateVal + '.xls');
    	    /*var objectUrl = URL.createObjectURL(blob);
    	    window.open(objectUrl);*/
    	}).error(function (data, status, headers, config) {
    	    //downnload failed
    	});

    }


    $scope.submitSetUp = function() {
        console.log("submit called")
        var compareJSON = function(obj1, obj2) {
            var ret = {};
            for(var i in obj2) {
                if(!obj1.hasOwnProperty(i) || obj2[i] !== obj1[i]) {
                    ret[i] = obj2[i];
                }
            }
            return ret;
        };

        var data   = [];
        var params = {};

        if( $scope.collection.length > 0 && defaultSet.length > 0 ) {

            for(loop=0; loop < defaultSet.length; loop++) {

                var diffObj = compareJSON(defaultSet[loop], $scope.collection[loop]);

                var ObjLen = 0;
                ObjLen = Object.keys( diffObj ).length || 0;

                if( ObjLen > 1 )  {

                    var dataSet                 = {};
                    dataSet.lineNumber          = diffObj.lineNumber        ||  $scope.collection[loop].lineNumber      || "";
                    dataSet.userName            = diffObj.userName          ||  $scope.collection[loop].userName        || "";
                    dataSet.ext                 = diffObj.ext               ||  $scope.collection[loop].ext             || "";
                    dataSet.callingIDname       = diffObj.callingIdName     ||  $scope.collection[loop].callingIdName   || "";
                    //dataSet.emailAddress        = diffObj.emailAddress    ||  $scope.collection[loop].emailAddress;
                    //dataSet.subscriberEmail     = diffObj.subscriberEmail ||  $scope.collection[loop].subscriberEmail;
                    dataSet.emailAddress        = diffObj.subscriberEmail   ||  $scope.collection[loop].subscriberEmail || "";

                    data.push( dataSet );

                }

            }

        }

        params.userUpdateInfoList = data;

        volteServices.setOption( Constants.API.SETUPUSERINFO_PAGE.UPDATE_USER_INFO );
        volteServices.postData( params ).success(function( response ){

            if(response.appHeader.statusCode == "OK") {
                $scope.showMsg  = true;
                $scope.msgType  = "success";
                $scope.msgTxt   = "Successfully Updated!";

                //$scope.updateUserInfoFrm.$pristine = true;

            } else {

                $scope.showMsg  = true;
                $scope.msgType  = "error";
                $scope.msgTxt   = response.appHeader.statusMessage;

            }

        });

    }

    /*************************************************************/
    /**
         * Paginate previous page
         *
         * @method     prev
         */
    $scope.prev = function() {
        //toggleSelect(false);
        setUpUserInfoService.prevPage()
            .then(serviceResponseHandler)
            .catch(errorHandler);
    };

    /**
     * Paginate next page
     *
     * @method     next
     */
    $scope.next = function() {
        //toggleSelect(false);
        setUpUserInfoService.nextPage()
            .then(serviceResponseHandler)
            .catch(errorHandler);
    };

    /**
     * Update page size and refresh
     *
     * @method     setPageSize
     * @param      {Number}  value   Rows per page value
     */
    $scope.setPageSize = function(value) {
        //toggleSelect(false);
        setUpUserInfoService.setPageSize(value)
            .then(serviceResponseHandler)
            .catch(errorHandler);
    };

    /**
     * Performs filter operation
     *
     * @method     filter
     * @param      {String}  filterBy  The type by which to filter against (business or holiday)
     */
    $scope.filter = function(filterBy) {
        //toggleSelect(false);
        console.log(filterBy)
        setUpUserInfoService.filter(filterBy)
            .then(serviceResponseHandler)
            .catch(errorHandler);
    };
    /**
     * Performs search operation
     *
     * @method     search
     * @param      {String}  searchQuery
     */
    $scope.search = function (searchQuery,searchFilter,$event,dateRangUpdateVal) {
        console.log($scope.manage_schedule_filter_selected);
        if(setUpUserInfoService.getOperationType() ==='server' || setUpUserInfoService.getServerSearchValue())
        {
           var isClickedEnterVal = $event == undefined ? $event : $event.which;
           if(isClickedEnterVal === 13 ||isClickedEnterVal == undefined)
            {
                console.log("clicked enter")
                searchFunc(searchQuery,searchFilter,$scope.manage_schedule_filter_selected);
            }
        }
        else
        {
           searchFunc(searchQuery,searchFilter,$scope.manage_schedule_filter_selected);
        }
    };
    function searchFunc(searchQuery,searchFilter,dateRangUpdateVal){
        console.log(dateRangUpdateVal);
        setUpUserInfoService.search(searchQuery,searchFilter,dateRangUpdateVal)
            .then(serviceResponseHandler)
            .catch(errorHandler);
        // var params = {"filter": {"status": "","type": "","searchKeyword": searchQuery},"paging": {"offset": -1 ,"limit": -1}, "sort": {"name": "","direction": ""},"dateRange":$scope.manage_schedule_filter_selected};
        // getData(params,true);
        // return searchQuery;
    }
    function errorHandler(err) {
        $scope.loadFlag = false;
        $scope.msgType = 'error';
        $scope.msgTxt = err.message || 'An unknown error has occured';
        $scope.showMsg = true;
    }

    function successHandler(message) {
        $scope.msgType = 'success';
        $scope.msgTxt = message;
        $scope.showMsg = true;
    }
    function serviceResponseHandler(response) {
        $scope.selectAll = false;
        $scope.collection = setUpUserInfoService.getList();
        console.log($scope.collection)
        defaultSet        = angular.copy( $scope.collection );
        $scope.count = setUpUserInfoService.getCount();
        $scope.pageSize = setUpUserInfoService.getPageSize();
        $scope.pagesLength = setUpUserInfoService.getPagesLength();
        $scope.currentPage = setUpUserInfoService.getCurrentPage();
        $scope.length = setUpUserInfoService.getLength();
        $scope.total = setUpUserInfoService.getTotal();
        $scope.noRecordsMessage = $scope.total === 0 ? "No Records Found" : "The schedule cannot be found.";
        $scope.serverSearch = false;
        $scope.serverSearch = setUpUserInfoService.getServerSearchValue();
        // $scope.isEnableAll = isEnabled();
        // $scope.isDisableAll = isDisabled();
        // console.log('sdfsff' + $scope.isEnableAll, $scope.isDisableAll)
        // console.log('enabled' + $scope.isAllEnabled);
        return response;
    }
    function loadList(){
       setUpUserInfoService.loadList({})
            .then(serviceResponseHandler)
            .catch(errorHandler)
            .then(function() {
                $scope.loadFlag = false;
            });
        console.log($scope.collection);
        // setUpUserInfoService.loadList({})
        //     .then(serviceResponseHandler)
        //     .catch(errorHandler)
        //     .then(function() {
        //         $scope.loading = false;
        //     });
        // console.log($scope.collection);
    }
    /*************************************************************/
    function init() {

        //Initialize Variables
        $scope.loadFlag     =  true;
        $scope.fileName = null;
        $scope.collection = {};
        $scope.numberOfSchedules;
        $scope.modelChanged = true;
        $scope.manage_schedule_filter = SetUpUserInfoConst.MANAGE_FILTER;
        $scope.manage_schedule_filter_selected = "30";
        $scope.upload_filter_selected = "30";

        $scope.pageTitle =setUpUserConst.pageTitle;
        $scope.pageDesc = setUpUserConst.pageDesc;
        $scope.dropDownRangeValue = "30";
        $scope.searchFilterArr = [  {   name: "Phone Lines",
                                        value: "phoneNumber"
                                    }, {
                                        name: "User Name",
                                        value: "userName"
                                }];
        $scope.searchFilter = 'phoneNumber';
        $scope.searchField = 'phoneNumber';
        var params = {"dateRange":$scope.manage_schedule_filter_selected};
        serviceResponseHandler();
        getData(params);

    }

    init();

};


setUpUserInfoCtrl.$inject = ["$scope","$rootScope", "$http", "$window", "$location", "ngDialog", "$compile", "$state","CallWaitingConst","setUpUserConst","setUpUserInfoService","SetUpUserInfoConst", "volteServices", "Constants"];
angular.module( window.AppName ).controller("setUpUserInfoCtrl", setUpUserInfoCtrl);

