(function() {
    var MobileDevicesCtrl = function($scope, devicesService, linesConst) {
        var abstracts = $scope.abstracts,
            batchSize = 20;

        devicesService.setPageSize(batchSize);

        /**
         * Getter for the service
         *
         * @returns {Service}  lines service singleton
         */
        abstracts.getService = function() {
            return devicesService;
        };

        /**
         * Determines if we should reset $scope.list[] based on the operation
         */
        abstracts.beforeLoad = function(operation) {
            if ($scope.initialized && operation !== 'next') {
                devicesService.setPageSize(batchSize);
            }

            if (operation === 'init') {
                $scope.loading = true;
            }
        };

        /**
         * Determines if we should show or hide the "Loading More" indicator
         */
        abstracts.onLoad = function(operation) {
            var length = devicesService.getLength();

            $scope.hideLoadMore = $scope.list.length === length;

            if (operation === 'init') {
                $scope.loading = false;
            }
        };

        abstracts.errorHandler = function(err) {
            $scope.showMsg = true;
            $scope.msgType = 'error';
            $scope.msgTxt = err.message || "Error performing operation";
        };

        abstracts.successHandler = function (message) {
            $scope.showMsg = true;
            $scope.msgType = 'success';
            $scope.msgTxt = message;
        };

        /**
         * Default values for dropdowns
         */
        $scope.actions = linesConst.DEVICES_ACTIONS;
        $scope.linesFilter = linesConst.DEVICES_FILTER;

        /**
         * Event listeners
         */
        $scope.$watch('searchQuery', abstracts.search); // TODO: Should wait for the "Enter" key
        $scope.$watch('filterBy', abstracts.filter);

        /**
         * Gets executed when the scroll position reaches the "Loadinging More" text
         *
         * @param {Boolean}  loadMoreVisible
         */
        $scope.onLoadMoreChange = function(loadMoreVisible) {
            if (loadMoreVisible) {
                setTimeout(function() {
                    var pageSize = devicesService.getPageSize();

                    pageSize += batchSize;

                    abstracts.setPageSize(pageSize);
                }, 300);
            }
        };

        /**
         * Gets executed when the user selects an item from the "Actions" field
         *
         * It's ABSOLUTELY necessary to reset the value of $scope.selectedAction to an
         * empty string ("").
         *
         * @param {String} value - Selected value
         */
        $scope.onActionSelect = function(value) {
            $scope.selectedAction = '';
            console.log(value);
        };

        /**
         * Used to parse the status value to the desirable output
         *
         * @param {String} status - Device status
         * @returns {String} output
         */
        $scope.parseStatus = function(status) {
            switch ((status || '').toLowerCase()) {
                case 'enable':
                    return 'Enabled';
                case 'disabled':
                case 'inactive':
                    return 'Inactive';
            }
            return status;
        };

        /**
         * Kick off the list load service
         */
        abstracts.init();
    };

    MobileDevicesCtrl.$inject = ['$scope', 'devicesService', 'linesConst'];

    angular.module(window.AppName).controller('MobileDevicesCtrl', MobileDevicesCtrl);

})();