(function() {
    var AbstractCtrl = function($scope, $http, ngDialog, Constants, $state, cache, $rootScope) {
        // What should the logic be here?
        var platform = window.innerWidth <= 480 ? 'mobile' : 'desktop';
        $scope.type = 'lines';
        $scope.imgHost = "http://ss7.vzw.com";
        var searchField;
        // console.log(cache.get('fromOverviewPage'))
        /**
         * Placeholder for abstract methods. These may or may not be
         * used by the the views, but is necessary to be bound to the $scope
         * so that the abstract methods can be overwritten by implementing
         * sub-controllers.
         */
        $scope.abstracts = {
            /**
             * Basic initializer
             */
            init: function() {
                console.log('init');
                var abstracts = $scope.abstracts,
                    service = abstracts.getService(),
                    params = {};

                $scope.searchQuery = service.getSearchQuery();
                console.log($scope.searchQuery);
                $scope.filterBy = service.getFilter();
                $scope.selectAll = false;
                $scope.loadFlag = true;
                $scope.loadFlags = true;
                //abstracts.beforeLoad('init');
                abstracts.getTransactionLink();
                service.loadList(params)
                    .then(function(){
                        abstracts.serviceResponseHandler();
                    })
                    .catch(abstracts.errorHandler)
                    .then(function() {
                        //abstracts.onLoad('init');
                        console.log($scope.loadFlag)
                        $scope.initialized = true;
                        $scope.loadFlag = false;
                        $scope.loadFlags = true;
                        $scope.serverSearch = service.getServerSearchValue();
                        console.log($scope.serverSearch)
                        $scope.operationType = service.getOperationType();
                        console.log($scope.operationType);
                    });
            },
            /**
             * Getter for the individual service singleton
             *
             * @abstract
             * @returns {Service}
             */
            getService: function() {
                throw new Error("The getService() abstract method has not been implemented");
            },

            /**
             * Executes before making a service request
             *
             * @abstract
             */
            beforeLoad: function() {},

            /**
             * Executes after the service request gets processed
             *
             * @abstract
             */
            onLoad: function() {},

            /**
             * Process the returned values
             */
            serviceResponseHandler: function() {
                var abstracts = $scope.abstracts,
                    service = abstracts.getService();

                $scope.list = service.getList();
                $scope.serverSearch = service.getServerSearchValue();
                console.log($scope.list)
                console.log($scope.serverSearch)
                $scope.count = service.getCount();
                $scope.pageSize = service.getPageSize();
                $scope.pagesLength = service.getPagesLength();
                $scope.currentPage = service.getCurrentPage();
                $scope.length = service.getLength();
                $scope.total = service.getTotal();
            },
            setSearch: function(searchQuery){
               searchField = searchQuery;
               console.log(searchField);
            },

            /**
             * Basic Error Handler
             *
             * @abstract
             * @param {Error} error - The error instance
             */
            errorHandler: function() {
                throw new Error("The errorHandler() abstract method has not been implemented");
            },

            /**
             * Basic Success Handler
             *
             * @abstract
             * @param {String} message - The success message
             */
            successHandler: function() {},

            /**
             * Event handler for the "reload" or "refresh" button that will force
             * the lines service to purge existing data and fetch new ones
             */
            refresh: function() {
                var abstracts = $scope.abstracts,
                    service = abstracts.getService();

                abstracts.beforeLoad('refresh');

                service.reload()
                    .then(abstracts.serviceResponseHandler)
                    .catch(abstracts.errorHandler)
                    .then(function() {
                        abstracts.onLoad('refresh');
                    });
            },

            /**
             * Wrapper function for the configured service to get the previous page
             */
            prev: function() {
                var abstracts = $scope.abstracts,
                    service = abstracts.getService();

                abstracts.beforeLoad('prev');

                service.prevPage()
                    .then(abstracts.serviceResponseHandler)
                    .catch(abstracts.errorHandler)
                    .then(function() {
                        abstracts.onLoad('prev');
                    });
            },

            /**
             * Wrapper function for the configured service to get the next page
             */
            next: function() {
                var abstracts = $scope.abstracts,
                    service = abstracts.getService();

                abstracts.beforeLoad('next');

                service.nextPage()
                    .then(abstracts.serviceResponseHandler)
                    .catch(abstracts.errorHandler)
                    .then(function() {
                        abstracts.onLoad('next');
                    });
            },

            /**
             * Sets the pagination page size
             */
            setPageSize: function(value) {
                var abstracts = $scope.abstracts,
                    service = abstracts.getService();

                abstracts.beforeLoad('pagesize');

                service.setPageSize(value)
                    .then(abstracts.serviceResponseHandler)
                    .catch(abstracts.errorHandler)
                    .then(function() {
                        abstracts.onLoad('pagesize');
                    });
            },
            getTransactionLink: function(){
               //console.log('qwqwqw',$rootScope.EPAMLink.indexOf())
               if( $rootScope.EPAMLink.indexOf() ) {
                console.log($rootScope.EPAMLink)
                var transLinkArr  = window.EPAMLink.split("?");
                    $scope.NavLink    = transLinkArr[0] + "#transactionHistory";
                } else {
                    $scope.NavLink    = window.EPAMLink + "#transactionHistory";
                }

                // Commented bacause it causes "Page not found" error
                // Back URL not needed for EPAM
                // Redirect with back URL
/*
                var currentUrlPath = window.location.href;
                var redirectUrlPath = $scope.NavLink;
                $scope.NavLink = redirectUrlWithReturnURL(redirectUrlPath, currentUrlPath, Constants.API.REDIRECT_URL_PATHS.split_At);
*/
            },
            /**
             * Search wrapper
             *
             * @param {String} query - The combined search query string
             */
            search: function(query,filterBy) {
                var abstracts = $scope.abstracts,
                    service = abstracts.getService();
                abstracts.beforeLoad('search');

                service.search(query,searchField,filterBy)
                    .then(abstracts.serviceResponseHandler)
                    .catch(abstracts.errorHandler)
                    .then(function() {
                        console.log(query);
                        abstracts.onLoad('search');
                    });
            },

            /**
             * Filter wrapper
             *
             * @param {String} filterBy - The string key by which to filter
             */
            filter: function(filterBy,query) {
                var abstracts = $scope.abstracts,
                    service = abstracts.getService();

                abstracts.beforeLoad('filter');
                service.filter(filterBy,query,searchField)
                    .then(abstracts.serviceResponseHandler)
                    .catch(abstracts.errorHandler)
                    .then(function() {
                        abstracts.onLoad('filter');
                    });
            },
            counterVal: function(val) {
                $scope.counterVal = val;
                return $scope.counterVal;
            },
            initialPageLoad:function()
            {
                var abstracts = $scope.abstracts,
                    service = abstracts.getService();
                $scope.list = [];
                $scope.pageSize = 10;
                $scope.pagesLength = 0;
                $scope.currentPage = 1;
                $scope.length = 0;
                $scope.total = 0;
                $scope.searchQuery = service.getSearchQuery();
                $scope.filterBy = service.getFilter();
                $scope.selectAll = false;
            }
        };

        /**
         * Util functions
         */
        var counterval;
        $scope.util = {
            tel: function(input) {
                return (input + '').replace(/(\d{3})(\d{3})(\d{4})/, '$1-$2-$3');
            },
            titlecase: function(input) {
                var words = [];

                if (typeof input === 'string') {
                    words = input.split(" ");
                    for (var i = 0, ln = words.length; i < ln; i++) {
                        words[i] = words[i].charAt(0).toUpperCase() + words[i].substr(1).toLowerCase();
                    }
                }

                return words.join(" ");
            }
        };
        // console.log($state.params.type);
        $scope.fromOverviewPage = cache.get('fromOverviewPage');
        if ($scope.fromOverviewPage) {
            $scope.type = $scope.fromOverviewPage;
            //cache.remove('fromOverviewPage', null);
        } else {
            $scope.tplUrl = 'partials/lines-devices/lines.html';
        }
        //$scope.type = 'lines';
        $scope.$watch('type', function(value) {
            if (platform === 'mobile') {
                if (value == 'devices') {
                    $scope.tplUrl = 'partials/lines-devices/mobile/devices.html';
                } else if (value === 'lines') {
                    $scope.tplUrl = 'partials/lines-devices/mobile/lines.html';
                }
            } else {
                if (value == 'devices') {
                    $scope.tplUrl = 'partials/lines-devices/devices.html';
                } else if (value === 'lines') {
                    $scope.tplUrl = 'partials/lines-devices/lines.html';
                }
            }
        });

        /**
         * Event listener for accordion expand/collapse button
         *
         * We're going to maintain the "expanded" state internally within the
         * model instance itself.  This way we don't have to make redundant
         * requests.
         *
         * @param {Object} record - The model instance
         */
        $scope.toggleAccordion = function(record) {
            var abstracts = $scope.abstracts,
                service = abstracts.getService();

            record.expanded = !record.expanded;

            if (record.expanded) {
                record.loading = true;
                service.loadAssociatedDevices(record)
                    .then(function() {
                        record.loading = false;
                    })
                    .catch(abstracts.errorHandler)
                    .catch(function() {
                        record.loading = false;
                    });
            }
        };

        /**
         * Toggles the lines vs. devices values
         */
        $scope.toggleType = function() {
            $scope.type = $scope.type === 'lines' ? 'devices' : 'lines';
        };

        /**
         * Opens a dialog box to add a new device
         */
        $scope.addNewDevice = function(record) {
            console.log(record)
            var lineData = {
                associatedDeviceInfo: record
            }
            var new_dialog = ngDialog
                .open({
                    template: 'partials/components/dialog/addNewDevice.html',
                    closeByDocument: false,
                    closeByEscape: false,
                    template: 'partials/components/dialog/addNewDevice.html',
                    scope: $scope,
                    data: lineData,
                    controller: 'addNewDeviceCtrl'
                });
        };

        /**
         * Used by the template to set the "disabled" attribute of the checkbox
         */
        $scope.disableOnACL = function(type) {
            return String(type).toLowerCase() === 'employee';
        };
        $scope.fallBackImg = function(deviceType, icon,
                    isVirtualDevice) {

                    if (!icon && deviceType) {

                        switch (deviceType.toLowerCase()) {

                            case 'smartphone':
                                return 'smartphone-missing';
                                break;
                            case 'deskphone':
                                if (isVirtualDevice) {
                                    return 'bridged-with-admin';
                                } else {
                                    return 'desktop-missing';
                                }

                                break;
                            case 'yealink':
                                break;

                            case 'ott' :
                                return 'ipad-missing' ;
                                break;
                        }
                    }
                }
        /**
         * Used by the template to download the list to an excel spreadsheet
         */
        $scope.downloadFile = function(params,type,urlType) {
            console.log($scope.type);
            // var urlType = type=='downloadPdf'?Constants.API.LINES_PAGE.DOWNLOADPDF:;
            $http({
                url: window.APP_HOST + urlType,
                method: "POST",
                data: params,
                headers: {
                    'Content-type': 'application/json'
                },
                responseType: 'arraybuffer'
            }).success(function(data, status, headers, config) {
                if(type=='downloadPdf')
                {
                    var blob = new Blob([data], {
                        type: "application/pdf;charset=utf-8"
                    });
                    saveAs(blob, 'DownloadList_' + $scope.type + '.pdf');
                }
                else
                {
                    var blob = new Blob([data], {
                        type: "application/txt;charset=utf-8"
                    });
                    saveAs(blob, 'DownloadList_' + $scope.type + '.csv');
                }
                // saveAs(new Blob([data], {type: "application/vnd.ms-excel;charset=utf-8"}), $scope.type  + '.xls');
            }).error(function(data, status, headers, config) {
                //upload failed
                console.error('An error has occured with the download request');
            });

            //   $http({
            //     url: window.APP_HOST + Constants.API.SETUPUSERINFO_PAGE.DOWNLOAD_ICON,
            //     method: "POST",
            //     data: params, //this is your json data string
            //     headers: {
            //        'Content-type': 'application/json'
            //     },
            //     responseType: 'arraybuffer'
            // }).success(function (data, status, headers, config) {
            //     //var blob = new Blob([data], {type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"});
            //     //var blob = new Blob([data], {type: "application/vnd.ms-excel"});
            // var blob = new Blob([data], {type: "application/vnd.ms-excel;charset=utf-8"});
            //     saveAs(blob, 'DownloadList_' + $scope.downloadType  + '.xls');
            //     //saveAs(blob, 'DownloadList_' + $scope.downloadType + dateVal + '.xls');
            //     /*var objectUrl = URL.createObjectURL(blob);
            //     window.open(objectUrl);*/
            // }).error(function (data, status, headers, config) {
            //     //upload failed
            // });
        };
    };

    function isTouchSupported() {
        var msTouchEnabled = window.navigator.msMaxTouchPoints,
            generalTouchEnabled = 'ontouchstart' in window;

        return !!(msTouchEnabled || generalTouchEnabled);
    }

    AbstractCtrl.$inject = ['$scope', '$http', 'ngDialog', 'Constants', '$state', 'cache', '$rootScope'];

    angular.module(window.AppName).controller('LinesDevicesCtrl', AbstractCtrl);

})();