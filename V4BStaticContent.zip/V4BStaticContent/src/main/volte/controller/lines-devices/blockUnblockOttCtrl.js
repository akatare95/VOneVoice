var blockUnblockOttCtrl = function ($scope,dropdownValueConst,linesService) {
   var constType=$scope.ottType.toUpperCase();
   $scope.EPAMLink=window.EPAMLink;
   $scope.blockUnblockLine=function(){
      var blockOTTIndicator=constType=='UNBLOCKMOBILE'?'N':'Y';
      var submitParams={"mtnList":$scope.ottBlockUnblockList,"blockOTTIndicator":blockOTTIndicator};
      console.log(submitParams);
      linesService.postBlockUnblockOtt(submitParams).
        then(function (result) {
          console.log(result);
          $scope.transactionId=result.serviceHeader.transactionId;
          $scope.confirmationNumber = result.serviceBody.serviceResponse.confirmationNumber ;
          $scope.thankuTxtDrop=dropdownValueConst[constType][0].thankuTxt;
          $scope.msgTxtDrop=dropdownValueConst[constType][0].pageSuccessTxt;
          $scope.msgTypeDrop='success';
          $scope.$parent.showMsg = false;
          confirmationOtt();
          $scope.$parent.ottCalling=$scope.$parent.ottCalling == 'Unblocked' ? 'Blocked' : 'Unblocked';
          // $scope.$parent.selectedAction='';
        },
        function(reason){
          console.log(reason);
          //console.log($scope.ottCalling);
          $scope.thankuTxtDrop=reason;
          $scope.msgTxtDrop='';
          $scope.msgTypeDrop='error';
          $scope.$parent.showMsg = false;
          confirmationOtt();
          //console.log(reason);
          // $scope.$parent.selectedAction='';
        });
   };
   function confirmationOtt(){
      $scope.confirmation=true;
      $scope.showWarning=false;
      $scope.showMsgDrop=true;
   }
   function warningOtt(){
      $scope.confirmation=false;
      $scope.showWarning=true;
      $scope.showMsgDrop=true;
   }
   function initOtt(){
    if($scope.ottType=='unblockmobile')
    {
      console.log($scope.test);
      $scope.blockUnblockLine();
    }
    else
    {
      warningOtt();
      $scope.bulkInfo=$scope.ottBlockUnblockList;
      $scope.hideLines=true;
      $scope.msgTypeDrop='error';
      console.log($scope.ottType);
      $scope.alertMsg=dropdownValueConst[constType][0].pageAlertTxt;
      if($scope.bulkInfo.length==1)
      {
         $scope.msgTxtDrop=dropdownValueConst[constType][0].pageConfirmationTxt;
      }
      else if($scope.bulkInfo.length>1)
      {
        $scope.msgTxtDrop=dropdownValueConst[constType][0].pageBulkConfirmationTxt;
      }
    }
   }
   initOtt();
 };
    blockUnblockOttCtrl.$inject = ['$scope', 'dropdownValueConst', 'linesService'];

    angular.module(window.AppName).controller('blockUnblockOttCtrl', blockUnblockOttCtrl);
