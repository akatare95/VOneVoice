(function() {
    var DesktopLinesCtrl = function($scope, linesService, linesConst, ngDialog, cache, Constants) {
        var abstracts = $scope.abstracts;
        //abstracts.getTransactionLink();
         if(linesService.getOperationType() !== 'server')
         {
            linesService.setPageSize(10);
         }
         $scope.searchFilter = "phoneNumber";
        /**
         * Getter for the service
         *
         * @returns {Service}  lines service singleton
         */
        abstracts.getService = function() {
            return linesService;
        };

        /**
         * Gets executed before the request gets proxied
         * to the service. Used to un-select all the records
         * that may have been selected BEFORE the operation
         * takes place (i.e. pagination)
         */
        abstracts.beforeLoad = function(operation) {
            toggleSelect(false);

            if (operation === 'init') {
                $scope.loading = true;
            }
        };

        /**
         * Gets executed after the request gets proxied
         * to the service. Used to un-select the master
         * checkbox
         */
        abstracts.onLoad = function(operation) {
            $scope.selectAll = false;

            if (operation === 'init') {
                $scope.loading = false;
            }
        };

        abstracts.errorHandler = function(err) {
            $scope.showMsg = true;
            $scope.msgType = 'error';
            $scope.msgTxt = err.message || "Error performing operation";
        };

        abstracts.successHandler = function (message) {
            $scope.showMsg = true;
            $scope.msgType = 'success';
            $scope.msgTxt = message;
        };

        /**
         * Default values for dropdowns
         */
        $scope.actions = linesConst.LINES_ACTIONS;
        $scope.linesFilter = linesConst.LINES_FILTER;
        $scope.downloadActions = linesConst.DOWNLOAD;

        /**
         * Event listeners
         */
        // abstracts.serviceResponseHandler();
        $scope.searchFunc= function(searchQuery,$event){
            console.log('inside ng-change')
            console.log($scope.filterBy)
            abstracts.setSearch($scope.searchFilter);
            if(linesService.getOperationType() === 'server' || linesService.getServerSearchValue())
            {
                console.log(searchQuery);
                var isClickedEnterVal = $event == undefined ? $event : $event.which;
                console.log(isClickedEnterVal);
                if(isClickedEnterVal === 13 ||isClickedEnterVal == undefined)
                {
                    abstracts.search(searchQuery,$scope.filterBy);
                }
            }
            else
            {
                abstracts.search(searchQuery);
            }
        };
        $scope.clearSearch = function(){
            $scope.searchQuery='';
            $scope.searchFunc($scope.searchQuery);
        }
        // $scope.$watch('searchQuery', function(newVal,oldVal){
        //     //console.log(linesService.getOperationType())
        //     if(newVal !== undefined && newVal !== null && newVal !== '')
        //     {
        //       console.log(linesService.getOperationType());
        //       abstracts.search(newVal);
        //     }
        // }); // TODO: Should wait for the "Enter" key
        // $scope.searchFunc=function(searchQuery,$event){
        //     if(linesService.getOperationType() !== 'server')
        //     {
        //        abstracts.search(searchQuery);
        //     }
        //     else
        //     {
        //         if($event.which === 13)
        //         {
        //             abstracts.search(searchQuery);
        //         }
        //     }
        // }
        $scope.filterFunc= function(value){
            // $scope.searchQuery = '';
            abstracts.setSearch($scope.searchFilter);
            abstracts.filter(value,$scope.searchQuery);
        };
        // $scope.$watch('filterBy', function(newVal,oldVal){
        //     if(newVal !== undefined && newVal !== null && newVal !== '' )
        //     {
        //       abstracts.filter(newVal);
        //     }
        // });
        $scope.$watch('selectAll', toggleSelect);

        /**
         * Columns
         *
         * Represents the fields/columns that will be visible/hidden
         * from view.  Also serves as the lexicon for which to translate
         * to the desired language (currently only English)
         */
        var columnsList = [{
            visible: true,
            id: 'ext',
            name: 'Ext',
            getVisiblity: function() {
                return 'tablet';
            },
            getName: function(lang) {
                var lexicon = {
                    en: 'Ext'
                };
                return lexicon[lang || 'en'];
            },
            getValue: function(record) {
                return record.ext;
            }
        }, {
            visible: true,
            id: 'userName',
            name: 'User Name',
            getVisiblity: function() {
                return '';
            },
            getName: function(lang) {
                var lexicon = {
                    en: 'User Name'
                };
                return lexicon[lang || 'en'];
            },
            getValue: function(record) {
                return $scope.util.titlecase(record.userName);
            }
        }, {
            visible: true,
            id: 'status',
            name: 'Status',
            getVisiblity: function() {
                return 'phone';
            },
            getName: function(lang) {
                var lexicon = {
                    en: 'Status'
                };
                return lexicon[lang || 'en'];
            },
            getValue: function(record) {
                return $scope.util.titlecase(record.status);
            }
        }, {
            visible: true,
            id: 'type',
            name: 'Type',
            getVisiblity: function() {
                return 'phone';
            },
            getName: function(lang) {
                var lexicon = {
                    en: 'Type'
                };
                return lexicon[lang || 'en'];
            },
            getValue: function(record) {
                return $scope.util.titlecase(record.type);
            }
        }, {
            visible: true,
            id: 'associatedDeviceCount',
            name: '#Associated Devices',
            getVisiblity: function() {
                return 'tablet';
            },
            getName: function(lang) {
                var lexicon = {
                    en: '#Associated Devices'
                };
                return lexicon[lang || 'en'];
            },
            getValue: function(record) {
                var count = parseInt(record.associatedDeviceCount, 10) || 0;

                return count + ' ' + (count === 1 ? 'Device' : 'Devices');
            }
        }];
        $scope.availableLines = [];
        $scope.columns = columnsList;
        $scope.models = {
            selected: null,
            lists: {
                "availableLine": $scope.availableLines,
                "selectedLines": $scope.columns.slice()
            },
            defaultCheck: true,
            selectedRecord: 10,
            dropdownList: [{
                name: "10 Records Per Page",
                value: 10
            }, {
                name: "20 Records Per Page",
                value: 20
            }, {
                name: "30 Records Per Page",
                value: 30
            }, {
                name: "50 Records Per Page",
                value: 50
            }, {
                name: "100 Records Per Page",
                value: 100
            }]
        };
        $scope.$watch('models.defaultCheck', function(newVal) {
            if (newVal) {
                $scope.columns = columnsList.slice();
                $scope.availableLines = [];
                $scope.models.lists.selectedLines = $scope.columns.slice();
                $scope.models.lists.availableLine = $scope.availableLines;
            }
        });
        $scope.$watch('models.lists.availableLine.length', function(newVal) {
            $scope.models.defaultCheck = newVal === 0;
        });

        /**
         * External interface by which the template can communicate with
         * to get all the "visible" columns (allows it to be dynamic)
         */
         $scope.refresh= function(){
            abstracts.refresh();
            $scope.filterBy = 'all';
            // abstracts.filter($scope.filterBy);
            $scope.searchQuery = '';
            // abstracts.search($scope.searchQuery);
         }
        $scope.getColumns = function() {
            var result = [],
                column;

            for (var i = 0, ln = $scope.columns.length; i < ln; i++) {
                column = $scope.columns[i];
                if (column.visible) {
                    result.push(column);
                }
            }

            return result;
        };

        /**
         * Sets the record.selected flag of the currently
         * visible result set.
         */
        function toggleSelect(value) {
            var list = linesService.getList(),
                record;

            for (var i = 0, ln = list.length; i < ln; i++) {
                record = list[i];

                if ($scope.disableOnACL && !$scope.disableOnACL(record.type)) {
                    record.selected = value;
                }
            }
        }

        /**
         * Download functionality
         */
        $scope.download = function(type) {
            var linesForDownloadList, params, row;
            console.log(type)
            var urlType = type=='downloadPdf'?Constants.API.LINES_PAGE.LINESDOWNLOADPDF:Constants.API.LINES_PAGE.LINESDOWNLOADCSV;
            params = {};

            // if (type === 'Selected') {
                linesForDownloadList = params.lineData = [];

                for (var i = 0, ln = $scope.list.length; i < ln; i++) {
                    row = $scope.list[i];
                    if (row.selected) {
                        linesForDownloadList.push({
                            lineNumber: row.lineNumber,
                            ext: row.ext,
                            userName: row.userName,
                            status: row.status,
                            type: row.type,
                            associatedDeviceCount: row.associatedDeviceCount
                        });
                    }
                }
            // }
            params.lineData = linesForDownloadList.length?linesForDownloadList:undefined;
            $scope.downloadVal = '';
            $scope.downloadFile(params,type,urlType);
        };

        /**
         * Gets executed when the user selects an item from the "Actions" field
         *
         * It's ABSOLUTELY necessary to reset the value of $scope.selectedAction to an
         * empty string ("").
         */
        $scope.onActionSelect = function() {
            $scope.ottType = $scope.selectedAction.toLowerCase() == 'unblockmobile' ? 'unblockmobile' : 'mobileclient';
            $scope.selectedAction = '';

            $scope.ottBlockUnblockList = [];
            for (var i = 0; i < $scope.list.length; i++) {
                if ($scope.list[i].selected) {
                    $scope.ottBlockUnblockList.push({
                        "mtn": $scope.list[i].lineNumber,
                        "userName": $scope.list[i].userName
                    });
                }
            }

            if ($scope.ottBlockUnblockList && $scope.ottBlockUnblockList.length === 0) {
                abstracts.errorHandler(new Error('Please Select a record'));
            } else {
                getDialogBox();
            }
        };

        function getDialogBox() {
            var dialogTemp = 'partials/components/dialog/' + $scope.ottType + '.html';
            ngDialog.open({
                template: dialogTemp,
                closeByDocument: false,
                closeByEscape: false,
                scope: $scope,
                controller: 'blockUnblockOttCtrl'
            });
        }
        $scope.settings = function() {
            ngDialog.open({
                template: 'partials/components/dialog/customizableTable.html',
                closeByDocument: false,
                closeByEscape: false,
                scope: $scope,
                controller: 'editableTableCtrl'
            });
        };
        $scope.closeDialog = function() {
            try {
                var windowIDs = ngDialog.getOpenDialogs();
                ngDialog.close(windowIDs[1]);
            } catch (err) {

            }
        };
        $scope.closeContinueDialog = function() {
            toggleSelect(false);
            abstracts.onLoad();
            $scope.selectedAction = '';
            $scope.closeDialog();
        };

        /**
         * Kick off the list load service
         */
        //console.log('*****************'+$scope.fromOverviewPage);
        console.log(cache.get('fromOverviewPage')+'*****************');
        if(cache.get('fromOverviewPage') !== 'lines')
        {
           abstracts.serviceResponseHandler();
           abstracts.init();
        }
        else
        {
            cache.remove('fromOverviewPage', null);
            if(linesService.getOperationType() == 'client' )
            {
               abstracts.init();
               abstracts.search($scope.searchQuery);
            }
            else{
                abstracts.initialPageLoad();
                abstracts.getTransactionLink();
                abstracts.beforeLoad('init');
                linesService.search($scope.searchQuery).then(function(){
                            abstracts.serviceResponseHandler();
                    })
                    .catch(abstracts.errorHandler)
                    .then(function() {
                        abstracts.onLoad('init');
                    });
            }
        }
    };

    DesktopLinesCtrl.$inject = ['$scope', 'linesService', 'linesConst', 'ngDialog', 'cache', 'Constants'];

    angular.module(window.AppName).controller('DesktopLinesCtrl', DesktopLinesCtrl);
})();
