(function() {
    var DesktopDevicesCtrl = function($scope, devicesService, linesConst, ngDialog, AuthorizeConst, cache, Constants) {
        var abstracts = $scope.abstracts;
        console.log(devicesService.getOperationType(),cache.get('fromOverviewPage'));
        if(devicesService.getOperationType() !== 'server')
        {
         devicesService.setPageSize(10);
        }
        $scope.filterBy = 'all';
        $scope.searchFilter = 'deviceId';
        // if ($scope.fromOverviewPage == 'devices') {
        //     $scope.filterBy = 'deskphone';
        // }
        // else {  $scope.filterBy = 'all';}
        // $scope.filterBy = $scope.fromOverviewPage !==undefined ? 'deskphone' : undefined ;
        /**
         * Getter for the service
         *
         * @returns {Service}  devices service singleton
         */
        abstracts.getService = function() {
            return devicesService;
        };

        /**
         * Gets executed before the request gets proxied
         * to the service. Used to un-select all the records
         * that may have been selected BEFORE the operation
         * takes place (i.e. pagination)
         */
        abstracts.beforeLoad = function(operation) {
            toggleSelect(false);

            if (operation === 'init') {
                $scope.loading = true;
            }
        };

        /**
         * Gets executed after the request gets proxied
         * to the service. Used to un-select the master
         * checkbox
         */
        abstracts.onLoad = function(operation) {
            $scope.selectAll = false;

            if (operation === 'init') {
                $scope.loading = false;
            }
        };

        abstracts.errorHandler = function(err) {
            $scope.showMsg = true;
            $scope.msgType = 'error';
            $scope.msgTxt = err.message || "Error performing operation";
        };

        abstracts.successHandler = function(message) {
            $scope.showMsg = true;
            $scope.msgType = 'success';
            $scope.msgTxt = message;
        };

        /**
         * Default values for dropdowns
         */
        $scope.actions = linesConst.DEVICES_ACTIONS;
        $scope.linesFilter = linesConst.DEVICES_FILTER;
        $scope.downloadActions = linesConst.DOWNLOAD;

        /**
         * Event listeners
         */
        //abstracts.serviceResponseHandler();
        $scope.searchFunc= function(searchQuery,$event){
            abstracts.setSearch($scope.searchFilter);
            console.log(devicesService.getOperationType() == 'server', devicesService.getServerSearchValue())
            if(devicesService.getOperationType() == 'server' || devicesService.getServerSearchValue())
            {
                console.log(searchQuery);
                var isClickedEnterVal = $event == undefined ? $event : $event.which;
                console.log(isClickedEnterVal);
                if(isClickedEnterVal === 13 ||isClickedEnterVal == undefined)
                {
                    console.log($scope.searchFilter)
                    abstracts.search(searchQuery,$scope.filterBy);
                }
               //abstracts.search(searchQuery);
            }
            else
            {
                abstracts.search(searchQuery);
            }
        };
        $scope.clearSearch = function(){
            $scope.searchQuery = '';
            $scope.searchQuery='';
            $scope.searchFunc($scope.searchQuery);
        }
        $scope.filterFunc= function(value){
            console.log("serachQuery**********")
            console.log($scope.searchQuery);
            abstracts.setSearch($scope.searchFilter);
            abstracts.filter(value,$scope.searchQuery);
        };
        $scope.$watch('selectAll', toggleSelect);

        /**
         * Columns
         *
         * Represents the fields/columns that will be visible/hidden
         * from view.  Also serves as the lexicon for which to translate
         * to the desired language (currently only English)
         */
        var columnsList = [{
            visible: true,
            id: 'deviceType',
            name:'Device Type',
            getVisiblity: function() {
                return 'tablet';
            },
            getName: function(lang) {
                var lexicon = {
                    en: 'Device Type'
                };
                return lexicon[lang || 'en'];
            },
            getValue: function(record) {
                return $scope.util.titlecase(record.deviceType);
            }
        }, {
            visible: true,
            id: 'deviceId',
            name:'Device ID',
            getVisiblity: function() {
                return 'tablet';
            },
            getName: function(lang) {
                var lexicon = {
                    en: 'Device ID'
                };
                return lexicon[lang || 'en'];
            },
            getValue: function(record) {
                return record.deviceId;
            }
        }, {
            visible: true,
            id: 'lineNumber',
            name:'Line Number',
            getVisiblity: function() {
                return '';
            },
            getName: function(lang) {
                var lexicon = {
                    en: 'Line Number'
                };
                return lexicon[lang || 'en'];
            },
            getValue: function(record) {
                return $scope.util.tel(record.lineNumber);
            }
        }, {
            visible: true,
            id: 'userName',
            name:'User Name',
            getVisiblity: function() {
                return 'tablet';
            },
            getName: function(lang) {
                var lexicon = {
                    en: 'User Name'
                };
                return lexicon[lang || 'en'];
            },
            getValue: function(record) {
                return $scope.util.titlecase(record.userName);
            }
        }];
        $scope.availableLines = [];
        $scope.columns = columnsList;
        /**
         *Models maintains the values required for editableTableCtrl
         */
        $scope.models = {
            selected: null,
            lists: {
                "availableLine": $scope.availableLines,
                "selectedLines": $scope.columns.slice()
            },
            defaultCheck: true,
            selectedRecord: 10,
            dropdownList: [{
                name: "10 Records Per Page",
                value: 10
            }, {
                name: "20 Records Per Page",
                value: 20
            }, {
                name: "30 Records Per Page",
                value: 30
            }, {
                name: "50 Records Per Page",
                value: 50
            }, {
                name: "100 Records Per Page",
                value: 100
            }]
        };
        /**
         *Watch for the changes and update defaultCheck
         */
        $scope.$watch('models.defaultCheck', function(newVal, oldVal) {
            if (newVal) {
                $scope.columns = columnsList.slice();
                $scope.availableLines = [];
                $scope.models.lists.selectedLines = $scope.columns.slice();
                $scope.models.lists.availableLine = $scope.availableLines;
            }
        });
        $scope.$watch('models.lists.availableLine.length', function(newVal, oldVal) {
            $scope.models.defaultCheck = newVal === 0;
        });
        $scope.refresh= function(){
            abstracts.refresh();
            $scope.filterBy = 'all';
            // abstracts.filter($scope.filterBy);
            $scope.searchQuery = '';
            // abstracts.search($scope.searchQuery);
         }
        /**
         * External interface by which the template can communicate with
         * to get all the "visible" columns (allows it to be dynamic)
         */
        $scope.getColumns = function() {
            var result = [],
                column;

            for (var i = 0, ln = $scope.columns.length; i < ln; i++) {
                column = $scope.columns[i];
                if (column.visible) {
                    result.push(column);
                }
            }

            return result;
        };

        /**
         * Sets the record.selected flag of the currently
         * visible result set.
         */
        function toggleSelect(value) {
            var list = devicesService.getList(),
                record;

            for (var i = 0, ln = list.length; i < ln; i++) {
                record = list[i];

                if ($scope.disableOnACL && !$scope.disableOnACL(record.type)) {
                    record.selected = value;
                }
            }
        }

        /**
         * Download functionality
         */
        $scope.download = function(type) {
            var devicesForDownloadList, params, row;
            var urlType = type=='downloadPdf'?Constants.API.LINES_PAGE.DEVICESDOWNLOADPDF:Constants.API.LINES_PAGE.DEVICESDOWNLOADCSV;
            params = {};
            devicesForDownloadList = params.deviceData = [];
            // if (type === 'Selected') {
            //     devicesForDownloadList = params.deviceData = [];

                for (var i = 0, ln = $scope.list.length; i < ln; i++) {
                    row = $scope.list[i];
                    if (row.selected) {
                        devicesForDownloadList.push({
                            deviceMake: row.deviceMake,
                            deviceModel: row.deviceModel,
                            deviceType: row.deviceType,
                            deviceId: row.deviceId,
                            lineNumber: row.lineNumber,
                            userName: row.userName,
                            deviceStatus: row.deviceStatus
                        });
                    }
                }
            // }
            params.deviceData = devicesForDownloadList.length?devicesForDownloadList:undefined;
            $scope.downloadVal = '';
            $scope.downloadFile(params,type,urlType);
        };

        /**
         * Gets executed when the user selects an item from the "Actions" field
         *
         * It's ABSOLUTELY necessary to reset the value of $scope.selectedAction to an
         * empty string ("").
         */
        $scope.onActionSelect = function(value) {
            $scope.actionSelected = $scope.selectedAction;
            $scope.selectedAction = '';
            if ($scope.actionSelected == 'Update 911 Address') {
                $scope.deviceMDNList = getFilterByDeskphoneValues();
                if (!!$scope.deviceMDNList) {
                    if ($scope.deviceMDNList.length === 0) {
                        abstracts.errorHandler(new Error('Please Select a record'));
                        return;
                    } else {
                        $scope.update911Lookup();
                    }
                }
            }
        };

        function getFilterByDeskphoneValues() {
            var deviceMDNList = [];
            for (var i = 0; i < $scope.list.length; i++) {
                //$scope.collection[i].settingsInfo.active=$scope.collection[i].settingsInfo.active=='true'?true:false;
                if ($scope.list[i].selected) {
                    if ($scope.list[i].deviceType == 'DESKPHONE') {
                        deviceMDNList.push({
                            "lineNumber": $scope.list[i].lineNumber,
                            "deviceId": $scope.list[i].deviceId
                        });
                    } else {
                        toggleSelect(false);
                        abstracts.onLoad();
                        abstracts.errorHandler(new Error('Please Select Deskphones'));
                        return;
                    }
                }
                //i++;
            }
            return deviceMDNList;
        }
        $scope.state_values = AuthorizeConst.STATE_LIST;
        $scope.update911Lookup = function() {
            ngDialog.open({
                template: 'partials/components/dialog/update911LinesNdevices.html',
                closeByDocument: false,
                closeByEscape: false,
                scope: $scope,
                controller: 'update911Ctrl'
            });
        };
        $scope.settings = function() {
            ngDialog.open({
                template: 'partials/components/dialog/customizableTable.html',
                closeByDocument: false,
                closeByEscape: false,
                scope: $scope,
                controller: 'editableTableCtrl'
            });
        };

        $scope.closeDialog = function() {
            try {
                var windowIDs = ngDialog.getOpenDialogs();
                ngDialog.close(windowIDs[1]);
            } catch (err) {

            }
        };
        $scope.closeDialogWithCheckBoxes = function() {
            toggleSelect(false);
            abstracts.onLoad();
            $scope.selectedAction = '';
            $scope.closeDialog();
        };

        /**
         * Kick off the devices load service
         */
        console.log(cache.get('fromOverviewPage'))
        if(cache.get('fromOverviewPage') !== 'devices')
        {
           abstracts.serviceResponseHandler();
           abstracts.init();
        }
        else
        {
            cache.remove('fromOverviewPage', null);
            if(devicesService.getOperationType() == 'client' )
            {
               console.log('inside client')
               $scope.loadFlag = true;
               abstracts.serviceResponseHandler();
               abstracts.init();
               abstracts.search($scope.searchQuery);
            }
            else{
                abstracts.initialPageLoad();
                abstracts.getTransactionLink();
                abstracts.beforeLoad('init');
                devicesService.search($scope.searchQuery).then(function(){
                        abstracts.serviceResponseHandler();
                })
                .catch(abstracts.errorHandler)
                .then(function() {
                    abstracts.onLoad('init');
                });
            }
        }
    };

    DesktopDevicesCtrl.$inject = ['$scope', 'devicesService', 'linesConst', 'ngDialog', 'AuthorizeConst', 'cache', 'Constants'];

    angular.module(window.AppName).controller('DesktopDevicesCtrl', DesktopDevicesCtrl);

})();