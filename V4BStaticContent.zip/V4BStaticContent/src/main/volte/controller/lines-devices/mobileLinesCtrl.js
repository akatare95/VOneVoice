(function() {
    var MobileLinesCtrl = function($scope, linesService, linesConst) {
        var abstracts = $scope.abstracts,
            batchSize = 20;

        linesService.setPageSize(batchSize);

        /**
         * Getter for the service
         *
         * @returns {Service}  lines service singleton
         */
        abstracts.getService = function() {
            return linesService;
        };

        /**
         * Determines if we should reset $scope.list[] based on the operation
         */
        abstracts.beforeLoad = function(operation) {
            if ($scope.initialized && operation !== 'next') {
                linesService.setPageSize(batchSize);
            }

            if (operation === 'init') {
                $scope.loading = true;
            }
        };

        /**
         * Determines if we should show or hide the "Loading More" indicator
         */
        abstracts.onLoad = function(operation) {
            var length = linesService.getLength();

            $scope.hideLoadMore = $scope.list.length === length;

            if (operation === 'init') {
                $scope.loading = false;
            }
        };

        abstracts.errorHandler = function(err) {
            $scope.showMsg = true;
            $scope.msgType = 'error';
            $scope.msgTxt = err.message || "Error performing operation";
        };

        abstracts.successHandler = function (message) {
            $scope.showMsg = true;
            $scope.msgType = 'success';
            $scope.msgTxt = message;
        };

        /**
         * Default values for dropdowns
         */
        $scope.actions = linesConst.LINES_ACTIONS;
        $scope.linesFilter = linesConst.LINES_FILTER;

        /**
         * Event listeners
         */
        $scope.$watch('searchQuery', abstracts.search); // TODO: Should wait for the "Enter" key
        $scope.$watch('filterBy', abstracts.filter);

        /**
         * Gets executed when the scroll position reaches the "Loading More" text
         *
         * @param {Boolean}  loadMoreVisible
         */
        $scope.onLoadMoreChange = function(loadMoreVisible) {
            if (loadMoreVisible) {
                setTimeout(function() {
                    var pageSize = linesService.getPageSize();

                    pageSize += batchSize;

                    abstracts.setPageSize(pageSize);
                }, 300);
            }
        };

        /**
         * Gets executed when the user selects an item from the "Actions" field
         *
         * It's ABSOLUTELY necessary to reset the value of $scope.selectedAction to an
         * empty string ("").
         */
        $scope.onActionSelect = function(value) {
            $scope.selectedAction = '';
            console.log(value);
        };

        /**
         * Kick off the list load service
         */
        abstracts.init();
    };

    MobileLinesCtrl.$inject = ['$scope', 'linesService', 'linesConst'];

    angular.module(window.AppName).controller('MobileLinesCtrl', MobileLinesCtrl);

})();