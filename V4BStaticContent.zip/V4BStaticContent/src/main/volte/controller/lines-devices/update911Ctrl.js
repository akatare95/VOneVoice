(function() {
    var update911Ctrl = function($scope, linesService, $state) {
        var abstracts = $scope.abstracts,stateFilteredVal;

        $scope.inDetailsPage = !!$state.params.lineNumber;

        if ($scope.inDetailsPage) {
            $scope.addressone = $scope.address911.addressLine1;
            $scope.addresstwo = $scope.address911.addressLine2;
            $scope.city = $scope.address911.city;
            var filteredArray = $scope.state_values
                .filter(function(record) {
                    return record.value == $scope.address911.state;
                });
            $scope.state = filteredArray[0];
            $scope.zipcode = $scope.address911.zipCode;

        }
        $scope.submit911AddressInfo = function() {
              var params = $scope.inDetailsPage ? getDetail911Params() : getDevices911Params();
            linesService.update911Address(params)
                .then(function(response) {
                    if($scope.inDetailsPage)
                    {
                        $scope.address911.addressLine1 = $scope.addressone;
                        $scope.address911.addressLine2 = $scope.addresstwo;
                        $scope.address911.city = $scope.city;
                        $scope.address911.state = $scope.state.value;
                        $scope.address911.zipCode = $scope.zipcode;
                        $scope.closeDialog();
                    }
                    else
                    {
                        $scope.closeDialogWithCheckBoxes();
                    }
                    //$scope.inDetailsPage ? $scope.closeDialog() : $scope.closeDialogWithCheckBoxes();
                    abstracts.successHandler("Successfully Updated!");
                }, function(reason) {
                    var serviceRepsonse = reason.appResult.serviceRepsonse;
                    $scope.showMsgdial = true;
                    $scope.msgTypedial = "error";
                    $scope.msgTxtdial = reason.appHeader.statusMessage;
                    if(serviceRepsonse.alternateAddress && serviceRepsonse.alternateAddress.length){
                        $scope.addressone = serviceRepsonse.alternateAddress[0].addressLine1;
                        $scope.addresstwo = serviceRepsonse.alternateAddress[0].addressLine2;
                        $scope.city = serviceRepsonse.alternateAddress[0].city;
                        var filteredArray = $scope.state_values.filter(function(record) {
                            return record.value == serviceRepsonse.alternateAddress[0].state;
                        });
                        $scope.state = filteredArray[0];
                        $scope.zipcode = serviceRepsonse.alternateAddress[0].zipCode;
                    }
                    // $scope.inDetailsPage ? $scope.closeDialog() : $scope.closeDialogWithCheckBoxes();
                    // abstracts.errorHandler(reason);
                });
        };

        function getDetail911Params() {
            $scope.deviceMDNList = [{
                "lineNumber": $state.params.lineNumber,
                "deviceId": $scope.asscDevices[$scope.currentAsscIndex].deviceId // TODO: Where is "deviceIndex" coming from?
            }];
            //console.log($scope.state.value)
            // var filteredArray = $scope.state_values
            //     .filter(function(record) {
            //         return record.name == $scope.state || record.value == $scope.state;
            //     });
            //     stateFilteredVal = filteredArray[0].value;
            console.log($scope.state)
            var params = {
                "deviceMDNList": $scope.deviceMDNList,
                "911Address": {
                    "addressLine1": $scope.addressone,
                    "addressLine2": $scope.addresstwo,
                    "city": $scope.city,
                    "state": $scope.state.value,
                    "zipCode": $scope.zipcode
                }
            };
            console.log(params)
            return params;
        }

        function getDevices911Params() {
            console.log($scope.state)
            var params = {
                "deviceMDNList": $scope.deviceMDNList,
                "911Address": {
                    "addressLine1": $scope.addressone,
                    "addressLine2": $scope.addresstwo,
                    "city": $scope.city,
                    "state": $scope.state.value,
                    "zipCode": $scope.zipcode
                }
            };
            return params;
        }
    };

    update911Ctrl.$inject = ['$scope', 'linesService', '$state'];

    angular.module(window.AppName).controller('update911Ctrl', update911Ctrl);
})();