(function() {
    var editableTableCtrl = function($scope) {
        $scope.models.selectedRecord = $scope.pageSize;
        var availableLinesChosen = [];
        var selectedLinesChosen = [];
        $scope.editableVal = {};
        $scope.editableVal.fromAvailableLinesToSelectedLines = function() {
            for (var i = 0; i < availableLinesChosen.length; i++) {
                $scope.models.lists.selectedLines.push(availableLinesChosen[i]);
                $scope.models.lists.availableLine.splice($scope.models.lists.availableLine.indexOf(availableLinesChosen[i]), 1);
            }
            //$scope.defaultCheck=$scope.models.lists.availableLine.length==0?true:false;
            availableLinesChosen = [];
        };
        $scope.editableVal.fromSelectedLinesToAvailableLines = function() {
            for (var i = 0; i < selectedLinesChosen.length; i++) {
                $scope.models.lists.availableLine.push(selectedLinesChosen[i]);
                $scope.models.lists.selectedLines.splice($scope.models.lists.selectedLines.indexOf(selectedLinesChosen[i]), 1);
            }
            //$scope.defaultCheck=$scope.models.lists.availableLine.length==0?true:false;
            selectedLinesChosen = [];
        };
        $scope.editableVal.onAvailableLinesClick = function(event, index, item) {
            var ele = event.currentTarget;
            //check whether an already chosen line is selected again
            //if so, clear the selection
            //else set selection
            if (angular.element(ele).hasClass('selected-line')) {
                angular.element(ele).removeClass('selected-line');
                availableLinesChosen.splice(availableLinesChosen.indexOf(item), 1);
            } else {
                angular.element(ele).addClass('selected-line');
                availableLinesChosen.push(item);
            }
        };
        $scope.editableVal.onSelectedLinesClick = function(event, index, item) {
            var ele = event.currentTarget;
            //check whether an already chosen line is selected again
            //if so, clear the selection
            //else set selection
            if (angular.element(ele).hasClass('selected-line')) {
                angular.element(ele).removeClass('selected-line');
                selectedLinesChosen.splice(selectedLinesChosen.indexOf(item), 1);
            } else {
                angular.element(ele).addClass('selected-line');
                selectedLinesChosen.push(item);
            }
        };
        $scope.editableVal.moveUp = function() {
            for (var i = 0; i < selectedLinesChosen.length; i++) {
                var idx = $scope.models.lists.selectedLines.indexOf(selectedLinesChosen[i])
                if (idx > 0) {
                    var itemToMove = $scope.models.lists.selectedLines.splice(idx, 1);
                    $scope.models.lists.selectedLines.splice(idx - 1, 0, itemToMove[0]);
                }
            }
        };
        $scope.editableVal.moveDown = function() {
            for (var i = 0; i < selectedLinesChosen.length; i++) {
                var idx = $scope.models.lists.selectedLines.indexOf(selectedLinesChosen[i]);
                if (idx < $scope.models.lists.selectedLines.length - 1) {
                    var itemToMove = $scope.models.lists.selectedLines.splice(idx, 1);
                    $scope.models.lists.selectedLines.splice(idx + 1, 0, itemToMove[0]);
                }
            }
        };
        $scope.save = function() {
            $scope.$parent.columns = $scope.models.lists.selectedLines.slice();
            $scope.$parent.availableLines = $scope.models.lists.availableLine.slice();
            console.log($scope.$parent.availableLines, $scope.$parent.columns);
            $scope.pageSize = $scope.models.selectedRecord;
            $scope.abstracts.setPageSize($scope.pageSize);
            $scope.closeDialog();
        };
    };

    editableTableCtrl.$inject = ['$scope'];

    angular.module(window.AppName).controller('editableTableCtrl', editableTableCtrl);
})();