/*
 *
 *  LinesCtrl - This controller handles lines & devices page
 *
 */
app
	.controller(
		'lineDetailCtrl', [
			"$scope",
			"$http",
			"ngDialog",
			"$timeout",
			"$rootScope",
			"$compile",
			"asyncLoadData",
			"lineServices.deprecated",
			"mediatorCtrlFactory",
			"$state",
			"vzCache",
			"lineUserInfo",
			"linesConst",
			"volteServices",
			"directedCallPickUpBargeinService",
			"Constants",
			"$templateCache",
			"AuthorizeConst",
			"userFeatureListForRadiotoggle",
			"$window",
			function($scope, $http, ngDialog,
				$timeout, $rootScope, $compile, asyncLoadData,
				lineServices, mediatorCtrlFactory, $state,
				vzCache, lineUserInfo, linesConst,
				volteServices,
				directedCallPickUpBargeinService, Constants,
				$templateCache, AuthorizeConst, userFeatureListForRadiotoggle, $window) {
				// ------ Adding EPAM funtion : Start
				var optionAPI;

				$scope.bridgedAdmin =[] ; //HD
				$scope.showLineDetailMessage = function(msgType, msgTxt) {
					$scope.msgType = msgType;
					$scope.msgTxt = msgTxt;
					$scope.showMsgLineDetail = true;
				};
				$scope.hideLineDetailMessage = function() {
					$scope.showMsgLineDetail = false;
				};
				$scope.processActionRest = function() {
					console
						.log("making processActions call to server");

					var params = {};
					params.actionSelected = "AddEndPoint";
					params.line = $state.params.lineNumber;

					console.log("input data params : " + JSON.stringify(params));

					volteServices
						.setOption(Constants.API.LINES_PAGE.LINE_ADDEPAM);
					volteServices
						.postData(params)
						.success(
							function(response) {
								if (response.appHeader.statusCode == "OK") {
									$scope.msgType = "success";
									$scope.msgTxt = 'Line Successfully Added';
									$scope.showMsgLineDetail = true;
								} else {
									$scope.msgType = "error";
									$scope.msgTxt = 'Record Updation Failed';
									$scope.showMsgLineDetail = true;
								}
							})
						.error(
							function() {
								$scope.closeDialog();
								$scope.msgType = "error";
								$scope.msgTxt = 'Record Updation Failed';
								$scope.showMsgLineDetail = true;
							});
				}


				$scope.navigateToUrl = function(url) {
					console.log("lineDetailCtrl - navigateToUrl input url : " + url);
					var f = document.createElement("FORM");
					f.action = url;

					var indexQM = url.indexOf("?");
					if (indexQM >= 0) {
						// the URL has parameters => convert them to
						// hidden form inputs
						var params = url.substring(indexQM + 1)
							.split("&");
						for (var i = 0; i < params.length; i++) {
							var keyValuePair = params[i].split("=");
							var input = document
								.createElement("INPUT");
							input.type = "hidden";
							input.name = keyValuePair[0];
							input.value = keyValuePair[1];
							f.appendChild(input);
						}
					}

					document.body.appendChild(f);
					f.submit();
				};

				// --- End

				function declareVariables() {
					$scope.actionButtonActive = false;
					$scope.serverError = false;
					$rootScope.selectedRedItemLabel = "All Lines";
				}

				function getEPAMLink() {
					var HREFArr = window.location.href.split("#");
					var TokenGoBackURL = HREFArr[0] + "#/line-devices/details/device/" + $state.params.deviceID + "/" + $state.params.deviceType + "/" + $state.params.lineNumber + "/" + $state.params.lineType;
					TokenGoBackURL = encodeURIComponent(TokenGoBackURL);
					var TokenLineNumber = $state.params.lineNumber;

					$scope.EPAMLink = $rootScope.EPAMLink.replace(
						"TokenGoBackURL", TokenGoBackURL);
					$scope.EPAMLink = $scope.EPAMLink.replace(
						"TokenLineNumber", TokenLineNumber);

		            // Commented bacause it causes "Page not found" error
		            // Back URL not needed for EPAM
		            // Redirect with back URL
/*
		            var currentUrlPath = window.location.href;
		            var redirectUrlPath = $scope.EPAMLink;
		            $scope.EPAMLink = redirectUrlWithReturnURL(redirectUrlPath, currentUrlPath, Constants.API.REDIRECT_URL_PATHS.split_At);
*/
				}
				$scope.goToEPAM =function(){
					console.log("Call $scope.goToEPAM");
					var HREFArr = window.location.href.split("#");
					var TokenGoBackURL = HREFArr[0] + "#/line-devices/details/device/" + $state.params.deviceID + "/" + $state.params.deviceType + "/" + $state.params.lineNumber + "/" + $state.params.lineType;
					TokenGoBackURL = encodeURIComponent(TokenGoBackURL);
					var TokenLineNumber = $state.params.lineNumber;

					$scope.EPAMLink = $rootScope.EPAMLink.replace(
						"TokenGoBackURL", TokenGoBackURL);
					$scope.EPAMLink = $scope.EPAMLink.replace(
						"TokenLineNumber", TokenLineNumber);

		            // Redirect with back URL
		            var currentUrlPath = window.location.href;
		            var redirectUrlPath = $scope.EPAMLink;
		            window.location.href = redirectUrlWithReturnURL(redirectUrlPath, currentUrlPath, Constants.API.REDIRECT_URL_PATHS.split_At);
				}

				$scope.actionButton = function() {
					$scope.actionButtonActive = !$scope.actionButtonActive;
				}
				$scope.editUserinfo = function() {
					//var newtemplate = 'partials/components/dialog/editUserInfo.html';
					//$scope.lineDetails = type;
					$scope.editUserName = $scope.lineDetail.userName;
					$scope.editcallingIdName = $scope.lineDetail.callingIdName;
					$scope.editemailAddress = $scope.lineDetail.emailAddress;
					$scope.editcontactNumber = $scope.lineDetail.contactNumber;
					$scope.editext = $scope.lineDetail.ext;
					$scope.editUserForm = {};
					$scope.submitEditUserInfo = function(userName,
						callId, email, lineNumber, ext) {
						var nonDigitsPattern = /\D/;
						if (String(ext).match(nonDigitsPattern)) {
							$scope.showMsgdial = true;
							$scope.msgTypedial = 'error';
							$scope.msgTxtdial = 'Invalid extension.The extension can only contain characters 0-9.';
							console.log($scope.$parent.lineDetail);
							$scope.editUserForm.form.$setPristine();
							return;
						}
						if (String(ext).length != 4) {
							$scope.showMsgdial = true;
							$scope.msgTypedial = 'error';
							$scope.msgTxtdial = 'Invalid extension. The extension length for this group is 4 digits long.';
							console.log($scope.$parent.lineDetail);
							$scope.editUserForm.form.$setPristine();
							return;
						}

						var params = {
							"userUpdateInfoList": [{
								"lineNumber": $state.params.lineNumber,
								"ext": String(ext),
								"userName": userName,
								"contactNumber": lineNumber,
								"emailAddress": email,
								"callingIDname": callId
							}]
						};
						volteServices
							.setOption(Constants.API.SETUPUSERINFO_PAGE.UPDATE_USER_INFO);
						volteServices
							.postData(params)
							.success(
								function(response) {

									if (response.appHeader.statusCode == "OK") {

										$scope.msgType = "success";
										$scope.msgTxt = "Successfully Updated!";
										$scope.showMsgLineDetail = true;
										$scope.lineDetail.userName = userName;
										$scope.lineDetail.contactNumber = lineNumber;
										$scope.lineDetail.emailAddress = email;
										$scope.lineDetail.ext = ext;
										$scope.closeDialog();
									} else {

										$scope.msgType = "error";
										$scope.msgTxt = response.appHeader.statusMessage;
										$scope.showMsgLineDetail = true;
										$scope.closeDialog();
									}

								});
					}
					var new_dialog = ngDialog.open({
						template: 'partials/components/dialog/editUserInfo.html',
						closeByDocument: false,
						closeByEscape: false,
						scope: $scope
					});
				};
				$scope.closeDialog = function() {
						try {
							var windowIDs = ngDialog.getOpenDialogs();
							// console.log(windowIDs);
							ngDialog.close(windowIDs[1]);
						} catch (err) {
							// console.log('Error:', err);
						}
					}
					/*
					 * Disables the checkbox for employee type in the vz
					 * grid for lines
					 *
					 */
				$scope.fallBackImg = function(deviceType, icon,
					isVirtualDevice) {

					if (!icon && deviceType) {

						switch (deviceType.toLowerCase()) {

							case 'smartphone':
								return 'smartphone-missing';
								break;
							case 'deskphone':
								if (isVirtualDevice) {
									return 'bridged-with-admin';
								} else {
									return 'desktop-missing';
								}

								break;
							case 'yealink':
								break;

							case 'ott' :
								return 'ipad-missing' ;
								break;
						}
					}
				}

				function toTitleCase(str) {
					return str.replace(/\w\S*/g, function(txt) {
						return txt.charAt(0).toUpperCase() + txt.substr(1).toLowerCase();
					});
				}
				$scope.lookupDialogSelectiveForwarding = function(row, rowIndex, gearType) {
					row.isSubmitClicked = false;
					var rowTypeInfo = {
						row: row,
						rowIndex: rowIndex,
						gearType: gearType
					};
					var new_dialog = ngDialog.open({
						template: 'partials/features/userFeatures/callForwarding/dialog/settings.html',
						closeByDocument: false,
						className: 'ngdialog-theme-default selective-call-rejection-dialog',
						closeByEscape: false,
						data: rowTypeInfo,
						preCloseCallback: function() {
							if (row.isSubmitClicked == false && gearType === true) {
								console.log('inside pre close');
								if (!$scope.$$phase) {
									$scope.$apply(function() {
										row.settingsInfo.active = false;
									});
								} else {
									row.settingsInfo.active = false;
								}
							}
							return true;
						},
						scope: $scope,
						controller: 'callForwardSelectiveDialogCtrl'
					});
				}
				$scope.lookupDialogNonSelectiveForwarding = function(row, rowIndex, gearType, tabSelected) {
						row.isSubmitClicked = false;
						var rowTypeInfo = {
							row: row,
							rowIndex: rowIndex,
							gearType: gearType,
							tabSelected: tabSelected
						};
						var new_dialog = ngDialog.open({
							template: 'partials/features/userFeatures/callForwarding/dialog/settings.html',
							closeByDocument: false,
							className: 'ngdialog-theme-default selective-call-rejection-dialog',
							closeByEscape: false,
							data: rowTypeInfo,
							preCloseCallback: function() {
								if (row.isSubmitClicked == false && gearType === true) {
									console.log('inside pre close');
									if (!$scope.$$phase) {
										$scope.$apply(function() {
											row.settingsInfo.active = false;
										});
									} else {
										row.settingsInfo.active = false;
									}
								}
								return true;
							},
							scope: $scope,
							controller: 'callForwardNonSelectiveDialogCtrl'
						});
					}
					// --------------------------------------------------------
					// PreAlert Announcement : start
					// ----------------------------------------------
				$scope.lookupDialogPreAlert = function(row, rowInd, type) {
					row.isSubmitClicked = false;
					var rowTypeInfo = {
						row: row,
						rowIndex: rowInd,
						gearType: type
					};
					var new_dialog = ngDialog.open({
						template: 'partials/features/userFeatures/preAlerting/dialog/preAlerting.html',
						className: 'ngdialog-theme-default pre-alerting-announcement-dialog',
						closeByDocument: false,
						closeByEscape: false,
						preCloseCallback: function() {
							if (row.isSubmitClicked == false && type === true) {
								console.log('inside pre close');
								if (!$scope.$$phase) {
									$scope.$apply(function() {
										row.settingsInfo.active = false;
									});
								} else {
									row.settingsInfo.active = false;
								}
							}
							return true;
						},
						scope: $scope,
						data: rowTypeInfo,
						controller: 'preAlertDialogCtrl'
					});
				}
				$scope.lookupDialogCallPickup = function(row, rowIndex, gearType) {
					console.log(row);
					row.isSubmitClicked = false;
					var rowTypeInfo = {
						row: row,
						rowIndex: rowIndex,
						gearType: gearType
					};
					var new_dialog = ngDialog.open({
						template: 'partials/components/dialog/userFeatures/directedCallBargeIn.html',
						closeByDocument: false,
						closeByEscape: false,
						className: 'ngdialog-theme-default remote-call-pickup-barge-in-modal',
						preCloseCallback: function() {
							if (row.isSubmitClicked == false && gearType === true) {
								console.log('inside pre close');
								if (!$scope.$$phase) {
									$scope.$apply(function() {
										row.settingsInfo.active = false;
									});
								} else {
									row.settingsInfo.active = false;
								}
							}
							return true;
						},
						scope: $scope,
						data: rowTypeInfo,
						controller: 'directedCallPickUpDialogCtrl'
					});
				};
				// -- Remote Call Pickup : End --
				// --------------------------------------------------------
				// Call Acceptance Rejection : start
				// ----------------------------------------------
				$scope.lookupCallRejection = function(
						row, rowIndex, gearType) {
						row.isSubmitClicked = false;
						var rowTypeInfo = {
							row: row,
							rowIndex: rowIndex,
							gearType: gearType
						};
						var new_dialog = ngDialog.open({
							template: 'partials/features/userFeatures/selectiveCallRejection/dialog/callRejection.html',
							closeByDocument: false,
							className: 'ngdialog-theme-default selective-call-rejection-dialog',
							closeByEscape: false,
							data: rowTypeInfo,
							preCloseCallback: function() {
								if (row.isSubmitClicked == false && gearType === true) {
									console.log('inside pre close');
									if (!$scope.$$phase) {
										$scope.$apply(function() {
											row.settingsInfo.active = false;
										});
									} else {
										row.settingsInfo.active = false;
									}
								}
								return true;
							},
							scope: $scope,
							controller: 'callrejectionDialogCtrl'
						});

					}
					// --------------------------------------------------------
					// Simultaneous Ring Service : start
					// ----------------------------------------------

				$scope.lookupDialogRingService = function(row,
					rowIndex, gearType) {
					console.log(row);
					row.isSubmitClicked = false;
					var rowTypeInfo = {
						row: row,
						rowIndex: rowIndex,
						gearType: gearType
					};
					var new_dialog = ngDialog.open({
						template: 'partials/components/dialog/userFeatures/simultaneousRingService.html',
						closeByDocument: false,
						className: 'ngdialog-theme-default simultaneous-ring-service-dialog',
						closeByEscape: false,
						data: rowTypeInfo,
						preCloseCallback: function() {
							if (row.isSubmitClicked == false && gearType === true) {
								console.log('inside pre close');
								if (!$scope.$$phase) {
									$scope.$apply(function() {
										row.settingsInfo.active = false;
									});
								} else {
									row.settingsInfo.active = false;
								}
							}
							return true;
						},
						scope: $scope,
						controller: 'simultaneousRingDilaogCtrl'
					});
				}

				// --------------------------------------------------------
				// Calling Plan : start
				// ----------------------------------------------

				// $scope.lookupDialogCallingPlan = function() {
				// 	console.log($scope.callingPlanUserList);
				// }
				$scope.lookupDialogCallingPlan = function() {
					    console.log($scope.callingPlanUserList);
						var rowTypeInfo = {
							row: $scope.callingPlanUserList
						};
						var new_dialog = ngDialog.open({
							template: 'partials/features/userFeatures/callingPlan/dialog/callingPlanDialog.html',
							className: 'ngdialog-theme-default user-calling-plan-dialog',
							closeByDocument: false,
							closeByEscape: false,
							scope: $scope,
							data: rowTypeInfo,
							controller: 'callingPlanDialogCtrl'
						});
					}
					// ================================================
					// User Features Overlay : End
					// ================================================================

				$scope.getLineDetail = function() {

					$scope.loadFlag = true;
                    $scope.ottCalling = null;
					$scope.lineDetail = {};
					$scope.userFeaturesList = {};
					$scope.authorizCollection = [];

					var URL = window.location.href;
					var URLParts = URL.split("#");

					var URI = URLParts[1];
					var URIParts = URI.split("/");

					var lineNumber = URIParts[URIParts.length - 3];
					var lineType = $state.params.lineType ? $state.params.lineType.toUpperCase() : $state.params.lineType;

					// console.log($state.params.lineType);

					// Getting line number from URL params
					var lineNum = $state.params.lineNumber;
					var lineType = lineType;

					console.log("lineNum>>" + lineNum);
					// lineNum>>3039906364
                    if(lineType)
                    {
                      $scope.lineType = toTitleCase($state.params.lineType);
                    }

					if (lineNum == undefined)
						lineNum = '';

					// Checking selected Tab
					if ($scope.type == 'lines') {

						lineServices
							.getLineDetail(lineNum, lineType)
							.success(
								function(result) {
									if (result.appHeader.statusCode == 'OK') {
										$scope.loadFlag = false;

										$scope.lineDetail = result.appResult.serviceRepsonse;
										$scope.ottCalling = $scope.lineDetail.ottCalling;
										console.log($scope.ottCalling+'*********************')
										if ($scope.lineDetail && $scope.lineDetail.featuresResponse && $scope.lineDetail.featuresResponse.length)
											// $scope.userFeaturesList = $scope.lineDetail.featuresResponse;
										var itr = 0;
										console
											.log("userFeatures length--" + $scope.userFeaturesList.length);
                                        var filteredArray = $scope.lineDetail.featuresResponse.filter(function( record ) {
							                //$scope.existNumber = true;
							                if (record.featureId == '1014' || record.featureId == '1015') {
														console.log(record.criteriaInfo);
														console.log('before**********');
														record.active=true;
														record.settingsInfo.active = record.criteriaInfo && record.criteriaInfo.length > 0 ? true : false;
													    console.log(record.settingsInfo.active);
											}
											else if(record.featureId == '1018')
							                {
							                	$scope.callingPlanUserList = record;
							                }else {
														record.settingsInfo.active = record.settingsInfo.active == 'true' ? true : false;

											}
							                return record.featureId !== '1003' && record.featureId !== '1018' && record.featureId !== "1012";
							            });
							            console.log(filteredArray);
							            $scope.userFeaturesList = filteredArray;
										lineUserInfo.data.name = $scope.lineDetail.userName;
										lineUserInfo.data.number = vzProcessLineFormatting($state.params.lineNumber);
										getAsscList(lineNum,lineType)

									} else {
										$scope.serverError = true;
										$scope.msgType = "error";
										$scope.msgTxt = result.appHeader.statusMessage;
										$scope.showMsgLineDetail = true;
									}

								}).error(function(error) {
								$scope.serverError = true;
							});

					} else {
						lineServices
							.getDeviceDetail(lineNum, lineType)
							.success(
								function(result) {
									if (result.appHeader.statusCode == 'OK') {
										$scope.loadFlag = false;
										$scope.lineDetail = result.appResult.serviceRepsonse;
										lineUserInfo.data.name = $scope.lineDetail.userName;
										lineUserInfo.data.number = $scope.lineDetail.lineNumber;
										getAsscList(lineNum,lineType);
									} else {
										$scope.serverError = true;
									}
								}).error(function(error) {
								$scope.serverError = true;
							});
					}
					// To generate associate device tabs

					getScheduleData();
				};
                 function getAsscList(lineNum,lineType)
                 {
                 	lineServices.getLineAssociatedDevices(lineNum,lineType).success(
						function(result) {
							if (result.appHeader.statusCode == 'OK') {
								$scope.loadFlag = false;
								$scope.bridgedAdmin=[];
								// $timeout(function() {
								$scope.asscDevices = result.appResult.serviceRepsonse.associatedDeviceList;
								$scope.asscBlockUrl = 'partials/lines/associatedDevices.html';
								$scope.noOfOtherPhones = 0;
								// console.log($state.params);
								if ($scope.asscDevices.length > 0) {
									$scope.noOfOttDevices = 0;
									for (var i = 0; i < $scope.asscDevices.length; i++) {
					                    $scope.asscDevices[i].adminLineInfo && $scope.asscDevices[i].adminLineInfo.length && $scope.asscDevices[i].isVirtualDevice ? $scope.bridgedAdmin.push($scope.asscDevices[i].adminLineInfo[0]):$scope.bridgedAdmin; //HD

										if ($scope.asscDevices[i].deviceType.toUpperCase() == 'OTT') {
											$scope.ottCalling = $scope.asscDevices.length==1 ? undefined:$scope.ottCalling;
											console.log($scope.asscDevices.length,$scope.ottCalling+"**************");
											$scope.noOfOttDevices++;
										} else if ($scope.asscDevices[i].deviceType
											.toUpperCase() == 'DESKPHONE' || $scope.asscDevices[i].deviceType
											.toUpperCase() == 'SMARTPHONE') {
											$scope.noOfOtherPhones++;
										}
									}
									if ($scope.noOfOttDevices < 5 && $scope.asscDevices.length < 8) {
										var leftOutOtt = 5 - $scope.noOfOttDevices;
										var leftOutAssDevices = 8 - $scope.asscDevices.length;
										var infoMsgNoTxt = leftOutAssDevices > leftOutOtt ? leftOutOtt : leftOutAssDevices;
										$scope.infoMsg = 'You can add ' + infoMsgNoTxt + ' mobile clients';
									}
									console.log($state.params.deviceID)
										//$scope.loadDeviceBlock($state.params.deviceID);
								}
								else
								{
									$scope.ottCalling = undefined;
								}
							} else {
								$scope.serverError = true;
							}
						}).error(function(error) {
						$scope.serverError = true;
					});
                 }
				function getScheduleData() {

					volteServices.setOption(Constants.API.SCHEDULE.LIST);
					volteServices.getData().success(function(response) {
						//  $scope.loadFlag     =  false;
						if (response.appHeader.statusCode == "OK") {
							var scheduleList = response.appResult.serviceRepsonse.scheduleList;
							var bzList = [];
							var hoList = [];

							hoList.push({
								'name': 'Select',
								'value': ''
							});
							bzList.push({
								'name': 'Select',
								'value': ''
							});

							angular.forEach(scheduleList, function(value, key) {
								if (value.scheduleType == 'HOLIDAY') {
									hoList.push({
										'name': value.scheduleName,
										'value': value.scheduleName
									});
								} else {
									bzList.push({
										'name': value.scheduleName,
										'value': value.scheduleName
									});
								}
							});

							$scope.biz_schedule = bzList;
							$scope.holiday_schedule = hoList;

						}
					}).error(function() {});
				}
				$scope.getFunction = function(featureName, row, index, gearType) {
					console.log('inside getFunction')
					switch (featureName) {
						case "Anonymous Call Rejection":
							optionAPI = Constants.API.ANNONYMOUS_CALL_REJECTION.POST;
							$scope.submitData(row);
							break ;

						case "Automatic Callback":
							optionAPI = Constants.API.AUTO_CALLBACK.POST ;
							$scope.submitData(row);
							break ;

						case "Simultaneous Ring Service":
							$scope.lookupDialogRingService(row, index, gearType);
							break;
						case "Selective Call Rejection":
							$scope.lookupCallRejection(row, index, gearType);
							break;
						case "Selective Call Acceptance":
							$scope.lookupCallRejection(row, index, gearType);
							break;
						case "Remote Call Pickup with Barge In":
							$scope.lookupDialogCallPickup(row, index, gearType);
							break;
						case "Pre-Alerting Announcement":
							$scope.lookupDialogPreAlert(row, index, gearType);
							break;
						case "Call Forwarding - Always":
							$scope.lookupDialogNonSelectiveForwarding(row, index, gearType, 'always');
							break;
						case "Call Forwarding - Busy":
							$scope.lookupDialogNonSelectiveForwarding(row, index, gearType, 'busy');
							break;
						case "Call Forwarding - No Answer":
							$scope.lookupDialogNonSelectiveForwarding(row, index, gearType, 'noAnswer');
							break;
						case "Call Forwarding - Selective":
							$scope.lookupDialogSelectiveForwarding(row, index, gearType);
							break;
					}
				}
				$scope.getSubmitFunction = function(featureName, row) {
					switch (featureName) {
						case "Anonymous Call Rejection":
							optionAPI = Constants.API.ANNONYMOUS_CALL_REJECTION.POST;
							$scope.submitData(row);
							break ;

						case "Automatic Callback":
							optionAPI = Constants.API.AUTO_CALLBACK.POST ;
							$scope.submitData(row);
							break ;

						case "Simultaneous Ring Service":
							optionAPI = Constants.API.SIMULTANEOUS_RING_SERVICE.POST;
							$scope.submitData(row);
							break;
						case "Selective Call Rejection":
							optionAPI = Constants.API.SELECTIVE_CALL_REJECTION.POST;
							$scope.deleteSettings(row);
							break;
						case "Selective Call Acceptance":
							optionAPI = Constants.API.SELECTIVE_CALL_ACCEPTANCE.POST;
							$scope.deleteSettings(row);
							break;
						case "Remote Call Pickup with Barge In":
							optionAPI = Constants.API.DIRECTED_CALL_PICKUP.POST;
							console.log(row);
							$scope.submitData(row);
							break;
						case "Pre-Alerting Announcement":
							optionAPI = Constants.API.PRE_ALERT_ANNOUNCEMENT.POST;
							$scope.submitData(row);
							break;
						case "Call Forwarding - Always":
							optionAPI = Constants.API.CALL_FORWARDING.ALWAYS.POST;
							$scope.submitData(row);
							break;
						case "Call Forwarding - Busy":
							optionAPI = Constants.API.CALL_FORWARDING.BUSY.POST;
							$scope.submitData(row);
							break;
						case "Call Forwarding - No Answer":
							optionAPI = Constants.API.CALL_FORWARDING.NOANSWER.POST;
							$scope.submitData(row);
							break;
						case "Call Forwarding - Selective":
							optionAPI = Constants.API.CALL_FORWARDING.SELECTIVE.POST;
							$scope.submitData(row);
							break;
					}
				}

				$scope.submitData = function(row) {
					//var optionAPI = Constants.API[$scope.userFeatureListInfo[row.featureId].option].POST;
					var params = {
						"updateFeatures": {
							"updateFeature": [{
								"phoneNo": row.phoneNo,
								"updateType": "Status",
								"settingsInfo": {}
							}]
						}
					};
					var updateFeature = JSON.parse(JSON.stringify(row));
					//updateFeature.settingsInfo.active = 'false';
					if(row.featureId === '1013')
					{
                      params.updateFeatures.updateFeature[0].settingsInfo = updateFeature.settingsInfo;
                      params.updateFeatures.updateFeature[0].settingsInfo.active = 'false';
                      params.updateFeatures.updateFeature[0].settingsInfo.audioFileDescription = undefined;
                      params.updateFeatures.updateFeature[0].settingsInfo.audioMediaType = undefined;
					}
					else
					{
                      params.updateFeatures.updateFeature[0].settingsInfo = updateFeature.settingsInfo;
					}
					params.updateFeatures.updateFeature[0].criteriaInfo = row.criteriaInfo;
					console.log(row);
					console.log(params);
					volteServices.setOption(optionAPI);
					volteServices.postData(params)
						.success(function(result) {
							//console.log('post call resp', JSON.stringify(result));
							if (result.appHeader.statusCode == "OK") {
								console.log(result);
								// row.settingsInfo.active= false;
								$scope.msgType = "success";
								$scope.msgTxt = "Successfully updated";
								$scope.showMsg = true;
							} else {
								console.log(result);
								row.settingsInfo.active= true;
								$scope.msgType = "error";
								$scope.msgTxt = result.appHeader.statusMessage;
								$scope.showMsg = true;
							}
						})
						.error(function() {
							$scope.msgType = "error";
							$scope.msgTxt = "Error performing Operation";
							$scope.showMsg = true;
						});
				};
				$scope.deleteSettings = function(row) {
					//console.log("dsdhsjfhdfidjfi");
					var params = {
						"updateFeatures": {
							"updateFeature": [{
								"phoneNo": row.phoneNo
							}]
						   }
					    };
					//var option = (row.featureId == '1014') ? Constants.API.SELECTIVE_CALL_ACCEPTANCE.POST : Constants.API.SELECTIVE_CALL_REJECTION.POST;
					// var param;
					var updateFeature = JSON.parse(JSON.stringify(row));
					console.log(updateFeature.criteriaInfo)
					if(updateFeature.criteriaInfo)
					{
						params.updateFeatures.updateFeature[0].criteriaInfo = [];
						for(var i=0;i<updateFeature.criteriaInfo.length;i++)
						{
							params.updateFeatures.updateFeature[0].criteriaInfo.push({
								timeSchedule :updateFeature.criteriaInfo[i].timeSchedule,
								holidaySchedule : updateFeature.criteriaInfo[i].holidaySchedule ,
								blacklisted : "false",
								criteriaName : updateFeature.criteriaInfo[i].criteriaName,
								deleteCriteria : true
							});
						}
						params.updateFeatures.updateFeature[0].updateType= "Criteria";
					}
					console.log(params);
					volteServices.setOption(optionAPI);
					volteServices.postData(params).success(function(response) {
						if (response.appHeader.statusCode == "OK") {
							console.log(response)
							$scope.closeDialog();
							$scope.msgType = "success";
							$scope.msgTxt = 'Successfully Updated';
							$scope.showMsg = true;
						} else {
							$scope.closeDialog();
							$scope.msgType = "error";
							$scope.msgTxt = 'Record Updation Failed';
							$scope.showMsg = true;
						}
					}).error(function() {});
				};

				function devicePath() {

					$scope.imageHost = window.ENV;

				}
				$scope.getOttCalling = function(type) {
					$scope.ottType = type;
					$scope.ottBlockUnblockList = [{
						"mtn": $state.params.lineNumber
					}];
					var dialogTemp = 'partials/components/dialog/' + $scope.ottType + '.html';
					ngDialog.open({
						template: dialogTemp,
						closeByDocument: false,
						closeByEscape: false,
						scope: $scope,
						controller: 'blockUnblockOttCtrl'
					});
				}
				$scope.closeContinueDialog = function() {
					try {
						// console.log($scope.collection);
						var windowIDs = ngDialog.getOpenDialogs();
						ngDialog.close(windowIDs[1]);
					} catch (err) {
						// console.log('Error:', err);
					}
				}
				$scope.setForm = function(scopeForm) {
					this.scopeForm = scopeForm;
				}
				$scope.enableForLines = function() {

					if ($state.params.deviceType == 'lines')
						return true;
					else
						return false;
				}
				$scope.enableForDevices = function() {

						// console.log("Type = " + $scope.type);

						if ($state.params.deviceType == 'devices')
							return true;
						else
							return false;
					}
					/* Start Bridge to Line */
					/* End Bridge to Line */
                $scope.goBack = function() {
                	console.log("**********GOBACK********")
				    window.history.back();
				}
				function init() {

					$scope.loadFlag = true;
					//$scope.hostURL;
					$scope.state_values = AuthorizeConst.STATE_LIST;
					//$scope.getHostURL();
					//getScheduleData();
					$scope.userFeatureListInfo = userFeatureListForRadiotoggle.userFeatureListInfo;
					$scope.lineType = $state.params.lineType;
					$scope.biz_schedule_selected = "Select";
					$scope.holiday_schedule_selected = "Select";
					$scope.tabSelected = 'selective';
					$scope.address911 = {};
					$scope.loadFeatureData = true;
					getEnv();
					$scope.imgHost = "assets/images/";
					$scope.confirmation = true;
					$scope.load = true;
					$scope.pageStartIndex = 0;
					$scope.pageEndIndex = 2;
					getEPAMLink();
					$scope.lookupNo = '';
					$scope.collection = {};
					$scope.lineType = $state.params.lineType;
					$scope.vzGridTpl = "partials/lines/vz-grid/vz.grid.lines.html";
					$scope.lines_filter = linesConst.LINES_FILTER;
					$scope.lines_filter_selected = undefined;
					$scope.lines_actions = linesConst.LINES_ACTIONS;
					$scope.lines_actions_selected = undefined;
					$scope.selectedStatus = '';
					$scope.selectedType = '';
					$scope.lineDetail = '';
					$scope.showManageAccountLink = true;
					$scope.modelDialog = true;
					$scope.showMsgdial = false;
					$scope.msgTypedial = '';
					$scope.msgTxtdial = '';
					$scope.msgType = null;
					$scope.showMsgLineDetail = false;
					$scope.msgTxt = null;
					$scope.type = 'lines';
					$scope.authorizCollection = [];
				}

				init();
			}
		]);
