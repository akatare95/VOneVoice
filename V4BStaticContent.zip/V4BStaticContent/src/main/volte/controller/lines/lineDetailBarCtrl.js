/*
*
*  LinesCtrl - This controller handles lines & devices page
*
*/
var lineDetailBarCtrl = function($scope, lineUserInfo) {

    $scope.goBack=function(){
        window.history.back();
    }
    function init() {
    	$scope.userInfo = lineUserInfo.data;
    }

    init();

};

lineDetailBarCtrl.$inject = ["$scope", "lineUserInfo"];
angular.module( window.AppName ).controller("lineDetailBarCtrl", lineDetailBarCtrl);
