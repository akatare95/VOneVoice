var devicesTabCtrl = function ($scope, lineServices, linesConst, AuthorizeConst, mediatorCtrlFactory, ngDialog, volteServices, Constants, dropdownValueConst, $http, Constants, cache) {
    /**
     * Default scope variables
     */

    /**
     * Kick of the list load service
     */
     function getDevices() {
        //console.log(angular.element(document.getElementsByClassName('lines-dropdown'))[0].children[0].children[0].children[0].innerText='Action');
        lineServices.setOption( $scope.type );
        lineServices.getDeviceCount()
            .success(function (result) {
                if (result.appHeader.statusCode == 'OK') {
                    $scope.redBarItems = [
                        {label: "All Devices", value: result.appResult.serviceRepsonse.totalCount, type:"devices", filter:undefined},
                        {label: "Smartphones", value: result.appResult.serviceRepsonse.smartphoneCount, type:"devices", filter:"SMARTPHONE"},
                        {label: "Deskphones", value: result.appResult.serviceRepsonse.deskphoneCount, type:"devices", filter:"DESKPHONE"},
                        {label: "OTT", value: result.appResult.serviceRepsonse.ottDevicesCount, type:"devices", filter:"OTT"}
                    ];
                    mediatorCtrlFactory.mediate( $scope.redBarItems );

                } else {
                    $scope.redBarItems = [
                        {label: "All Devices", value: 0, type:"devices", filter:undefined},
                        {label: "Smartphones", value: 0, type:"devices", filter:"SMARTPHONE"},
                        {label: "Deskphones", value: 0, type:"devices", filter:"DESKPHONE"},
                        {label: "STMA", value: 0, type:"devices", filter:"OTT"}
                    ];
                    mediatorCtrlFactory.mediate( $scope.redBarItems );
                    $scope.serverError = true;
                }
            })
            .error(function (error) {
                $scope.serverError = true;
                console.log( 'Unable to load customer data: ' + error.message );
                //$scope.status = 'Unable to load customer data: ' + error.message;
            });

        getData();
    }
    $scope.setTypeFilter = function(item) {
        // $rootScope.selectedRedItemLabel = item;
        $scope.devices_filter_selected=item;
    };
    function getData(){
       lineServices.loadGrid()
            .success(function (result) {
                if (result.appHeader.statusCode == 'OK') {
                    $scope.serverError = false;
                    $scope.loadFlag   = false;
                    $scope.collection = result.appResult.serviceRepsonse.deviceSummaryList;
                    console.log($scope.collection);
                } else {
                    $scope.serverError = true;
                }
            })
            .error(function (error) {
                $scope.serverError = true;
            });
     }
      $scope.checkAll = function () {
        if ($scope.selectedAll) {
            $scope.selectedAll = true;
        } else {
            $scope.selectedAll = false;
        }
        angular.forEach($scope.collection, function (row) {
            row.Selected = $scope.selectedAll;
        });

    };
     $scope.renderColumn = function (field, record) {

        switch (field) {
            case 'associatedDeviceCount':
                return (record[field]==undefined?0:record[field]) + ' ' + (parseInt(record[field]) === 1 ? 'Device' : 'Devices');
            default:
                return record[field];
        }
    };
    $scope.renderColumnName = function (field) {
        var map = {
            userName: 'User Name',
            ext: 'Ext',
            status: 'Status',
            type: 'Type',
            associatedDeviceCount: '#Associated Devices'
        };

        return map[field];
    };
    $scope.loadData = function( option  ) {
      $scope.loadFlag     =  true;
      $scope.incrementVal =  10;
      $scope.limitIndex   =  10;
      $scope.startIndex   =  1;
      $scope.downloadType = "exportTypeDevice";
      getDevices();
    }
     $scope.downloadFile = function() {
      console.log("in download : 1");
        var params  = {};
        params.excelType = "exportTypeDevice";
        params.dateRange = "30";
        console.log("excelType==>"+$scope.downloadType);
       var dateVal = new Date();

       var devicesForDownloadList=[];
       for(var i=0;i<$scope.collection.length;i++){
          if($scope.collection[i].Selected == true)
          {
        	  devicesForDownloadList.push({
                         "deviceMake":$scope.collection[i].deviceMake,
                         "deviceModel":$scope.collection[i].deviceModel,
                         "deviceType":$scope.collection[i].deviceType,
                         "deviceId":$scope.collection[i].deviceId,
                         "lineNumber":$scope.collection[i].lineNumber,
                         "userName":$scope.collection[i].userName,
                         "deviceStatus":$scope.collection[i].deviceStatus
                       });
          }
       };
       params.deviceData = devicesForDownloadList;


      $http({
          url: window.APP_HOST + Constants.API.SETUPUSERINFO_PAGE.DOWNLOAD_ICON,
          method: "POST",
          data: params, //this is your json data string
          headers: {
             'Content-type': 'application/json'
          },
          responseType: 'arraybuffer'
      }).success(function (data, status, headers, config) {
          //var blob = new Blob([data], {type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"});
          //var blob = new Blob([data], {type: "application/vnd.ms-excel"});
      var blob = new Blob([data], {type: "application/vnd.ms-excel;charset=utf-8"});
          saveAs(blob, 'DownloadList_' + $scope.downloadType  + '.xls');
          //saveAs(blob, 'DownloadList_' + $scope.downloadType + dateVal + '.xls');
          /*var objectUrl = URL.createObjectURL(blob);
          window.open(objectUrl);*/
      }).error(function (data, status, headers, config) {
          //upload failed
      });
    }
     function getFilterDeskSmarPhoneVal()
    {
      var deviceMDNList=[];
          for(var i=0;i<$scope.collection.length;i++){
                    //$scope.collection[i].settingsInfo.active=$scope.collection[i].settingsInfo.active=='true'?true:false;
                   if($scope.collection[i].Selected == true)
                   {
                         if($scope.collection[i].deviceType=='DESKPHONE' || $scope.collection[i].deviceType=='SMARTPHONE')
                         {
                            deviceMDNList.push({
                                  "lineNumber": $scope.collection[i].lineNumber,
                                  "deviceId":  $scope.collection[i].deviceId
                                });
                         }
                       else
                       {
                        $scope.showMsg=true;
                        $scope.msgType='error';
                        $scope.msgTxt='Please Select Deskphones';
                        console.log('Please Select Deskphones');
                        return;
                       }
                   }
                   //i++;
                };
                return deviceMDNList;
    }
    function getFilterValues()
    {
      var deviceMDNList=[];
          for(var i=0;i<$scope.collection.length;i++){
                    //$scope.collection[i].settingsInfo.active=$scope.collection[i].settingsInfo.active=='true'?true:false;
                   if($scope.collection[i].Selected == true)
                   {

                            deviceMDNList.push({
                                  "lineNumber": $scope.collection[i].lineNumber,
                                  "deviceId":  $scope.collection[i].deviceId,
                                  "status": $scope.collection[i].status,
                                  "isChecked":false
                                });
                   }
                   //i++;
                };
                return deviceMDNList;
    }
    function getFilterDeskphoneValues(){
       var deviceMDNList=[];
          for(var i=0;i<$scope.collection.length;i++){
                    //$scope.collection[i].settingsInfo.active=$scope.collection[i].settingsInfo.active=='true'?true:false;
                   if($scope.collection[i].Selected == true)
                   {
                         if($scope.collection[i].deviceType=='DESKPHONE')
                         {
                            deviceMDNList.push({
                                  "lineNumber": $scope.collection[i].lineNumber,
                                  "deviceId":  $scope.collection[i].deviceId
                                });
                         }
                         else
                         {
                          $scope.showMsg=true;
                          $scope.msgType='error';
                          $scope.msgTxt='Please Select Deskphones';
                          return;
                         }
                   }
                   //i++;
                };
                return deviceMDNList;
    }
    $scope.checkValue=function(){
      if($scope.lines_actions_selected=='Update 911 Address')
      {
          $scope.deviceMDNList=getFilterDeskphoneValues();
          if(!!$scope.deviceMDNList)
          {
              if($scope.deviceMDNList.length==0)
            {
                      $scope.lines_actions_selected=undefined;
                      $scope.showMsg=true;
                      $scope.msgType='error';
                      $scope.msgTxt='Please Select a record';
                      return;
            }
            else
            {
              $scope.update911LookupDial();
              $scope.lines_actions_selected=undefined;
            }
          }
      }
      else if(!!$scope.lines_actions_selected && $scope.lines_actions_selected !=='Update 911 Address')
      {
        // $scope.lines_actions_selected=='Reboot'||$scope.lines_actions_selected=='Disable'||$scope.lines_actions_selected=='Remove'
         $scope.deviceMDNList=$scope.lines_actions_selected=='Reboot'?getFilterDeskphoneValues():($scope.lines_actions_selected=='Disable'?getFilterDeskSmarPhoneVal():getFilterValues());
         if(!!$scope.deviceMDNList)
         {
            if($scope.deviceMDNList.length==0)
            {
                      $scope.showMsg=true;
                      $scope.msgType='error';
                      $scope.msgTxt='Please Select a record';
                      console.log('Please Select a record');
                      $scope.lines_actions_selected=undefined;
                      return;
            }
            else
            {
               console.log($scope.deviceMDNList);
               var type=$scope.lines_actions_selected.toUpperCase();
               $scope.lines_actions_selected=undefined;
               getDialogBox($scope.deviceMDNList,type);
            }
         }
         else
         {
           $scope.lines_actions_selected=undefined;
         }
      }
    }
    function getDialogBox(params,type)
    {
      var constType=type.toUpperCase();
      //var constType=type.toUpperCase();
      initDial();
      function initDial(){
        console.log(params)
        $scope.showWarning=true;
        $scope.bulkInfo=params;
        $scope.hideLines=true;
        $scope.showMsgDrop=true;
        $scope.msgTypeDrop='error';
        $scope.confirmation=false;
        $scope.alertMsg=dropdownValueConst[constType][0].pageAlertTxt;
        if($scope.bulkInfo.length==1)
        {
           $scope.msgTxtDrop=dropdownValueConst[constType][0].pageConfirmationTxt+' '+$scope.bulkInfo[0].lineNumber+' ?';
        }
        else if($scope.bulkInfo.length>1)
        {
          $scope.msgTxtDrop=dropdownValueConst[constType][0].pageConfirmationTxt+' the selected lines ?';
        }
      }
      $scope.blockLine=function(){
      console.log('block line');
      $scope.confirmation=true;
      $scope.showWarning=false;
      $scope.showMsgDrop=true;
      $scope.msgTypeDrop='success';
      $scope.thankuTxtDrop=dropdownValueConst[constType][0].thankuTxt;
      $scope.msgTxtDrop=dropdownValueConst[constType][0].pageSuccessTxt;
      //$scope.thankuTxtDrop='Thank You';
      }
      var dialogTemp='partials/components/dialog/'+type.toLowerCase()+'.html'
      var new_dialog = ngDialog.open({ template: dialogTemp,
           closeByDocument: false,
           closeByEscape: false,
           scope:$scope
            });
    }
    $scope.update911LookupDial=function(){
      $scope.update911Form={};
      $scope.showMsgdial=false;
      $scope.msgTypedial='';
      $scope.submit911AddressInfo=function(){
          var arrayVal=[$scope.update911Form.addressone,$scope.update911Form.addresstwo,$scope.update911Form.city,$scope.update911Form.state,$scope.update911Form.zipcode];
          for(var i=0;i<arrayVal.length;i++)
          {
            if(!!arrayVal[i] && i!=1 )
            {
                      $scope.showMsgdial=true;
                      $scope.msgTypedial='error';
                      $scope.msgTxtdial='Please fill required fields';
                      $scope.update911Form.form.$setPristine();
                      console.log('Please Select Deskphones');
                      return;
            }
          }
          var params={
                    "deviceMDNList":[$scope.deviceMDNList[0]],
                    "911Address": {
                                    "addressLine1": $scope.update911Form.addressone,
                                    "addressLine2": $scope.update911Form.addresstwo,
                                    "city": $scope.update911Form.city,
                                    "state":$scope.update911Form.state,
                                    "zipCode": $scope.update911Form.zipcode
                                  }
                    };
          volteServices.setOption( Constants.API.UPDATE911ADDRESS.POST );
          volteServices.postData( params ).success(function( response ){

              if(response.appHeader.statusCode == "OK") {

                  $scope.msgType  = "success";
                  $scope.msgTxt   = "Successfully Updated!";
                  $scope.showMsg  = true;
                  $scope.selectedAll = false;
                  $scope.checkAll();
                  $scope.closeDialog();
              } else {
                  $scope.closeDialog();
                  $scope.$parent.msgType  = "error";
                  $scope.$parent.msgTxt   = response.appHeader.statusMessage;
                  $scope.$parent.showMsg  = true;
                  $scope.selectedAll = false;
                  $scope.checkAll();
                  //$scope.closeDialog();
              }
          })
      }
      var new_dialog = ngDialog.open({ template: 'partials/components/dialog/update911LinesNdevices.html',
         closeByDocument: false,
         closeByEscape: false,
         scope: $scope
      });
    }
     $scope.editableTable=function()
    {
        var editableSelected=$scope.selectedLines.slice();
        var editableAvailable=$scope.availableLines.slice();
        var availableLinesChosen=[];
        var selectedLinesChosen=[];
        $scope.models =
                {
                    selected: null,
                    lists:
                    {
                        "availableLine": editableAvailable ,
                        "selectedLines": editableSelected
                    }
                };
        $scope.fromAvailableLinesToSelectedLines=function()
        {
           for(var i=0;i<availableLinesChosen.length;i++)
           {
             $scope.models.lists.selectedLines.push(availableLinesChosen[i]);
             $scope.models.lists.availableLine.splice($scope.models.lists.availableLine.indexOf(availableLinesChosen[i]),1);
           }
           availableLinesChosen=[];
        }
        $scope.fromSelectedLinesToAvailableLines=function(){
            for(var i=0;i<selectedLinesChosen.length;i++)
           {
             $scope.models.lists.availableLine.push(selectedLinesChosen[i]);
             $scope.models.lists.selectedLines.splice($scope.models.lists.selectedLines.indexOf(selectedLinesChosen[i]),1);
           }
           selectedLinesChosen=[];
        }
        $scope.onAvailableLinesClick = function(event, index, item) {
        var ele = event.currentTarget;
        //check whether an already chosen line is selected again
        //if so, clear the selection
        //else set selection
        if(angular.element(ele).hasClass('selected-line')){
            angular.element(ele).removeClass('selected-line');
            availableLinesChosen.splice(availableLinesChosen.indexOf(item), 1);
        } else {
            angular.element(ele).addClass('selected-line');
            availableLinesChosen.push(item);
          }
        }
        $scope.onSelectedLinesClick = function(event, index, item) {
        var ele = event.currentTarget;
        //check whether an already chosen line is selected again
        //if so, clear the selection
        //else set selection
        if(angular.element(ele).hasClass('selected-line')) {
            angular.element(ele).removeClass('selected-line');
            selectedLinesChosen.splice(selectedLinesChosen.indexOf(item), 1);
        } else {
            angular.element(ele).addClass('selected-line');
            selectedLinesChosen.push(item);
        }
       }
        $scope.moveUp=function()
        {
            for(var i = 0; i < selectedLinesChosen.length; i++) {
                var idx = $scope.models.lists.selectedLines.indexOf(selectedLinesChosen[i])
                if (idx > 0) {
                    var itemToMove = $scope.models.lists.selectedLines.splice(idx, 1);
                    $scope.models.lists.selectedLines.splice(idx-1, 0, itemToMove[0]);
                }
            }
        }
        $scope.moveDown=function()
        {
         for(var i = 0; i < selectedLinesChosen.length; i++)
         {
            var idx = $scope.models.lists.selectedLines.indexOf(selectedLinesChosen[i]);
            if (idx < $scope.models.lists.selectedLines.length-1) {
                var itemToMove = $scope.models.lists.selectedLines.splice(idx, 1);
                $scope.models.lists.selectedLines.splice(idx+1, 0, itemToMove[0]);
            }
        }
       }
        $scope.save=function(){
            $scope.selectedLines= $scope.models.lists.selectedLines.slice();
            $scope.availableLines=$scope.models.lists.availableLine.slice();
            $scope.closeDialog();
        }
      var new_dialog = ngDialog.open({ template: 'partials/components/dialog/editableTable.html',
           closeByDocument: false,
           closeByEscape: false,
           scope:$scope
      });
    }
    $scope.closeDialog = function() {
      try {
        // $scope.$parent.lines_actions_selected=undefined;
        // angular.element(document.getElementsByClassName('dropdown-display'))[0].children[0].innerText='Action';
        var windowIDs = ngDialog.getOpenDialogs();
        //console.log(windowIDs);
        ngDialog.close(windowIDs[1]);
        //$scope.lines_actions_selected = undefined;
      } catch(err) {
        //console.log('Error:', err);
      }
    }
    $scope.closeContinueDialog = function()
    {
      try {
            //console.log($scope.collection);
            $scope.selectedAll = false;
            $scope.checkAll();
            var windowIDs = ngDialog.getOpenDialogs();
            ngDialog.close(windowIDs[1]);
          } catch(err) {
            //console.log('Error:', err);
      }
    }
    $scope.setSearchText = function() {
        var lineDeviceFilterInputTextval =  $scope.lineDevice.FilterInputText;
        console.log(lineDeviceFilterInputTextval);
        if(lineDeviceFilterInputTextval!=undefined){
            $scope.lineDeviceFilterVal = lineDeviceFilterInputTextval.replace(/-/g, "");
        }

        console.log("lineDeviceFilterVal - " + $scope.lineDeviceFilterVal );
    }
    function init () {
      console.log("Inside devicesTabCtrl::init()..." );
       getEnv();
      $scope.type = "devices";
      $scope.loadFlag   = true;
      $scope.imgHost = "http://ss7.vzw.com";
      $scope.devices_filter = linesConst.DEVICES_FILTER;
      if($scope.update911AddressOrBridgeALine == false){
    	 $scope.devices_filter_selected = undefined;
      }
      $scope.update911AddressOrBridgeALine=false;

      $scope.lines_actions= linesConst.DEVICES_ACTIONS;
      $scope.lines_actions_selected = undefined;
      $scope.state_values=AuthorizeConst.STATE_LIST;
      $scope.collection = [];
      $scope.selectedLines=[{'name':'Device ID','value':'deviceId'},{'name':'Device Type','value':'deviceType'},{'name':'Phone Line','value':'lineNumber'},{'name':'User','value':'userName'},{'name':'Status','value':'deviceStatus'}];
      $scope.availableLines=[];
      getDevices();
      $scope.setSearchText();
    }

    init();
};

devicesTabCtrl.$inject = ['$scope', 'lineServices.deprecated', 'linesConst', 'AuthorizeConst', 'mediatorCtrlFactory', 'ngDialog', 'volteServices', 'Constants', 'dropdownValueConst', '$http', 'Constants', 'cache'];

angular.module(window.AppName).controller('devicesTabCtrl', devicesTabCtrl);
