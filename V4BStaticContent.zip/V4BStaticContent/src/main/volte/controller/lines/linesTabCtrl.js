var linesTabCtrl = function ($scope, lineServices, linesConst, AuthorizeConst, ngDialog, dropdownValueConst, mediatorCtrlFactory, $http, Constants, cache, $rootScope) {
    /**
     * Default scope variables
     */

    /**
     * Kick of the list load service
     */
     var linesAPI=Constants.API.LINES_PAGE;
     function getLines() {
        //console.log(angular.element(document.getElementsByClassName('lines-dropdown')[0].children));
        lineServices.setOption( $scope.type );
        lineServices.getLineCount()
            .success(function (result) {
              console.log($scope.redBarItems);
                if (result.appHeader.statusCode == 'OK') {
                    $scope.navCollection=result.appResult.serviceRepsonse;
                    $scope.redBarItems = [
                        {label: "All Lines", value: $scope.navCollection.totalCount, type:"lines", filter:undefined},
                        {label: "Corporate Lines", value: $scope.navCollection.cleuCount, type:"lines", filter:"Corporate"},
                        {label: "Employee Lines", value: $scope.navCollection.eleuCount, type:"lines", filter:"Employee"}
                    ];
                    mediatorCtrlFactory.mediate( $scope.redBarItems );

                } else {
                    $scope.redBarItems = [
                        {label: "All Lines", value: 0, type:"lines", filter:undefined},
                        {label: "Corporate Lines", value: 0, type:"lines", filter:"Corporate"},
                        {label: "Employee Lines", value: 0, type:"lines", filter:"Employee"}
                    ];
                    // mediatorCtrlFactory.mediate( $scope.redBarItems );
                    $scope.serverError = true;
                }
            })
            .error(function (error) {
                $scope.serverError = true;
                console.log( 'Unable to load customer data: ' + error.message );
                //$scope.status = 'Unable to load customer data: ' + error.message;
            });

        getData();

    }
     $scope.downloadFile = function() {
      console.log("in download : 1");
        var params  = {};
        //params.excelType = $scope.downloadType;
        params.excelType = "exportTypeLine";
        params.dateRange = "30";

        var linesForDownloadList=[];
        for(var i=0;i<$scope.collection.length;i++){
           if($scope.collection[i].Selected == true)
           {
        	   linesForDownloadList.push({
                          "lineNumber": $scope.collection[i].lineNumber,
                          "ext":$scope.collection[i].ext,
                          "userName":$scope.collection[i].userName,
                          "status":$scope.collection[i].status,
                          "type":$scope.collection[i].type,
                          "associatedDeviceCount":$scope.collection[i].associatedDeviceCount
                        });
           }
        };
        params.lineData = linesForDownloadList;


        console.log("excelType==>"+$scope.downloadType);
       var dateVal = new Date();

      $http({
          url: window.APP_HOST + Constants.API.SETUPUSERINFO_PAGE.DOWNLOAD_ICON,
          method: "POST",
          data: params, //this is your json data string
          headers: {
             'Content-type': 'application/json'
          },
          responseType: 'arraybuffer'
      }).success(function (data, status, headers, config) {
          //var blob = new Blob([data], {type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"});
          //var blob = new Blob([data], {type: "application/vnd.ms-excel"});
      var blob = new Blob([data], {type: "application/vnd.ms-excel;charset=utf-8"});
          saveAs(blob, 'DownloadList_' + $scope.downloadType  + '.xls');
          //saveAs(blob, 'DownloadList_' + $scope.downloadType + dateVal + '.xls');
          /*var objectUrl = URL.createObjectURL(blob);
          window.open(objectUrl);*/
      }).error(function (data, status, headers, config) {
          //upload failed
      });
    }
     function getData(){
       lineServices.loadGrid()
            .success(function (result) {
                if (result.appHeader.statusCode == 'OK') {
                    $scope.serverError = false;
                    $scope.loadFlag   = false;
                    $scope.collection = result.appResult.serviceRepsonse.lineSummaryList;
                } else {
                  // $scope.showmsg=true;
                  // $scope.msgTxt;
                  // $scope.msgType=;
                    $scope.serverError = true;
                }
            })
            .error(function (error) {
                $scope.serverError = true;
            });
     }
     function getFilterValues()
    {
      var deviceMDNList=[];
      var ottCallingTypeCheck=$scope.lines_actions_selected.toUpperCase()=='UNBLOCKMOBILE'?'UnBlocked':'Blocked';
      var checkBlockUnblockVal=ottCallingTypeCheck=='Blocked'?'A':'D';
      console.log(ottCallingTypeCheck);
          for(var i=0;i<$scope.collection.length;i++){
                    //$scope.collection[i].settingsInfo.active=$scope.collection[i].settingsInfo.active=='true'?true:false;
                   if($scope.collection[i].Selected == true)
                   {
                            deviceMDNList.push({
                                  "mtn": $scope.collection[i].lineNumber,
                                  "userName":$scope.collection[i].userName
                                });
                   }
                   //i++;
                };
                return deviceMDNList;
    }
      $scope.checkValue=function(){
         if(!!$scope.lines_actions_selected)
         {
            $scope.deviceMDNList=getFilterValues();

	         if($scope.deviceMDNList.length==0)
	          {
	                    $scope.showMsg=true;
	                    $scope.msgType='error';
	                    $scope.msgTxt='Please Select a record';
	                    console.log('Please Select a record');
	                    $scope.lines_actions_selected=undefined;
	                    // $scope.lines_actions_selected=undefined;
	                    // console.log(document.getElementsByClassName('lines-dropdown')[0].children[0].children[0].children[0].innerText='Action');
	                    return;
	          }
	          else
	          {
	            //console.log('work in progress.....');
	            //$state.go('')
	             console.log($scope.deviceMDNList);
	             var type=$scope.lines_actions_selected=='Mobile Client'?'MOBILECLIENT':$scope.lines_actions_selected.toUpperCase();
	             $scope.lines_actions_selected=undefined;
	             getDialogBox($scope.deviceMDNList,type);
	          }
         }
    }
    function getDialogBox(params,type)
    {
      var constType=type.toUpperCase();
      var lineAPI;
      $scope.params=params;
      $scope.blockOTTIndicator=type=='MOBILECLIENT'?'Y':'N';
      //var constType=type.toUpperCase();
      initDial();
      function initDial(){
        console.log(params)
        $scope.showWarning=true;
        $scope.bulkInfo=params;
        $scope.hideLines=true;
        $scope.showMsgDrop=true;
        $scope.msgTypeDrop='error';
        $scope.confirmation=false;
        console.log($rootScope.userProfileIdList.loggedInUserId);
        if(type=='MOBILECLIENT')
        {
            $scope.alertMsg=dropdownValueConst[constType][0].pageAlertTxt;
            //$scope.msgTxtDrop=dropdownValueConst[constType][0].pageConfirmationTxt;
            if($scope.bulkInfo.length==1)
            {
               $scope.msgTxtDrop=dropdownValueConst[constType][0].pageConfirmationTxt;
            }
            else if($scope.bulkInfo.length>1)
            {
              $scope.msgTxtDrop=dropdownValueConst[constType][0].pageBulkConfirmationTxt;
            }
        }
        else if(type=='UNBLOCKMOBILE'){
          $scope.blockUnblockLine();
        }
        $scope.anchorLink='';
      }

      $scope.blockUnblockLine=function(blockVal){
          var submitParams={"mtnList":$scope.params,"blockOTTIndicator":$scope.blockOTTIndicator};
          console.log(submitParams);
          lineServices.getBlockUnBlockData(linesAPI.BLOCKUNBLOCK,submitParams).
          success(function (result) {
            console.log(result);
                if (result.appHeader.statusCode == 'OK') {
                    $scope.confirmation=true;
                    $scope.showWarning=false;
                    $scope.showMsgDrop=true;
                    $scope.msgTypeDrop='success';
                    $scope.transactionId=123456;
                    $scope.thankuTxtDrop=dropdownValueConst[constType][0].thankuTxt;
                    $scope.msgTxtDrop=dropdownValueConst[constType][0].pageSuccessTxt;
                } else {
                    $scope.confirmation=true;
                    $scope.showWarning=false;
                    $scope.showMsgDrop=true;
                    $scope.showMsg=false;
                    $scope.msgTypeDrop='error';
                    $scope.msgTxtDrop=result.appHeader.statusMessage;
                    $scope.thankuTxtDrop='Error';
                    // $scope.msgTxtDrop=dropdownValueConst[constType][0].pageSuccessTxt;
                }
            })
            .error(function (error) {
                $scope.serverError = true;
            });
      }
      var dialogTemp='partials/components/dialog/'+type.toLowerCase()+'.html'
      var new_dialog = ngDialog.open({ template: dialogTemp,
           closeByDocument: false,
           closeByEscape: false,
           scope:$scope
            });
    }
     $scope.checkAll = function () {
        angular.forEach($scope.filteredlength, function (row) {
            row.Selected = $scope.selectedAll;
        });

    };
     $scope.renderColumn = function (field, record) {
        switch (field) {
            case 'associatedDeviceCount':
                return (record[field]==undefined?0:record[field]) + ' ' + (parseInt(record[field]) === 1 ? 'Device' : 'Devices');
            default:
                return record[field];
        }
    };
    $scope.renderColumnName = function (field) {
        var map = {
            userName: 'User Name',
            ext: 'Ext',
            status: 'Status',
            type: 'Type',
            associatedDeviceCount: '#Associated Devices'
        };

        return map[field];
    };
    $scope.editableTable=function()
    {
        var editableSelected=$scope.selectedLines.slice();
        var editableAvailable=$scope.availableLines.slice();
        var availableLinesChosen=[];
        var selectedLinesChosen=[];
        $scope.models =
                {
                    selected: null,
                    lists:
                    {
                        "availableLine": editableAvailable ,
                        "selectedLines": editableSelected
                    }
                };
        $scope.fromAvailableLinesToSelectedLines=function()
        {
           for(var i=0;i<availableLinesChosen.length;i++)
           {
             $scope.models.lists.selectedLines.push(availableLinesChosen[i]);
             $scope.models.lists.availableLine.splice($scope.models.lists.availableLine.indexOf(availableLinesChosen[i]),1);
           }
           availableLinesChosen=[];
        }
        $scope.fromSelectedLinesToAvailableLines=function(){
            for(var i=0;i<selectedLinesChosen.length;i++)
           {
             $scope.models.lists.availableLine.push(selectedLinesChosen[i]);
             $scope.models.lists.selectedLines.splice($scope.models.lists.selectedLines.indexOf(selectedLinesChosen[i]),1);
           }
           selectedLinesChosen=[];
        }
        $scope.onAvailableLinesClick = function(event, index, item) {
        var ele = event.currentTarget;
        //check whether an already chosen line is selected again
        //if so, clear the selection
        //else set selection
        if(angular.element(ele).hasClass('selected-line')){
            angular.element(ele).removeClass('selected-line');
            availableLinesChosen.splice(availableLinesChosen.indexOf(item), 1);
        } else {
            angular.element(ele).addClass('selected-line');
            availableLinesChosen.push(item);
          }
        }
        $scope.onSelectedLinesClick = function(event, index, item) {
        var ele = event.currentTarget;
        //check whether an already chosen line is selected again
        //if so, clear the selection
        //else set selection
        if(angular.element(ele).hasClass('selected-line')) {
            angular.element(ele).removeClass('selected-line');
            selectedLinesChosen.splice(selectedLinesChosen.indexOf(item), 1);
        } else {
            angular.element(ele).addClass('selected-line');
            selectedLinesChosen.push(item);
        }
       }
        $scope.moveUp=function()
        {
            for(var i = 0; i < selectedLinesChosen.length; i++) {
                var idx = $scope.models.lists.selectedLines.indexOf(selectedLinesChosen[i])
                if (idx > 0) {
                    var itemToMove = $scope.models.lists.selectedLines.splice(idx, 1);
                    $scope.models.lists.selectedLines.splice(idx-1, 0, itemToMove[0]);
                }
            }
        }
        $scope.moveDown=function()
        {
         for(var i = 0; i < selectedLinesChosen.length; i++)
         {
            var idx = $scope.models.lists.selectedLines.indexOf(selectedLinesChosen[i]);
            if (idx < $scope.models.lists.selectedLines.length-1) {
                var itemToMove = $scope.models.lists.selectedLines.splice(idx, 1);
                $scope.models.lists.selectedLines.splice(idx+1, 0, itemToMove[0]);
            }
        }
       }
        $scope.save=function(){
            $scope.selectedLines= $scope.models.lists.selectedLines.slice();
            $scope.availableLines=$scope.models.lists.availableLine.slice();
            $scope.closeDialog();
        }
      var new_dialog = ngDialog.open({ template: 'partials/components/dialog/editableTable.html',
           closeByDocument: false,
           closeByEscape: false,
           scope:$scope
      });
    }
    $scope.closeDialog = function() {
      try {
        // $scope.$parent.lines_actions_selected=undefined;
        // angular.element(document.getElementsByClassName('dropdown-display'))[0].children[0].innerText='Action';
        var windowIDs = ngDialog.getOpenDialogs();
        //console.log(windowIDs);
        ngDialog.close(windowIDs[1]);
        //$scope.lines_actions_selected = undefined;
      } catch(err) {
        //console.log('Error:', err);
      }
    }
    $scope.closeContinueDialog = function()
    {
      try {
            //console.log($scope.collection);
            $scope.selectedAll = false;
            $scope.checkAll();
            var windowIDs = ngDialog.getOpenDialogs();
            ngDialog.close(windowIDs[1]);
          } catch(err) {
            //console.log('Error:', err);
      }
    }
    $scope.loadData = function( option  ) {
      $scope.loadFlag     =   false;
      $scope.incrementVal =  10;
      $scope.limitIndex   =  10;
      $scope.startIndex   =  1;
      $scope.downloadType = "exportTypeLine";
      getLines();
    }
    $scope.setTypeFilter = function(item, gridType) {
        // $rootScope.selectedRedItemLabel = item;
        $scope.lines_filter_selected=item;
    };
    $scope.setSearchText = function() {
        var lineDeviceFilterInputTextval =  $scope.lineDevice.FilterInputText;
        console.log(lineDeviceFilterInputTextval);
        if(lineDeviceFilterInputTextval!=undefined){
            $scope.lineDeviceFilterVal = lineDeviceFilterInputTextval.replace(/-/g, "");
        }

        console.log("lineDeviceFilterVal - " + $scope.lineDeviceFilterVal );
    }

    function init () {
      console.log("Info - " );
      getEnv();
      $scope.type='lines';
      $scope.vzGridTpl="";
      $scope.loadFlag   = true;
      $scope.imgHost = "http://ss7.vzw.com";
      $scope.lines_filter = linesConst.LINES_FILTER;
      $scope.lines_filter_selected = undefined;
      $scope.lines_actions= linesConst.LINES_ACTIONS;
      $scope.lines_actions_selected = undefined;
      $scope.state_values=AuthorizeConst.STATE_LIST;
      $scope.collection = [];
      $scope.selectedLines=[{'name':'Ext','value':'ext'},{'name':'User Name','value':'userName'},{'name':'Status','value':'status'},{'name':'Type','value':'type'},{'name':'#Associated Devices','value':'associatedDeviceCount'}];
      $scope.availableLines=[];
      $scope.setSearchText();
      getLines();
    }

    init();
};

linesTabCtrl.$inject = ['$scope', 'lineServices.deprecated', 'linesConst', 'AuthorizeConst','ngDialog', 'dropdownValueConst', 'mediatorCtrlFactory', '$http', 'Constants', 'cache', '$rootScope'];

angular.module(window.AppName).controller('linesTabCtrl', linesTabCtrl);
