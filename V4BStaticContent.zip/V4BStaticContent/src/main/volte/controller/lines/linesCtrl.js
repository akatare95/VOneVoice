/*
*
*  LinesCtrl - This controller handles lines & devices page
*
*/
var LinesCtrl = function($scope, ngDialog, cache) {

    /*
    * Declaring variables
    *
    */
    $scope.tplUrl= $scope.tplUrl ||'partials/lines/linesTab.html';
    $scope.sample=[];
    $scope.lineDevice={};
    $scope.lineDevice.FilterInputText = cache.get("line-devices-auto");
    var showType;
    showType  = cache.get("show-type");
    if(showType=='Devices')
    {
        $scope.tplUrl='partials/lines/deviceTab.html';
        var searchType=cache.get("searchType");
        if(searchType == 'Deskphone'){
        	cache.put("searchType", "");
        	$scope.devices_filter_selected='DESKPHONE';
        	$scope.update911AddressOrBridgeALine=true;
        	console.log("Setting the filter selected as DESKPHONE");
        }
    }
    else
    {
        $scope.tplUrl='partials/lines/linesTab.html';
    }
    $scope.toggleType = function (type) {
        $scope.tplUrl=type=='lines'?'partials/lines/linesTab.html':'partials/lines/deviceTab.html';
    };
    $scope.disableOnACL = function (type) {
        return String(type).toLowerCase() === 'employee';
    };

};

LinesCtrl.$inject = ["$scope", "ngDialog", "cache"];
angular.module( window.AppName ).controller("LinesCtrl", LinesCtrl);
