(function() {
    var associatedDevicesCtrl = function($scope, linesService, $state, ngDialog, volteServices, Constants, dropdownValueConst, $http, $window, $rootScope) {
        // console.log($scope.asscDevices);
        // console.log($scope.asscUrl);
        $scope.currentAsscIndex = 0;
        $scope.abstracts={
           errorHandler: function(err) {
             $scope.showMsg=true;
             $scope.msgType='error';
             $scope.msgTxt = err.message;
           } ,
           successHandler: function(message) {
             $scope.showMsg=true;
             $scope.msgType='success';
             $scope.msgTxt = message;
           }
        }

        if ($scope.asscDevices.length)
         {
            $scope.currentAsscIndex = 0;
            $scope.asscUrl = 'partials/details/devices/' + $scope.asscDevices[$scope.currentAsscIndex].deviceType.toUpperCase() + '.html';
            if ($scope.asscDevices[$scope.currentAsscIndex].deviceType.toUpperCase() === 'DESKPHONE') {
                getData911UpdateData();
            }
            $scope.deviceId = $scope.asscDevices[$scope.currentAsscIndex].deviceId;
            $scope.device = $scope.asscDevices[$scope.currentAsscIndex];
            if($scope.device && $scope.device.adminLineInfo && $scope.device.adminLineInfo.length )
            {
              $scope.phoneNumber = $scope.asscDevices[$scope.currentAsscIndex].adminLineInfo[0].phoneNumber ;
              $scope.userName =    $scope.asscDevices[$scope.currentAsscIndex].adminLineInfo[0].userName ;
            }

        }
          $scope.loadDeviceBlock = function(index) {
            $scope.currentAsscIndex = index;
            $scope.asscUrl = 'partials/details/devices/' + $scope.asscDevices[index].deviceType.toUpperCase() + '.html';
            if ($scope.asscDevices[$scope.currentAsscIndex].deviceType.toUpperCase() === 'DESKPHONE') {
                getData911UpdateData();
            }
            $scope.deviceId = $scope.asscDevices[$scope.currentAsscIndex].deviceId;
            $scope.device = $scope.asscDevices[$scope.currentAsscIndex];
            if($scope.device && $scope.device.adminLineInfo && $scope.device.adminLineInfo.length )
            {
              $scope.phoneNumber = $scope.asscDevices[$scope.currentAsscIndex].adminLineInfo[0].phoneNumber ;
              $scope.userName =    $scope.asscDevices[$scope.currentAsscIndex].adminLineInfo[0].userName ;
            }
        };
        $scope.changeHandler = function() {
			var lineNumber = $state.params.lineNumber;
			var smartPhoneCount = 0,
				deskPhoneCount = 0;
			$scope.asscDevices.forEach(function(device) {
				if (device.deviceType === 'SMARTPHONE') {
					smartPhoneCount++;
				} else if (device.deviceType === 'DESKPHONE') {
					deskPhoneCount++;
				}
			});
			lineNumber = lineNumber.substr(0, 3) + "-" + lineNumber.substr(3, 3) + "-" + lineNumber.substr(6);
			$http({
			    url: Constants.API.LINES_PAGE.EPAM_PROCESS_ACTIONS,
			    method: "POST",
			    data: {
			        actionSelected: "ChangeEndPoint",
			        line: lineNumber
			    },
			    crossDomain: true,
			    withCredentials: true,
			    headers: {
			        'Content-type': 'application/json'
			    }
			}).success(function(response, status, headers, config) {
			    if (!response.errorStatus) {
			        $http({
			            url: Constants.API.LINES_PAGE.SELECT_STRING,
			            method: "POST",
			            data: {
			                actionSelected: "ChangeEndPoint",
			                line: lineNumber,
			                source: "VOLTE",
			                imei : $scope.asscDevices[$scope.currentAsscIndex].imei,
			                deviceId: $scope.asscDevices[$scope.currentAsscIndex].deviceId,
			                deviceType: $scope.asscDevices[$scope.currentAsscIndex].deviceTypeId
			            },
			            crossDomain: true,
			            withCredentials: true,
			            headers: {
			                'Content-type': 'application/json'
			            }
			        }).success(function(response, status, headers, config) {
			            if (!response.errorStatus) {
			                //$window.location.href = response.redirectUrl + "&smartPhoneCount=" + smartPhoneCount + "&deskPhoneCount=" + deskPhoneCount;

                            // Redirect with back URL
                            var currentUrlPath = window.location.href;
                            var redirectUrlPath = response.redirectUrl + "&smartPhoneCount=" + smartPhoneCount + "&deskPhoneCount=" + deskPhoneCount;
                            $window.location.href = redirectUrlWithReturnURL(redirectUrlPath, currentUrlPath, Constants.API.REDIRECT_URL_PATHS.split_At);

			            } else {
			                errorHandler();
			            }
			        }).error(function(response, status, headers, config) {
			            errorHandler();
			        });
			    } else {
			        errorHandler();
			    }
			}).error(function(response, status, headers, config) {
			    errorHandler();
			});
			function errorHandler() {
				$scope.showLineDetailMessage("error", 'Record Updation Failed');
			}
		};

        $scope.upgradeHandler = function() {
			var lineNumber = $state.params.lineNumber;
			lineNumber = lineNumber.substr(0, 3) + "-" + lineNumber.substr(3, 3) + "-" + lineNumber.substr(6);
			var smartPhoneCount = 0,
				deskPhoneCount = 0;
			$scope.asscDevices.forEach(function(device) {
				if (device.deviceType === 'SMARTPHONE') {
					smartPhoneCount++;
				} else if (device.deviceType === 'DESKPHONE') {
					deskPhoneCount++;
				}
			});

            var maxdeskPhoneAllowedCount= 2;
            var maxsmartPhoneAllowedCount =1;
            var smartPhoneAllowedCount = maxsmartPhoneAllowedCount - smartPhoneCount;
            var deskPhoneAllowedCount = maxdeskPhoneAllowedCount - deskPhoneCount;

            //$window.location.href = ENV_COPY.server.mb + '/b2b/commerce/amsecure/index.go?ssPath=upgradeEndPoint&mtn=' + lineNumber + '&smartPhoneAllowedCount=' + smartPhoneAllowedCount + '&deskPhoneAllowedCount=' + deskPhoneAllowedCount + '&deviceId=' + $scope.asscDevices[$scope.currentAsscIndex].deviceId;

            // Redirect with back URL
            var currentUrlPath = window.location.href;
            var redirectUrlPath = ENV_COPY.server.mb + '/b2b/commerce/amsecure/index.go?ssPath=upgradeEndPoint&mtn=' + lineNumber + '&smartPhoneAllowedCount=' + smartPhoneAllowedCount + '&deskPhoneAllowedCount=' + deskPhoneAllowedCount + '&deviceId=' + $scope.asscDevices[$scope.currentAsscIndex].deviceId;
            $window.location.href = redirectUrlWithReturnURL(redirectUrlPath, currentUrlPath, Constants.API.REDIRECT_URL_PATHS.split_At);

		}
        $scope.getAsccItemSelected = function(index) {
            var returnVal = index == $scope.currentAsscIndex ? 'item-selected' : false;
            return returnVal;
        };

        $scope.addNewDevice = function() {
            // var associatedDeviceInfo = {
            //     lineNumber:$state.params.lineNumber,
            //     associatedDevices :$scope.asscDevices
            // }
            var lineData = { associatedDeviceInfo: {
                lineNumber:$state.params.lineNumber,
                associatedDevices :$scope.asscDevices
               }
            }
            var new_dialog = ngDialog
                .open({
                    template: 'partials/components/dialog/addNewDevice.html',
                    closeByDocument: false,
                    closeByEscape: false,
                    template: 'partials/components/dialog/addNewDevice.html',
                    scope: $scope,
                    data:  lineData,
                    controller:'addNewDeviceCtrl'
                });
        };
        $scope.getDialogBox = function(type) {
            var constType = type.toUpperCase();
            $scope.currType = constType;
            var params = [{
                'lineNumber': $state.params.lineNumber
            }];
            initDial();

            function initDial() {
                $scope.showWarning = true;
                console.log(params);
                $scope.bulkInfo = params;
                $scope.hideLines = true;
                $scope.showMsgDrop = true;
                $scope.msgTypeDrop = 'error';
                $scope.confirmation = false;
                $scope.alertMsg = dropdownValueConst[constType][0].pageAlertTxt;
                $scope.msgTxtDrop = dropdownValueConst[constType][0].pageConfirmationTxt; //+ ' '+ $scope.bulkInfo[0].lineNumber+ ' ?';
            }
            $scope.DisableLine = function(lineNumber) {
                // console.log('calling disable');
                $scope.transactionId = '';
                var param = {
                    "lineNumber": lineNumber,
                    "deviceId": $scope.asscDevices[$scope.currentAsscIndex].deviceId
                };
                //$scope.$parent.$parent.showMsg = false;
                volteServices.setOption(Constants.API.DISABLE_DESKPHONE.POST);
                volteServices.postData(param).success(
                    function(response) {
                        if (response.appHeader.statusCode == "OK") {
                            $scope.msgConfirm('success');
                            $scope.thankuTxtDrop = type == 'MOBILECLIENT' ? 'Thank You. You have successfully blocked the mobile clients.' : 'Thank You. You have successfully submitted the request to unlink the line from your device';
                            $scope.msgTxtDrop = dropdownValueConst[constType][0].pageSuccessTxt;
                            $scope.transactionId = response.appResult.serviceRepsonse.transactionId;
                            getData911UpdateData();
                            // console.log('submittedSuccessfully with unchecked'+JSON.stringify(param));
                        } else {
                            $scope.msgConfirm('error');
                            $scope.thankuTxtDrop = 'Error';
                            $scope.msgTxtDrop = response.appHeader.statusMessage;;
                            $scope.transactionId = "";
                        }
                    });
            }
            $scope.EnableLine = function(lineNumber) {
                $scope.transactionId = '';
                var param = {
                    "lineNumber": lineNumber,
                    "deviceId": $scope.asscDevices[$scope.currentAsscIndex].deviceId
                };
                //$scope.$parent.$parent.showMsg = false;
                volteServices.setOption(Constants.API.ENABLE_DESKPHONE.POST);
                volteServices.postData(param).success(
                    function(response) {

                        if (response.appHeader.statusCode == "OK") {
                            $scope.msgConfirm('success');
                            $scope.thankuTxtDrop = type == 'MOBILECLIENT' ? 'Thank You. You have successfully blocked the mobile clients.' : 'Thank You. You have successfully submitted the request to re-enable your device';
                            $scope.msgTxtDrop = dropdownValueConst[constType][0].pageSuccessTxt;
                            $scope.transactionId = response.appResult.serviceRepsonse.transactionId;

                            getData911UpdateData();
                            // console.log('submitted Successfully with unchecked'+JSON.stringify(param));
                        } else {
                            $scope.msgConfirm('error');
                            $scope.thankuTxtDrop = 'Error';
                            $scope.msgTxtDrop = response.appHeader.statusMessage;
                            $scope.transactionId = "";
                        }
                    });
            };
            $scope.RebootLine = function(lineNumber) {
                $scope.transactionId = '';
                var param = {
                    "lineNumber": lineNumber,
                    "deviceId": $scope.asscDevices[$scope.currentAsscIndex].deviceId
                };
                //$scope.$parent.$parent.showMsg = false;
                volteServices.setOption(Constants.API.REBOOT_DESKPHONE.POST);
                volteServices.postData(param).success(
                    function(response) {
                        // if(response.errorCode == "0") {
                        if (response.appHeader.statusCode == "OK") {
                            $scope.msgConfirm('success');
                            $scope.thankuTxtDrop = 'Thank You. You have sucessfully reboot your device.';
                            $scope.msgTxtDrop = dropdownValueConst[constType][0].pageSuccessTxt;
                            $scope.transactionId = response.appResult.serviceRepsonse.transactionId;
                            getData911UpdateData();
                            // console.log('submitted Successfully with unchecked'+JSON.stringify(param));
                        } else {
                            $scope.msgConfirm('error');
                            // $scope.msgTxt = response.appHeader.statusMessage;
                            $scope.thankuTxtDrop = 'Error';
                            $scope.msgTxtDrop = response.appHeader.statusMessage;
                            $scope.transactionId = "";
                        }
                    });
            };
            $scope.RemoveLine = function(lineNumber) {
                $scope.transactionId = '';
                $scope.confirmationNumber = '' ; // HD

                var param;

                console.log("1. Device Type :: " + $scope.asscDevices[$scope.currentAsscIndex].deviceType);
                console.log("2. Device Type :: " + $scope.deviceType);



                if ($scope.asscDevices[$scope.currentAsscIndex].deviceType.toUpperCase() === 'OTT')
                {
                    param = {


                        "lineNumber": lineNumber.replace(/-/g, ""),
                        "deviceId": $scope.asscDevices[$scope.currentAsscIndex].deviceId
                    };
                    volteServices.setOption(Constants.API.DISCONNECT_OTT.POST);
                }
                else
                {

                    param = {
                    "deviceLinePair": [{
                        "deviceId": $scope.asscDevices[$scope.currentAsscIndex].deviceId,
                        "deviceIdType": $scope.asscDevices[$scope.currentAsscIndex].deviceTypeId,
                        "mtn": lineNumber.replace(/-/g, "")
                    }]};
                    volteServices.setOption(Constants.API.REMOVE_DESKPHONE.POST);
                }
                volteServices.postData(param).success(
                    function(response) {
                        // if(response.errorCode == "0") {
                        console.log(response)
                        if (response.appHeader.statusCode == "OK") {
                            $scope.msgConfirm('success');
                            $scope.thankuTxtDrop = type == 'MOBILECLIENT' ? 'Thank You.You have successfully blocked the mobile clients.' : dropdownValueConst[constType][0].thankuTxt;
                            $scope.msgTxtDrop = dropdownValueConst[constType][0].pageSuccessTxt;
                            $scope.transactionId = response.appResult.serviceRepsonse.service.serviceHeader.transactionId;
                            $scope.confirmationNumber =  response.appResult.serviceRepsonse.service.serviceBody.serviceResponse.confirmationNumber; //HD

                            console.log ($scope.confirmationNumber) //HD
                            console.log($scope.transactionId)
                            getData911UpdateData();
                        } else {
                            $scope.msgConfirm('error');
                            $scope.thankuTxtDrop = "Error";
                            $scope.msgTxtDrop = response.appHeader.statusMessage;
                        }
                    });
            };
            var dialogTemp = 'partials/components/dialog/' + type.toLowerCase() + '.html';
            var new_dialog = ngDialog.open({
                template: dialogTemp,
                closeByDocument: false,
                closeByEscape: false,
                scope: $scope
            });
        };
        $scope.msgConfirm = function(type) {
            console.log('called msgConfirm');
            $scope.confirmation = true;
            $scope.showWarning = false;
            $scope.showMsgDrop = true;
            $scope.msgTypeDrop = type;
        };
        $scope.removeAllOtt = function(type) {
            //$scope.ottType = type;
            $scope.removeAllOttList = {"deviceLinePair":[{"mtn":$state.params.lineNumber}]};
            var dialogTemp = 'partials/components/dialog/' + type + '.html';
            ngDialog.open({
                template: dialogTemp,
                closeByDocument: false,
                closeByEscape: false,
                scope: $scope,
                controller: 'removeAllOttCtrl'
            });
        };
        $scope.getOttCalling = function(type) {
            $scope.ottType = type;
            $scope.ottBlockUnblockList = [{
                "mtn": $state.params.lineNumber
            }];
            var dialogTemp = 'partials/components/dialog/' + $scope.ottType + '.html';
            ngDialog.open({
                template: dialogTemp,
                closeByDocument: false,
                closeByEscape: false,
                scope: $scope,
                controller: 'blockUnblockOttCtrl'
            });
        };
        $scope.update911Address = function() {
            var new_dialog = ngDialog.open({
                template: 'partials/components/dialog/update911LinesNdevices.html',
                closeByDocument: false,
                closeByEscape: false,
                scope: $scope,
                controller: 'update911Ctrl'
            });
        };
        $scope.unBridgeLine = function(row) {
            console.log("Row data" + JSON.stringify(row));
            $scope.row = row;
            $scope.successMessage = false;
            $scope.confirmation = true;
            $scope.showMsgDrop = true;
            $scope.transactionId = null;
            $scope.msgTypeDrop = "confirm";
            $scope.alertMsgDrop = "Are you sure you want to unbridge this phone number from this device?";
            $scope.msgTxtDrop = "Once you unbridge, the phone number will no longer ring on the selected device.";
            $scope.unBridgeLineNumber = row.phoneNumber;
            console.log($scope.unBridgeLineNumber)
            var new_dialog = ngDialog.open({
                template: 'partials/components/dialog/unbridge.html',
                closeByDocument: false,
                closeByEscape: false,
                scope: $scope
            });

        };


         $scope.unBridgeHandler = function(row) {
            console.log("Row data" + JSON.stringify(row));
            $scope.row = row;
            $scope.successMessage = false;
            $scope.confirmation = true;
            $scope.showMsgDrop = true;
            $scope.msgTypeDrop = "confirm";
            $scope.alertMsg = "Are you sure you want to unbridge this phone number from this device?";
            $scope.msgTxtDrop = "Once you unbridge, the phone number will no longer ring on the selected device.";
            $scope.unBridgeLineNumber =  $scope.asscDevices[$scope.currentAsscIndex].adminLineInfo[0].phoneNumber ;
            console.log($scope.unBridgeLineNumber)
            var new_dialog = ngDialog.open({
                template: 'partials/components/dialog/virtualUnbridge.html',
                closeByDocument: false,
                closeByEscape: false,
                scope: $scope
            });

        };


        $scope.LoadBridgeRowData = function() {
            console.log("Load count : " + $scope.bridgedLines.length);
            $scope.pageStartIndex = 0;
            $scope.pageEndIndex = $scope.bridgedLines.length;
            $scope.load = false;
        };
        $scope.UnLoadBridgeRowData = function() {
            console.log("Load count : " + $scope.bridgedLines.length);
            $scope.pageStartIndex = 0;
            $scope.pageEndIndex = 2;
            $scope.load = true;
        };




        $scope.sumbitUnBridgeLine = function(lineNumber) {
            $scope.successMessage = true;
            $scope.confirmation = false;
            $scope.showMsgDrop = true;
            $scope.deskshowMsg = false;
            console.log(lineNumber)
            lineNumber = lineNumber.replace(/-/g, "");
            var param = {
                "deviceId": $scope.asscDevices[$scope.currentAsscIndex].deviceId,
                "bridgeToLineNumber":$scope.unBridgeLineNumber.replace(/-/g, ""),
                "deviceLineNumber": $state.params.lineNumber.replace(/-/g, "")
            };
            volteServices.setOption(Constants.API.BRIDGE_TO_LINE.unBridgeLine_POST);
            volteServices.postData(param).success(
                function(response) {
                    console.log(response);
                    if (response.appHeader.statusCode == "OK") {
                        $scope.showMsgDrop = true;
                        $scope.msgTypeDrop = "success";
                        $scope.thankuTxtDrop = dropdownValueConst.UNBRIDGELINE[0].pageSuccessTxt
                        $scope.transactionId = response.appResult.serviceRepsonse.transactionId;
                        $scope.msgTxtDrop = "The transaction ID is ";
                        getData911UpdateData();

                    } else {
                        $scope.showMsgDrop = true;
                        $scope.msgTypeDrop = "error";
                        $scope.thankuTxtDrop = response.appHeader.statusMessage;
                        $scope.showMsgLineDetail = true;
                        $scope.msgTxtDrop = "";

                    }
                });

        };


//HD
       $scope.sumbitUnBridgeLineHandler = function(lineNumber) {
            console.log(lineNumber)
            lineNumber = lineNumber.replace(/-/g, "");
            var param = {
                "deviceId": $scope.asscDevices[$scope.currentAsscIndex].deviceId,
                "bridgeToLineNumber": $state.params.lineNumber.replace(/-/g, ""),
                "deviceLineNumber":   $scope.unBridgeLineNumber.replace(/-/g, "")
            };


            volteServices.setOption(Constants.API.BRIDGE_TO_LINE.unBridgeLine_POST);
            volteServices.postData(param).success(
                function(response) {
                    $scope.showMsgDrop = true;
                    $scope.successMessage = true;
                    $scope.confirmation = false;
                    //$scope.showMsgDrop = true;
                    $scope.deskshowMsg = false;
                    console.log(response);
                    if (response.appHeader.statusCode == "OK") {
                        $scope.showMsgDrop = true;
                        $scope.msgTypeDrop = "success";
                        $scope.thankuTxtDrop = "Thank you.  You have successfully submitted the request to unbridge the line to your device.";
                        $scope.transactionId = response.appResult.serviceRepsonse.transactionId;
                        $scope.msgTxtDrop = "The transaction ID is ";
                        getData911UpdateData();

                    } else {
                        $scope.showMsgDrop = true;
                        $scope.msgTypeDrop = "error";
                        $scope.thankuTxtDrop = response.appHeader.statusMessage;
                        $scope.showMsgLineDetail = true;
                        $scope.msgTxtDrop = "";

                    }
                });

        };

//HD
        $scope.submitBridgetoLine = function() {
            $scope.transactionBridgeId = '';
            // lineNumber = lineNumber.replace(/-/g, "");
            var brdigeLineunFormattedNumber = document.getElementById("lookupNo").value;
            var brdigeLineNumber = brdigeLineunFormattedNumber.replace(/-/g, "");
            if(!(/^\d+$/.test(brdigeLineNumber)))
            {
                $scope.deskshowMsg = true;
                $scope.deskmsgType = "error";
                $scope.thankudeskmsgTxt = "Please enter numbers.";
                return;
            }
            if ($scope.bridgedLines === undefined) {
                $scope.bridgedLines = '';
            }

            console.log("text box: " + $scope.lookupNo);
            if ($scope.bridgedLines.length > 12) {
                $scope.deskshowMsg = true;
                $scope.deskmsgType = "error";
                $scope.thankudeskmsgTxt = "More then 12 bridged Lines are not allowed.";
                return;
            }

            if (document.getElementById("lookupNo").value == "") {
                $scope.deskshowMsg = true;
                $scope.deskmsgType = "error";
                $scope.thankudeskmsgTxt = "Enter line number to bridge.";
                // $scope.deskmsgTxt ="The transaction ID is
                // ";
                return;
            }
            var param = {
                "deviceId": $scope.asscDevices[$scope.currentAsscIndex].deviceId,
                "deviceLineNumber": $state.params.lineNumber,
                "bridgeToLineNumber": brdigeLineNumber
            };

            console.log(" LOG Params" + JSON.stringify(param));

            volteServices.setOption(Constants.API.BRIDGE_TO_LINE.bridgeLine_POST);
            volteServices.postData(param).success(
                function(response) {
                    if (response.appHeader.statusCode == "OK") {
                        var re, successTxt;
                        $scope.deskshowMsg = true;
                        $scope.deskmsgType = "success";
                        re = new RegExp('\\{'+0+'\\}', 'g');
                        successTxt = dropdownValueConst.BRIDGE[0].pageSuccessTxt.replace(re,brdigeLineunFormattedNumber)
                        $scope.thankudeskmsgTxt = successTxt;
                        $scope.deskmsgTxt = "  The transaction ID is ";
                        $scope.transactionBridgeId = response.appResult.serviceRepsonse.transactionId;
                        $scope.lookupNo = '';
                        document.getElementById("lookupNo").value = '';
                        getData911UpdateData();

                    } else {
                        $scope.deskshowMsg = true;
                        $scope.deskmsgType = "error";
                        $scope.thankudeskmsgTxt = response.appHeader.statusMessage;
                        $scope.deskmsgTxt = "";
                    }
                });

        };
        $scope.bridgetoLineCloseDialog = function() {
            try {
                var windowIDs = ngDialog.getOpenDialogs();
                ngDialog.close(windowIDs[1]);
            } catch (err) {

            }
        };
        $scope.navigateFromBridgeAdmin = function(phoneNumber)
        {
            $window.location.href=('#/line-devices/details/device/0/lines/'+phoneNumber+'/CORPORATE');
            $window.location.reload();
            //$state.transitionTo($state.current,{'deviceID' :'0','deviceType':'lines','lineNumber':phoneNumber,'lineType':'CORPORATE'},{reload: true,inherit: true ,notify:true})
            //$state.go('line-devices-details.devices',{'deviceID' :'0','deviceType':'lines','lineNumber':phoneNumber,'lineType':'CORPORATE'},{reload: true,inherit: true ,notify:true});
        }
        $scope.lookupDialog = function() {
            $scope.lookupSearch = '';
            $scope.selectedValue = '';
            $scope.erroMessage = '';
            var returnFlag = true;
            var digitsRegExp = new RegExp("^([0-9])*$");
            var alphaRegExp = new RegExp("^([A-Za-z])*$");
            $scope.phoneNumber = null;
            if ($scope.availableLineInfoToBridge === undefined) {
                $scope.availableLineInfoToBridge = '';
            }
            $scope.lookupNos = $scope.availableLineInfoToBridge;

            $scope.lookupDropdown = [{
                name: "Phone Lines",
                value: "phoneLines"
            }, {
                name: "User Name",
                value: "userName"
            }, ];

            $scope.checkDropDown = function() {
                // console.log("dropdown
                // value..."+selectedKeyConfig[item.key]);
                console.log("dropdown value..." + $scope.selectedValue);
                $scope.erroMessage = "";
            };

            $scope.checkInput = function() {
                var userInput = $scope.lookupSearch;
                var userSelect = "";
                var errorMsgVal = "";
                if ($scope.selectedValue)
                    userSelect = $scope.selectedValue;
                else
                    userSelect = "phoneLines";

                if ($scope.erroMessage)
                    errorMsgVal = $scope.erroMessage;
                else
                    errorMsgVal = "";

                // console.log("userSelect.."+userSelect);
                // console.log("userInput.."+userInput);

                if (userSelect == "userName") {
                    if (alphaRegExp.test(userInput)) {
                        errorMsgVal = "";
                        returnFlag = true;
                    } else {
                        errorMsgVal = "Invalid User Name";
                        returnFlag = false;
                    }
                }
                if (userSelect == "phoneLines") {
                    if (digitsRegExp.test(userInput)) {
                        errorMsgVal = "";
                        returnFlag = true;
                    } else {
                        errorMsgVal = "Invalid Phone Line";
                        returnFlag = false;
                    }
                }

                // console.log("Final error
                // msg.."+errorMsgVal);
                $scope.erroMessage = errorMsgVal;
                return returnFlag;
            };

            // if(returnFlag){

            $scope.lookupSearchResp = function() {
                return lookupSearch;
            };

            $scope.updateFromLookUp = function(record) {
                $scope.phoneNumber = record.phoneNumber;
                // console.log("$scope.phoneNumber" +
                // $scope.phoneNumber + " &&
                // record.phoneNumber" + $scope.phoneNumber
                // = record.phoneNumber );
            };

            $scope.addToTextBox = function() {

                if ($scope.lookupNos.length == 0) {
                    alert('There aren\'t any records to be added');
                }

                if ($scope.phoneNumber == null) {
                    alert("Please select a record");
                }
                document.getElementById("lookupNo").value = processLineFormatting($scope.phoneNumber);
                $scope.lookupNo = processLineFormatting($scope.phoneNumber);
                var windowIDs = ngDialog.getOpenDialogs();
                ngDialog.close(windowIDs[1]);

            };
            var new_dialog = ngDialog
                .open({
                    template: 'partials/components/dialog/lookupNightForwarding.html',
                    className: 'ngDialog-theme-vz',
                    closeByDocument: false,
                    closeByEscape: false,
                    scope: $scope

                });
        };

        function processLineFormatting(lineNumber) {

            lineNumber = lineNumber.replace(/\D/g, '');
            if (lineNumber.length > 2) {
                lineNumber = lineNumber.substring(0, 3) + '-' + lineNumber.substring(3);
            }
            if (lineNumber.length > 6) {
                lineNumber = lineNumber.substring(0, 7) + '-' + lineNumber.substring(7);
            }
            return lineNumber;
        }


        function getData911UpdateData() {
            // console.log($state.params.lineNumber,);
            var lineType = $state.params.lineType.toUpperCase();
            var params = {
                'lineNumber': $state.params.lineNumber,
                'deviceId': $scope.asscDevices[$scope.currentAsscIndex].deviceId,
                'lineType': lineType
            };
            volteServices.setOption(Constants.API.UPDATE911ADDRESS.GET);
            volteServices.postData(params).success(
                function(response) {

                    if (response.appHeader.statusCode == "OK") {
                        var serviceRepsonse = response.appResult.serviceRepsonse;

                        $scope.address911 = serviceRepsonse["911Address"];
                        $scope.bridgedLines = serviceRepsonse.bridgedLineInfo;
                        $scope.availableLineInfoToBridge = serviceRepsonse.availableLineInfoToBridge;
                        $scope.deviceId911 = serviceRepsonse.deviceId;
                        $scope.status = serviceRepsonse.status;
                    } else {

                        $scope.msgType = "error";
                        $scope.msgTxt = response.appHeader.statusMessage;
                        $scope.showMsgLineDetail = true;
                    }

                });
        }
        function getTransactionLink(){
            console.log('qwqwqw',$rootScope.EPAMLink.indexOf())
           if( $rootScope.EPAMLink.indexOf() ) {
            console.log($rootScope.EPAMLink)
            var transLinkArr  = window.EPAMLink.split("?");
                $scope.NavLink    = transLinkArr[0] + "#transactionHistory";
            } else {
                $scope.NavLink    = window.EPAMLink + "#transactionHistory";
            }

            // Commented bacause it causes "Page not found" error
            // Back URL not needed for EPAM
            // Redirect with back URL
/*
            var currentUrlPath = window.location.href;
            var redirectUrlPath = $scope.NavLink;
            $scope.NavLink = redirectUrlWithReturnURL(redirectUrlPath, currentUrlPath, Constants.API.REDIRECT_URL_PATHS.split_At);
*/
        }
        getTransactionLink();
        function init() {
            $scope.bridgedLines = [];
            $scope.availableLineInfoToBridge = [];
            $scope.unBridgeLineNumber = '';
            console.log('associatedDevicesCtrl')
            getTransactionLink();
        }
    };

    associatedDevicesCtrl.$inject = ['$scope', 'linesService', '$state', 'ngDialog', 'volteServices', 'Constants', 'dropdownValueConst', '$http', '$window', '$rootScope'];

    angular.module(window.AppName).controller('associatedDevicesCtrl', associatedDevicesCtrl);
})();
