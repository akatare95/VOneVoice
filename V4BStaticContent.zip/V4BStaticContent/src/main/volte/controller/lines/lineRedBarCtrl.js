/*
*
*  LinesCtrl - This controller handles lines & devices page
*
*/
var lineRedBarCtrl = function($scope, lineUserInfo, mySharedService) {


    function init() {
    	$scope.redLines = lineUserInfo.data;
    }

    init();


  $scope.setTypeFilter = function(msg, msg2) {
    mySharedService.prepForBroadcast(msg);
  };

  $scope.$on('handleBroadcast', function() {
    $scope.message = mySharedService.message;
  });


};

lineRedBarCtrl.$inject = ["$scope", "lineUserInfo", "mySharedService"];
angular.module( window.AppName ).controller("lineRedBarCtrl", lineRedBarCtrl);
