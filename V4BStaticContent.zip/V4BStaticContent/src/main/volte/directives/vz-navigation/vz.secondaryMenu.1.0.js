app.directive('vzSecondaryMenu', function() {

  return {
      restrict: 'AE',
      replace: true,
      templateUrl: 'partials/components/vz-navigation/secondaryMenu.html'
  }

});