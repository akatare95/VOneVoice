app.directive('vzMobileMenu', function($http, $templateCache, $compile, $parse, $timeout, $rootScope) {

  return {
      restrict: 'AE',
      replace: true,
      template: '<div data-status="closed" style="display: inline-block; width: 30px; height: 40px;"><div class="mobile-menu" ng-click="toggleMenu()" style="position: relative; z-index: 3;width: 16px; height: 16px; margin: 0 auto;">&nbsp;</div></div>',
      controller: function( $scope, $state ) {

        $scope.toggleMenu = function() {

          //If Submenu is true then one of the sub navigation is enabled.
          //It is enabled as true so the page redirection wont happen unnecessarily
          //But if we want to hide the menu submenu needs to be transfered as low
          if( $scope.subMenu === true ) {
            $scope.subMenu = false;
          }

        }

        $scope.redirect = function( URI ) {

          $scope.subMenu = false;

          $timeout(function() {
                  $state.go( URI );
                }, 1000);

        }


      },
      link: function( scope, element, attrs ) {

          parentElmntStack = [];
          elementsStack = [];

          //Bind the event to menu
          element.bind('click', function(e) {

            var status = element.attr("data-status");
            var detailDevice = 'vz-mobile-menu';

            if( !scope.subMenu ) {

              if( status == 'closed' ) {

                  var URL = "partials/components/vz-navigation/mobileMenu.html";
                  $http.get(URL, {cache: $templateCache}).success(function( response ){

                    var el = angular.element( response );
                    $compile( el )(scope);
                    var elClass = el.attr("class")
                    el.attr("class",elClass + " cbp-spmenu-open");
                    element.append(el);

                    parentElmntStack[detailDevice] = element;
                    elementsStack[detailDevice] = el;

                  });

                  element.attr("data-status","opened");

              } else {

                  var elClass = elementsStack[detailDevice].attr("class")
                  elClass = elClass.replace( "cbp-spmenu-open", "cbp-spmenu-closed" );
                  elementsStack[detailDevice].attr("class",elClass);
                  $timeout(function() {
                    elementsStack[detailDevice].remove();
                    element.attr("data-status","closed");
                  }, 800);

              }

            }


          });

      } //End of link

  }

});