app.directive('vzInfiniteScroll', function () {
    return {
        restrict: 'AE',
        replace: false,
        scope: {
            visible: '='
        },
        link: function (scope, element, attrs) {
            var footers = document.getElementsByTagName('vz-footer'),
                footer = footers ? footers[0] : null,
                footerDisplay = angular.element(footer).css('display'),
                scrollable = element.parent(),
                isVisible = false;

            angular.element(footer).css('display', 'none');

            // Bind listeners
            scrollable.on('scroll', onScroll);
            scope.$on("$destroy", onDestroy);

            function onScroll (e) {
                var el = this,
                    height = el.scrollHeight,
                    bottom = el.offsetHeight,
                    top = height - bottom,
                    buffer = element.height() || 20,
                    y = el.scrollTop,
                    _isVisible = y + buffer >= top;

                if (_isVisible !== isVisible) {
                    isVisible = _isVisible;
                    onVisibilityChange(isVisible);
                }
            }

            function onVisibilityChange (isVisible) {
                scope.visible && scope.visible(isVisible);
            }

            function onDestroy () {
                angular.element(scrollable).off('scroll', onScroll);
                angular.element(footer).css('display', footerDisplay);
            }
        }
    };
});