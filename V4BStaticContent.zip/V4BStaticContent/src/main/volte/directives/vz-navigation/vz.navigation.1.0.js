app.directive('vzPrimaryMenu', function($http, $templateCache, $compile, $parse, $rootScope, $state) {

  return {
      restrict: 'AE',
      replace: true,
      scope: {
            navBarSelected:'='
        },
      templateUrl: 'partials/components/vz-navigation/menu.html',
      controller: function($scope) {
        console.log("*********navBarSelected*******");
          // console.log($scope.navBarSelected);
          // $rootScope.$on('$stateChangeStart', function (event, toState, toParams, fromState, fromParams) {
          //   $rootScope.fromPreviousState = fromState;
          //   // var toState = toState;
          // });
      },
      link: function( scope, element, attrs ) {
        scope.getSelected=function(type)
          {
            var currentState;
            if($state.includes('line-devices-details'))
              {
                 // console.log($rootScope.fromPreviousState)
                 currentState = !$rootScope.fromPreviousState.name?'line-devices':$rootScope.fromPreviousState.name;
                 return currentState.includes(type);
              }
            else if($state.includes(type))
            {
              return true;
            }
          }
      }
  }

});
