app.directive('vzOnboardMenu', function($http, $templateCache, $compile, $parse, $rootScope) {

  return {
      restrict: 'AE',
      replace: true,
      templateUrl: 'partials/components/vz-navigation/vzOnboardMenu.html',
      controller: function() {

          // $rootScope.$on('$stateChangeStart', function (event, toState, toParams, fromState, fromParams) {
          //   //console.log( toState );
          // });

      },
      link: function( scope, element, attrs ) {

          //console.log("Root scope - ", $rootScope.$state.$current );

      }
  }

});