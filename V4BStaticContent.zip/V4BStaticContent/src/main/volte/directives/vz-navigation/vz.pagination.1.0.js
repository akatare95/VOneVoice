app.directive("vzPagination",function() {

	return {

		restrict: "AE",
		scope: {
			noOfPages: 		"=",
			incrementVal: 	"=",
			limitIndex: 	"=",
			startIndex: 	"=",
			rows: 			"=",
			enable:         "="
		},
		templateUrl: 'partials/components/vz-pagination/pagination.html',
		link: function(scope, elem, attr) {

			scope.noOfPages		  = 0;
	        scope.pageNum         = 1;
	        scope.startIndex	  = 0;
	        scope.incrementVal    = 10;
	        scope.limitIndex	  = scope.incrementVal;
	        scope.placeholderText = scope.incrementVal + " Records Per Page";


	        scope.display_records = [{
	            name: "10 Records Per Page",
	            value: 10
	        }, {
	            name: "20 Records Per Page",
	            value: 20
	        }, {
	            name: "30 Records Per Page",
	            value: 30
	        }, {
	            name: "50 Records Per Page",
	            value: 50
	        }, {
	            name: "100 Records Per Page",
	            value: 100
	        }];

			// console.log("limitIndex " + scope.limitIndex )
			// console.log("row " + scope.rows )
	  //         if (scope.rows < scope.limitIndex )
	  //        	{
	  //        		console.log("row condition" + scope.rows )
	  //        		scope.limitIndex = scope.rows;
	  //        	}


	        scope.$watch("rows", function(newVal, oldVal) {
	        	scope.noOfPages  = Math.ceil( scope.rows / scope.incrementVal );
	        });

	        scope.$watch("enable", function(newVal, oldVal){
		        scope.pageNum         = 1;
		        scope.startIndex	  = 0;
		        scope.incrementVal    = 10;
		         scope.limitIndex	  = scope.incrementVal;
		        scope.placeholderText = scope.incrementVal + " Records Per Page";
            });

		    scope.paginationPrev = function() {

		    	console.log("Before Start Index - " + scope.startIndex + " && Limit Index - " + scope.limitIndex + " && Limit - " + scope.incrementVal);

		        /*if( scope.startIndex  == 0 )
		            return;

		        //scope.startIndex = scope.startIndex - scope.incrementVal;
		        /*scope.startIndex = scope.limitIndex - scope.incrementVal - 1;
		        if( scope.startIndex < -1 ) {
		            scope.startIndex = 0;
		        }
		        //scope.limitIndex = scope.limitIndex - scope.incrementVal;
		        //scope.limitIndex = scope.startIndex - scope.incrementVal;
		        scope.limitIndex = scope.startIndex + scope.incrementVal;
		        /*if( scope.limitIndex <= 0 ) {
		        	scope.limitIndex = scope.incrementVal;
		        }*/

		        if( scope.pageNum <= 1 )
		        	return;

		        scope.pageNum     = scope.pageNum - 1;
		        scope.startIndex  = (scope.pageNum - 1) * scope.incrementVal;
		        scope.limitIndex  = scope.startIndex + scope.incrementVal;

		        console.log("After Start Index - " + scope.startIndex + " && Limit Index - " + scope.limitIndex + " Limit - " + scope.incrementVal);
		    }

		    scope.paginationNext = function() {

		    	if( scope.pageNum  == scope.noOfPages )
		            return;

		        try {

		        	//console.log("Before Start Index - " + scope.startIndex + " && " + scope.limitIndex + " && Limit - " + scope.incrementVal);

		        	scope.startIndex = scope.limitIndex; //scope.startIndex + scope.incrementVal;
			        //scope.limitIndex = scope.limitIndex + scope.incrementVal;
			        scope.limitIndex = scope.startIndex + scope.incrementVal;
			        if( scope.limitIndex >= scope.rows )
			        	scope.limitIndex = scope.rows;
			        scope.pageNum    = scope.pageNum + 1;

			        //console.log("After Start Index - " + scope.startIndex + " && " + scope.limitIndex + " && Limit - " + scope.incrementVal);

		        } catch( err ) {
		        	//console.log("Message - " + err.message );
		        }

		    }

		     scope.paginatioEnterPages = function( pageNum ) {

				if (pageNum =="" )
					return;
				if (pageNum == 0 )
					return;
		     	 if( scope.noOfPages < pageNum )
		        	return;

		        scope.pageNum     = pageNum;
		        scope.startIndex  = (scope.pageNum -1) * scope.incrementVal;
		        scope.limitIndex  = scope.startIndex + scope.incrementVal;
		       // console.log("After Start Index - " + scope.startIndex + " && Limit Index - " + scope.limitIndex + " Limit - " + scope.incrementVal);

		    }

		    scope.paginationIncreaseRecords = function( incrementVal ) {
		    	scope.incrementVal = incrementVal;
		    	scope.startIndex = 0;
		    	scope.limitIndex = scope.startIndex + scope.incrementVal;
				scope.pageNum = 1;
		    	scope.noOfPages  = Math.ceil( scope.rows / incrementVal );
		    }
		}
	};
});
