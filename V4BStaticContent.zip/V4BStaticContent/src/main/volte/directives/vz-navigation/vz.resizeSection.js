app.directive('vzHorizontalScroll', function($window) {

  return {
      restrict: 'AE',
      replace: false,
      link: function( scope, element, attrs ) {

        var windowWidth = $window.innerWidth;
        if( windowWidth < 600 ) {

/*
REASON: FTScroller doesn't allow certain objects with overflow property to scroll (i.e. dropdown)
*/
            // var scroll = new FTScroller(document.getElementById( attrs.id ), {
            //     scrollingY: false,
            //     snapping: false,
            //     scrollbars: false
            // });

          }

      } //End of link

  }

});

app.directive('vzResizeSection', function($window) {

  return {
      restrict: 'AE',
      replace: false,
      link: function( scope, element, attrs ) {

        scroll_key = attrs.id;
        scope.$parent.myScroll = [];

        scope.$watch(function(){
             return $window.innerWidth;
        }, function(newValue, oldValue) {

              console.log("page is resized!");

              var windowWidth = $window.innerWidth;
              var windowHeight = $window.innerHeight;

              //Initiate FT Scroller only for windows of lower width
              if( newValue < 801 ) {

                var headerHeight = 0;  //document.getElementById("container").offsetHeight;
                var sectionHeight = (windowHeight) + "px";
                console.log("Height - " + sectionHeight);
/*
REASON: FTScroller doesn't allow certain objects with overflow property to scroll (i.e. dropdown)
*/
                // element.css("height", sectionHeight);
                // element.css("width", (windowWidth -0) + "px");
                // element.css("overflow-x", "hidden");

                // default timeout
                var ngiScroll_timeout = 5;
                // default options
                var ngiScroll_opts = {
                    snap: true,
                    momentum: true,
                    hScrollbar: false,
                    scrollingX: false
                };

                // scope.$parent.myScroll[scroll_key] = new FTScroller(element[0], ngiScroll_opts);

              } else {

                //console.log("New Value - " + newValue);
                //element.css("width", "auto");
                //element.css("overflow-x", "hidden");
                //element.css("height", "auto");

                // element.css("width", "");
                // element.css("overflow-x", "");
                // element.css("height", "");


                if( typeof(scope.$parent.myScroll[scroll_key]) !== 'undefined' ) {
                    scope.$parent.myScroll[scroll_key].destroy();
                }

              }

        });



      } //End of link

  }

});
