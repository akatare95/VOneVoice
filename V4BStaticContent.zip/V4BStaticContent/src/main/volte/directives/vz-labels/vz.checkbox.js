app.directive('vzCheckbox', function(){
    return {
        restrict: 'EC',
        templateUrl: 'partials/components/vz-labels/checkbox.html',
        scope: {
            isChecked: '=?',
            desc:'@',
            ngClick:'=',
            ngModel:'='
        },
        link: function (scope, elem, attrs) {
            scope.toggleMe = function () {
                scope.isChecked = !(scope.isChecked);
            }
        }
    }});