app.directive("vzRadio", function() {
    return {
        templateUrl: 'partials/components/vz-labels/radio.html',
        restrict: 'E',
        scope: {
            desc: "@",
            ngChecked:'='
        },
        controller: function( $scope ) {

        }
    }
});