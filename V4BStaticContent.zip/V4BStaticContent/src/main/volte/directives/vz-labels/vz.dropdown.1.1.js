app.directive('dropdown', function($document, $window, $rootScope, $timeout) {
    return {
        restrict: 'E',
        transclude: false,
        require: '^ngModel',
        scope: {
            ngModel: '=',
            valueField: '=',
            // listcolumns: "=",
            placeholder: "@",
            // selectedItems:"=",
            listcolumns: "=?",
            selectedItems: "=?",
            ngDisabled:'=?'
        },
        templateUrl: 'partials/components/dropdown/vz.dropdown.1.1.html',
        link: function(scope, element, attrs, ngModelCtrl) {
            // console.log("*********disabled");
            // console.log(scope.ngDisabled);
            var clickflag = false;
            scope.listVisible = false;
            scope.isPlaceholder = true;

            scope.show = function() {
                if(!scope.ngDisabled)
                {
                  clickflag = true;
                  scope.listVisible = !scope.listVisible;
                }
            };

            scope.updateModel = function(item) {

                var value = (item.value != 'undefined') ? item.value : item;
                var name = (item.name != 'undefined') ? item.name : item;
                scope.selectedItems = value;
                ngModelCtrl.$setViewValue(value);
                scope.display = name;
                scope.isPlaceholder = false;

            };
            $timeout(function() {
                var clickHandlerFn = function($event) {
                    if (!clickflag) {
                        scope.listVisible = false;
                    }
                    clickflag = false;
                    scope.$digest();
                };
                $document.on('click', clickHandlerFn);
                scope.$on('$destroy', function() {
                    $document.off('click', clickHandlerFn);
                });
            });
            scope.$watch('valueField', function(newValue, oldValue) {
                scope.items = scope.valueField;
            });

            if (attrs.selectVal) {
                scope.display = attrs.selectVal;
                scope.isPlaceholder = false;
            }
        }
    };

});