app.directive('vzCheckAll', function () {
    return {
        restrict: 'E',
        templateUrl: 'partials/components/vz-labels/checkall.html',
        scope: {
            checkboxes: '=',
            isChecked: '=?',
            ngClick:'=',
            ngModel:'='
        },
        //template: '<input type="checkbox" ng-checked="isChecked" ng-click="toggleMe()" ng-change="masterChange()" ng-model="master" /><span style="padding: 7px;"></span>',
        controller: function ($scope, $element) {

            $scope.masterChange = function () {
                if ($scope.master) {
                    angular.forEach($scope.checkboxes, function (cb, index) {
                        cb.isChecked = true;
                    });
                } else {
                    angular.forEach($scope.checkboxes, function (cb, index) {
                        cb.isChecked = false;
                    });
                }
            };

            $scope.$watch('checkboxes', function () {
                var allSet = true,
                    allClear = true;
                    if($scope.checkboxes.length>0)
                    {
                      angular.forEach($scope.checkboxes, function (cb, index) {
                        if (cb.isChecked) {
                            allClear = false;
                        } else {
                            allSet = false;
                        }
                       });
                    }
                    else{
                        allSet = false;
                    }

                if ($scope.allselected !== undefined) {
                    $scope.allselected = allSet;
                }
                if ($scope.allclear !== undefined) {
                    $scope.allclear = allClear;
                }

                $element.prop('indeterminate', false);
                if (allSet) {
                    $scope.master = true;
                } else if (allClear) {
                    $scope.master = false;
                } else {
                    $scope.master = false;
                    $element.prop('indeterminate', true);
                }

            }, true);
        }
    };
});