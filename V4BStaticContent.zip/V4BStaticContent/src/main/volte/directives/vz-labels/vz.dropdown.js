app.directive('vzDropdown', ['$log', '$document', function($log, $document) {
	return {
		restrict: 'AE',
		require: 'ngModel',
		scope: {
			items: '=',
			width: '@'
		},
		templateUrl: 'partials/components/vz-labels/vzDropdown.html',
		link: function($scope, $element, $attrs, ctrl) {
			var ieClickFocusFix_InFocus;
			if ($scope.width) {
				$element.find(".vz-dropdown").css("min-width", $scope.width + 'px');
			}
			if ($attrs.tabIndex === undefined || $attrs.tabIndex === "") {
				$element.attr("tabIndex", "0");
			}
			var navigationKeyCodes = [38, 40, 36, 35];
			$scope.hoverIndex = -1;
			if (bowser.msie) {
				$element.click(function(event) {
					if (!ieClickFocusFix_InFocus) {
						angular.element(this).focus();
						ieClickFocusFix_InFocus = true;
					}
				});
			}
			$element.focus(function() {
				registerKeypress();
			});
			$element.blur(function() {
				ieClickFocusFix_InFocus = false;
				deregisterKeypress();
			});
			$scope.$on('$destroy', function() {
				//important to deregister
				$document.off('keydown', keypressHandlerFn);
			});
			itemsChanged();
			$scope.$watch('items', itemsChanged, true);
			$scope.menuVisisble = false;
			ctrl.$render = function() {
				$scope.$applyAsync(ctrlRender);
			};
			$scope.toggleDropdownMenu = function() {
				$scope.menuVisisble = !$scope.menuVisisble;
				if (!$scope.menuVisisble) {
					//needs to be here because of document click handling
					$scope.hoverIndex = -1;
				}
			};
			$scope.itemSelected = function(item) {
				$scope.toggleDropdownMenu();
				$scope.itemsCopy.forEach(function(item) {
					item.selected = false;
				});
				item.selected = true;
				$scope.selectedItem = item;
				ctrl.$setViewValue(item.value);
			};

			function registerKeypress() {
				$document.keydown(keypressHandlerFn);
			}

			function deregisterKeypress() {
				$document.off('keydown', keypressHandlerFn);
			}

			function keypressHandlerFn(eventObj) {
				if (navigationKeyCodes.indexOf(eventObj.which) !== -1) {
					$scope.$applyAsync(function($scope) {
						$scope.menuVisisble = true;
						var selectedItemIndex = -1;
						//Adjust the hoverIndex because the item may be already selected and not visible in the list
						$scope.itemsCopy.some(function(item, idx) {
							if (item.selected) {
								selectedItemIndex = idx;
								return true; //stop looping
							}
						});
						if (eventObj.which === 38) {
							//up arrow
							$scope.hoverIndex = Math.max(0, $scope.hoverIndex - 1);
							if ($scope.hoverIndex === selectedItemIndex) {
								if ($scope.hoverIndex === 0) {
									$scope.hoverIndex = Math.min($scope.itemsCopy.length - 1, $scope.hoverIndex + 1);
								} else {
									$scope.hoverIndex = Math.max(0, $scope.hoverIndex - 1);
								}
							}
						} else if (eventObj.which === 40) {
							//down arrow
							$scope.hoverIndex = Math.min($scope.itemsCopy.length - 1, $scope.hoverIndex + 1);
							if ($scope.hoverIndex === selectedItemIndex) {
								//Check if there are no more non-selected elements downwards
								if ($scope.hoverIndex === $scope.itemsCopy.length - 1) {
									$scope.hoverIndex = Math.max(0, $scope.hoverIndex - 1);
								} else {
									$scope.hoverIndex = Math.min($scope.itemsCopy.length - 1, $scope.hoverIndex + 1);
								}
							}
						} else if (eventObj.which === 36) {
							//home key
							$scope.hoverIndex = 0;
							if ($scope.hoverIndex === selectedItemIndex) {
								$scope.hoverIndex = Math.min($scope.itemsCopy.length - 1, $scope.hoverIndex + 1);
							}
						} else if (eventObj.which === 35) {
							//end key
							$scope.hoverIndex = $scope.itemsCopy.length - 1;
							if ($scope.hoverIndex === selectedItemIndex) {
								$scope.hoverIndex = Math.max(0, $scope.hoverIndex - 1);
							}
						}
					});
					eventObj.preventDefault();
				} else if (eventObj.which === 13) {
					//enter key
					$scope.$applyAsync(function($scope) {
						if (!$scope.menuVisisble) {
							$scope.menuVisisble = true;
						} else {
							//also select the chosen item
							if ($scope.hoverIndex !== -1) {
								$scope.itemSelected($scope.itemsCopy[$scope.hoverIndex]);
							}
						}
					});
					eventObj.preventDefault();
				} else if (eventObj.which === 27 || eventObj.which === 9) {
					//ESC key or TAB key respectively
					if ($scope.menuVisisble) {
						$scope.$applyAsync(function($scope) {
							$scope.toggleDropdownMenu();
						});
					}
					if (eventObj.which === 27) {
						eventObj.preventDefault();
					}
				}
			}

			function ctrlRender() {
				var result;
				if ($scope.itemsCopy && $scope.itemsCopy.length) {
					result = $scope.itemsCopy.some(function(item) {
						if (item.value === ctrl.$viewValue) {
							$scope.selectedItem = item;
							return true; //stop looping
						}
					});
				}
				//If a selected item is not found
				if (!result) {
					//Check if the $viewValue is non empty
					if (!ctrl.$viewValue) {
						//it's empty, set it to the placeholder
						$scope.selectedItem = {
							name: $attrs.placeholder ? $attrs.placeholder : '',
							value: ''
						};
					} else {
						//it's not empty, set it as it is!
						$scope.selectedItem = {
							name: ctrl.$viewValue,
							value: ctrl.$viewValue
						};
					}
				}
			}

			function itemsChanged() {
				if (!$scope.items || !$scope.items.length) {
					return;
				}
				$scope.itemsCopy = angular.copy($scope.items);
				$scope.itemsCopy.some(function(item) {
					if (item.selected) {
						$scope.selectedItem = item;
						ctrl.$setViewValue(item.value);
						return true; //stop looping
					}
				});
				//Also render the DOM when items collection has changed
				$scope.$applyAsync(ctrlRender);
			}
		}
	};
}]);