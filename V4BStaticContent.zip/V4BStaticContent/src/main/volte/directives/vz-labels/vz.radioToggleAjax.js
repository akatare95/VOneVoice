
app.directive("vzRadioToggleAjax", function($http,Constants,$filter) {
    return {
        template: '<div   ng-show="!toggleSbtBtnStatus" class="toggle-container"  ><input id="cmn-toggle-4" class="cmn-toggle cmn-toggle-round" checkedval="checkedval" ng-checked="checkedval" type="checkbox"><label for="cmn-toggle-4"></label></div>'+
                   '<span   ng-show="toggleSbtBtnStatus">Submitted</span>',
        restrict: 'E',
        require: '^ngModel',
        scope: {
            checkedval:'=',
            toggleStatus: '=',
            feature:'=',
            id: '=',
            multiple: '=',
            radiofeatureid:'=',
            settings:'=',
            username:'='
        },
        link: function( scope, element, elmAttr, ngModelCtrl) {
             //alert(scope.checkedval);
            // var API = Constants.API.CALL_WAITING;
            // var option = API.GET;
            scope.$parent.$parent.showMsg=false;
            var toggleArr = [
                                {"call_waiting": Constants.API.CALL_WAITING.POST},
                                {"directed_call_pickup":Constants.API.DIRECTED_CALL_PICKUP.POST},
                                {"call_forwarding_group":Constants.API.CALL_FORWARDING.GROUP_POST},
                                {"call_forwarding_selective":Constants.API.CALL_FORWARDING.SELECTIVE_POST},
                                {"call_forwarding_always":Constants.API.CALL_FORWARDING.ALWAYS_POST},
                                {"call_forwarding_busy":Constants.API.CALL_FORWARDING.BUSY_POST},
                                {"call_forwarding_noAnswer":Constants.API.CALL_FORWARDING.NOANSWER_POST},
                                //{"directed_call_Pickup":Constants.API.DIRECTED_CALL_PICKUP},
                                {"barge_in_exempt":Constants.API.BARGE_IN_EXEMPT.POST},
                                {"automatic_callback":Constants.API.AUTO_CALLBACK.POST},
                                {"annonymous_call_rejection":Constants.API.ANNONYMOUS_CALL_REJECTION.POST},
                                {"selective_call_rejection":Constants.API.SELECTIVE_CALL_REJECTION.POST},
                                {"selective_call_acceptance":Constants.API.SELECTIVE_CALL_ACCEPTANCE.POST},
                                {"simultaneous_ring":Constants.API.SIMULTANEOUS_RING_SERVICE.POST},
                                {"caller_id_block":Constants.API.CALLER_ID_BLOCK.POST},
                                {"pre_alert_announcement":Constants.API.PRE_ALERT_ANNOUNCEMENT.POST},
                                {"music_on_hold_user":Constants.API.MUSIC_ON_HOLD_USER.POST}
                            ];
            //Constants.API.CALL_WAITING.POST

            // console.log(scope.checkedval);
             //console.log(scope.feature);
   //          toggleArr[0]= “feature/callWaiting/post”;
			// toggleArr[“call_waiting”] = “feature/callWaiting/post”;
			// toggleArr[“call_forwarding”] = “feature/callForwarding/post”;

	        function setOption( opt ) {
		        option = opt;
		    };
	        function getData( data ) {
			    var params = data || {};
			    return $http.post( Constants.API_HOST + option, params);
			};
		    function postData( data ) {
		        var params = data || {};
		        return $http.post( Constants.API_HOST + option, params );
		    };

            function init() {
                //alert(scope.checkedval);
                var flag=false;
                //scope.$parent.showMsg=false;
                //scope.$parent.$parent.showMsg=false;
                // scope.$parent.$parent.msgType=undefined;
                // scope.$parent.$parent.msgTxt=undefined;
                //console.log("checking checkedval "+scope.radiofeatureid);
                //scope.checkedval=scope.checkedval=='true'?true:false;
                //alert(typeof(scope.checkedval));
                if( scope.checkedval) {
                    //scope.$parent.checkedval=true;
                    ngModelCtrl.$setViewValue( true );
                    element.find("input").attr("checked","checked");
                } else {
                    ngModelCtrl.$setViewValue( false );
                }
            }

            function toggleRadioBtn() {

                if( !scope.checkedval ) {
                    ngModelCtrl.$setViewValue( true );
                    element.find("input").attr("checked","checked");
                    // console.log("abc"+scope.multiple);
                    scope.checkedval = true;
                } else {
                    ngModelCtrl.$setViewValue( false );
                    element.find("input").attr("checked","");
                    console.log("abc"+scope.multiple);
                    element.find("input").removeAttr("checked");
                    scope.checkedval = false ;
                }
                console.log(scope.settings);
                if(scope.settings!==true)
                {
                  triggerAjax();
                }
            }

            function triggerAjax() {

                var jsonObj = "";
                var API     = "";
                var params  = "";

                try {
                    jsonObj = toggleArr.filter(function( record ) {
                        return record[ scope.feature ];
                    });
                    API = jsonObj[0][ scope.feature ];
                    // scope.$parent.msgType.push('error');
                    // scope.$parent.showMsg = true;
                    // scope.$parent.msgTxt = "Unable to load the data";
                    //console.log(scope.$parent.msgType,scope.$parent.showMsg,scope.$parent.msgTxt )
                    setOption( API );
                    params =  {
                                "updateFeatures": {
                                        "updateFeature": [
                                            {
                                                "updateType": "Status",
                                                "phoneNo": scope.id,
                                                "userName": scope.username,
                                                "settingsInfo": {
                                                    // "featureId": scope.radiofeatureid,
                                                    "active": scope.checkedval.toString()
                                                }
                                            }
                                        ]
                                }
                               };
                    scope.toggleSbtBtnStatus = true;
                    postData( params )
                    .success(function(result) {
                        console.log(result);
                         if(result.appHeader.statusCode == "OK")
                          {
                                // console.log(scope.$parent.showMsg=true);
                                // console.log(scope);
                                scope.$parent.$parent.showMsg=true;
                                scope.$parent.$parent.msgType="success";
                                scope.$parent.$parent.msgTxt="Sucessfully updated";
                                console.log(scope);
                            }
                            else {
                                scope.$parent.$parent.msgType = "error";
                                scope.$parent.$parent.msgTxt = result.appHeader.statusMessage;
                                scope.$parent.$parent.showMsg = true;
                            }
                        scope.collection=result.appResult.serviceRepsonse;

                        //scope.checkedval=scope.collection.status;
                        scope.toggleSbtBtnStatus = false;
                        // console.log(scope.showmsg,scope.msgtype,scope.msgtxt);
                        // scope.showMsg=true;
                        // scope.$parent.showMsg=true;
                        // scope.$parent.$parent.showMsg=true;
                        // scope.$parent.$parent.msgtype="success";
                        // scope.$parent.msgType="success";
                        // scope.$parent.msgTxt="Sucessfully updated"

                        // scope.$parent.msgTxt="updated"
                    console.log(scope.$parent.showMsg);
                        console.log(scope.$parent.showMsg);
                        console.log();
                    })
                    .error(function(){
                        console.log('error');
                        //scope.toggleSbtBtnStatus = false;
                    });

                } catch( err ) {
                    scope.toggleSbtBtnStatus = false;
                     // scope.$parent.msgType = "error";
                     // scope.$parent.msgType.push('error');
                     // scope.$parent.showMsg = true;
                     // scope.$parent.msgTxt = "Unable to load the data";
                    console.log("Error - " + err.message  );

                }

            }

            element.on("click",function(e){
                e.preventDefault();
                toggleRadioBtn();
            });

            //Trigger this functionality
            init();

            //Watch the changes in the checkval attribute
            scope.$watch("multiple", function(newValue, oldValue) {
                if(oldValue !== newValue)
                {
                    //console.log(oldValue,newValue);
                    // init();
                    if( scope.multiple ) {
                        scope.toggleSbtBtnStatus = true;
                    }
                    else
                    {
                        scope.toggleSbtBtnStatus = false;
                    }
                }
            });
            scope.$watch("checkedval", function(newValue, oldValue) {
                init();
            });

        }
    }
});