app.directive("vzFooter", function($rootScope, $document) {
  return {
      restrict: "E",
      templateUrl: "partials/layout/footer.html"
    }
});