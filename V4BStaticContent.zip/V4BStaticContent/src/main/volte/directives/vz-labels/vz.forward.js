app.directive("vzForward", function($compile) {
  return {
    replace: true,
    templateUrl: 'partials/components/vz-labels/forward.html',
    restrict: 'E',
    require:'^ngModel',
    scope: {
        desc: "@",
        ngChecked: '=',
        checkedval:'='
    },
      link:function(scope, element, attrs, ngModelCtrl){
          var val=true;
          scope.updateModel = function( )
          {
              ngModelCtrl.$setViewValue( val );
              if(scope.ngChecked=== "false")
                {
                  scope.ngChecked="true";
                  console.log(scope.ngChecked)
                }
              else{
                scope.ngChecked="false";
              }
          };
      }
  }
});
