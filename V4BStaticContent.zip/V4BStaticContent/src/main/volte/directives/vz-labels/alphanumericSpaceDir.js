app.directive('alphanumericspace', function() {
  return {
    require: 'ngModel',
    link: function (scope, element, attr, ngModelCtrl) {
      function fromUser(text) {
        var transformedInput = text.replace(/[^a-z0-9\s]/gi,'');
        //console.log(transformedInput);
        if(scope.showmsg)scope.showmsg=false;
        if(transformedInput !== text) {
            ngModelCtrl.$setViewValue(transformedInput);
            ngModelCtrl.$render();
            // scope.showmsg=true;
            // scope.msgtype="error";
            // scope.msgtxt="Enter an alphanumeric value";
        }
        return transformedInput;
      }
      ngModelCtrl.$parsers.push(fromUser);
    }
  };
});