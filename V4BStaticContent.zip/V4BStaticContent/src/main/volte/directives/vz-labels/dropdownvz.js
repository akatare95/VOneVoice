app.directive("dropdownvz", function($rootScope,$timeout,$document) {
    return {
        restrict: "E",
        templateUrl: 'partials/components/vz-labels/dropdownvz.html',
        scope: {
            placeholder: "@",
            list: "=",
            selected: "=",
            property: "@"
        },
        link: function(scope) {
            scope.listVisible = false;
            scope.isPlaceholder = true;
            var clickflag = false;
            scope.select = function(item) {
                scope.isPlaceholder = false;
                scope.selected = item;
                scope.listVisible = !scope.listVisible;
            };

            scope.isSelected = function(item) {
                if(scope.selected)
                {
                  return item[scope.property] === scope.selected[scope.property];
                }
                else
                {
                    return false;
                }
            };

            scope.show = function() {
                clickflag = true;
                scope.listVisible = !scope.listVisible;
            };

            // $rootScope.$on("documentClicked", function(inner, target) {
            //  console.log($(target[0]).is(".dropdown-display.clicked") || $(target[0]).parents(".dropdown-display.clicked").length > 0);
            //  if (!$(target[0]).is(".dropdown-display.clicked") && !$(target[0]).parents(".dropdown-display.clicked").length > 0)
            //      scope.$apply(function() {
            //          scope.listVisible = false;
            //      });
            // });
            $timeout(function() {
                var clickHandlerFn = function($event) {
                    if (!clickflag) {
                        scope.listVisible = false;
                    }
                    clickflag = false;
                    scope.$digest();
                };
                $document.on('click', clickHandlerFn);
                scope.$on('$destroy', function() {
                    $document.off('click', clickHandlerFn);
                });
            });

            scope.$watch("selected", function(value) {
                console.log('****************');
                console.log(value)
                if(scope.selected)
                {
                  scope.isPlaceholder = scope.selected[scope.property] === undefined;
                  scope.display = scope.selected[scope.property];
                }
                else
                {
                    scope.isPlaceholder =true;
                }
            });
        }
    }
});