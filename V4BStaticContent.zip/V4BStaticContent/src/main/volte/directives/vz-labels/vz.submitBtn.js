app.directive("vzSubmitBtn", function($compile, $rootScope) {
  return {

    restrict: 'E',
    templateUrl: 'partials/components/vz-labels/submitBtn.html',
    scope: {
        btnValue: '@',
        enableDescision: "=",
        someCtrlFn: '&callbackFn'
    },
    link:function(scope, element, attrs, ngModelCtrl){
        // if (scope.enableDescision){
        //         // var disable = $parse(attrs.disable);
        //         element.bind('click', foo);
        //  }
        //  else
        //  {
        //     element.unbind('click', foo);
        //  }
         // scope.$watch('enableDescision',function(oldVal,newVal){
         //  if (scope.enableDescision){
         //        // var disable = $parse(attrs.disable);
         //        element.bind('click', foo);
         // }
         // else
         // {
         //    element.bind('click', );
         // }
         // })
// scope.someCtrlFn();
 //console.log($rootScope.vzSubmitBtnStatus);
        // function foo(e)
        // {
        //     e.preventDefault();
        //     e.stopImmediatePropagation();
        //      // scope.someCtrlFn();
        // }
        // var disabled = false;

        // element.bind('click', function () {
        //     if (!disabled) {
        //         scope.someCtrlFn();
        //     }
        // });

        // scope.$watch('enableDescision',function(newVal,oldVal){
        //     disabled = newVal;
        // });

        var impersonationFlag = false;

        if( $rootScope.userProfile.role == 'I' )
            impersonationFlag = true;
        scope.vzSubmitBtnStatusFn = function( decision ) {
            if( !impersonationFlag ) {
                $rootScope.vzSubmitBtnStatus = !decision;
                return decision;

            } else {

                return true;
            }

        }

    }

  }

});