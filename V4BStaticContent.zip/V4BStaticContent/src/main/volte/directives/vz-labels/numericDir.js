app.directive('numerictxt', function() {
  return {
    require: 'ngModel',
    scope: {
            maxlen:'=?'
        },
    link: function (scope, element, attr, ngModelCtrl) {
      function fromUser(text) {
        //console.log(text);
        var transformedInput = text.replace(/[^0-9]/gi,'');
        if(scope.maxlen)
          {
            // parseInt(scope.maxlen);
            transformedInput = transformedInput.substring(0,parseInt(scope.maxlen));
          }
        if(transformedInput !== text) {
            ngModelCtrl.$setViewValue(transformedInput);
            ngModelCtrl.$render();
        }
        return transformedInput;
      }
      ngModelCtrl.$parsers.push(fromUser);
    }
  };
});