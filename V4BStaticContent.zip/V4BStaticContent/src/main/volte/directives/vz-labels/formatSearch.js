app.directive('formatsearch', function () {
    return {
        require: 'ngModel',
        scope: {
            filterby:'=?',
            serversearch:'=?'
        },
        link: function (scope, element, attr, ngModelCtrl) {
            function fromUser(text) {
                var transformedInput = text;
                if(scope.serversearch && (scope.filterby ==='phoneNumber') )
                {
                    transformedInput = text.replace(/[^0-9]/gi,'');
                    transformedInput = transformedInput.substring(0,10);
                    if(transformedInput !== text) {
                        ngModelCtrl.$setViewValue(transformedInput);
                        ngModelCtrl.$render();
                    }
                }
                return transformedInput;
            }
            ngModelCtrl.$parsers.push(fromUser);

            scope.$watch('filterby', function(newValue, oldValue) {
                if(newValue !== oldValue) {
                    ngModelCtrl.$setViewValue("");
                    ngModelCtrl.$render();
                }
            });

        }
    };
});
