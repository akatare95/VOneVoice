app.directive('timedropdown', function($rootScope) {
    //var currentHour = scope.increment(1);

    return {
        restrict: 'A',
        scope: {
            type:'@',
            type1:'@',
            selectTime: '@'
        },
        template:'<div ><div style="display:inline-block;height:56px;width:100px;float:left;">'+
        '<span class="valueIncDec">{{ value }}</span>' +
            '</div>'+
        '<div style="display:inline-block;height:54px;width:25px;border-bottom: 0px;">'+
        '<div style="height:22px; width:25px;border-bottom: 0px;"><span  ng-click="increment()"><img src="assets/images/menu-selected.png" style="width:17px;height:17px;" ></span></div>'+
        '<div style="height:22px; width:25px;border-bottom: 0px;padding-top:10px;"> <span ng-click="decrement()"> <img src="assets/images/arrow-calendar-down.png"></span></div></div></div>',
        link: function(scope, element, attrs) {
            //var currentTime = 1;
            var meridian = 'am';
            if(scope.type1=='endTime'){
                var currentTime=moment().add(12,'h');
            }
            else if(scope.type=='startTime'){
                var currentTime=moment();

            }

            if(scope.selectTime) {
                scope.value = moment(scope.selectTime, 'hh a').format('hh:00 a');
            } else {
                scope.value=currentTime.format('hh:00 a');
            }

            scope.selectedDays = ['mon'];
            //var time=moment().format('hh:00 a');
            scope.increment = function() {
                //alert(angular.element(this).attr('ng-click'));
                    var time=currentTime;
                    currentTime=time.add(1,'h');

                    console.log(currentTime.format('hh:00 a'));
                    scope.value = currentTime.format('hh:00 a');
                scope.selectTime = scope.value;

            }
            scope.decrement = function() {

                var time=currentTime;
                currentTime=time.subtract(1,'h');
                console.log(currentTime.format('hh:00 a'));
                scope.value = currentTime.format('hh:00 a');
                scope.selectTime = scope.value;
            }
        }
    };
});
