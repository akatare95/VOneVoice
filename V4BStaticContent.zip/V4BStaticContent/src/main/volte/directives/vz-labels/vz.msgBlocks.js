app.directive('vzMsgBlocks', ['$document', function($document) {
    return {
        restrict: 'EC',
        templateUrl: 'partials/components/vz-labels/msgBlock.html',
        scope: {
            showmsg: '=',
            msgtype: '=',
            msgtxt: '=',
            thankutxt: '=?'
        },
        link: function(scope, elem, attrs) {
            // console.log(scope.showmsg)
            console.log(scope.showmsg)
            // This SHOULDN'T be necessary, but this value is being set somewhere
            // and it's affecting screens that don't have a showMsg value already
            // set (due to prototypical inheritance)
            scope.$root[attrs.showmsg] = false;

            function hideMessage() {
                // scope.$apply(function() {
                    scope.showmsg = false;
                // });
                unregisterClickHandlerFn();
            }

            function unregisterClickHandlerFn() {
                $document.off('click', hideMessage);
            }
            scope.$on("$destroy", unregisterClickHandlerFn);
            if (scope.showmsg) {
                $document.on('click', hideMessage);
            }
            scope.$watch('showmsg', function(newVal, oldVal) {
                // Sometimes newVal === oldVal... bug?
                if (newVal !== oldVal) {
                    scope.showmsg = newVal;
                    if (newVal) {
                        $document.on('click', hideMessage);
                    }
                }
            });
        }
    };
}]);