app.directive("vzRadioToggle", function() {
    return {
        template: '<input id="cmn-toggle-4" class="cmn-toggle cmn-toggle-round" checkedval="checkedval" ng-checked="checkedval" type="checkbox"><label for="cmn-toggle-4"></label>',
        restrict: 'E',
        require: '^ngModel',
        scope: {
            checkedval:'=',
            toggleStatus: '=',
            ngDisabled: '@'
        },
        link: function( scope, element, elmAttr, ngModelCtrl) {

            function init() {
                if( scope.checkedval ) {
                    ngModelCtrl.$setViewValue( true );
                    element.find("input").attr("checked","checked");
                } else {
                    ngModelCtrl.$setViewValue( false );
                }
            }

            function toggleRadioBtn() {
                if( !scope.checkedval ) {
                    ngModelCtrl.$setViewValue( true );
                    element.find("input").attr("checked","checked");
                    scope.checkedval = true;
                } else {
                    ngModelCtrl.$setViewValue( false );
                    element.find("input").attr("checked","");
                    element.find("input").removeAttr("checked");
                    scope.checkedval = false ;
                }
                 console.log(scope.checkedval);

            }

            element.on("click",function(e){
                e.preventDefault();

                if( !scope.ngDisabled ) {
                    toggleRadioBtn();
                }

            });

            //Trigger this functionality
            init();

            //Watch the changes in the checkval attribute
            scope.$watch("checkedval", function(newValue, oldValue) {
                init();
            });

        }
    }
});