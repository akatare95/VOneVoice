(function() {
    var SubHeader = function ($compile) {
        return {
            templateUrl: 'partials/components/vz-labels/subheader.html',
            restrict: 'E',
            scope: {
                css: "@",
                title: "@",
                desc: "@",
                tooltipinfo: "=?",
                instructions: "=?",
                actionsTpl: "=?"
            },
            controller: function ($scope, $element,ngDialog) {
                var $instructions = $element.find('.feature-instructions .list'),
                    html;

                $scope.$watch('instructions', function (instructions) {
                    $instructions.empty();

                    if (instructions && instructions.length) {
                        html = instructionsBuilder(instructions);
                        $instructions.append($compile(html)($scope));
                    }
                });
        // $scope.setCustomFile=function(){
        // console.log('inside custom')
        // var new_dialog = ngDialog.open({
        //                     template: 'partials/components/dialog/instructionsLink.html',
        //                     closeByDocument: false,
        //                     className: 'ngdialog-theme-default selective-call-rejection-dialog',
        //                     closeByEscape: false,
        //                     scope: $scope
        //                 });
        // }
            }
        };
    };

    /**
     * Recursively builds an <ol> html string given an instructions array
     *
     * @param      {Object[]}             instructions
     * @return     {String}               <ol></ol>
     */
    var instructionsBuilder = function (instructions) {
        var ol = '<ol>';

        _.each(instructions, function (instruction) {
            var li = '<li><span>' + instruction.text + '</span>';

            _.each(instruction.links, function (link, i) {
                var re = new RegExp('\\{' + i + '\\}', 'g'), // Look for {0}, {1}, {3}
                    html;

                html = [
                    '<a ',
                    (link.href ? 'ui-sref="' + link.href + '"' : ''),
                    (link.ngClick ? ' ng-click="$parent.' + link.ngClick + '"' : ''),
                    '>',
                    link.text,
                    '</a>'
                ].join("");

                li = li.replace(re, html);
            });

            if (instruction.instructions && instruction.instructions.length) {
                li += instructionsBuilder(instruction.instructions);
            }

            li += '</li>';
            ol += li;
        });

        ol += '</ol>';

        return ol;
    };

    SubHeader.$inject = ['$compile'];

    app.directive("vzSubHeader", SubHeader);
})();
