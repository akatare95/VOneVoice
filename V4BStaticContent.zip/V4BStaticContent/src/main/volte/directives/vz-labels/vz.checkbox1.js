
app.directive('vzCheckbox1', function(){
    return {
        restrict: 'E',
        templateUrl: 'partials/components/vz-labels/checkbox1.html',
        scope: {
            isChecked: '=?',
            desc:'@',
            ngDisabled:'=?'
        },
        link: function (scope, elem, attrs) {

            scope.checkBoxFunc = function() {
                // If checkbox is disabled (not editable), then even the description (text) part must be disabled for any mouse clicks
                if(!scope.ngDisabled) {
                    scope.isChecked = !scope.isChecked;
                }
            };

        }
    }});