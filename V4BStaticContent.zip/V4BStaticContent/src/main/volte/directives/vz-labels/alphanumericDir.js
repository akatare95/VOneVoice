app.directive('alphanumeric', function() {
  return {
    require: 'ngModel',
    scope: {
            showmsg:'=',
            msgtype:'=',
            msgtxt:'='
        },
    link: function (scope, element, attr, ngModelCtrl) {
      function fromUser(text) {
        var transformedInput = text.replace(/[^a-z0-9]/gi,'');
        if(scope.showmsg)scope.showmsg=false;
        if(transformedInput !== text) {
            ngModelCtrl.$setViewValue(transformedInput);
            ngModelCtrl.$render();
            scope.showmsg=true;
            scope.msgtype="error";
            scope.msgtxt="Enter an alphanumeric value";
        }
        return transformedInput;
      }
      ngModelCtrl.$parsers.push(fromUser);
    }
  };
});