angular.module(window.AppName).directive("overviewPieChart", ['$log', function($log) {
	return {
		restrict: 'A',
		scope: {
			chartData: '=overviewPieChart'
		},
		link: function($scope, $element, $attrs) {
			$element.addClass("overview-pie-chart");
			$scope.$watch('chartData', watchFn);
			watchFn();

			function watchFn(newVal, oldVal) {
				plotGraph(angular.copy($scope.chartData || []), $element, $attrs['chartType']);
			}
		}
	};

	function plotGraph(graphData, $element, chartType) {
		console.log('called')
		var width = 350,
			height = 250,
			margins = {
				//These are percentage values
				top: 20,
				right: 20,
				bottom: 15,
				left: 40
			},
			outerRadius,
			stripWidth,
			color = d3.scale.ordinal().range(graphData.map(function(item) {
				return item.color;
			}));

		var totalDesc;
		var linesCountArr = [], devicesCountArr=[];
		if (chartType === 'lines') {
			totalDesc = 'Total Lines'
		} else if (chartType === 'devices') {
			totalDesc = 'Total Devices'
		}

		var dataAvailable = true;
		if (!graphData.length) {
			dataAvailable = false;
			color.range(['#CCCCCC']);
			if (chartType === 'lines') {
				graphData = [{
					color: '#abe0f9',
					label: "Corporate",
					value: 0
				}, {
					color: '#66cbab',
					label: "Employee",
					value: 0
				}];
			} else if (chartType === 'devices') {
				graphData = [{
					color: '#cd1909',
					label: "Smartphones",
					value: 0
				}, {
					color: '#f69269',
					label: "Desk Phones",
					value: 0
				}, {
					color: '#f9d362',
					label: "Mobile Clients",
					value: 0
				}];
			}
		}

		//Calculate actual margins
		margins.top = margins.top / 100 * height;
		margins.bottom = margins.bottom / 100 * height;

		margins.right = margins.right / 100 * height;
		margins.left = margins.left / 100 * height;


		outerRadius = (Math.min(width, height) - margins.left - margins.right) / 2;
		outerRadius += 25; //minor adjustment

		stripWidth = 15;

		//Assumption is graphData contains label/value/color property objects
		//Remove old SVG element
		$element.empty();

		var format = d3.format("0,000");
		var svg = d3.select($element[0]).append("svg");
		var legendsContainer = d3.select($element[0])
			.append("div")
			.attr("class", "legend-container")
			.selectAll(".legend")
			.data(graphData)
			.enter()
			.append("div")
			.attr("class", "legend");

		legendsContainer.append("div")
			.attr("class", "legend-color")
			.attr("style", function(d) {
				return "background-color: " + d.color;
			});

		legendsContainer.append("div")
			.attr("class", "legend-text")
			.text(function(d) {
				return d.label
			});

		var chartOrigin = [outerRadius + margins.left, outerRadius + margins.top];

		var vis = svg.attr("width", width)
			.attr("height", height)
			.append("g")
			.attr("transform", "translate(" + chartOrigin[0] + "," + chartOrigin[1] + ")");

		//The main ARC
		var arc = d3.svg.arc()
			.innerRadius(outerRadius - stripWidth)
			.outerRadius(outerRadius);

		//Defining the Half Pie Chart - Active Devices
		var pie = d3.layout.pie()
			.value(function(d) {
				return d.value;
			})
			.sort(null);

		if (!dataAvailable) {
			graphData = [{
				color: '#CCCCCC',
				label: "",
				value: 100
			}];
		} else {
			graphData = graphData.filter(function(item) {
				return item.value > 0;
			});
		}
		//Creates Arc Slices for Connected and Disconnected Devices
		var arcs = vis.selectAll("g.slice")
			.data(pie(graphData))
			.enter()
			.append("g")
			.attr("class", "slice");

		arcs.append("path")
			.attr("fill", function(d, i) {
				return color(i);
			})
			.attr("d", arc)
			.attr("stroke", 'steelblue')
			.attr("stroke-width", 0)
			.transition()
			.each("end", function() {
				if (graphData.length > 1) {
					d3.select(this).on('mouseover', function(d, i) {
						var me = d3.select(this);
						var centroid = arc.centroid(d);
						//convert the y co-ordinate to a convential value
						centroid[1] = -centroid[1];
						var teta = Math.atan2(centroid[1], centroid[0]);
						var r = 5;
						var cartCord = [r * Math.cos(teta), -r * Math.sin(teta)];
						me.transition().duration(500).attr("transform", "translate(" + cartCord + ")");
					})
					.on('mouseout', function(d) {
						var me = d3.select(this);
						var cartCord = [0, 0];
						me.transition().duration(100).attr("transform", "translate(" + cartCord + ")");
					});
				}
			})
			.duration(750)
			.attrTween("d", function(d) {
				var interpolate = d3.interpolate({
					startAngle: 0,
					endAngle: 0
				}, d);
				return function(t) {
					return arc(interpolate(t));
				};
			});

		var totalDevices = graphData.reduce(function(prevVal, item) {
			if(chartType === 'lines')
				{
					linesCountArr.push(item.value);
				}
				else
				{
					devicesCountArr.push(item.value)
				}
			return prevVal + item.value;
		}, 0);

		if (!dataAvailable) {
			totalDevices = 0;
		}
        if(((linesCountArr[0]*100)/totalDevices)<=20 || ((linesCountArr[0]*100)/totalDevices)>=80)
        {
        	angular.element( document.querySelector( '.pie-container' ) )[0].style.marginLeft = "-70px";
        	console.log(angular.element( document.querySelector( '.pie-container' ) )[0].style)
        }
        else
        {
        	angular.element( document.querySelector( '.pie-container' ) )[0].style.marginLeft = "-30px";
        }
		var totalContainer = vis.append("g").attr("class", "middle-total").attr("text-anchor", "middle");
		totalContainer.append("text").attr("class", "count").text(format(totalDevices));
		totalContainer.append("text").attr("class", "desc").attr("dy", 20).text(totalDesc);

		if (!dataAvailable) {
			return; //do not execute any further
		}

		//Now draw the labels
		var labelGroups = arcs.append("g")
			.attr("class", "pathlabel")
			.attr("transform", function(d) {
				var centroid = arc.centroid(d);
				//convert the y co-ordinate to a convential value
				centroid[1] = -centroid[1];
				//Use atan2 to calculate the correct teta value, if you use Math.tan() the value can be incorrect.
				var teta = Math.atan2(centroid[1], centroid[0]);
				var r = outerRadius + 15;
				var cartCord = [r * Math.cos(teta), -r * Math.sin(teta)];
				return "translate(" + cartCord + ")";
			});

		labelGroups.append("path")
			.attr("stroke", "#595a5d")
			.attr("stroke-width", 1)
			.attr("d", function(d, i) {
				var path = [];

				var centroid = arc.centroid(d);
				//convert the y co-ordinate to a convential value
				centroid[1] = -centroid[1];
				//Use atan2 to calculate the correct teta value, if you use Math.tan() the value can be incorrect.
				var teta = Math.atan2(centroid[1], centroid[0]);

				var radiusStart = -15;
				var radiusEnd = -5;

				var cartCordStart = [radiusStart * Math.cos(teta), -radiusStart * Math.sin(teta)];
				var cartCordEnd = [radiusEnd * Math.cos(teta), -radiusEnd * Math.sin(teta)];

				path.push('M');
				path = path.concat(cartCordEnd);

				path.push('L');
				path = path.concat(cartCordStart);
				return path.join(' ');
			});

		labelGroups.append("text")
			.attr("class", "pathlabel-name")
			.attr("text-anchor", textAnchor)
			.text(function(d, i) {
				return d.data.label;
			})
			.attr("dy", 12);

		labelGroups.append("text")
			.attr("class", "pathlabel-value")
			.attr("text-anchor", textAnchor)
			.attr("dx", function(d) {
				var centroidAngle = Math.round((d.startAngle + d.endAngle) / 2, 4);
				if (centroidAngle <= Math.round(Math.PI, 4)) {
					return 3;
				} else {
					return 0;
				}
			})
			.text(function(d) {
				console.log(linesCountArr);
				return format(d.data.value);
			});

		function textAnchor(d) {
			var centroidAngle = Math.round((d.startAngle + d.endAngle) / 2, 4);
			if (centroidAngle > Math.round(Math.PI, 4)) {
				return "end";
			} else {
				return "start";
			}
		}
	}
}]);