app.directive("vzGridLoadDevices", ['$compile','$http', '$rootScope', 'lineServices.deprecated', function ($compile, $http, $rootScope, lineServices) {
    return {
        restrict: 'A',
        controller: function($scope, $http, $rootScope) {



        },
        link: function( scope, element, attrs ) {

            parentElmntStack = [];
            elementsStack = [];

            //console.log("State - ", scope);

            element.bind('click', function() {
                var status = element.attr("data-status");
                var detailDevice = 'device-detail-' + attrs.id;

                scope.getImageClass = function(deviceType) {
                    switch(deviceType) {
                        case 'smart phone':
                            return 'apple_iphone_6';
                            break;
                        case 'Desk Phone':
                            return 'yealink';
                            break;
                        case 'OTT':
                            return 'ott_tablet';
                            break;
                        default:
                            return 'bridge_with_admin';
                    }
                };

                if( status == 'closed' ) {

                    if (scope.type == 'lines') {
                      var lineNum = element.attr("line-number");
                      //lineServices.getAssociatedDevices(lineNum)
                      lineServices.getLineAssociatedDevices(lineNum)
                        .success(function (result) {
                            scope.associatedDevices = result.appResult.serviceRepsonse.associatedDeviceList;
                            scope.lineNumber = lineNum;
                        })
                        .error(function (error) {
                            console.log( 'Unable to load customer data: ' + error.message );
                            //$scope.status = 'Unable to load customer data: ' + error.message;
                        });
                    } else {
                      var lineNum = element.attr("line-number");
                      //lineServices.getDeviceAssociatedDevices(deviceId)
                      lineServices.getDeviceAssociatedDevices(lineNum)
                      .success(function (result) {
                          scope.deviceAsscDevices = result.appResult.serviceRepsonse.associatedDeviceList;
                          scope.lineNumber = lineNum;
                      })
                      .error(function (error) {
                          console.log( 'Unable to load customer data: ' + error.message );
                          //$scope.status = 'Unable to load customer data: ' + error.message;
                      });
                    }

                    $http.get('partials/lines/vz-associated-devices/vz.grid.load.devices-' + scope.type + '.html').then(function(result) {

                      //detailElmnsStack.push( detailDevice );
                      var el = angular.element('<tr><td colspan="8" id="'+ detailDevice +'" style="background-color: #ECEDEF; border-bottom: 3px solid #595A5D;">'+ result.data +'</td></tr>');
                      $compile( el )(scope);
                      element.parent().after(el);

                      //Save the references
                      parentElmntStack[detailDevice] = element;
                      elementsStack[detailDevice] = el;

                      //Do the css logics
                      element.parent().css("background-color","#ECEDEF");
                      element.attr("data-status","opened");
                      element.find("span").removeClass("expand-icon");
                      element.find("span").addClass("shrink-icon");

                    });

                } else {

                    //console.log("Parent Elements - ", parentElmntStack[detailDevice] );
                    //console.log("Parent Elements - ", parentElmntStack[detailDevice].parent().html() );
                    parentElmntStack[detailDevice].parent().css("background-color","#fff");
                    elementsStack[detailDevice].remove();
                    element.attr("data-status","closed");
                    element.find("span").removeClass("shrink-icon");
                    element.find("span").addClass("expand-icon");

                }

            });

        }
    }
}]);
