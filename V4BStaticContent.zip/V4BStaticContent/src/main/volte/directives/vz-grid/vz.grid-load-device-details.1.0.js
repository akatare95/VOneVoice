app.directive("vzGridLoadDeviceDetails", ['$compile','$http', '$rootScope', function ($compile, $http, $rootScope) {
    return {
        restrict: 'A',
        controller: function($scope, $http) {

            $scope.names=['Jani','Hege','Kai'];

            $scope.echo = function() {
              alert("works")
            }

        },
        link: function( scope, element, attrs ) {

            prevSelElement = {};
            prevSelElementDevice = {};

            element.bind('click', function(e) {

                  e.preventDefault();

                  //Highlight the currently selected element
                  element.addClass("item-selected");

                  //alert( attrs. );

                  //Load the data, compile that insert in the dom
                  $http.get('partials/lines/devices/'+ attrs.deviceType +'.html').then(function(result){


                  //Remove the select item class from the previous element
                  if( prevSelElement.length == 1) {
                    prevSelElement.removeClass("item-selected");
                    prevSelElementDevice.remove();
                  }

                    var el = angular.element('<div id="device-detail" class="tablet-device-details-float">'+ result.data +'</div><div class="tablet-device-details-overlay"></div>');
                    $compile( el )(scope);
                    element.parent().after(el);

                    //Store a referennce to the previous element
                    prevSelElement = element;
                    prevSelElementDevice = el;

                    return false;

                });

                return false;

            });

        }
    }
}]);