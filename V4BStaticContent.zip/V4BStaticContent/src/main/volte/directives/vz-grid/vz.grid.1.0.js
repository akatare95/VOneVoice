app.directive("vzGridAl", function() {
  return {
    template: '<ng-include src="getTemplateUrl()"/>',
    scope: {
      tpl: '@',
      ngModel: '=',
      ngSearch: '=',
      loadFlag: '='
    },
    restrict: 'E',
    controller: function($scope) {

      $scope.loadFlag = true;

      $scope.getTemplateUrl = function() {

        if( typeof($scope.tpl) !== 'undefined' )
          return $scope.tpl;
      }

      $scope.remove = function(array, index){
          array.splice(index, 1);
      }

      if( typeof($scope.loadFlag) != 'undefined' ) {
        $scope.loadFlag = $scope.loadFlag;
      }

      /*
      * Watch the loader in scope
      */
      scope.$watch(function() {
        return iAttrs.loadFlag;
      },function(newValue, oldValue){

        if( typeof newValue != 'undefined' )
          scope.loadFlag = newValue; //iAttrs.loadFlag;

      });


    }
  };
});


app.directive('vzGrid', function($http, $templateCache, $compile, $parse) {

  return {
      restrict: 'E',
      replace: true,
      link: function(scope , iElement, iAttrs) {

        prevEl   = {};
        //scope.loadFlag = true;

        init();

        function init() {

          if( typeof(iAttrs.tpl) == 'undefined' ) {
            return false;
          }

          if( typeof(iAttrs.loadFlag) != 'undefined' ) {
            scope.loadFlag = iAttrs.loadFlag;
          }

          fetchTemplate(iAttrs.tpl);

          watchScope();

        }

        function fetchTemplate( URL ) {

          var URL = URL || URL;

          $http.get(URL, {cache: $templateCache}).success(function(tplContent){

             if( typeof(prevEl.length) != 'undefined' ) {
                prevEl.remove();
              }

              var el = angular.element( tplContent );
              iElement.append( $compile(el)(scope) );
              prevEl = el;

          });

        }

        function watchScope() {

           //var parse = $parse(iAttrs.data)(scope);
          //console.log( parse );

          /*
          * Watch the type Attr
          */
          scope.$watch(function() {
              return iAttrs.tpl;
            }, function(newValue, oldValue) {

                if (newValue !== oldValue) {
                    //alert( iElement.attr('tpl') );
                    fetchTemplate( 'partials/lines/vz-grid/vz.grid.' + newValue +'.html' )
                }
          });

          /*
          * Watch the loader in scope
          */
          /*scope.$watch("loadFlag",function(newValue, oldValue){
            console.log("New Value - " + newValue +  " && Old Value - " + oldValue + " && Attr - " + iAttrs.loadFlag+ " && " + scope.loadFlag);
            if( typeof newValue != 'undefined' )
              scope.loadFlag = newValue;
          }, true);*/

        }

      }
  }
});