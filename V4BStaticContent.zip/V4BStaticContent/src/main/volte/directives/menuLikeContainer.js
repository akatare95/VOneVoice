app.directive('menuLikeContainer', ['$timeout', '$document', function ($timeout, $document) {
	return {
		restrict: 'A',
		scope: false,
		link: function ($scope, $element, $attrs) {
			var timeoutCancel = $timeout(function() {
				$document.on('click.menuLikeContainer' + $scope.$id, function(evt) {
					if ($element.get(0) === evt.target) {
						//if it's the same element that's clicked. Do nothing!
						return;
					}
					if ($element.has(evt.target).size() > 0 || jQuery(evt.target).parents('html').size() <= 0) {
						//If it's the child element that's clicked
						//OR
						//If the clicked element is detached from the DOM
						//Do nothing!
						return;
					}
					if ($attrs.menuLikeContainer) {
						$scope.$apply($attrs.menuLikeContainer);
					}
				});
				$scope.$on('$destroy', function() {
					$document.off('click.menuLikeContainer' + $scope.$id);
				});
			}, 0, false);
			$scope.$on("$destroy", function() {
				$timeout.cancel(timeoutCancel);
		    });
		}
	};
}]);