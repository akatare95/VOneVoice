app.directive('vzTabs', function() {

  return {
      restrict: 'AE',
      replace: false,
      scope: {
        tabOne: "@",
        tabTwo: "@"
      },
      controller: function( $scope, $state ) {

          $scope.toggleTab = function() {
              $scope.tab = !$scope.tab;
          }

          $scope.displayFirstTab = function() {
                if( $scope.tab == true ) {
                  return "vz-show";
              } else {
                  return "vz-hide";
              }
          }

          $scope.displaySecondTab = function() {
                if( $scope.tab != true ) {
                  return "vz-show";
              } else {
                  return "vz-hide";
              }
          }

          $scope.activateFirstTab = function( index ) {
              if( $scope.tab == true ) {
                  return "selected";
              } else {
                  return "";
              }
          }

          $scope.activateSecondTab = function( index ) {
              if( $scope.tab == false ) {
                  return "selected";
              } else {
                  return "";
              }
          }

      },
      templateUrl: 'partials/components/vz-tabs/tabs.html'
  }

});