app.directive("addnewtime", function(){
    return {
        restrict: "E",
        template: "<span addbuttons style='color:dodgerblue'>AddNewTime</span>"
    }
});
app.directive("addbuttons", function($compile){
    return function(scope, element, attrs){
        element.bind("click", function(){
            scope.count++;
            angular.element(document.getElementsByClassName('custom')).append($compile("<custom desc=Time"+scope.count+"></custom>")(scope));
        });
    };
});