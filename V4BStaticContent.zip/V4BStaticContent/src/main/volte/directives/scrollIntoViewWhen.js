app.directive('scrollIntoViewWhen', ['$timeout', function($timeout) {
	return {
		restrict: 'A',
		scope: {
			condition : '=scrollIntoViewWhen',
			scrollOptions : '='
		},
		link: function($scope, $element, $attrs) {
			var el = $element.get(0);
			function scrollEl() {
				var options = $scope.scrollOptions || false;
				if (el.scrollIntoView) {
					el.scrollIntoView(options);
				}
			}
			$scope.$watch('condition', function(newVal, oldVal) {
				if (newVal === true) {
					scrollEl();
				}
			});
		}
	};
}]);