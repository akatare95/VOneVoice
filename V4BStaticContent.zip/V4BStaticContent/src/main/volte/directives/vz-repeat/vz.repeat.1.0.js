app.directive('vzRepeat', function($http){
  return {
    transclude : 'element',
    compile : function(element, attr, linker){
      return function($scope, $element, $attr){

        //var s = (new Date).getTime();
        //console.log(" Diff 2 - " + s );

        var myLoop = $attr.vzRepeat,
            match = myLoop.match(/^\s*(.+)\s+in\s+(.*?)\s*(\s+track\s+by\s+(.+)\s*)?$/),
            indexString = match[1],
            collectionString = match[2],
            parent = $element.parent(),
            elements = [];

        // $watchCollection is called everytime the collection is modified
        $scope.$watchCollection(collectionString, function(collection){
          var i, block, childScope;

          // check if elements have already been rendered
          if(elements.length > 0){
            // if so remove them from DOM, and destroy their scope

            var limit = elements.length;
            //limit = 10;
            for (i = 0; i < limit; i++) {
              elements[i].el.remove();
              elements[i].scope.$destroy();
            };
            elements = [];
          }


          var fragment = angular.element( document.createDocumentFragment() );

          for (i = 0; i < collection.length; i++) {

            // create a new scope for every element in the collection.
            childScope = $scope.$new();

            // pass the current element of the collection into that scope
            childScope[indexString] = collection[i];

            linker(childScope, function(clone){
              // clone the transcluded element, passing in the new scope.
              //parent.append(clone); // add to DOM
              fragment.append(clone); // add to DOM
              childScope.$index = i;
              block = {};
              block.el = clone;
              block.scope = childScope;
              elements.push(block);

            });

          };

          //console.log( fragment );
          parent.append( fragment );

        });

        /*var s1 = ((new Date).getTime());
        console.log(" Diff 2 - " + ((new Date).getTime()) );
        var diff = s1 - s;
        console.log("Time - ", diff);*/

      }
    }
  }
});