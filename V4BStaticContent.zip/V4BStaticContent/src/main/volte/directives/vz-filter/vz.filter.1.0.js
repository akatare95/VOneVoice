app.directive("vzFilter", function() {
  return {
    templateUrl: 'partials/components/vz-filter/vz.filter.html',
    restrict: 'E',
    scope: {
        name: '@',
        itemClick: '=',
        lineDeviceFilterOptions: "=options"
    },
    link: function($scope, iElement, iAttrs) {
        $scope.selectedFilterOption = {id:"0", name:"All"};
        $scope.filterButtonActive = false;
        $scope.toggleState = function(item) {
            $scope.selectedFilterOption = item;
            $scope.itemClick(item);
            $scope.filterButtonActive = !$scope.filterButtonActive;
        }
        $scope.filterDropdownButton = function() {
            $scope.filterButtonActive = !$scope.filterButtonActive;
        };
    }
  }
});
