window.EXT = '';
window.APP_HOST = (window.EXT) ? 'server/json/' : window.portalBackendUrl + '/secure/';
window.impersonationFlag = true;
window.ENV_COPY = window.ENV;
app.constant('Constants', {

    //Application level Ajax timeout for all backend calls
    AJAX_TIMEOUT_IN_MILLIS: 216000,
    //User session timesout
    IDLE_PERIOD_IN_SECS: 24 * 60,
    GRACE_PERIOD_IN_SECS: 5 * 60,
    //API Host Name
    API_HOST: window.APP_HOST,
    //Max File Size limits in KB
    MAX_FILE_SIZE: {
        AUTO_ATTENDANT_GREETING: 2000,
        MUSIC_ON_HOLD: 5000,
        CUSTOM_RINGBACK: 1000,
        PRE_ALERTING: 2000
    },
    //API Service Urls
    API: {
        LANDING_PAGE: 'resources/fixtures/landingPage',
        LOG_OUT: 'resources/fixtures/session/logout',
        COMMON: {
            LINE_LOOKUP: 'line/lookup' + window.EXT
        },
        SESSION: {
            LOGOUT: 'resources/fixtures/session/logout',
            KEEP_ALIVE: 'heartbeat/extend' + window.EXT
        },
        LINES_PAGE: {
            LOAD_DEVICES_GRID: 'device/summaryList' + window.EXT,
            LOAD_LINES_GRID: 'line/summaryList' + window.EXT,
            LINESDOWNLOADPDF:'line/downloadpdf' + window.EXT,
            LINESDOWNLOADCSV:'line/downloadcsv'+ window.EXT,
            DEVICESDOWNLOADPDF:'device/downloadpdf' + window.EXT,
            DEVICESDOWNLOADCSV:'device/downloadcsv'+ window.EXT,
            LINE_COUNT_REDBAR: 'line/count' + window.EXT,
            DEVICE_COUNT_REDBAR: 'device/count' + window.EXT,
            ASSC_DEVICES_LINE: 'device/associatedDevices' + window.EXT,
            ASSC_DEVICES_DEVICE: 'device/associatedDevices' + window.EXT,
            LINE_DETAIL: 'line/detail' + window.EXT,
            DEVICE_DETAIL: 'device/detail' + window.EXT,
            LINE_ADDEPAM: 'line/addEndPoint' + window.EXT,
            BLOCKUNBLOCK: 'line/blockUnblock' + window.EXT,
            REMOVEALLOTT: 'device/removeDevice' + window.EXT,
            EPAM_PROCESS_ACTIONS : ENV.server.mb + '/epam/app/secure/processActions.go',
            SELECT_STRING : ENV.server.mb + '/epam/app/secure/servicelines/selectstring'
        },
        AUTHORIZE_PAGE: {
            PROFILE: 'v4bonbaording/retrieve' + window.EXT,
            SEND_TIMEZONE: 'authorize/admin' + window.EXT,
            VIEW_REQUEST_NOS: 'authorize/view_request_nos' + window.EXT,
        },
        SETUPUSERINFO_PAGE: {
            UPDATE_USER_INFO: 'dashBoard/updateUserInfo' + window.EXT,
            DOWNLOAD_ICON: 'volte/exportToExcel' + window.EXT,
            UPLOAD_FILE: 'dashBoard/processFileUpload' + window.EXT
        },
        ONBOARD_PAGE: {
            PROFILE: 'v4bonbaording/retrieve' + window.EXT,
            ENROLL: 'v4bonbaording/submit' + window.EXT
        },
        PREAUTHORIZE_PAGE: {
            //LOAD_LINES_GRID: 'eleu/retrieveRequestHistory',
            LOAD_LINES_GRID: 'eleu/retrieveRequestHistory' + window.EXT,
            SEND_REQUEST: 'eleu/preauthorization' + window.EXT,
            MTN_VALIDATE: 'eleu/mtn/basicDetails' + window.EXT
        },
        FEATURES_CONFIG: {
            FETCH: 'feature/enterprise/config/fetch' + window.EXT,
            UPDATE: 'feature/enterprise/config/update' + window.EXT
        },
        MUSIC_ON_HOLD: {
            GET: 'feature/enterprise/musiconhold/get' + window.EXT,
            UPDATE: 'feature/enterprise/musiconhold/update' + window.EXT,
            UPDATE_NO_FILE: 'feature/enterprise/musiconhold/updateWithoutFile' + window.EXT
        },
        CALLING_PLAN: {
            GET: 'feature/user/callingPlanAuthCode/get' + window.EXT,
            UPDATE: 'feature/user/callingPlanAuthCode/update' + window.EXT
        },
        // CALLING_PLAN:{
        //  GET:'feature/enterprise/callingplan/get' + window.EXT,
        //  UPDATE:'feature/enterprise/callingplan/update' + window.EXT
        // },
        FACC: {
            GET: 'feature/enterprise/facc' + window.EXT
        },
        CUSTOM_RINGBACK: {
            GET: 'feature/enterprise/customringback/get' + window.EXT,
            UPDATE: 'feature/enterprise/customringback/update' + window.EXT,
            UPDATE_NO_FILE: 'feature/enterprise/customringback/updateWithoutFile' + window.EXT
        },
        ACCOUNT_CODE: {
            ACCOUNT_SUMMARY: 'feature/enterprise/accountcode/get' + window.EXT,
            CREATE_ACCOUNT: 'feature/enterprise/accountcode/add' + window.EXT,
            AVAILABLE_LINES: 'feature/enterprise/accountcode/manageUsers' + window.EXT,
            MODIFY_ACCOUNT_CODE: 'feature/enterprise/accountcode/modifyUsers' + window.EXT,
            DELETE_LINES: 'feature/enterprise/accountcode/delete' + window.EXT
        },
        CALL_PICKUP_REMOTE: {
            CALL_PICKUP_SUMMARY: 'feature/enterprise/callpickup/getList' + window.EXT,
            DELETE_LINES: 'feature/enterprise/callpickup/delete' + window.EXT,
            GETINFO: 'feature/enterprise/callpickup/getInfo' + window.EXT,
            MODIFY_GROUP: 'feature/enterprise/callpickup/modify' + window.EXT,
            ADD_GROUP: 'feature/enterprise/callpickup/add' + window.EXT,
            AVAILABLE_LINES: 'feature/enterprise/callpickup/availableLines' + window.EXT
        },
        AUTHORIZE_CODE: {
            AUTHORIZE_SUMMARY: 'feature/enterprise/authorizationCode/get' + window.EXT,
            CREATE_AUTHORIZE: 'feature/enterprise/authorizationCode/create' + window.EXT,
            DELETE: 'feature/enterprise/authorizationCode/delete' + window.EXT,
            UPDATE: 'feature/enterprise/authorizationCode/update' + window.EXT,
            MANAGE: 'feature/enterprise/authorizationCode/manage' + window.EXT,
            AVAILABLE_LINES: 'line/lookup' + window.EXT
        },
        AUTO_ATTENDANT: {
            GET_LIST: 'feature/enterprise/autoattendant/getList' + window.EXT,
            GET_INFO: 'feature/enterprise/autoattendant/getInfo' + window.EXT,
            MODIFY: 'feature/enterprise/autoattendant/modify' + window.EXT,
            MODIFY_WITHOUT_FILE: 'feature/enterprise/autoattendant/modifyWithoutFile' + window.EXT
        },
        HUNT_GROUP: {
            HUNT_SUMMARY: 'feature/enterprise/huntgroup/getList' + window.EXT,
            HUNTGROUP_INFO: 'feature/enterprise/huntgroup/info' + window.EXT,
            MODIFY_HUNTGROUP: 'feature/enterprise/huntgroup/modify' + window.EXT,
            AVAILABLE_LINES: 'line/lookup' + window.EXT
        },
        CALLING_LINE_ID: {
            GET: 'feature/enterprise/callingLineId/get' + window.EXT,
            MODIFY: 'feature/enterprise/callingLineId/modify' + window.EXT
        },
        GROUP_FORWARDING: {
            GET: 'feature/enterprise/groupforwarding/get' + window.EXT,
            MODIFY: 'feature/enterprise/groupforwarding/update' + window.EXT
        },
        SCHEDULE: {
            GET: 'schedule' + window.EXT,
            GET_EVENTLIST: 'feature/enterprise/schedule/eventlist' + window.EXT,
            LIST: 'feature/enterprise/schedule/list' + window.EXT,
            MODIFY: 'feature/enterprise/schedule/modifyName' + window.EXT,
            ADD: 'feature/enterprise/schedule/add' + window.EXT,
            DELETE: 'feature/enterprise/schedule/deleteList' + window.EXT,
            MODIFY_SCHEDULE: 'feature/enterprise/schedule/modify' + window.EXT
        },
        DASHBOARD: {
            COUNT: 'dashBoard/count' + window.EXT
        },
        CALL_WAITING: {
            GET: 'feature/user/callWaiting/get' + window.EXT,
            POST: 'feature/user/callWaiting/update' + window.EXT
        },
        DIRECTED_CALL_PICKUP: {
            GET: 'feature/user/directedCallPickup/get' + window.EXT,
            POST: 'feature/user/directedCallPickup/update' + window.EXT
        },
        BARGE_IN_EXEMPT: {
            GET: 'feature/user/bargeInExempt/get' + window.EXT,
            POST: 'feature/user/bargeInExempt/update' + window.EXT
        },
        ANNONYMOUS_CALL_REJECTION: {
            GET: 'feature/user/anonymousCallRejection/get' + window.EXT,
            POST: 'feature/user/anonymousCallRejection/update' + window.EXT
        },
        AUTO_CALLBACK: {
            GET: 'feature/user/autoCallback/get' + window.EXT,
            POST: 'feature/user/autoCallback/update' + window.EXT
        },
        SELECTIVE_CALL_ACCEPTANCE: {
            GET: 'feature/user/selectiveCallAcceptance/get' + window.EXT,
            POST: 'feature/user/selectiveCallAcceptance/update' + window.EXT
        },
        SELECTIVE_CALL_REJECTION: {
            GET: 'feature/user/selectiveCallRejection/get' + window.EXT,
            POST: 'feature/user/selectiveCallRejection/update' + window.EXT
        },
        SIMULTANEOUS_RING_SERVICE: {
            GET: 'feature/user/simultaneousRing/get' + window.EXT,
            POST: 'feature/user/simultaneousRing/update' + window.EXT
        },
        PRE_ALERT_ANNOUNCEMENT: {
            GET: 'feature/user/preAlertingAnnouncement/get' + window.EXT,
            POSTFILE: 'feature/user/preAlertingAnnouncement/updateWithFile' + window.EXT,
            POST: 'feature/user/preAlertingAnnouncement/updateWithoutFile' + window.EXT
        },
        CALLER_ID_BLOCK: {
            GET: 'feature/user/callingIdBlocking/get' + window.EXT,
            POST: 'feature/user/callingIdBlocking/update' + window.EXT
        },
        CALL_FORWARDING: {
            GROUP:{
              GET: 'feature/user/nightForwarding/get' + window.EXT,
              POST: 'feature/user/nightForwarding/update' + window.EXT
            },
            ALWAYS:{
              GET: 'feature/user/callforwardingAlways/get' + window.EXT,
              POST: 'feature/user/callforwardingAlways/update' + window.EXT
            },
            SELECTIVE:{
              GET: 'feature/user/callForwardingSelective/get' + window.EXT,
              POST: 'feature/user/callForwardingSelective/update' + window.EXT
            },
            BUSY:{
              GET: 'feature/user/callForwardingBusy/get' + window.EXT,
              POST: 'feature/user/callForwardingBusy/update' + window.EXT
            },
            NOANSWER:{
              GET: 'feature/user/callForwardingNoAnswer/get' + window.EXT,
              POST: 'feature/user/callForwardingNoAnswer/update' + window.EXT
            }
        },
        CALLING_PLAN_USER: {
            GET: 'feature/user/callingPlan/get' + window.EXT,
            POST: 'feature/user/callingPlan/update' + window.EXT
        },
        MUSIC_ON_HOLD_USER: {
            GET: 'feature/user/musicOnHold/get' + window.EXT,
            POST: 'feature/user/musicOnHold/update' + window.EXT
        },
        UPDATE911ADDRESS: {
            POST: 'device/update911Address' + window.EXT,
            GET: 'device/deskPhoneDetail' + window.EXT
        },
        REMOVE_DESKPHONE: {
            POST: 'device/removeDevice' + window.EXT
        },

        DISCONNECT_OTT: {
        POST:'device/disconnectDevice' + window.EXT
        },

        REBOOT_DESKPHONE: {
            POST: 'device/rebootDeskPhone' + window.EXT
        },
        ENABLE_DESKPHONE: {
            POST: 'device/enableDevice' + window.EXT
        },
        DISABLE_DESKPHONE: {
            POST: 'device/disableDevice' + window.EXT
        },
        BRIDGE_TO_LINE: {
            bridgeLine_POST: 'device/bridgeLine' + window.EXT,
            unBridgeLine_POST: 'device/unBridgeLine' + window.EXT
                // GET:'device/deskPhoneDetail'+ window.EXT
        },
        REDIRECT_URL_PATHS: {
            split_At: 'volte',

            prod: 'https://b2b.verizonwireless.com',
            dev: 'https://b2b{0}.sdc.vzwcorp.com',

            commerce: '/b2b/commerce/amsecure/index.go',

            paramAA: 'ssPath=AA',
            paramHG: 'ssPath=HG',
            paramNSO: 'ssPath=NSO',
            paramNSE: 'ssPath=NSE',

            epamAppJS: '/epam/app/secure/entry.go',
            epam: '/epam/app/ng/secure/entry.go',

            //Declared for future use
            protocol: 'https://',
            domain: 'b2b',
            prod_Domain_Host: 'b2b.verizonwireless.com',
            dev_No_Sub_Domain_Host: 'b2b.sdc.vzwcorp.com',
            dev_Replace_Sub_Domain_Host: 'b2b{0}.sdc.vzwcorp.com',
            dev_Local_Sub_Domain_Host: 'b2balhost.sdc.vzwcorp.com',
            dev_QA1_Sub_Domain_Host: 'b2bqa1.sdc.vzwcorp.com',
            dev_QA2_Sub_Domain_Host: 'b2bqa2.sdc.vzwcorp.com',
            dev_QA3_Sub_Domain_Host: 'b2bqa3.sdc.vzwcorp.com',

            // No use
/*
            PROD: {
                commerce: 'https://b2b.verizonwireless.com/b2b/commerce/amsecure/index.go',
                commerceAA: 'https://b2b.verizonwireless.com/b2b/commerce/amsecure/index.go?ssPath=AA',
                commerceHG: 'https://b2b.verizonwireless.com/b2b/commerce/amsecure/index.go?ssPath=HG',
                commerceNSO: 'https://b2b.verizonwireless.com/b2b/commerce/amsecure/index.go?ssPath=NSO',
                commerceNSE: 'https://b2b.verizonwireless.com/b2b/commerce/amsecure/index.go?ssPath=NSE',

                epamAppJS: 'https://b2b.verizonwireless.com/epam/app/secure/entry.go',
                epam: 'https://b2b.verizonwireless.com/epam/app/ng/secure/entry.go',
                epamLS: 'https://b2b.verizonwireless.com/epam/app/ng/secure/entry.go#/lineSelection',

                xxx: 'xxx'
            },

            DEV: {
                commerce: 'https://b2b{0}.sdc.vzwcorp.com/b2b/commerce/amsecure/index.go',
                commerceAA: 'https://b2b{0}.sdc.vzwcorp.com/b2b/commerce/amsecure/index.go?ssPath=AA',
                commerceHG: 'https://b2b{0}.sdc.vzwcorp.com/b2b/commerce/amsecure/index.go?ssPath=HG',
                commerceNSO: 'https://b2b{0}.sdc.vzwcorp.com/b2b/commerce/amsecure/index.go?ssPath=NSO',
                commerceNSE: 'https://b2b{0}.sdc.vzwcorp.com/b2b/commerce/amsecure/index.go?ssPath=NSE',

                epamAppJS: 'https://b2b{0}.sdc.vzwcorp.com/epam/app/secure/entry.go',
                epam: 'https://b2b{0}.sdc.vzwcorp.com/epam/app/ng/secure/entry.go',
                epamLS: 'https://b2b{0}.sdc.vzwcorp.com/epam/app/ng/secure/entry.go#/lineSelection',

                xxx: 'xxx'
            },
*/
            xxx: 'xxx'

        }
    }
});
app.constant('Config', {

    //TITLE: "Business VoLTE", HD
    TITLE: "One Talk",
    AUTOMATED_RECEPTIONIST_TITLE: "Automated Receptionist",
    AUTOMATED_RECEPTIONIST_DESC: "The Automated Receptionist will answer incoming calls to your business" +
        " and allow the caller to select which department or person they wish to speak with.",
    SCHEDULE_TITLE: "Schedule",
    SCHEDULE_DESC: "Allows the company to set office hours of operation and holidays. " +
        "These scheduled can be used for call management features at the user and group level.",
    SCHEDULE_BIZ_TITLE: "Create New Business Schedule",
    SCHEDULE_BIZ_DESC: "There are two types of schedules that can be used: business schedules to accommodate hours of operation based on days of the week and holiday schedules for specific calendar holidays. Once schedules are defined they can be applied to features and determine when the feature is active. If Business and Holiday schedules overlap, the Holiday schedule will be used.",
    SCHEDULE_HOLIDAY_TITLE: "Create New Holiday Schedule",
    SCHEDULE_HOLIDAY_DESC: "",
    CALLING_PLAN_TITLE: "Calling Plan",
    CALLING_PLAN_DESC: "You can require authorization codes for dialing outside of the One Talk business group;" +
        " that could include calls to Local/Long Distance and/or International numbers.",
    ACCOUNT_CODE_TITLE: "Account Codes",
    ACCOUNT_CODE_DESC: "Codes that allow you to associate individual calls  with a specific code" +
        " for tracking purposes. The system administrator can later view the calls" +
        " placed using each code. ",
    MANAGE_ACCOUNT_CODES_TITLE: "Manage Account Codes",
    CREATE_ACCOUNT_CODES_TITLE: "Create Account Codes",
    MANAGE_ASSIGN_USERS_TITLE: "Manage/Assign Users",

    AUTHORIZATION_CODE_TITLE: "Authorization Codes",
    AUTHORIZATION_CODE_DESC: "Required codes allow you to require users to enter a code before placing" +
        "specific call types.",
    MANAGE_AUTHORIZATION_CODES_TITLE: "Manage Authorization Codes",
    CREATE_AUTHORIZATION_CODES_TITLE: "Create Authorization Codes",
    MANAGE_USERS_TITLE: "Manage/Assign Users",
    CALLING_LINE_ID_TITLE: "Calling Line ID Delivery",
    CALLING_LINE_ID_DESC: "Define a number from your One Talk group that will be sent to other callers " +
        "when you call them.",
    MUSIC_ON_HOLD_TITLE: "Music On Hold",
    MUSIC_ON_HOLD_DESC: "Play custom or default music when a caller is placed on Hold.",

    GROUP_FORWARDING_TITLE: "Group Forwarding ",
    GROUP_FORWARDING_DESC: "Quickly forward multiple user lines to the same destination/number; most commonly used for business continuity.",

    HUNT_GROUP_TITLE: "Hunt Group",
    HUNT_GROUP_DESC: "Set and apply rules for passing incoming calls to the first available line in the pre-defined group of users/lines.",

    CUSTOM_RINGBACK_TITLE: "Custom Ringback",
    CUSTOM_RINGBACK_DESC: "Use the default or upload a custom audio file that gets played when callers dial a One Talk" +
        " business line. This would replace the standard ringing tone.",
    // SCHEDULE_TITLE: "Schedule",
    // SCHEDULE_DESC:  "This features helps to creates the schedule for business and holidays",
    AUTO_ATTENDANT_TITLE: "Automated Receptionist",
    AUTO_ATTENDANT_DESC: "The Automated Receptionist will answer incoming calls to your business and allow the caller to " +
        "select which department or person they wish to speak with.",
    CREATE_SCHEDULE: "Create Schedule",
    CREATE_SCHEDULE_DESC: "This features helps to creates the schedule for business and holidays",

    CREATE_BIZ_SCHEDULE: "Create Business Schedule",
    CREATE_BIZ_SCHEDULE_DESC: "This features helps to creates the schedule for business and holidays",

    MANAGE_REMOTE_GROUP_PICKUP_TITLE: "Manage Remote Group Pickup",
    REMOTE_GROUP_PICK_UP_DESC: "Ensures calls are answered by allowing you to remotely pick up someone else's ringing line in the group from your phone.",
    CREATE_NEW_GROUP_TITLE: "Create New Group",
    REMOTE_GROUP_PICK_UP_TITLE: "Remote Group Pickup",

    CALL_WAITING_TITLE: "Call Waiting",
    CALL_WAITING_DESC: "Alerts you and allows you to take a second call while you are on the phone with someone.",

    REMOTE_CALL_PICKUP_TITLE: "Remote Call Pickup with Barge In",
    REMOTE_CALL_PICKUP_DESC: "Allows other members of your business to remotely pick up your line while it is " +
        "ringing or join your call in progress with or without a warning tone.",
    SELECTIVE_CALL_REJECTION_TITLE: "Selective Call  Acceptance / Rejection",
    SELECTIVE_CALL_REJECTION_DESC: "Reject incoming calls based on pre-defined conditions you set."

    // SCHEDULE_TITLE: "Schedule",
    // SCHEDULE_DESC:  "This features helps to creates the schedule for business and holidays",

    // CREATE_SCHEDULE: "Create Schedule",
    // CREATE_SCHEDULE_DESC:  "This features helps to creates the schedule for business and holidays",

    // CREATE_BIZ_SCHEDULE: "Create Business Schedule",
    // CREATE_BIZ_SCHEDULE_DESC:  "This features helps to creates the schedule for business and holidays",

});

app.constant('GroupForwardingConst', {

    BIZ_SCHEDULE: [{
        name: "1:00 A.M.",
        value: "1:00 A.M."
    }, {
        name: "2:00 A.M.",
        value: "2:00 A.M."
    }, {
        name: "3:00 A.M.",
        value: "3:00 A.M."
    }],

    HOLIDAY_SCHEDULE: [{
        name: "1:00 A.M.",
        value: "1:00 A.M."
    }, {
        name: "2:00 A.M.",
        value: "2:00 A.M."
    }, {
        name: "3:00 A.M.",
        value: "3:00 A.M."
    }]

});



app.constant('AuthorizeConst', {

    STATE_LIST: [{
        name: "Alabama",
        value: "AL"
    }, {
        name: "Alaska",
        value: "AK"
    }, {
        name: "American Samoa",
        value: "AS"
    }, {
        name: "Arizona",
        value: "AZ"
    }, {
        name: "Arkansas",
        value: "AR"
    }, {
        name: "California",
        value: "CA"
    }, {
        name: "Colorado",
        value: "CO"
    }, {
        name: "Connecticut",
        value: "CT"
    }, {
        name: "Delaware",
        value: "DE"
    }, {
        name: "District of Columbia",
        value: "DC"
    }, {
        name: "Florida",
        value: "FL"
    }, {
        name: "Georgia",
        value: "GA"
    }, {
        name: "Guam",
        value: "GU"
    }, {
        name: "Hawaii",
        value: "HI"
    }, {
        name: "Idaho",
        value: "ID"
    }, {
        name: "Illinois",
        value: "IL"
    }, {
        name: "Indiana",
        value: "IN"
    }, {
        name: "Iowa",
        value: "IA"
    }, {
        name: "Kansas",
        value: "KS"
    }, {
        name: "Kentucky",
        value: "KY"
    }, {
        name: "Louisiana",
        value: "LA"
    }, {
        name: "Maine",
        value: "ME"
    }, {
        name: "Maryland",
        value: "MD"
    }, {
        name: "Massachusetts",
        value: "MA"
    }, {
        name: "Michigan",
        value: "MI"
    }, {
        name: "Minnesota",
        value: "MN"
    }, {
        name: "Mississippi",
        value: "MS"
    }, {
        name: "Missouri",
        value: "MO"
    }, {
        name: "Montana",
        value: "MT"
    }, {
        name: "Nebraska",
        value: "NE"
    }, {
        name: "Nevada",
        value: "NV"
    }, {
        name: "New Hampshire",
        value: "NH"
    }, {
        name: "New Jersey",
        value: "NJ"
    }, {
        name: "New Mexico",
        value: "NM"
    }, {
        name: "New York",
        value: "NY"
    }, {
        name: "North Carolina",
        value: "NC"
    }, {
        name: "North Dakota",
        value: "ND"
    }, {
        name: "Northern Mariana Islands",
        value: "MP"
    }, {
        name: "Ohio",
        value: "OH"
    }, {
        name: "Oklahoma",
        value: "OK"
    }, {
        name: " Oregon",
        value: "OR"
    }, {
        name: "Pennsylvania",
        value: "PA"
    }, {
        name: "Puerto Rico",
        value: "PR"
    }, {
        name: "Rhode Island",
        value: "RI"
    }, {
        name: "South Carolina",
        value: "SC"
    }, {
        name: "South Dakota",
        value: "SD"
    }, {
        name: "Tennessee",
        value: "TN"
    }, {
        name: "Texas",
        value: "TX"
    }, {
        name: "Utah",
        value: "UT"
    }, {
        name: "Vermont",
        value: "VT"
    }, {
        name: "Virginia",
        value: "VA"
    }, {
        name: "Virgin Islands",
        value: "VI"
    }, {
        name: "Washington",
        value: "WA"
    }, {
        name: "West Virginia",
        value: "WV"
    }, {
        name: "Wisconsin",
        value: "WI"
    }, {
        name: "Wyoming",
        value: "WY"
    }],

    DESC: "Please select the state where most of your One Talk lines will be activated.",

    SUCCESS_MSG: "Thank you!",

    FAILURE_MSG: "Failure",

    NOT_AUTHORIZED_MSG: "Not Authorized",

    SUCCESS_MSG_DETAIL: "You will receive an email when the enrollment is complete.",

    NOT_AUTHORIZED_MSG_DETAIL: "You are not authorized to perform this transaction. Please contact your account administrator.",

    MSG_FOR_ERROR_PROVISIONAL_STATUS: "There has been a problem with your company’s enrollment into One Talk.  Please have your company’s primary contact reach out to us at 888-555-1212 for assistance.",

    MSG_CONGRATS_FOR_SPOC: "Your account is being enrolled in One Talk. You will receive an email when the enrollment is complete.  If you would like to learn more about One Talk, click on the link below.",

    MSG_CONGRATS_FOR_ADMIN: "Your account is being enrolled in One Talk. If you would like to learn more about One Talk, click on the link below.",

    MSG_CONTACT_FOR_SPOC: "You are not authorized to perform this transaction. Please contact the primary account administrator to either elevate your privilege access or perform the transaction logging with the proper access credentials.",

    MSG_CONTACT_FOR_SPOC_EXT: "In the meantime, if you would like to learn more about One Talk, click on learn more.",

    MSG_CONTACT_FOR_OTHER_ROLES: "Even though your account is being enrolled in One Talk, you are not authorized to perform this transaction.  Please contact the primary account administrator or perform the transaction logging in with the proper access credentials. If you would like to learn more about One Talk, click on the link below.",

    MSG_FOR_UNAUTHORIZED_USERS: "You are not authorized to perform this transaction. Please contact the primary account administrator to either elevate your privilege access or perform the transaction logging with the proper access credentials.",

    MSG_FOR_UNAUTHORIZED_USERS_EXT: "In the meantime, if you would like to learn more about One Talk, click on learn more.",

    MSG_FOR_UNAUTHORIZED_ROLES: "You are not authorized to perform this transaction. Please contact the primary account administrator to either elevate your privilege access or perform the transaction logging with the proper access credentials.",

    MSG_FOR_UNAUTHORIZED_ROLES_EXT: "In the meantime, if you would like to learn more about One Talk, click on learn more.",

    LINK_LEARN_MORE: "https://www.verizonwireless.com/biz/solutions-and-services/one-talk/",

    VIEW_REQUEST_FILTER: [{
        name: "All",
        value: ""
    }, {
        name: "Submitted",
        value: "submitted"
    }, {
        name: "Failed",
        value: "failed"
    }, {
        name: "Enrolled",
        value: "enrolled"
    }]

});

app.constant('callingPlanFilterConst', {
    callingplan_list: [{
        name: "Allow",
        value: "Allow"
    }, {
        name: "Allow with authorization code",
        value: "Allow with authorization code"
    }]

});

app.constant('HuntGroupConst', {

    TIME_ZONE: [{
        name: "Select",
        value: "Select"
    }, {
        name: "Pacific/Honolulu",
        value: "Pacific/Honolulu"
    }, {
        name: "America/Anchorage",
        value: "America/Anchorage"
    }, {
        name: "America/Los_Angeles",
        value: "America/Los_Angeles"
    }, {
        name: "America/Phoenix",
        value: "America/Phoenix"
    }, {
        name: "America/Denver",
        value: "America/Denver"
    }, {
        name: "America/Chicago",
        value: "America/Chicago"
    }, {
        name: "America/New_York",
        value: "America/New_York"
    }],

    SELECT_RINGS: [{
        name: "After 1 Ring",
        value: "1"
    }, {
        name: "After 2 Rings",
        value: "2"
    }, {
        name: "After 3 Rings",
        value: "3"
    }, {
        name: "After 4 Rings",
        value: "4"
    }, {
        name: "After 5 Rings",
        value: "5"
    }, {
        name: "After 6 Rings",
        value: "6"
    }, {
        name: "After 7 Rings",
        value: "7"
    }, {
        name: "After 8 Rings",
        value: "8"
    }, {
        name: "After 9 Rings",
        value: "9"
    }, {
        name: "After 10 Rings",
        value: "10"
    }],
    ENTER_MINUTES: [{
        name: "1 Minute",
        value: 60
    }, {
        name: "2 Minutes",
        value: 120
    }, {
        name: "3 Minutes",
        value: 180
    }, {
        name: "4 Minutes",
        value: 240
    }, {
        name: "5 Minutes",
        value: 300
    }]

});
app.constant('scheduleConst', {
    managepageTitle: "Manage Schedules",
    pageDesc: "There are two types of schedules that can be used: business schedules to accommodate hours of operation based on days of the week and holiday schedules for specific calendar holidays. Once schedules are defined they can be applied to features and determine when the feature is active. If Business and Holiday schedules overlap, the Holiday schedule will be used.",
    tooltipinfo: "These features can use schedules: Automated Receptionist, Group Forwarding, Simultaneous Ring, Selective Call Rejection, Selective Call Acceptance and Selective Call Forwarding.",
    scheduleTypePageTitle: "Create New Schedule - Select Schedule Type",
    businessPageTitle: "Create Business Schedule",
    reviewBusinessPageTitle: "Update Business Schedule",
    reviewHolidayPageTitle: "Update Holiday Schedule",
    holidayPageTitle: "Create Holiday Schedule",
    manageInstructions: {
        instructions: [{
            text: "Select Create New Schedule."
        }]
    },
    scheduleNameInstructions: {
        instructions: [{
            text: "Choose the schedule type you want to create (Business or Holiday).",
        }, {
            text: "Give your schedule a name (so you can identify it easily)"
        }, {
            text: "Click on Choose schedule to proceed"
        }]
    },
    createNewBusinessInstructions: {
        instructions: [{
            text: "Select from 24x7, 9-5 or Custom",
        }, {
            text: "If custom is selected define the hours of operation for it.  You can have up to 2 time slots per day.",
        }, {
            text: "Submit to save the set-up of your Business schedule.",
        }]
    },
    createNewHolidayInstructions: {
        instructions: [{
            text: "Define the dates and determine if you want the date to recur each year.",
        }, {
            text: "Define the hours of operation during Holidays if your business is open part of a holiday date.",
        }, {
            text: "Submit to save the set-up of your Holiday schedule",
        }]
    }
});

app.constant('autoAttendantConst', {
    managePageTitle: "Manage Automated Receptionist",
    pageDesc: "Incoming callers are presented with a greeting and a set of options to choose from (press 1 for sales for example) and routed to the selection made.  Different options can be made available depending on the Schedule (Business Hours, After Hours, Holiday)",
    detailPageTitle: "Automated Receptionist",
    reviewPageTitle: "Automated Receptionist",
    patternsPageTitle: "Automated Receptionist",
    instructionsManage: [{
        text: "Select the Automated Receptionist number you want to set up or change or get a new number."
    }],
    instructionsDetails: [{
        text: "Enter the Name, the Calling ID Name and the Time Zone of the Automated Receptionist."
    }],
    instructionsBusinessHoliday: [{
        text: "Choose the schedule."
    }, {
        text: "Determine if you want to use the standard greeting or create a custom greeting."
    }, {
        text: "If you use a standard greeting, the menu options can't be changed."
    }, {
        text: "If you want to use a custom greeting, upload it."
    }, {
        text: "For custom greetings, configure the menu keys for your business needs."
    }],
    instructions: [{
        text: "Start with setting up your greeting and menu options for your business hours",
        instructions: [{
            text: "Select the greeting your callers will hear: Default or upload a {0}.",
            links: [{
                text: 'custom audio file',
                href: '',
                ngClick:'setCustomFile()'
            }]
        }, {
            text: "Define where your callers are directed when selecting  a number on their phone (Press 1 for Customer Service for example)"
        }]
    }, {
        text: "Now set up your greeting and menu options for your after hours/holidays.",
        instructions: [{
            text: "Select the greeting your callers will hear:  Default or upload a {0}",
            links: [{
                text: 'custom audio file',
                href: '',
                ngClick:'setCustomFile()'
            }]
        }, {
            text: "Decide if you want to use the same menu options as business hours or set up new menu options for after hours"
        }, {
            text: "Decide if you want to also use this greeting and menu options for any Holiday schedules.  Holidays are optional."
        }]
    }, {
        text: "Submit to save your set-up."
    }]
});

app.constant('huntGroupConst', {
    pageTitle: "Hunt Group",
    pageDesc: "Incoming calls to the hunt group line will ring a group of numbers.  There are four calling sequences to choose from to best fit your business needs.",
    algorithmpageTitle: "Select Hunt Group Type (Sequence)",
    reviewpageTitle: "Hunt Group",
    managepageTitle: "Manage Hunt Group",
    detailsPageTitle: "Hunt Group",
    instructionsManage: [{
        text: "Select the Hunt Group number you want to set up or change or get a new number."
    }],
    instructionsDetails: [{
        text: "Enter the Name, the Calling ID Name and the Time Zone of the Hunt Group."
    }],
    instructionsSelectType: [{
        text: "Choose the calling sequence. Clicking each one will give more details about how it works."
    }, {
        text: "Place the numbers into the Hunt Group."
    }, {
        text: "Select the number of rings before the call goes to the next line in the sequence."
    }, {
        text: "Uncheck the box if you want call waiting on busy lines before going to the next line in the sequence."
    }, {
        text: "Set a maximum amount of time your customers will stay in hunt if desired and enter the number you want to forward calls to after this amount of time."
    }],
    instructions: [{
        text: "Activate, purchase or port the Hunt Group number."
    }, {
        text: "Define Name, Calling ID and Time Zone."
    }, {
        text: "Select Ring Sequence Type."
    }, {
        text: "Assign lines to the Ring Sequence selected and action for busy/non-busy status."
    }, {
        text: "Determine if you want incoming calls to forward after a pre-set amount of minutes of hunting.",
        instructions: [{
            text: "If you want a timer, select the time out option and enter the number of minutes a caller should stay in hunt before being forwarded."
        }, {
            text: "Enter the forward to number that calls will be sent to after the timer expires"
        }]
    }, {
        text: "Submit to save your set-up and activate the Hunt Group."
    }]
});

app.constant('callingLineConst', {
    pageTitle: "Calling Line ID Delivery",
    pageTitle_Desc: "Use one number for all lines in your group for caller ID, or use each individual number.",
    instructions: [{
        text: "Choose to send individual numbers or a group number to the called party.",
    }, {
        text: "If you chose group, define the number to send and the associated name.",
    }, {
        text: "If desired check the box to send name as well as line."
    }]
});

app.constant('customRingbackConst', {
    pageTitle: "Custom Ringback",
    pageTitle_Desc: "This allows you to play a custom audio file instead of standard ringing when any number in your group is called.",
    instructionsUpload: [{
        text: "Upload your custom audio file {0} to replace standard ringing.",
        links: [{
            text: 'custom audio file',
            href: '',
            ngClick:'setCustomFile()'
        }]
    }],
    instructions: [{
        text: "Decide if you want to use the system default or {0}.",
        links: [{
            text: 'custom audio file',
            href: '',
            ngClick:'setCustomFile()'
        }]
    }, {
        text: "Upload the custom audio file if desired."
    }, {
        text: "Submit to save your set-up and turn the feature on."
    }]
});

app.constant('musicOnHoldConst', {
    pageTitle: "Music On Hold",
    pageTitle_Desc: "A caller placed on hold will hear the selected audio file  for the business.Once the feature is enabled at the business level, it can be turned on/off at the User level.",
    instructions: [{
        text: "Decide if you want to use the system default or custom audio file"
    }, {
        text: "Upload the custom audio file if desired"
    }, {
        text: "Submit to turn the feature on"
    }, {
        text: "If you don't want Music On Hold enabled for everyone, go to the Individual {0} and Turn off the feature by line as needed",
        links: [{
            text: 'Music on Hold feature',
            href: 'features.user.music_on_hold_user'
        }]
    }]
});

app.constant('linkInstructions',{
   recordInstructions:[{
    text: "Go to <b> Start | All Programs | Accessories | Entertainment | Sound Recorder.</b> The Sound Recorder appears."
   },
   {
    text: "Click Record."
   },
   {
    text: "Say your name to record it."
   },
   {
    text: "Click Stop."
   },
   {
    text: "Click File | Save As and save you recorded name as a .wav file."
   },
   {
    text: "Select File | Open to re-open the saved file."
   },
   {
    text: "Select File | Save As again to change the format."
   },
   {
    text: "Click the Change button at the bottom of the Sound Recorder."
   },
   {
    text: "Select CCITT u-law from the Format drop-down list."
   },
   {
    text: "Select 8,000 kHz 8-bit mono from the Attributes drop-down list."
   },
   {
    text: "Click OK."
   },
   {
    text: "Click Save. The file is now in the correct format and ready to be uploaded."
   }]
})
app.constant('groupForwardingConst', {
    pageTitle: "Group Forwarding",
    pageTitle_Desc: "Forwards all calls for lines in the group to another number all the time, or based on a schedule.",
    instructions: [{
        text: "Turn the feature On or Off as desired (you can still configure with the feature Off)."
    }, {
        text: "Enter the number you want to forward the calls to."
    }, {
        text: "Choose to forward calls based on a schedule or all the time (you can still shut it off if Always is selected)."
    }, {
        text: "Select the lines you want forwarded.",
    }]
});

app.constant('codeConst', {
    pageTitle: "Code",
    pageTitle_Desc: "Lorem Ipsum is simply dummy text of the printing and typesetting industry.",
    createpageTitle: "Create Code",
    createpageTitle_Desc: "Lorem Ipsum is simply dummy text of the printing and typesetting industry."
});

app.constant('callingPlanConst', {
    pageTitle: "Calling Plan",
    pageTitle_Desc: "Calling Plans determine whether authorization codes are required to make International calls.",
    settingsPageTitle: "Calling Plan",
    instructions: [{
        text: "Use the settings icon to configure individual lines."
    }, {
        text: "Decide if you want to require Authorization codes for International calls."
    }, {
        text: "Create the 6 digit code for the user. More than one can be created."
    }, {
        text: "Provide the code to the individual to use while placing international calls."
    }]
});
app.constant('accountCodeConst', {
    manageAccountPageTitle: "Manage Account Code",
    pageDesc: "Mandatory or Optional Account Codes can be used to track outbound calls. Account Codes are 6 digits in length and will appear on call detail records for tracking purposes.",
    createAccountPageTitle: "Create Account Codes",
    manageAssignPageTitle: "Manage/Assign Users",
    instructions: [{
        text: "Create 6 digit Account Codes for tracking outbound calls."
    }, {
        text: "Enter a description for each Account Code to serve as a reminder of that code's purpose. For example, 'Sales'."
    }
    ],
    assignInstructions: [{
        text: "Assign individuals to mandatory or optional account codes."
    }, {
        text: "Anyone assigned to mandatory account codes must enter a code before placing outbound calls."
    }, {
        text: "Anyone assigned to optional account codes can enter a code before dialing out, but doesn't have to."
    }
    ]
});
app.constant('remoteGroupPickupConst', {
    manageRemotePageTitle: "Manage Remote Group Pickup",
    pageDesc: "Use this to create groups of numbers that can answer each others' ringing calls by using an access code.  If more than one line in the group is ringing, the line that has been ringing the longest will be picked up first.",
    createNewGroupPageTitle: "Create New Group",
    instructions: [{
        text: "Select an existing group or create a new one."
    }, {
        text: "Assign the lines to the group."
    }]
});
app.constant('callWaitingUserConst', {
    pageTitle: "Call Waiting",
    pageDesc: "If you are already on a call and another call comes in, you will hear a tone and can answer the second call when Call Waiting is on.",
    instructions: [{
        text: "Select the line you want to Turn on/off."
    }, {
        text: "Turn on/off."
    }]
});
app.constant('remoteCallPickupBargeInConst', {
    pageTitle: "Remote Call Pickup with Barge In",
    pageDesc: "Allows other members of your business to remotely pick up your line while it is ringing or join your call in progress with or without a warning tone.",
    settingsPageTitle: "Barge in Settings",
    instructions: [{
        text: "Use the settings icon to configure individual lines."
    }]
});
app.constant('annonymousCallRejectionConst', {
    pageTitle: "Anonymous Call Rejection",
    pageDesc: "If no Caller ID number is present in the incoming call, the call will be blocked",
    instructions: [{
        text: "Select the line or lines you want to affect."
    }, {
        text: "Turn the feature ON or OFF."
    }]
});
app.constant('musiconHoldUserConst', {
    pageTitle: "Music On Hold",
    pageDesc: "A caller placed on hold will hear the selected audio file  for the business.Once the feature is enabled at the business level, it can be turned on/off at the User level."

});
app.constant('simultaneousRingConst', {
    pageTitle: "Simultaneous Ring Service",
    pageDesc: "You can specify up to 10 different phone numbers that will ring when the line is called.",
    settingsPageTitle: "Settings",
    instructions: [{
        text: 'Use the settings icon to configure individual lines.'
    }]
});
app.constant('preAlertingAnnouncementConst', {
    pageTitle: "Pre Alerting Announcement",
    pageDesc: "You can upload a custom audio file that will be played to your callers while they wait to connect.  This can be done at all times, or you can use a Schedule.",
    settingsPageTitle: "Pre-alert Settings",
    instructions: [{
        text: 'Use the settings icon to configure individual lines.'
    }, {
        text: 'Upload a {0}.',
        links: [{
            text: 'custom audio file',
            href: '',
            ngClick:'setCustomFile()'
        }]
    }, {
        text: 'Determine if you want to play the custom file all the time or based on a Schedule.'
    }]


});
app.constant('automaticCallbackConst', {
    pageTitle: "Automatic Callback",
    pageDesc: "When you dial a number and the line is busy, the call will be retried until the line is no longer busy.",
    instructions: [{
        text: 'Select the number you want to configure.'
    }, {
        text: 'Turn the feature ON or OFF.',
    }]
});
app.constant('bargeinExemptConst', {
    pageTitle: "Barge In Exempt ",
    pageDesc: "When Barge In Exempt is active, other users in your group can't join a call in progress. Other users can still answer your line when it is ringing.",
    instructions: [{
        text: 'Select the number you want to configure.'
    }, {
        text: 'Turn the feature ON or OFF.',
    }]
});
app.constant('callerIdConst', {
    pageTitle: "Caller ID Blocking",
    pageDesc: "Prevents your number from being sent to others on outbound calls.  When this feature is on the people you call won't be able to see your number if they have caller ID.",
    instructions: [{
        text: 'Select the number you want to configure.'
    }, {
        text: 'Turn the feature ON or OFF.',
    }]
});
app.constant('selectiveCallRejectionConst', {
    pageTitle: "Selective Call Acceptance / Rejection",
    pageDesc: "You can decide to reject all calls, or only calls from up to 10 specific numbers per criteria.  You can decide to always reject these calls or only reject calls based on a Schedule.  Up to 5 different rejection criteria can be defined.  If you have both Acceptance and Rejection activated, Acceptance will be used first.",
    pageAcceptanceTitle: "Selective Call Acceptance / Rejection",
    pageAcceptanceDesc: "You can accept all calls or only calls from up to 10 specific phone numbers based on a pre-defined schedule (Business or Holiday).  Up to 5 conditions/options can be configured.   If you have both Selective Call Acceptance and Rejection activated, the settings for Acceptance will be used first.",
    instructions: [{
        text: 'Use the settings icon to configure individual lines.'
    }, {
        text: 'Define whether you want to reject calls from any number or only from specfic numbers (up to 10).',
    }, {
        text: 'Determine if you want to always reject calls or use a Schedule.',
    }, {
        text: 'You can enter up to 5 different criteria for call rejection.',
    }]
});
app.constant('setUpUserConst', {
    pageTitle: "Setup User Info",
    pageDesc: "Use this page to verify and update the contact information of users and specify the extension and Caller ID Name that will be used for One Talk subscribers."
});
app.constant('selectiveCallAcceptanceConst', {
    pageTitle: "Selective Call Acceptance / Rejection",
    pageDesc: "You can accept all calls or only calls from up to 10 specific phone numbers based on a pre-defined schedule (Business or Holiday).  Up to 5 conditions/options can be configured.   If you have both Selective Call Acceptance and Rejection activated, the settings for Acceptance will be used first.",
    instructions: [{
        text: 'Use the settings icon to configure individual lines.'
    }, {
        text: 'Define whether you want to accept calls from any number or only from specific numbers (up to 10).',
    }, {
        text: 'Determine if you want to always use the acceptance criteria or use a Schedule.',
    }, {
        text: 'You can enter up to 5 different criteria for call acceptance.',
    }]
});
app.constant('callForwardingConst', {
    pageTitle: "Call Forwarding",
    pageDesc: "There are 5 different call forwarding capabilities that can be used to make sure you never miss a call.",
    groupForwardInstructions: {
        instructions: [{
            text: "Use the {0} setting to activate the service.",
            links: [{
                text: 'Group level feature',
                href: '',
                ngClick:'groupLevelFeature()'
            }]
        }, {
            text: "If you want to turn off Group forwarding for an individual line, use the toggle."
        }]
    },
    selectiveForwardInstructions: {
        instructions: [{
            text: "Select the line you want to forward using the toggle."
        }, {
            text: "Enter up to 5 different criteria to forward calls."
        }]
    },
    alwaysInstructions: {
        instructions: [{
            text: "Select the line you want to forward using the toggle."
        }, {
            text: "Forward to voicemail or enter the forward to number."
        }]
    },
    busyInstructions: {
        instructions: [{
            text: "Select the line you want to forward using the toggle."
        }, {
            text: "Forward to voicemail or enter the forward to number."
        }]
    },
    noAnswerInstructions: {
        instructions: [{
            text: 'Use the settings icon to configure individual lines.'
        }, {
            text: 'Forward to voicemail or enter the forward to number.'
        }]
    }
});
app.constant('musicOnHoldUserConst', {
    pageTitle: "Music On Hold",
    pageDesc: "Allows you to send all incoming calls to another phone number; calls will be forwarded as long as the line is active"
});
app.constant('dropdownValueConst', {
    MOBILECLIENT: [{
        pageTitle: "Block Mobile Client",
        pageSuccessTxt: "Your confirmation number is",
        pageAlertTxt: "Are you sure you want to block all existing mobile clients from the line and block future downloads of the mobile client?",
        pageConfirmationTxt: "All existing mobile clients will be removed from the line, and no new ones can be added until block is lifted.",
        pageBulkConfirmationTxt: "All existing mobile clients will be removed from the line(s), and no new ones can be added until block is lifted.",
        thankuTxt: "Thank You. You have successfully blocked the mobile clients."
    }],
    UNBLOCKMOBILE: [{
        pageTitle: "UnBlock Mobile Client",
        pageSuccessTxt: "Your confirmation number is",
        pageConfirmationTxt: "Are you sure you want to unblock mobile clients for ",
        pageBulkConfirmationTxt: "All existing mobile clients will be disconnected and you will not be able to add any new mobile clients for this line.",
        thankuTxt: "Thank you. You have successfully submitted the request to unblock the mobile clients."
    }],
    REMOVEALLOTT: [{
        pageTitle: "Remove All Mobile Clients",
        pageSuccessTxt: "Your confirmation number is",
        pageAlertTxt: "Are you sure you want to remove all mobile clients from the line ?",
        pageConfirmationTxt: "All existing mobile clients will be removed from the line .",
        thankuTxt: "Thank You. You have successfully removed all mobile clients."
    }],
    REBOOT: [{
        pageTitle: "Reboot",
        pageAlertTxt: "Are you sure you want to reboot your device?",
        pageSuccessTxt: "Your transaction ID is",
        pageConfirmationTxt: "You will not be able to make or receive calls while the device reboots.",
        thankuTxt: "Thank You"
    }],
    DISABLE: [{
        pageTitle: "Disable",
        pageAlertTxt: "Are you sure you want to disable this device?",
        pageSuccessTxt: "The transaction ID is",
        pageConfirmationTxt: "Disabled devices can no longer make or receive calls",
        thankuTxt: "Thank You"
    }],
    ENABLE: [{
        pageTitle: "Enable",
        pageAlertTxt: "Are you sure you want to enable this device? ",
        pageSuccessTxt: "The transaction ID is",
        pageConfirmationTxt: "Enabled devices can no longer make or receive calls "
    }],
    REMOVE: [{
        pageTitle: "Remove",
        pageAlertTxt: "Are you sure you want to remove this device from your line?",
        pageSuccessTxt: "Your confirmation number is",
        pageConfirmationTxt: "Once a device is removed, it will no longer be able to make or receive calls.",
        thankuTxt: "Thank you. You have successfully submitted the request to remove your device."
    }],
    UNBRIDGELINE: [{
        pageTitle: "Confirm",
        pageConfirmationTxt: "Are you sure you want to unbridge this phone number from this device?",
        pageConfirmationTxt1: "Once you unbridge, the phone number will no longer ring on the selected device.",
        pageSuccessTxt: "Thank you.  You have successfully submitted the request to unbridge the line to your device.",
        pageSuccessTxt2: "The transaction ID is"
    }],
    BRIDGE: [{
        pageTitle: "Remove",
        pageAlertTxt1: "More then 12 bridged Lines are not allowed.",
        pageAlertTxt2: "Enter line number to bridge.",
        pageSuccessTxt: "Thank you. {0} has successfully submitted the request to bridge the line to your device.",
        pageSuccessTxt1: " The transaction ID is",
        pageConfirmationTxt: "Are you sure you want to remove your device from"
    }]
});

app.constant('LineDetailsBrideLineMessage', {
    UNBRIDGELINE: [{
        pageTitle: "Confirm",
        pageConfirmationTxt: "Are you sure you want to unbridge this phone number from this device?",
        pageConfirmationTxt1: "Once you unbridge, the phone number will no longer ring on the selected device.",
        pageSuccessTxt: "Thank you. You have successfully submitted the request to unbridge the line from this device.",
        pageSuccessTxt2: "The transaction ID is"
    }],
    BRIDGE: [{
        pageTitle: "Remove",
        pageAlertTxt1: "More then 12 bridged Lines are not allowed.",
        pageAlertTxt2: "Enter line number to bridge.",
        pageSuccessTxt: "Thank you. You have successfully submitted the request to unbridge the line from this device.",
        pageSuccessTxt1: " The transaction ID is",
        pageConfirmationTxt: "Are you sure you want to remove your device from"
    }]
});



app.constant('ScheduleConst', {

    MANAGE_FILTER: [{
        name: "All",
        value: undefined
    }, {
        name: "Business",
        value: "BUSINESS"
    }, {
        name: "Holiday",
        value: "Holiday"
    }]

});
app.constant('ScheduleCalendarConst', {

    time_list: [{
        name: "12:00 AM",
        value: "12:00 AM"
    }, {
        name: "1:00 AM",
        value: "1:00 AM"
    }, {
        name: "2:00 AM",
        value: "2:00 AM"
    }, {
        name: "3:00 AM",
        value: "3:00 AM"
    }, {
        name: "4:00 AM",
        value: "4:00 AM"
    }, {
        name: "5:00 AM",
        value: "5:00 AM"
    }, {
        name: "6:00 AM",
        value: "6:00 AM"
    }, {
        name: "7:00 AM",
        value: "7:00 AM"
    }, {
        name: "8:00 AM",
        value: "8:00 AM"
    }, {
        name: "9:00 AM",
        value: "9:00 AM"
    }, {
        name: "10:00 AM",
        value: "10:00 AM"
    }, {
        name: "11:00 AM",
        value: "11:00 AM"
    }]

});
app.constant('UserConfig', {
    TITLE: "Simple Talk",
    CALL_WAITING_TITLE: "Call Waiting",
    CALL_WAITING_DESC: "Alerts you and allows you to take a second call while you are on the phone with someone.",

    REMOTE_CALL_PICKUP_BARGE_IN_TITLE: "Remote Call Pickup with Barge In",
    REMOTE_CALL_PICKUP_BARGE_IN_DESC: "Allows other members of your business to remotely pick up your line" +
        " while it is ringing or join your call in progress with or without a warning tone.",

    ANNONYMOUS_CALL_REJECTION_TITLE: "Anonymous Call Rejection",
    ANNONYMOUS_CALL_REJECTION_DESC: "Your business will not receive calls unless there is a Caller ID number" +
        " from the caller.",

    CALL_FORWARDING_TITLE: "Call Forwarding",
    CALL_FORWARDING_DESC: "Keep your business in touch with callers by automatically forwarding incoming calls" +
        " to the best available resource. There are various options available to best fit your business needs.",
    CALLING_PLAN_TITLE: "Calling Plan",
    CALLING_PLAN_DESC: "You can require authorization codes for dialing outside of the One Talk business group;" +
        " that could include calls to Local/Long Distance and/or International numbers.",

    SIMULTANEOUS_RING_SERVICE_TITLE: "Simultaneous Ring Service",
    SIMULTANEOUS_RING_SERVICE_DESC: "Have more than one phone number ring when someone calls your number.",

    PRE_ALERTING_ANNOUNCEMENT_TITLE: "Pre-Alerting Announcement",
    PRE_ALERTING_ANNOUNCEMENT_DESC: "Play an audio file of your choice while the caller waits to be connected when your number is called.",

    AUTOMATIC_CALLBACK_TITLE: "Automatic Callback",
    AUTOMATIC_CALLBACK_DESC: "Automatically redial a busy number until it is available.",

    BARGE_IN_EXEMPT_TITLE: "Barge In Exempt ",
    BARGE_IN_EXEMPT_DESC: "Prevents others from joining your calls in progress when you have the Remote Call Pickup feature enabled.",

    CALLER_ID_BLOCK_TITLE: "Caller ID Blocking",
    CALLER_ID_BLOCK_DESC: "Prevents your number from being sent on out going caller ID.",

    SELECTIVE_CALL_REJECTION_TITLE: "Selective Call  Acceptance / Rejection",
    SELECTIVE_CALL_REJECTION_DESC: "Only accept specific calls based on conditions you define or reject incoming calls based on pre-defined conditions you set.",
    MUSIC_ON_HOLD_TITLE: "Music On Hold",
    MUSIC_ON_HOLD_DESC: "Play custom or default music when a caller is placed on Hold.",
    SELECTIVE_CALL_ACCEPTANCE_TITLE: "Selective Call Acceptance",
    SELECTIVE_CALL_ACCEPTANCE_DESC: "Only accept specific calls based on conditions you define",

});
app.constant('userFeatureListForRadiotoggle', {
    userFeatureListInfo: {
        "1000": {
            "featureName": "annonymous_call_rejection",
            "tooltipTemplate": "Prevents incoming calls that don't have a caller ID number",
            "isSettings": false
        },
        "1002": {
            "featureName": "automatic_callback",
            "tooltipTemplate": "Automatically redial a busy number until it is available",
            "isSettings": false
        },
        "1003": {
            "featureName": "barge_in_exempt",
            "tooltipTemplate": "Prevents others from joining your calls in progress using the Remote Call Pickup feature",
            "isSettings": false
        },
        "1005": {
            "featureName": "call_forwarding_always",
            "tooltipTemplate": "Forwards all calls to your number to another destination",
            "isSettings": true,
            "option": "ALWAYS_POST"
        },
        "1006": {
            "featureName": "call_forwarding_busy",
            "tooltipTemplate": "Forwards calls to another destination when your line is busy",
            "isSettings": true,
            "option": "BUSY_POST"
        },
        "1008": {
            "featureName": "call_forwarding_noAnswer",
            "tooltipTemplate": "Forwards calls to another destination when you don't answer your line after 5 or more rings",
            "isSettings": true,
            "option": "NOANSWER_POST"
        },
        "1009": {
            "featureName": "call_forwarding_selective",
            "tooltipTemplate": "Forwards select calls based on predefined criteria including specific numbers that might call you and schedules for the service to be active",
            "isSettings": true,
            "option": "SELECTIVE_POST"
        },
        "1017": {
            "featureName": "caller_id_block",
            "tooltipTemplate": "Prevents your number from being sent on out going caller ID",
            "isSettings": false
        },
        "1010": {
            "featureName": "call_waiting",
            "tooltipTemplate": "Alerts you and allows you to take a second call while you are on the phone with someone",
            "isSettings": false
        },
        "1012": {
            "featureName": "music_on_hold_user",
            "tooltipTemplate": "Plays the music defined by your company when calls are placed on hold",
            "isSettings": false
        },
        "1013": {
            "featureName": "pre_alert_announcement",
            "tooltipTemplate": "Play an audio file of your choice for your callers while they wait to be connected",
            "isSettings": true,
            "option": "PRE_ALERT_ANNOUNCEMENT"
        },
        "1011": {
            "featureName": "directed_call_pickup",
            "tooltipTemplate": "Prevents others from joining your calls in progress using the Remote Call Pickup feature",
            "isSettings": true,
            "option": "DIRECTED_CALL_PICKUP"
        },
        "1014": {
            "featureName": "selective_call_acceptance",
            "tooltipTemplate": "Only accept incoming calls based on specific conditions you define",
            "isSettings": true,
            "option": "SELECTIVE_CALL_ACCEPTANCE"
        },
        "1015": {
            "featureName": "selective_call_rejection",
            "tooltipTemplate": "Block incoming calls based on pre-defined conditions you set",
            "isSettings": true,
            "option": "SELECTIVE_CALL_REJECTION"
        },
        "1016": {
            "featureName": "simultaneous_ring",
            "tooltipTemplate": "Have more than one phone number ring when someone calls your number",
            "isSettings": true,
            "option": "SIMULTANEOUS_RING_SERVICE"
        }
    }
});
app.constant('CallWaitingConst', {

    MANAGE_FILTER: [{
        name: "All",
        value: undefined
    }, {
        name: "Enabled",
        value: true
    }, {
        name: "Disabled",
        value: false
    }]
});
app.constant('enableDisableConst', {

    MANAGE_FILTER: [{
        name: "All",
        value: undefined
    }, {
        name: "Enabled",
        value: "enabled"
    }, {
        name: "Disabled",
        value: "disabled"
    }]
});

app.constant('SetUpUserInfoConst', {

    MANAGE_FILTER: [{
        name: "Last 30 Days",
        value: "30"

    }, {
        name: "Last 60 Days",
        value: "60"
    }, {
        name: "Last 90 Days",
        value: "90"
    }, {
        name: "Last 180 Days",
        value: "180"
    }, {
        name: "Last 1 Year",
        value: "365"
    }]
});


app.constant('linesConst', {
    LINES_FILTER: [{
        name: "All",
        value: undefined
    }, {
        name: "Active",
        value: "ACTIVE"
    }, {
        name: "Suspended",
        value: "INACTIVE"
    }, {
        name: "Corporate",
        value: "Corporate"
    }, {
        name: "Employee",
        value: "Employee"
    }],
    DEVICES_FILTER: [{
        name: "All",
        value: undefined
    }, {
        name: "Active Devices",
        value: "ENABLE"
    }, {
        name: "Disabled Devices",
        value: "INACTIVE"
    }, {
        name: "Deskphone",
        value: "DESKPHONE"
    }, {
        name: "Smartphone",
        value: "SMARTPHONE"
    }, {
        name: "Mobile Client",
        value: "OTT"
    }],
    LINES_ACTIONS: [{
        name: "Block Mobile Client",
        value: "Mobile Client"
    }, {
        name: "Unblock Mobile Client",
        value: "UnblockMobile"
    }],
    DEVICES_ACTIONS: [{
        name: "Update 911 Address (Only for Deskphone)",
        value: "Update 911 Address"
    }],
    DOWNLOAD: [{
        name: 'Download PDF',
        value: 'downloadPdf'
    }, {
        name: 'Download CSV',
        value: 'downloadCsv'
    }]
});

// app.constant('AllFeautureConst', {
//  'callingPlanConst':callingPlanConst
// });
