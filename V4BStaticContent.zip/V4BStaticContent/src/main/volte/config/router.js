function initiateRoute($stateProvider, $urlRouterProvider) {

    // Now set up the states
    $stateProvider

        .state('index', {
        url: "/",
        data: {
            displayName: 'One Talk'
        },
        views: {
            'main-content': {}
        } //End of views
    })

    .state('onboard', {
        url: "/onboard",
        data: {
            displayName: 'Onboard'
        },
        views: {
            'main-content': {
                templateUrl: "partials/authorize/onboard.html",
                controller: "authorizeCtrl"
            }
        } //End of views

    })

    .state('preauthorize', {
        url: "/pre-authorize",
        data: {
            displayName: 'Pre-Authorize'
        },
        views: {
            'main-content': {
                templateUrl: "partials/authorize/preAuthorize.html",
                controller: "preAuthorizeCtrl"
            }
        },
        abstract: true //End of views
    })

    .state('preauthorize.tabs', {
        url: "/",
        data: {
            displayName: 'Pre Authorization'
        },
        views: {
            'tab-one': {
                templateUrl: "partials/authorize/tabs/add-employee-number.html"
            },
            'tab-two': {
                templateUrl: "partials/authorize/tabs/view-request-sent.html"
            }
        } //End of views
    })


    .state('setUpUserInfo', {
        url: "/setUpUserInfo",
        data: {
            displayName: 'Setup User Info'
        },
        views: {
            'main-content': {
                templateUrl: "partials/authorize/setUpUserInfo.html",
                controller: "setUpUserInfoCtrl"
            }
        },
        //abstract: true //End of views

    })

    .state('setUpUserInfo.tabs', {
        url: "/",
        data: {
            displayName: 'Setup User Info'
        },
        views: {
            'tab-one': {
                templateUrl: "partials/authorize/tabs/update-user-info.html"
            },
            'tab-two': {
                templateUrl: "partials/authorize/tabs/upload-spreadsheet.html"
            }
        } //End of views
    })

    .state('overview', {
        url: "/overview",
        views: {
            'main-content': {
                templateUrl: "partials/dashboard/dashboard.html",
                controller: "DashboardCtrl"
            }
        }, //End of views
        data: {
            displayName: 'Overview'
        }
    })

    .state('resources', {
        url: "/resources",
        views: {
            'main-content': {
                templateUrl: "partials/resources/resources.html",
                controller: "ResourcesCtrl"
            }
        }, //End of views
        data: {
            displayName: 'Resources'
        }
    })

    .state('line.detail', {
        url: "/detail",
        views: {
            '': {
                templateUrl: "partials/lines/devices.html"
            }
        } //End of views

    })

    .state('devices', {
        url: "/devices",
        views: {
            'main-content': {
                templateUrl: "partials/devices.html"
            },
            'secondary-nav': {
                templateUrl: "partials/devices-nav.html"
            }
        } //End of views
    })

    .state('line-devices', {
            url: "/line-devices",
            data: {
                displayName: 'Lines & Devices'
            },
            views: {
                'main-content': {
                    templateUrl: "partials/lines-devices/list.html",
                    controller: "LinesDevicesCtrl"
                },
                'secondary-nav': {
                    templateUrl: "partials/lines-devices/linesNav.html"
                }
            } //End of views

        })
        // .state('lines-devices', {
        //     url: "/lines-devices",
        //      data: {
        //           displayName: 'Lines & Devices'
        //     },
        //     views: {
        //         'main-content': {
        //           templateUrl: "partials/lines-devices/list.html",
        //           controller: "LinesDevicesCtrl"
        //         },
        //         'secondary-nav': {
        //           templateUrl: "partials/lines-devices/linesNav.html"
        //         }
        //     } //End of views
        // })
        .state('lines', {
            url: "/lines",
            data: {
                displayName: 'Lines'
            },
            views: {
                'main-content': {
                    templateUrl: "partials/lines/linesTab.html",
                }

            } //End of views

        })
        .state('device', {
            url: "/device",
            data: {
                displayName: 'Device'
            },
            views: {
                'main-content': {
                    templateUrl: "partials/lines/deviceTab.html"
                }

            } //End of views

        })
        .state('line-devices-details', {
            url: "/line-devices/details",
            data: {
                displayName: 'Lines & Devices'
            },
            views: {
                'main-content': {
                    templateUrl: "partials/lines/details.html",
                    controller: "lineDetailCtrl"
                },
                'secondary-nav': {
                    templateUrl: "partials/lines/detailsNav.html",
                    controller: "lineDetailBarCtrl"
                }

            } //End of views

        })

    .state('line-devices-details.devices', {
        url: "/device/:deviceID/:deviceType/:lineNumber/:lineType",
        data: {
            displayName: 'Details'
        },
        views: {
            'device-info': {
                templateUrl: "partials/lines/device-details.html",
                controller: "deviceDetailsCtrl"
            }
        } //End of views
    })

    .state('config', {
        url: "/config",
        data: {
            displayName: 'Config'
        },
        views: {
            'main-content': {
                templateUrl: "partials/features/config.html",
                controller: "featureConfigCtrl"
            }
        }
    })

    .state('features', {
        url: "/features",
        data: {
            displayName: 'Features'
        },
        views: {
            'main-content': {
                templateUrl: "partials/features/features.html",
                controller: "FeaturesCtrl"
            }
        }
    })

    .state('features.enterprise', {
            url: "/enterprise",
            views: {
                '': {
                    templateUrl: "partials/features/enterprise.html"
                }
            }, //End of views
            abstract: true
        })
        .state('features.user', {
            url: "/user",
            views: {
                '': {
                    templateUrl: "partials/features/enterprise.html"
                }
            }, //End of views
            abstract: true
        })

    .state('features.enterprise.code', {
        url: "/code",
        data: {
            displayName: 'Code'
        },
        views: {
            '': {
                templateUrl: "partials/features/code.html",
                controller: "codeCtrl"
            }

        } //End of views

    })

    .state('features.enterprise.createCode', {
        url: "/create-code",
        views: {
            '': {
                templateUrl: "partials/features/create-code.html",
                controller: "codeCtrl"
            }
        } //End of views

    })

    .state('features.enterprise.createCode.tabs', {
        url: "/",
        data: {
            displayName: 'Create Code'
        },
        views: {
            'tab-one': {
                templateUrl: "partials/features/code-search.html"
            },
            'tab-two': {
                templateUrl: "partials/features/code-viewall.html"
            }
        } //End of views
    })

    .state('features.enterprise.remote_group_pick_up', {
            url: "/remote-group-pick-up",
            data: {
                displayName: 'Remote Group Pick Up'
            },
            views: {
                '': {
                    templateUrl: "partials/features/enterpriseFeatures/manageRemoteGroupPickup/manage-remote-group-pickup.html",
                    controller: "manageRemoteGroupPickupCtrl"
                }

            } //End of views

        })
        .state('features.enterprise.remote_group_pick_up.create-new-group', {
            url: "/create-new-group/:name",
            data: {
                displayName: 'Create New Group'
            },
            views: {
                '': {
                    templateUrl: "partials/features/enterpriseFeatures/manageRemoteGroupPickup/create-new-group.html",
                    controller: "createGroupPickupCtrl"
                }

            } //End of views

        })
        .state('features.enterprise.account_code', {
            url: "/account-code",
            data: {
                displayName: 'Account Code',
                successTxt: null
            },
            views: {
                '': {
                    templateUrl: "partials/features/manage-account-code.html",
                    controller: "manageAccountCodeCtrl"
                }

            } //End of views

        })

    .state('features.enterprise.account_code.create-account-code', {
        url: "/create-account-code",
        data: {
            displayName: 'Create Account Code'
        },
        views: {
            '': {
                templateUrl: "partials/features/create-account-code.html",
                controller: "manageAccountCodeCtrl"
            }

        } //End of views

    })

    .state('features.enterprise.update-account-code', {
            url: "/update-account-code/:code",
            data: {
                displayName: 'Update Account Code'
            },
            views: {
                '': {
                    templateUrl: "partials/features/enterpriseFeatures/accountCode/update-account-code.html",
                    controller: "updateAccountCodeCtrl"
                }

            } //End of views

        })
        .state('features.enterprise.assign_account_code', {
            url: "/account-code-mng",
            data: {
                displayName: 'Account Code'
            },
            views: {
                '': {
                    templateUrl: "partials/features/accountAssign.html"
                        // controller: "accountAssignCtrl"
                }

            } //End of views

        })

    .state('features.enterprise.account_code.assign_code', {
        url: "/assign-code",
        data: {
            displayName: 'Manage/Assign Users'
        },
        views: {
            '': {
                templateUrl: "partials/features/manage-assign-code.html",
                controller: "accountCodeCtrl"
            }

        } //End of views

    })

    .state('features.enterprise.authorize_code', {
        url: "/authorize-code",
        data: {
            displayName: 'Authorize Code'
        },
        views: {
            '': {
                templateUrl: "partials/features/manage-authorize-code.html",
                controller: "manageAuthorizeCodeCtrl"
            }

        } //End of views

    })

    .state('features.enterprise.createauthorizecode', {
        url: "/create-authorize/:code",
        data: {
            displayName: 'Code'
        },
        views: {
            '': {
                templateUrl: "partials/features/create-authorize-code.html",
                controller: "createAuthorizeCodeCtrl"
            }

        } //End of views

    })


    // .state('features.enterprise.manageSchedule.createHolidaySchedule', {
    //     url: "/create-holiday-schedule",
    //     data: {
    //         displayName: 'Create Holiday Schedule'
    //     },
    //     views: {
    //         '': {
    //             templateUrl: "partials/features/enterpriseFeatures/schedule/create-holiday-schedule.html",
    //             controller: "createHolidayScheduleCtrl"
    //         }
    //     } //End of views
    // })

    // .state('features.enterprise.manageSchedule.createBusinessSchedule', {
    //     url: "/create-business-schedule",
    //     data: {
    //         displayName: 'Create Business Schedule'
    //     },
    //     views: {
    //         '': {
    //             templateUrl: "partials/features/enterpriseFeatures/schedule/create-business-schedule.html",
    //             controller: "scheduleCreateBizCtrl"
    //         }
    //     } //End of views
    // })

    // .state('features.enterprise.manageSchedule.reviewBusinessSchedule', {
    //     url: "/review-business-schedule",
    //     data: {
    //         displayName: 'Review Business Schedule'
    //     },
    //     views: {
    //         '': {
    //             templateUrl: "partials/features/enterpriseFeatures/schedule/review-business-schedule.html",
    //             controller: "reviewBusinessScheduleCtrl"
    //         }
    //     } //End of views
    // })

    .state('features.enterprise.manageSchedule', {
        url: "/manage-schedule",
        data: {
            displayName: 'Schedules'
        },
        views: {
            '': {
                templateUrl: "partials/features/enterpriseFeatures/schedule/manage-schedule.html",
                controller: "manageScheduleCtrl"
            }
        } //End of views
    })

    .state('features.enterprise.createSchedule', {
        url: "/create-schedule",
        data: {
            displayName: 'Create Schedule'
        },
        views: {
            '': {
                templateUrl: "partials/features/enterpriseFeatures/schedule/create-schedule.html",
                // controller: "createScheduleCtrl"
            }

        } //End of views
    })
    .state('features.enterprise.updateSchedule', {
        url: "/update-schedule/:scheduleType/:scheduleName",
        data: {
            displayName: 'Update Schedule'
        },
        views: {
            '': {
                templateUrl: "partials/features/enterpriseFeatures/schedule/update-schedule.html",
                // controller: "updateScheduleCtrl"
            }
        } //End of views
    })


        .state('features.user.call_waiting', {
            url: "/call-waiting",
            data: {
                displayName: 'Call Waiting'
            },
            views: {
                '': {
                    templateUrl: "partials/features/userFeatures/callWaiting.html",
                    controller: "callWaitingCtrl"
                }
            } //End of views
        })
        .state('features.user.music_on_hold_user', {
            url: "/music-on-hold-user",
            data: {
                displayName: 'Music On Hold'
            },
            views: {
                '': {
                    templateUrl: "partials/features/userFeatures/musicOnHold/musicOnHold.html",
                    controller: "musicOnHoldCtrlUser"
                }
            } //End of views
        })
        .state('features.user.calling_plan', {
            url: "/calling-plan-user",
            data: {
                displayName: 'Calling Plan'
            },
            views: {
                '': {
                    templateUrl: "partials/features/userFeatures/callingPlan/callingPlan.html",
                    controller: "callingPlanCtrlUser"
                }
            } //End of views
        })

    .state('features.user.dir_call_pickup', {
        url: "/dir-call-pickup",
        data: {
            displayName: 'Remote Call Pickup with Barge In'
        },
        views: {
            '': {
                templateUrl: "partials/features/userFeatures/directedcallpickup-bargein.html",
                controller: "directedCallPickUpBargeinCtrl"
            }
        } //End of views
    })

    .state('features.enterprise.manageSchedule.reviewHolidaySchedule', {
        url: "/review-holiday-schedule",
        data: {
            displayName: 'Review Holiday Schedule'
        },
        views: {
            '': {
                templateUrl: "partials/features/enterpriseFeatures/schedule/business-schedule-review.html",
                controller: "reviewScheduleCtrl"
            }

        } //End of views

    })

    .state('features.users', {
        url: "/users",
        data: {
            displayName: 'Users'
        },
        views: {
            '': {
                templateUrl: "partials/users/users.html",
                controller: "UsersCtrl"
            }

        } //End of views
    })

    .state('features.users.search', {
        url: "/search",
        views: {
            'search': {
                templateUrl: "partials/users/tabs.html",
                controller: "UsersCtrl"
            }
        } //End of views
    })

    .state('features.users.search.tabs', {
        url: "/",
        views: {
            'tab-one': {
                templateUrl: "partials/users/tabs/users-search.html"
            },
            'tab-two': {
                templateUrl: "partials/users/tabs/users-viewall.html"
            }
        } //End of views
    })

    .state('features.enterprise.calling_plan', {
        url: "/calling-plan",
        data: {
            displayName: 'Coding Plan'
        },
        views: {
            '': {
                templateUrl: "partials/features/calling-plan.html",
                controller: "callingPlanCtrl"
            }

        } //End of views

    })

    .state('features.enterprise.group_forwarding', {
        url: "/group-forwarding",
        data: {
            displayName: 'Group Forwarding'
        },
        views: {
            '': {
                templateUrl: "partials/features/group-forwarding.html",
                controller: "nightForwardingCtrl"
            }

        } //End of views

    })

    .state('features.enterprise.custom_ringback', {
        url: "/custom-ringback",
        data: {
            displayName: 'Custom Ringback'
        },
        views: {
            '': {
                templateUrl: "partials/features/custom-ringback.html",
                controller: "customRingbackCtrl"
            }

        } //End of views

    })

    .state('features.enterprise.music_on_hold', {
        url: "/music-on-hold",
        data: {
            displayName: 'Music On Hold'
        },
        views: {
            '': {
                templateUrl: "partials/features/enterpriseFeatures/musicOnHold/music_on_hold.html",
                controller: "musicOnHoldCtrl"
            }

        } //End of views

    })

    .state('dashboard', {
        url: "/dashboard",
        views: {

            'main-content': {
                templateUrl: "partials/dashboard/dashboard.html",
                controller: "DashboardCtrl"
            }

        } //End of views

    })

    .state('features.enterprise.auto_attendant_review', {
            url: "/auto-attendant-review",
            data: {
                displayName: 'Automated Receptionist Review',
                pageName: 'auto-attendant-review'
            },
            views: {
                '': {
                    templateUrl: "partials/features/auto-attendant-review.html",
                    controller: "automatedReceptionsitCtrl"
                }

            } //End of views
        })
        .state('features.enterprise.calling_line_id', {
            url: "/calling-line-id",
            data: {
                displayName: 'Calling Line ID Delivery'
            },
            views: {
                '': {
                    templateUrl: "partials/features/calling-line-id.html",
                    controller: "callingLineIDCtrl"
                }

            } //End of views

        })

    .state('features.enterprise.hunt_group', {
        url: "/manage-hunt-group",
        data: {
            displayName: 'Hunt Group',
            successTxt:null
        },
        views: {
            '': {
                templateUrl: "partials/features/manage-hunt-group.html",
                controller: "huntGroupCtrl"
            }

        } //End of views
    })

    .state('features.enterprise.hunt_group_details', {
        url: "/hunt-group-details/:lineNumber/:status",
        data: {
            displayName: 'Hunt Group Details'
        },
        views: {
            '': {
                templateUrl: "partials/features/hunt-group-details.html",
                controller: "huntGroupDetailsCtrl"
            }
        }
    })

    .state('features.enterprise.hunt_group_algorithm', {
        url: "/hunt-group-algorithm/:lineNumber",
        data: {
            displayName: 'Hunt Group Algorithm'
        },
        views: {
            '': {
                templateUrl: "partials/features/hunt-calling-algorithm.html",
                controller: "huntCallingAlgorithmCtrl"
            }
        }
    })

    .state('features.enterprise.hunt_group_review', {
        url: "/hunt-group-review/:lineNumber",
        data: {
            displayName: 'Hunt Group Review'
        },
        views: {
            '': {
                templateUrl: "partials/features/hunt-group-review.html",
                controller: "huntGroupReviewCtrl"
            }
        }
    })

    .state('features.enterprise.auto_attendant', {
        url: "/auto-attendant",
        data: {
            displayName: 'Automated Receptionist',
            pageName: 'auto-attendant',
            successTxt: null
        },
        views: {
            '': {
                templateUrl: "partials/features/auto-attendant-manage.html",
                controller: "automatedReceptionsitCtrl"
            }

        } //End of views
    })

    .state('features.enterprise.auto_attendant_setup', {
        url: "/auto-attendant-setup",
        data: {
            displayName: 'Setup Automated Receptionist',
            pageName: 'auto-attendant-setup'
        },
        views: {
            '': {
                templateUrl: "partials/features/auto-attendant-setup.html",
                controller: "automatedReceptionsitCtrl"
            }

        } //End of views
    })

    .state('features.enterprise.auto_attendant_detail', {
        url: "/auto-attendant-detail/:lineNumber",
        data: {
            displayName: 'Automated Receptionist Detail',
            pageName: 'auto-attendant-detail'
        },
        views: {
            '': {
                templateUrl: "partials/features/auto-attendant-detail.html",
                controller: "automatedReceptionsitCtrl"
            }

        } //End of views
    })

    .state('all-features', {
        url: "/all-features",
        views: {
            'main-content': {
                templateUrl: "partials/features/new-features.html"
            }
        } //End of views

    })

    .state('user-features', {
        url: "/user-features",
        views: {
            'main-content': {
                templateUrl: "partials/features/user-features.html"
            }
        } //End of views

    })

    .state('enterprise-features', {
        url: "/enterprise-features",
        views: {
            'main-content': {
                templateUrl: "partials/features/enterprise-features.html"
            }
        } //End of views

    })

    .state('features.user.automatic_callback', {
        url: "/automatic-callback",
        data: {
            displayName: 'Automatic Callback'
        },
        views: {
            '': {
                templateUrl: "partials/features/userFeatures/automatic-callback.html",
                controller: "autoCallbackCtrl"
            }
        } //End of views
    })

    .state('features.user.barge_InExempt', {
        url: "/barge-InExempt",
        data: {
            displayName: 'Barge In Exempt '
        },
        views: {
            '': {
                templateUrl: "partials/features/userFeatures/barge-InExempt.html",
                controller: "bargeInExemptCtrl"
            }
        } //End of views
    })

    .state('features.user.sim_ring_service', {
        url: "/sim-ring-service",
        data: {
            displayName: 'Simultaneous Ring Service'
        },
        views: {
            '': {
                templateUrl: "partials/features/userFeatures/simultaneous-RingService.html",
                controller: "simultaneousRingServiceCtrl"
            }
        } //End of views
    })

    .state('features.user.selective_call_acceptance', {
            url: "/sel-call-acceptance",
            data: {
                displayName: 'Call Acceptance'
            },
            views: {
                '': {
                    templateUrl: "partials/features/userFeatures/selectiveCallRejection/selective-call-rejection.html",
                    controller: "selectiveCallAcceptRejectionCtrl"
                }
            } //End of views
        })
        .state('features.user.selective_call_rejection', {
            url: "/sel-call-rejection",
            data: {
                displayName: 'Call Rejection'
            },
            views: {
                '': {
                    templateUrl: "partials/features/userFeatures/selectiveCallRejection/selective-call-rejection.html",
                    controller: "selectiveCallAcceptRejectionCtrl"
                }
            } //End of views
        })
        .state('features.user.anonymous_call_rejection', {
            url: "/anonymus-callrejection",
            data: {

                displayName: 'Anonymous Call Rejection'
            },
            views: {
                '': {
                    templateUrl: "partials/features/userFeatures/anonymus-CallRejection.html",
                    controller: "anonymusCallRejectionCtrl"
                }
            } //End of views
        })

    .state('features.user.call_forwarding', {
        url: "/call-forwarding",
        data: {
            displayName: 'Call Forwarding'
        },
        views: {
            '': {
                templateUrl: "partials/features/userFeatures/callForwarding/call-forwarding.html",
                controller: "callForwardingCtrl"
            }
        } //End of views
    })

    .state('features.user.pre_alert_announcement', {
        url: "/pre-alert-announcement",
        data: {

            displayName: 'Pre Alerting Announcement'
        },
        views: {
            '': {
                templateUrl: "partials/features/userFeatures/preAlerting/pre-alerting-announcement.html",
                controller: "preAlertAnnouncementCtrl"
            }
        } //End of views
    })

    .state('features.user.caller_id_block', {
        url: "/caller-id-block",
        data: {

            displayName: 'Caller ID Blocking'
        },
        views: {
            '': {
                templateUrl: "partials/features/userFeatures/caller-IdBlock.html",
                controller: "callerIdBlockCtrl"
            }
        } //End of views
    })

    .state('maintenance', {
        url: "/maintenance",
        views: {
            'main-content': {
                templateUrl: "partials/common/maintenance.html"
            }
        } //End of views

    });
}
