function getSelectedTextVal(a, objName) {
    if (typeof a != "undefined") {
        if (typeof objName == "undefined") {
            objName = "drop+down+menu"
        }
        _hbLink(a.options[a.selectedIndex].text, objName)
    }
}

function getSelectedRadioVal(a, objName) {
    if (typeof a != "undefined") {
        if (typeof objName == "undefined") {
            objName = "radio+button"
        }
        for (var i = 0; i < a.length; i++) {
            if (a[i].checked) {
                _hbLink(a[i].value, objName)
            }
        }
    }
}

function _hbxMLCjoin(prefix, mlc1, mlc2, mlc3, mlc4) {
    var mlc = prefix;
    if (undefined != mlc1 && mlc1 != "") {
        mlc += "/" + _hbxStrip(mlc1);
        if (undefined != mlc2 && mlc2 != "") {
            mlc += "/" + _hbxStrip(mlc2);
            if (undefined != mlc3 && mlc3 != "") {
                mlc += "/" + _hbxStrip(mlc3);
                if (undefined != mlc4 && mlc4 != "") {
                    mlc += "/" + _hbxStrip(mlc4)
                }
            }
        }
    }
    return mlc
}

function _hbxParamStrip(a) {
    a = a.split(",").join("");
    return _hbxStrip(a)
}

function _hbxHTMLStrip(a) {
    return _hbxStrip(a.trim().stripHTML())
}

function _hbxStrip(a, is_cat) {
    a = a.split("&reg;").join("");
    a = a.split("&trade;").join("");
    a = a.split("&amp;").join("");
    a = a.split("&ndash;").join("-");
    if (typeof is_cat == "undefined" || is_cat != "1") {
        if (a.substring(0, 1) == "/") {
            a = a.substring(1)
        }
        a = a.split("/").join("-")
    }
    a = a.split("|").join("");
    a = a.split("&").join("");
    a = a.split("'").join("");
    a = a.split("#").join("");
    a = a.split("$").join("");
    a = a.split("%").join("");
    a = a.split("^").join("");
    a = a.split("*").join("");
    a = a.split(":").join("");
    a = a.split("!").join("");
    a = a.split("<").join("");
    a = a.split(">").join("");
    a = a.split("~").join("");
    a = a.split(";").join("");
    a = a.split("®").join("");
    a = a.split("™").join("");
    a = a.split(" ").join("+");
    if (typeof a != "undefined" && a != null) {
        if (hbx.pn != "PUT+PAGE+NAME+HERE") {
            return a.toLowerCase()
        }
    }
    return a
}
String.prototype.trim = function() {
    return this.replace(/^\s+|\s+$/g, "")
};
String.prototype.ltrim = function() {
    return this.replace(/^\s+/, "")
};
String.prototype.rtrim = function() {
    return this.replace(/\s+$/, "")
};
String.prototype.stripHTML = function() {
    var matchTag = /<(?:.|\s)*?>/g;
    return this.replace(matchTag, "")
};
String.prototype.alphaNumOnly = function() {
    return this.replace(/[^a-zA-Z 0-9]+/g, "")
};

function _hbxUpdatePN(pname) {
    hbx.pn = _hbxStrip(pname)
};
