(function() {
	
	function SiteCatalyst(cfg, $window, $document, $log) {
		function pageView(pn, mlc) {
			try {
				_hbPageView(pn, mlc);
			} catch(ex) {
				$log.warn(ex);
			}
		}
		
		function link(name, type) {
			try {
				_hbLink(name, type);
			} catch(ex) {
				$log.warn(ex);
			}
		}
		
		this.pageView = function(pageName) {
			hbx.pn=_hbxStrip(pageName);
			hbx.mlc=_hbxStrip("/" + category,1);
			hbx.ci=hbx.hc1=hbx.hc2=hbx.hc3=hbx.hc4=hbx.hrf=hbx.pec="";
			$window.cv=_hbEvent("cv");
			cv.c18="unauthenticated";
			cv.c19="prospect";			
			pageView(hbx.pn, hbx.mlc);
			hbx.oi="";  //Confirmation id
			hbx.pv="";

			hbx.pr_ = "";
			hbx.ot = "";
			hbx.gp=""; //order type for order conf pages
			hbx.prdQtyPc='';
			scProductMetrics(hbx.prdQtyPc);
		};
		
		var me = this,
			buttonSelectors = cfg.buttonSelectors,
			category = cfg.category;
		
		$document.on('click', function(event) {
			var target = angular.element(event.target);
			buttonSelectors.some(function(selector) {
				if (target.is(selector)) {
					var tagName = target.attr('sc-tag');
					if(target.hasClass('scAgreement')){
						me.clickHandler('agreementNumber:' + target.text().trim(), 'link');
					}else if(target.hasClass('ui-grid-icon-plus-squared')){
						me.txnClick('Expand');				   
                    }else if(target.hasClass('ui-grid-icon-minus-squared')){
                    	me.txnClick('Collapse');	
                    }else if(selector == '.btn'&& !tagName){
                        me.clickHandler(target.val().trim(), 'button');
                    }else if(selector == 'a' && !tagName){
                        me.clickHandler(target.text().trim(), 'link');
                    }
					return true;
				}
				return false;
			});						
		});
		
		this.configureSiteCatalyst = function(initData) {
			console.log("********initData*******");
			console.log(initData)
			var pageURL = window.location.href;
			s.un = "vzwitestenv";
			if (ENV.isProd) {
			    s.un = "vzwiglobal,vzwibusiness";
			}				
			s.channel = "/volte";
			s.application = "/volte";
			s.prop1 = "manage";
			s.prop10 = "business";//page type
			s.prop24 = initData.assignedPortal;
			s.prop25 = initData.ecpdId;
			s.prop32 = initData.impersonatorId;
			s.prop34 = "v4b"; //customerType
			s.eVar41 = "D=c34";
			s.eVar42 = "customer";
			createCustomTag("impersonatorRole", initData.impersonatorRole);
			createCustomTag("userId", initData.userId);
		};

		this.updateLineQuantity = function(txnType, orderQuantity, orderNbr){
			hbx.oi=orderNbr;  //Confirmation id
			hbx.pv=orderQuantity;

			hbx.pr_ = txnType;
			hbx.ot = "acct main.";
			hbx.gp="LAST"; //order type for order conf pages
			hbx.prdQtyPc=';'+hbx.pr_+';'+hbx.pv+';;;';
			mapPageCodeToSC();
		};

		this.resetLineQuantity = function(){
			hbx.oi="";  //Confirmation id
			hbx.pv="";

			hbx.pr_ = "";
			hbx.ot = "";
			hbx.gp=""; //order type for order conf pages
			hbx.prdQtyPc='';
			scProductMetrics(hbx.prdQtyPc);
		};
		
		this.clickHandler = function(tagName, type){
			if(angular.isDefined(tagName) && tagName !== null){
				tagName = tagName.replace('&', 'and');
				link(tagName, type);
				//Resetting the button tags for subsequent user events
				s.prop11 = "";
				s.prop12 = "";
				s.prop13 = "";
			}
		};
        
		this.txnClick = function(t) {
			var pageName = s.pageName ? s.pageName.toLowerCase() : '';
			var pageId = pageName.substr(pageName.lastIndexOf('/')+1);
			if(pageName.indexOf('wireless numbers') > -1){
				pageId = "Line"
			}else if(pageName.indexOf('billing acct') > -1){
				pageId = "Account"
			}else if(pageName.indexOf('transaction') > -1){
				pageId = "Transaction"
			}
			var buttonName = t + " " + pageId + " Details";			
			link(buttonName, 'button');
		};   
		
		
		this.sendError = function(msg) {
			if (typeof cv == 'undefined') {
				$window.cv=_hbEvent("cv");
			}
			cv.c6=msg;
			pageView(hbx.pn, hbx.mlc);
			cv.c6='';
		};
	}
	
	var app = angular.module('ves-analytics', []);
	app.provider('SiteCatalyst', function SiteCatalystProvider() {
		var category = 'manage';
		var buttonSelectors = ["a.siteCatalyst", ".btn", "i.ui-grid-icon-plus-squared", "i.ui-grid-icon-minus-squared"];
		
		this.setCategory = function(value) {
			category = value;
		};
		this.addButtonSelector = function(value) {
			buttonSelectors.push(value);
		};
		
		this.$get = ['$window', '$document', '$log', function SiteCatalystFactory($window, $document, $log) {
			return new SiteCatalyst({
				category : category,
				buttonSelectors : buttonSelectors
			}, $window, $document, $log);
		}];
	});
})();
