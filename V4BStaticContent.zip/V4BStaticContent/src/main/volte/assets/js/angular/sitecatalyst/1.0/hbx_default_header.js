var enableWebAnalytics = true;
var _hbEC = 0,
    _hbE = new Array;

function _hbEvent(a, b) {
    b = _hbE[_hbEC++] = new Object();
    b._N = a;
    b._C = 0;
    return b
}
var hbx = _hbEvent("pv");
hbx.vpc = "HBX0200u";
hbx.gn = "www35.vzw.com";
if (!enableWebAnalytics) {
    hbx.gn = "www.verizonwireless.com"
}
var pageURL = window.location.href;
if (pageURL.indexOf("verizonwireless.com") > -1 || pageURL.indexOf("b2b.vzw.com") > -1 || pageURL.indexOf("mbassistant.vzwcorp.com") > -1) {
    hbx.acct = "DM570203L6VD;DM561203FJWA";
    hbx.eacct = "DM570203L6VD;DM561203FJWA";
    hbx.cacct = "975702189232"
} else {
    hbx.acct = "DM5701312PCS;DM57013166EV";
    hbx.eacct = "DM5701312PCS;DM57013166EV";
    hbx.cacct = "975703022451"
}
hbx.pn = "PUT+PAGE+NAME+HERE";
hbx.mlc = "CONTENT+CATEGORY";
hbx.pndef = "title";
hbx.ctdef = "full";
hbx.sr = "3";
hbx.so = "us";
hbx.cu = "business";
hbx.lc = "y";
hbx.fv = "";
hbx.lt = "auto";
hbx.dlf = "n";
hbx.dft = "n";
hbx.elf = "n";
hbx.seg = "";
hbx.fnl = "";
hbx.cmp = "";
hbx.cmpn = "";
hbx.dcmp = "";
hbx.dcmpn = "";
hbx.dcmpe = "";
hbx.dcmpre = "";
hbx.hra = "";
hbx.hqsr = "";
hbx.hqsp = "";
hbx.hlt = "";
hbx.hla = "";
hbx.gp = "";
hbx.gpn = "";
hbx.hcn = "";
hbx.hcv = "";
hbx.cp = "null";
hbx.cpd = "";
hbx.ci = "";
hbx.hc1 = "";
hbx.hc2 = "";
hbx.hc3 = "";
hbx.hc4 = "";
hbx.hrf = "";
hbx.pec = "";
hbx.oi="";
hbx.pv="";
hbx.pr_="";
hbx.ot="";
hbx.gp="";
hbx.prdQtyPc="";