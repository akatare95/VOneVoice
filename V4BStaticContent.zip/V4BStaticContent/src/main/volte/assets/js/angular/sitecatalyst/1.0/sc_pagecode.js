function populateSObj(winObjName, scMapping) {
    if (typeof window[winObjName] != undefined) {
        for (var key in window[winObjName]) {
            var mapObj = scMapping[winObjName + "." + key];
            if (checkIfValid(window[winObjName][key]) && mapObj != undefined) {
                if (checkIfValid(mapObj.scKey)) {
                    createCustomTag(mapObj.scKey, window[winObjName][key], mapObj.exempt);
                }
                mapObj.func();
            }
        }
    }
}

function mbEmpty() {}

function getMapObj(key, func, exemptions) {
    return {
        scKey: key,
        func: typeof func == "function" ? func : mbEmpty,
        exempt: exemptions ? exemptions : []
    };
}

function mapPageCodeToSC() {
    var scMapping = {
        "cv.c6": getMapObj("error", function() {
            s.pageName = s.pageName + " error";
        }),
        "cv.c21": getMapObj("impersonator", function() {
            createCustomTag("authStatus", "MBA");
        }),
        "cv.c5": getMapObj("s.eVar14"),
        "cv.c11": getMapObj("s.eVar15"),
        "cv.c18": getMapObj("authStatus"),
        "cv.c19": getMapObj("s.eVar42"),
        "cv.c20": getMapObj("s.eVar24"),
        "cv.p1": getMapObj("s.prop1"),
        "cv.p3": getMapObj("s.prop3", function() {
            createCustomTag("s.eVar6", "D=c3");
        }),
        "cv.p4": getMapObj("s.prop4"),
        "cv.p5": getMapObj("s.prop5", null, [":"]),
        "cv.p6": getMapObj("s.prop6"),
        "cv.p7": getMapObj("s.prop7"),
        "cv.p43": getMapObj("s.prop43"),
        "cv.p45": getMapObj("s.prop45"),
        "hbx.bulkTotal": getMapObj("s.prop55"),
        "hbx.sr": getMapObj("s.prop40"),
        "hbx.seg": getMapObj("visitorSeg"),
        "hbx.hc1": getMapObj("s.eVar52"),
        "hbx.hc3": getMapObj("s.eVar12"),
        "hbx.hc4": getMapObj("ECPDId"),
        "hbx.hc2": getMapObj("s.eVar11"),
        "hbx.ba": getMapObj("s.state"),
        "hbx.bz": getMapObj("s.zip"),
        "hbx.oi": getMapObj("s.purchaseID"),
        "hbx.ds": getMapObj("s.eVar36"),
        "hbx.gp": getMapObj(null, function() {
            if (hbx.gp == "LAST") {
                if (checkIfValid(s.prop2)) {
                    createCustomTag("s.eVar37", s.prop2.substring(1));
                } else {
                    if (checkIfValid(s.prop1)) {
                        createCustomTag("s.eVar37", s.prop1.substring(1));
                    }
                }
            }
        }),
        "hbx.hc3": getMapObj(null, function() {
            tmpAreaReg = hbx.hc3.split("|").join("");
            if (checkIfValid(tmpAreaReg)) {
                createCustomTag("s.eVar12", hbx.hc3);
            }
        }),
        "hbx.ot": getMapObj(null, function() {
            createCustomTag("s.eVar37", hbx.ot);
        }),
        "hbx.pr": getMapObj(null, function() {
            if (checkIfValid(hbx.pv) && (hbx.pv == "1")) {
                scCategorySku = hbx.ca + ";" + hbx.pr + ";1;;event21=" + hbx.pc;
                scProductView(scCategorySku);
                createCustomTag("s.eVar16", "business");
            } else {
                if (checkIfValid(hbx.pv) && (parseInt(hbx.pv) > 1)) {
                    scCategorySku = hbx.ca + ";" + hbx.pr + ";" + hbx.pv + ";;event21=" + hbx.pc;
                    scProductView(scCategorySku);
                    createCustomTag("s.products", scCategorySku);
                    createCustomTag("s.eVar16", "business");
                }
            }
        }),
        "hbx.prdQtyPc": getMapObj(null, function() {
            scProductMetrics(hbx.prdQtyPc);
            createCustomTag("s.eVar16", "business");
        })
    };
    if (typeof hbx.pn == "undefined" || hbx.pn == "" || hbx.pn == "PUT+PAGE+NAME+HERE") {
        if (document.title != "" && document.title != location) {
            hbx.pn = document.title;
        }
    }
    var tmpPageName = "";
    if (typeof hbx.pn != "undefined" && hbx.mlc != "undefined") {
        hbx.pn = hbx.pn.split("/").join("-");
        hbx.mlc = hbx.mlc.split("//").join("/");
        tmpPageName = hbx.mlc.toLowerCase() + "/" + hbx.pn.toLowerCase();
        var pn_hold = new Array();
        pn_hold = tmpPageName.split("+");
        tmpPageName = pn_hold.join(" ");
    } else {
        tmpPageName = document.location.pathname.toLowerCase();
    }
    tmpPageName = tmpPageName.split("///").join("/");
    tmpPageName = tmpPageName.split("//").join("/");
    scAddPageName(tmpPageName);
    populateSObj("cv", scMapping);
    populateSObj("hbx", scMapping);
    if (typeof hbx != "undefined") {
        createProcessFlowMetrics(hbx.flState, s.prop1.substring(1), hbx.flType, s.prop2.substring(1));
    }
}
mapPageCodeToSC();