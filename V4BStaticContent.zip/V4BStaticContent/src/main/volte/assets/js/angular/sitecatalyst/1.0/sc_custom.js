var sep = "/";

function scAddPageName(a) {
    a = replace(a);
    if (a != null && a != "null" && a != "") {
        a = a.toLowerCase();
        s.pageName = s.application + a;
        setPathTransaction()
    }
}

function setPathTransaction() {
    var pnv = s.pageName.split("/");
    s.prop1 = "";
    s.prop2 = "";
    if (pnv[2] && pnv.length > 3) {
        s.prop1 = sep + pnv[2]
    }
    if (pnv[3] && pnv.length > 4) {
        for (var cV = 3; cV <= pnv.length - 2; cV++) {
            s.prop2 += sep + pnv[cV]
        }
    }
}

function createCustomTag(name, value, exempt) {
    if (value != null && value != "null" && value != "") {
        if (name == "visitorSeg") {
            s.prop61 = replace(value, exempt);
            s.eVar61 = "D=c61"
        } else {
            if (name == "error") {
                s.prop23 = replace(value, exempt);
                s.eVar51 = "D=c23";
                s.events = s.apl(s.events, "event13", ",", 0)
            } else {
            	if (name == "impersonatorRole") {
                    s.eVar43 = value;
                }  else {
                    if (name == "customerType") {
                        s.prop34 = replace(value, exempt);
                        s.eVar41 = "D=c34"
                    } else {
                        if (name == "checkoutEvent") {
                            s.events = s.apl(s.events, "event14", ",", 0)
                        } else {
                            if (name == "CustomerProspectInd") {
                                s.eVar42 = replace(value, exempt)
                            } else {
                                if (name == "ECPDId") {
                                    s.prop25 = replace(value, exempt);
                                    s.eVar13 = "D=c25"
                                } else {
                                    if (name == "authStatus") {
                                        s.prop24 = replace(value, exempt);
                                        s.eVar46 = "D=c24"
                                    } else {
                                    	if (name == "application"){
                                    		s.application = value;
                                    	} else {
                                    		if (name == "userId") {
                                                s.eVar24 = value;
                                            }  else {}
                                    	}
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

function scCartAdd() {
    s.events = s.apl(s.events, "scAdd,scOpen", ",", 0)
}

function scCartRemove() {
    s.events = "scRemove"
}

function scCheckout() {
    s.events = "scCheckout";
    submitSCTag()
}

function scProductView(scCategorySku) {
    s.products = replace(scCategorySku);
    s.events = s.apl(s.events, "prodView,event24", ",", 0)
}

function scProductMetrics(skuQtyPrice) {
    createCustomTag("s.eVar4", s.pageName);
    if (checkIfValid(hbx.st)) {
        createCustomTag("s.eVar33", hbx.st)
    }
    if (checkIfValid(hbx.pt)) {
        createCustomTag("s.eVar35", hbx.pt)
    }
    if (checkIfValid(hbx.pm)) {
        createCustomTag("s.eVar34", hbx.pm)
    }
    if (checkIfValid(hbx.po)) {
        createCustomTag("s.eVar36", hbx.po)
    }
    skuQtyPrice = preprocessProdMetrics(skuQtyPrice);
    s.products = replace(skuQtyPrice);
    if (typeof hbx.gp != "undefined" && hbx.gp == "LAST") {
        s.events = "purchase"
    }
    if (typeof hbx.gp != "undefined" && hbx.gp == "CART") {
        scCartAdd()
    }
}

function preprocessProdMetrics(skuQtyPrice) {
    b = skuQtyPrice.trim();
    if (checkIfValid(hbx.cartValue)) {
        hbx.cartValue = replaceComma(hbx.cartValue);
        b = b.split(":CART-VALUE:").join(hbx.cartValue)
    } else {
        b = b.split(":CART-VALUE:").join("")
    }
    if (checkIfValid(hbx.sp)) {
        b = b.split(":SHIP-CHARGE:").join(hbx.sp)
    } else {
        b = b.split("|event22=:SHIP-CHARGE:").join("")
    }
    if (checkIfValid(hbx.tax)) {
        hbx.tax = replaceComma(hbx.tax);
        b = b.split(":TAX:").join(hbx.tax)
    } else {
        b = b.split("|event23=:TAX:").join("")
    }
    return b
}

function createProcessFlowMetrics(flowState, flowName_19, flowType_20, flowInteraction_21) {
    if (checkIfValid(flowState) && checkIfValid(flowName_19) && checkIfValid(flowType_20)) {
        var fsStripped = removeWhiteSpaces(flowState).toUpperCase();
        if (fsStripped == "FLOW_START" || fsStripped == "FLOW_STEP" || fsStripped == "FLOW_END") {
            s.prop19 = replace(flowName_19);
            s.eVar8 = "D=c19";
            s.prop20 = replace(flowType_20);
            s.eVar9 = "D=c20";
            if (checkIfValid(flowInteraction_21)) {
                s.prop21 = replace(flowInteraction_21);
                s.eVar10 = "D=c21"
            }
            if (fsStripped == "FLOW_START") {
                s.events = s.apl(s.events, "event6,event7", ",", 0)
            } else {
                if (fsStripped == "FLOW_STEP") {
                    s.events = s.apl(s.events, "event7", ",", 0)
                } else {
                    if (fsStripped == "FLOW_END") {
                        s.events = s.apl(s.events, "event7,event8", ",", 0)
                    }
                }
            }
        }
    }
}

function checkIfValid(a) {
    return (a != null && a != undefined && removeWhiteSpaces(a).length > 0)
}

function removeWhiteSpaces(a) {
    if (a != null && a != "") {
        a = a.replace(new RegExp(/^\s+/), "");
        a = a.replace(new RegExp(/\s+$/), "")
    }
    return a
}

function replaceComma(d) {
    d = d.trim();
    d = d.split(",").join("");
    return d
}

function replace(b, exempt) {
    var exclude = {
        chr: ["[", "\\]", "{", "}", "'", "#", "$", "%", "\\^", "*", ":", "!", "<", ">", "~", "\xAE", "\xAE", '"'],
        string: ["&reg;", "reg;", "&trade;", "trade;", "&amp;", "amp;"]
    };
    var chr, idx;
    while (exempt && (chr = exempt.shift())) {
        if ((idx = exclude.chr.indexOf(chr)) >= 0) {
            exclude.chr.splice(idx, 1)
        }
    }
    var charExp = "(([" + exclude.chr.join("") + "]*)";
    var stringExp = "(" + exclude.string.join("|") + "))*";
    return b.replace(new RegExp(charExp + "|" + stringExp, "g"), "").replace(/[\s\+]+/g, " ").replace(/&ndash;/g, "-").trim()
}

function submitSCTag() {
    var s_code = s.t();
    if (s_code) {
        document.write(s_code)
    }
}

function _hbPageViewAssign(hbxpn, hbxmlc) {
    pn = "";
    if (hbxmlc == "/" || hbxmlc == "//") {
        hbxmlc = "";
        hbx.mlc = ""
    }
    if (checkIfValid(hbxmlc)) {
        if (hbxmlc[0] != "/") {
            pn = "/" + hbxmlc
        } else {
            pn = hbxmlc
        }
    }
    if (checkIfValid(hbxpn)) {
        if (hbxpn[0] != "/") {
            pn = pn + "/" + hbxpn
        } else {
            pn = pn + hbxpn
        }
    }
    pn = pn.split("//").join("/");
    scAddPageName(pn)
}

function _hbPageView(hbxpn, hbxmlc) {
    _hbPageViewAssign(hbxpn, hbxmlc);
    submitSCTag()
};
