var loginStatus = "My Business";
createCustomTag("authStatus", loginStatus);
createCustomTag("s.eVar42", "customer");
createCustomTag("customerType", "b2b");
createCustomTag("application", "/volte");
