app.factory('MyUtils', ['SiteCatalyst', function(SiteCatalyst) {
    var initData = {};
    var trackVars = [
                     'assignedPortal',
                     'impersonationInfo',
                     'contactInfo',
                     'userInfo',
                     'userId',
                     'currentActiveProfile',
                     'entitledCompanyProfiles'
                     ];
    return {
        configSiteCatalyst: function() {
            var rootObject = angular.copy(initData);
            var homePortal = 'OneTalk';
            // if (rootObject.assignedPortal == 'VZB')
            //     homePortal = 'VEC';
            rootObject.assignedPortal = homePortal;
            SiteCatalyst.configureSiteCatalyst(rootObject);
        },
        setInitDataValues: function(data){
            initData = data;
        },
        updateMultilineOrderQuantity: function(txnType, orderQuantity, orderNbr){
            SiteCatalyst.updateLineQuantity(txnType, orderQuantity, orderNbr);
        },
        resetOrderQuantityVars: function(){
            //SiteCatalyst.resetLineQuantity();
        },
        assignUserProfileData: function(userProfile){
            var userDetails = {};
            this.decodeAndAssignObj(userProfile, false);
        },
        appendData : function(target){
            angular.extend(initData, target);
        },
        decodeAndAssignObj: function(srcData, appendAll){
            var scope = this;
            angular.forEach(srcData, function(value, key){
                if(trackVars.indexOf(key) > -1 || appendAll){
                    if(angular.isObject(value) && !angular.isArray(value))
                        scope.decodeAndAssignObj(value, true);
                    else if(value != null){
                        initData[key] = value;
                    }
                }
            });
        },
        unbindUIGridScroll: function ($element) {
            // this is used to fix the scroll down issue in UI Grid.  Call when refreshing data in UI Grid.
            var $viewport = $element.find('.ui-grid-render-container');
            ['touchstart', 'touchmove', 'touchend','keydown', 'wheel', 'mousewheel', 'DomMouseScroll', 'MozMousePixelScroll'].forEach(
                function (eventName) {
                    $viewport.unbind(eventName);
                }
            );
        },
        assignWebChatVars: function (pageName, flow, section) {
            // Call the webchat function to properly set the pageName
            if (mbAddVars !== undefined) {
                mbAddVars('page', 'Section', section);
                mbAddVars('page', 'VzWB_Flow', flow, true);
                mbAddVars('page', 'PageName', pageName);
                addCompletionVars();
            }
        },
        reinitWebChat: function(pageName){
            reinitWebChat(pageName);
        }
    };
}]);
