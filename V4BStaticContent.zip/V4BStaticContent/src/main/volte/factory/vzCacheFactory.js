/*
*
* This factory is used to Cache REST calls
*
*/
app.factory('vzCache', function($cacheFactory) {

	return $cacheFactory('resp');

});


app.factory( 'cache', function($cacheFactory) {
  var cache = $cacheFactory('myCache');
  return cache;
});
