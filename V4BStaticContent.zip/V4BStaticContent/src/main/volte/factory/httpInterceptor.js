app.factory('httpInterceptor', function ($q, $rootScope, $log, Constants) {

    var loadingCount = 0;

    return {
        request: function (config) {

            //config.headers["Access-Control-Allow-Origin"] = "*";
            //config.headers["Access-Control-Allow-Methods"] = "GET, POST, OPTIONS";
            //config.headers["Access-Control-Allow-Headers"] = "Content-Type";
            //config.headers["Access-Control-Request-Headers"] = "X-Requested-With, accept, content-type";

            config.timeout = Constants.AJAX_TIMEOUT_IN_MILLIS;

            if(config.method == 'POST') {
                //console.log('Triggering Idle Watch');
                //Idle.watch();
            }

            if(++loadingCount === 1) $rootScope.$broadcast('loading:progress');
            return config || $q.when(config);
        },

        response: function (response) {

            var status = response.status;
            //console.log('Status Code(response):', status);
            //console.log('Response Data:', response.data);
            if (status == '302') {

                //console.log('Found Error: 302');

                if(typeof window.volte != "undefined") {
                    window.volte.app.exit();
                }
                setTimeout(function(){ location.reload(true) }, 2000);
            }

            if (typeof response.data === 'string' && response.data.indexOf("Verizon business account login")>-1) {

                //console.log('Found Error: 302 - Login Page');

                if(typeof window.volte != "undefined") {
                    window.volte.app.exit();
                }
                setTimeout(function(){ location.reload(true) }, 2000);
            }

            if( typeof(response.data.appHeader) != 'undefined' ) {
                if( response.data.appHeader.statusCode != 'OK' ) {
                    //$rootScope.$state.go("maintenance");
                }
            }

            --loadingCount;

            $rootScope.$broadcast('loading:finish',{"status": response,"responseData":response.data});

            return response || $q.when(response);
        },

        responseError: function (response) {

            var status = response.status;

            //console.log('Status Code(responseError):', status);
            //console.log('Response Data:', response.data);

            if (status == '302') {

                //console.log('Found Error: 302');

                if(typeof window.volte != "undefined") {
                    window.volte.app.exit();
                }
                setTimeout(function(){ location.reload(true) }, 2000);
            }

            switch( status ) {
                case '200':
                    break;
                default:
                    $rootScope.$broadcast('loading:error',{"status": response,"responseData":response.data});
                    break;
            }

            /*var status = response.status;

            switch( status ) {

                case '302':

                console.log("Server is down!");

                var new_dialog = ngDialog.open({ template: 'partials/components/maintenance/302.html',
                       closeByDocument: false,
                       closeByEscape: true
                });

                break;
                case '401':

                //Whenever there is an inactivity redirect them to the SSO page
                //Clean this place and move everything to the constants
                //make sure that the redirect is happening to the proper page
                //var SSOURL = "https://mbaccmgrdev2.sdc.vzwcorp.com/amserver/sso/login.go?appGroup=VZW&goto=https%3A%2F%2Fv4bdev2.sdc.vzwcorp.com%3A443%2Fvolte%2Fsecure%2Findex";
                var SSOURL = "https://mbaccmgrdev2.sdc.vzwcorp.com/amserver/sso/login.go?appGroup=VZW";
                //window.location.href = SSOURL;

                break;
            }*/

            if(--loadingCount === 0) $rootScope.$broadcast('loading:finish',{"status": response});
            return $q.reject(response);

        }
    };

}).config(function ($httpProvider) {

    $httpProvider.interceptors.push('httpInterceptor');

});
