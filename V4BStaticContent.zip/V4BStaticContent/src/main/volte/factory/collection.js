(function () {

/**
 * @constructor
 */
var Collection = function (overrides) {
    var me = this,
        config = __extend({
            __id__: __unique()
        }, overrides || {});

    __extend(me, config);

    me.__listeners__ = {};

    __watch(me, 'all', function (data, old) {
        if (data !== old) {
            me.reset().onLoad(data);
        }
    });
    __watch(me, 'pageSize', function (pageSize, old) {
        if (pageSize !== old) {
            me.currentPageIndex = 0;
            me.refresh();
        }
    });

    // Bind the execution context to this instance
    me.refresh = function () {
        Collection.prototype.refresh.call(me);

        me.fireEvent('refresh');

        return me;
    };
    me.addListener = function () {
        return Collection.prototype.addListener.apply(me, arguments);
    };
    me.removeListener = function () {
        return Collection.prototype.removeListener.apply(me, arguments);
    };

    /**
     * The cache property is used internally to bypass
     * unnecessary iterations if the previous operation
     * parameters haven't changed
     *
     * @private
     * @property {Object}
     */
    me.cache = {};
};

Collection.prototype = {
    /**
     * Identifier
     *
     * @property {String} __id__
     */
    __id__: null,

    /**
     * Flag to determine if the data was loaded
     *
     * @property {Boolean} loaded
     */
    loaded: false,

    /**
     * If false, you must manually call refresh()
     *
     * If performaing multiple expensive operations, this might be a
     * good idea.
     *
     * @property {Boolean} autoRefresh
     */
    autoRefresh: true,

    /**
     * Name of fields that will be included to be searchable
     * This will only work if the data is not nested.
     *
     * @property {String[]} searchableFields
     */
    searchableFields: [],

    /**
     * Search query
     *
     * @private
     * @property {String} searchQuery
     */
    searchQuery: '',

    /**
     * List of search tokens
     *
     * @private
     * @property {RegExp[]} searchTokens
     */
    searchTokens: [],

    /**
     * Used to explode a search query into an array of RegExp
     *
     * @private
     */
    searchDelimiter: ' ',

    /**
     * @property {Boolean} Used by search
     */
    caseSensitiveSearch: false,

    /**
     * Pagination size
     * Setting to Infinity will disable pagination
     *
     * @property {Number|Infinity} pageSize
     */
    pageSize: 10,

    /**
     * Current page index
     *
     * @property {Number} currentPageIndex
     */
    currentPageIndex: 0,

    /**
     * Iteratee functions to execute against each record to filter
     *
     * @property {Filter[]} filters
     */
    filters: [],

    /**
     * Iteratee functions to execute against each record to sort
     *
     * @property {Sorter[]} sorters
     */
    sorters: [],

    /**
     * Represents the total list returned from the server
     *
     * @property {Object[]} all
     */
    all: [],

    /**
     * Represents the list with pagination applied (if applicable)
     *
     * This is the array that is used for iteration
     *
     * @private
     * @property {Object[]} resultSet
     */
    resultSet: [],

    /**
     * Represents the list with filters/sorters/search applied
     *
     * @private
     * @property {Object[]} processed
     */
    processed: [],

    /**
     * Processed length
     * @property {Number} length
     */
    length: 0,

    /**
     * Complete length
     * @property {Number} total
     */
    total: 0,

    /**
     * Basic iterator - If iteratee returns false, it will stop
     *
     * @param iteratee
     * @param context
     * @returns {Collection}
     */
    each: function (iteratee, context) {
        var me = this,
            resultSet = me.resultSet,
            i = 0,
            ln = resultSet.length,
            key, value;

        for (; i < ln; i++) {
            value = resultSet[i];
            key = i;
            if (iteratee.call(context, value, key, resultSet) === false) {
                break;
            }
        }

        return me;
    },

    /**
     * @alias each
     */
    forEach: function () {
        return this.each.apply(this, arguments);
    },

    /**
     * Basic setter for all[]
     */
    setData: function (data) {
        if (data && data instanceof Array) {
            this.all = data;
        }

        return this;
    },

    /**
     * Appends the data to all[]
     */
    appendData: function (data) {
        var me = this,
            all = me.all,
            item;

        if (data && data instanceof Array) {
            item = data.shift();
            while (item) {
                all.push(data.shift());
            }
        }

        return me;
    },

    /**
     * Executes when the data gets set
     *
     * @private
     */
    onLoad: function (data) {
        var me = this,
            key;

        me.loaded = true;

        if (me.autoRefresh) {
            me.refresh();
        }

        return me;
    },

    /**
     * Executes all filters, sorters, paginators
     */
    refresh: function () {
        var me = this,
            startTime = new Date().getTime(),
            endTime;

        // The order matters!!!
        me.doSort().doFilter().doSearch().doPaginate();

        // Represents the filtered & searched results, not the paginated length
        me.length = me.processed.length;

        endTime = new Date().getTime();

        me.onRefresh(endTime - startTime);

        return me;
    },

    /**
     * Abstract method
     * @abstract
     */
    onRefresh: function () {},

    /**
     * Removes existing filters and automatically refreshes with
     * the new filters
     *
     * @param {Object[]} filters
     * @returns {Collection}
     */
    setFilters: function (filters) {
        var me = this;

        me.filters = [];
        me.addFilters(filters);

        return me;
    },

    /**
     * Appends the filters[] and automatically refreshes
     *
     * @param {Object[]} filters
     * @returns {Collection}
     */
    addFilters: function (filters) {
        var me = this,
            i = 0,
            ln = filters.length,
            filter;

        for (; i < ln; i++) {
            me.addFilter(filters[i]);
        }

        if (me.autoRefresh) {
            me.refresh();
        }

        return me;
    },

    /**
     * Adds a single filter object
     *
     * @param {Object} filter - Filter directive object
     */
    addFilter: function (filter) {
        var me = this,
            filters = me.filters,
            iteratee, getValue;

        iteratee = function (record) {
            var value = filter.getValue(record),
                testValue = filter.value;

            if (typeof testValue === 'string' && filter.caseSensitive === false) {
                value = (value + "").toLowerCase();
                testValue = (testValue + "").toLowerCase();
            }

            switch (filter.operator) {
                case '>':
                    return parseFloat(value) > testValue;
                case '>=':
                    return parseFloat(value) >= testValue;
                case '<':
                    return parseFloat(value) < testValue;
                case '<=':
                    return parseFloat(value) <= testValue;
                case '==':
                    return (value + "") == (testValue + "");
                case '===':
                    return value === testValue;
                case '!=': // return (value + "") != (testValue + "");
                case '!==':
                    return (value + "") !== (testValue + "");
                case '~=': // Fuzzy comparison
                    return (value + "").indexOf((testValue + "")) !== -1;
                default:
                    return true;
            }
        };

        getValue = function (record) { return record[filter.property]; };

        filter = __extend({
            property: undefined,
            value: '',
            operator: '==',
            caseSensitive: false,
            iteratee: iteratee,
            getValue: getValue
        }, filter);

        // If functions are default, it's cacheable
        filter.cacheable = filter.iteratee === iteratee && filter.getValue === getValue;

        filters.push(filter);

        return me;
    },

    /**
     * Applies the filters
     *
     * @private
     * @returns {Object[]} filteredResults
     */
    doFilter: function () {
        var me = this,
            cache = me.cache,
            filters = me.filters,
            all = me.all,
            filtered = [],
            useCache = true,
            filter;

        if (filters.length) {
            // If the filters from the previous doFilter are the same,
            // use the cached values instead of retesting the same thing
            if (cache.filters && cache.filters.length === filters.length) {
                for (var i = 0, ln = filters.length; i < ln; i++) if (useCache) {
                    filter = cache.filters[i];
                    useCache = (filter.cacheable &&
                        filter.property === filters[i].property &&
                        filter.value === filters[i].value &&
                        filter.operator === filters[i].operator &&
                        filter.caseSensitive == filters[i].caseSensitive);
                }
            } else {
                useCache = false;
            }

            if (useCache && cache.filtered) {
                filtered = cache.filtered;
            } else {
                var ai = 0, aln = all.length,
                    fi = 0, fln = filters.length,
                    record, include;

                filtered = all.slice();

                for (; fi < fln; fi++) {
                    filter = filters[fi];

                    for (ai = 0, aln = filtered.length; ai < aln; ai++) {
                        record = filtered[ai];

                        if (record && !filter.iteratee(record)) {
                            filtered.splice(ai, 1);
                            ai--;
                            aln = filtered.length;
                        }
                    }
                }

                cache.filters = filters;
                cache.filtered = filtered;
                delete cache.tokenSearch;
            }
        } else {
            // There are no filters
            filtered = all;
        }

        me.processed = filtered;

        return me;
    },





    /**
     * Tokenizes the search query and refreshes the collection
     */
    search: function (query) {
        var me = this;

        me.searchQuery = query || '';
        me.tokenizeQuery(query);

        if (me.autoRefresh) {
            me.refresh();
        }

        return me;
    },

    tokenizeQuery: function () {
        var me = this,
            delimiter = me.searchDelimiter,
            caseSensitive = me.caseSensitiveSearch,
            exploded = (me.searchQuery + "").split(delimiter),
            tokens = [],
            token;

        for (var i = 0, ln = exploded.length; i < ln; i++) {
            token = (exploded[i] + "");
            if (token) {
                tokens.push(caseSensitive === true ? token : token.toLowerCase());
            }
        }

        me.searchTokens = tokens;

        return tokens;
    },

    /**
     * Applies the search
     *
     * @private
     * @returns {Object[]} searchedResults
     */
    doSearch: function () {
        var me = this,
            cache = me.cache,
            tokens = me.searchTokens,
            caseSensitive = me.caseSensitiveSearch,
            fields = me.searchableFields,
            searched = me.processed.slice(),
            token,
            cachedToken,
            si,
            sln,
            joined;

        function join (record) {
            var dump = "",
                value;

            for (var i = 0, ln = fields.length; i < ln; i++) {
                value = record[fields[i]];
                if (value) {
                    dump += " " + (caseSensitive ? (value + "") : (value + "").toLowerCase());
                }
            }

            return dump;
        }

        for (var ti = 0, tln = tokens.length; ti < tln; ti++) {
            token = (tokens[ti] + "");
            for (si = 0, sln = searched.length; si < sln; si++) {
                record = searched[si];
                joined = join(record, fields);

                if (joined && joined.indexOf(token) === -1) {
                    searched.splice(si, 1);
                    si--;
                    sln = searched.length;
                }
            }
        }

        me.processed = searched;

        return me;
    },

    /**
     * Removes existing sorters and automatically refreshes with
     * the new sorters applied
     *
     * @param {Object[]} sorters
     * @returns {Collection}
     */
    setSorters: function (sorters) {
        var me = this;

        me.sorters = [];
        me.addSorters(sorters);

        return me;
    },

    /**
     * Appends the sorters[] and automatically refreshes
     *
     * @param {Object[]} sorters
     * @returns {Collection}
     */
    addSorters: function (sorters) {
        var me = this,
            i = 0,
            ln = sorters.length,
            filter;

        for (; i < ln; i++) {
            me.addSorter(sorters[i]);
        }

        if (me.autoRefresh) {
            me.refresh();
        }

        return me;
    },

    /**
     * Adds a single sorter object
     *
     * @param {Object} sorter - Sorter directive object
     */
    addSorter: function (sorter) {
        var me = this,
            sorters = me.sorters,
            iteratee, getValue;

        // Takes 2 objects, returns 1 if object 1 is greater,
        // -1 if object 2 is greater or 0 if they are equal
        iteratee = function (item1, item2) {
            var value1 = sorter.getValue(item1),
                value2 = sorter.getValue(item2),
                modifier = (sorter.direction || 'ASC').toUpperCase() === 'DESC' ? -1 : 1;

            return (value1 > value2 ? 1 : (value1 < value2 ? -1 : 0)) * modifier;
        };
        getValue = function (item) { return item[sorter.property]; };

        sorter = __extend({
            property: undefined,
            iteratee: iteratee,
            getValue: getValue
        }, sorter);

        // If functions are default, it's cacheable
        sorter.cacheable = sorter.iteratee === iteratee && sorter.getValue === getValue;

        sorters.push(sorter);

        return me;
    },

    /**
     * Applies sorts
     *
     * @private
     * @returns {Collection}
     */
    doSort: function () {
        var me = this,
            cache = me.cache,
            sorters = me.sorters,
            sorted = me.processed.slice(),
            all = me.all,
            useCache = true,
            sorter;

        if (cache.sorters && cache.sorters.length === sorters.length && sorters.length !== 0) {
            for (var i = 0, ln = sorters.length; i < ln; i++) if (useCache) {
                sorter = cache.sorters[i];
                useCache = (sorter.cacheable &&
                    sorter.property === sorters[i].property &&
                    sorter.direction === sorters[i].direction);
            }
        } else {
            useCache = false;
        }

        if (!useCache) {
            for (var i = 0, ln = sorters.length; i < ln; i++) {
                sorter = sorters[i];
                sorted.sort(sorter.iteratee);
                all.sort(sorter.iteratee);
                if (cache.filtered) {
                    cache.filtered.sort(sorter.iteratee);
                }
                if (cache.searchResults) {
                    cache.searchResults.sort(sorter.iteratee);
                }
            }
            cache.sorters = sorters;
        }

        me.processed = sorted;

        return me;
    },


    page: function (pageNumber) {
        var me = this;

        pageNumber = Math.max(pageNumber, 0);
        me.currentPageIndex = isNaN(parseInt(pageNumber, 10)) ? 1 : parseInt(pageNumber, 10) - 1;

        if (me.autoRefresh) {
            me.refresh();
        }

        return me;
    },

    /**
     * Updates the processed results with paginated range
     *
     * @param {Number} pageIndex
     */
    doPaginate: function () {
        var me = this,
            currentPageIndex = me.currentPageIndex || 0,
            pageSize = me.pageSize;

        if (isFinite(pageSize)) {
            var processed = me.processed,
                paginated = [],
                offset = currentPageIndex * pageSize,
                record;

            for (i = 0; i < pageSize; i++) {
                record = processed[i + offset];

                if (record) {
                    paginated.push(record);
                }
            }

            me.resultSet = paginated;
        } else {
            me.resultSet = me.processed;
        }

        return me;
    },


    /**
     * Add events
     *
     * @param {String} eventName
     * @param {Function} fn
     * @returns {Collection}
     */
    addListener: function (eventName, fn) {
        var me = this,
            listeners = me.__listeners__,
            handlers;

        if (typeof eventName === 'string') {
            handlers = listeners[eventName] || (listeners[eventName] = []);
            handlers.push(fn);
        }

        return me;
    },
    removeListener: function (eventName, fn) {
        var me = this,
            listeners = me.__listeners__,
            handlers = listeners[eventName],
            i;

        if (typeof eventName === 'string' && handlers) {
            i = handlers.indexOf(fn);
            if (i !== -1) {
                handlers.splice(i, 1);
            }
        }

        return me;
    },
    fireEvent: function (eventName) {
        var me = this,
            listeners = me.__listeners__,
            handlers = listeners[eventName] || [],
            i = 0,
            args = Array.prototype.slice.call(arguments),
            event = { eventType: eventName },
            ln, fn;

        args.splice(0, 1, event);

        for (ln = handlers.length; i < ln; i++) {
            fn = handlers[i];
            if (typeof fn === 'function') {
                fn.apply(me, args);
            }
        }
    },
    on: function () {
        return this.addListener.apply(this, arguments);
    },
    un: function () {
        return this.removeListener.apply(this, arguments);
    },


    /**
     *
     * @private
     */
    reset: function () {
        var me = this,
            all = me.all;

        me.total = all.length;
        me.currentPageIndex = 0;
        me.length = 0;
        me.resultSet = [];
        me.processed = [];
        me.cache = {};

        return me;
    }
};




/**
 * Helpers
 */
var __extend = function (destination) {
    var sources = arguments,
        i = 1,
        ln = sources.length,
        source,
        prop;

    for (; i < ln; i++) {
        source = sources[i];
        for (prop in source) {
            if (source.hasOwnProperty(prop)) {
                destination[prop] = source[prop];
            }
        }
    }

    return destination;
};
var __unique = function () {
    return ((1 + Math.random()) * 0x10000).toString(16).replace(/\./, '-');
};
var __watch = function (object, property, callback) {
    if (!object.__watch__) {
        Object.defineProperty(object, '__watch__', {
            enumerable: false,
            configurable: true,
            writable: false,
            value: function (property, callback) {
                var oldVal = this[property], // Original value
                    newVal = oldVal;

                if (delete this[property]) { // Can't watch constants
                    Object.defineProperty(this, property, {
                        get: function () {
                            return newVal;
                        },
                        set: function (value) {
                            oldVal = newVal;

                            newVal = value;

                            return callback.call(this, value, oldVal) || value;
                        },
                        enumerable: true,
                        configurable: true
                    });
                }
            }
        });
    }

    return object.__watch__(property, callback);
};
var __addListener = function (source, name, fn) {
    if (source.addEventListener){
        source.addEventListener(name, fn, false);
    } else if (source.attachEvent){
        source.attachEvent('on' + name, fn);
    }

    return source;
};

app.factory('Collection', function () {
    return Collection;
});

})();