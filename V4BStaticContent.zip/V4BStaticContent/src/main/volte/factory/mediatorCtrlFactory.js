app.factory('mediatorCtrlFactory', function($rootScope) {
    var updateViews = '';
    var result = '';
    return {
        update: function () {
            return updateViews;
        },
        mediate: function(val) {
            updateViews = val;
            $rootScope.$broadcast('event:updateViews');
        },
        mediateValues: function( val, broadcastEvent ) {
            result = val;
            $rootScope.$broadcast('event:' + broadcastEvent);
        },
        updateValues: function() {
            return result;
        }
    }
});